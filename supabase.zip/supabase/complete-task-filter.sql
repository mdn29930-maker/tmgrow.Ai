-- TM GROW — completed tasks must disappear from the worker marketplace
-- Re-creates list_available_tasks with two extra guards:
--   * the slot is not assigned to anyone (worker_id is null)
--   * the worker has no submission for that exact task
-- Campaign-level "already_done" is still returned so the UI can mark it, but
-- the submitted task itself never appears again.

create or replace function public.list_available_tasks(
  p_platform text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0,
  p_min_reward numeric default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  total int;
  items jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  perform public.expire_stale_tasks();

  select count(*) into total
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
    join public.services s on s.id = c.service_id
   where t.status = 'available'
     and t.worker_id is null
     and c.status = 'active'
     and t.reward >= coalesce(p_min_reward, 0)
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
     and (c.countries = '{}' or p.country_code = any (c.countries))
     and c.min_trust_score <= p.trust_score
     and not exists (
       select 1 from public.submissions sub
        where sub.worker_id = u and sub.task_id = t.id
     );

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id,
      'reward', t.reward,
      'created_at', t.created_at,
      'campaign_id', c.id,
      'title', c.title,
      'instructions_preview', left(c.instructions, 140),
      'platform', s.platform,
      'service_name', s.name,
      'quantity_left', (select count(*) from public.tasks t2 where t2.campaign_id = c.id and t2.status = 'available'),
      'target_url', c.target_url,
      'requires_account', c.require_linked_account,
      'account_linked', exists (
        select 1 from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
      ),
      'account_cooldown_until', (
        select a.linked_at + interval '7 days' from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
           and s.platform = 'x' and a.linked_at > now() - interval '7 days'
         limit 1
      ),
      'already_done', exists (
        select 1 from public.tasks t3
         where t3.campaign_id = c.id and t3.worker_id = u
           and t3.status in ('claimed','submitted','approved','rejected')
      )
    ) as x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
     where t.status = 'available'
       and t.worker_id is null
       and c.status = 'active'
       and t.reward >= coalesce(p_min_reward, 0)
       and (p_platform is null or p_platform = '' or s.platform = p_platform)
       and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
       and (c.countries = '{}' or p.country_code = any (c.countries))
       and c.min_trust_score <= p.trust_score
       and not exists (
         select 1 from public.submissions sub
          where sub.worker_id = u and sub.task_id = t.id
       )
     order by t.reward desc, t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 20), 50))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

revoke all on function public.list_available_tasks(text, text, int, int, numeric) from public, anon;
grant execute on function public.list_available_tasks(text, text, int, int, numeric) to authenticated;

notify pgrst, 'reload schema';
