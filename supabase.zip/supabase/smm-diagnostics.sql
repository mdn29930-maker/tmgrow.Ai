-- ============================================================================
-- TM GROW — SMM DRIP DIAGNOSTIC REPORT (read-only)
--
-- Paste this whole file into the Supabase SQL editor and run it. Every
-- statement is a SELECT; nothing is inserted, updated or deleted.
-- Each result set answers one of the eight questions in the report.
-- ============================================================================

-- 1. Is pg_cron installed, and does the drip job exist? -----------------------
select
  to_regclass('cron.job') is not null as pg_cron_installed,
  j.jobid, j.jobname, j.schedule, j.active as job_active,
  j.command, j.username
from (select 1) x
left join cron.job j on j.jobname = 'tmgrow-smm-drip';

-- 2. When did the scheduler last run, and what did it return? ----------------
--    (Written by smm_drip_scheduled() and smm_drip_release() after the fix.)
select a.created_at, a.action, a.details
  from public.audit_logs a
 where a.action like 'smm_drip.%'
 order by a.created_at desc
 limit 20;

-- 3. Are any SMM orders eligible for release right now? ---------------------
select
  count(*) filter (where o.status in ('pending','processing')) as open_orders,
  count(*) filter (where o.drip_paused) as paused_orders,
  count(*) filter (where o.drip_enabled and not o.drip_paused
                     and o.status in ('pending','processing')
                     and o.completed_quantity < o.quantity
                     and o.next_release_at <= now()) as eligible_now,
  count(*) filter (where o.drip_enabled and not o.drip_paused
                     and o.status in ('pending','processing')
                     and coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot) is null) as blocked_no_reward,
  count(*) filter (where o.drip_enabled and not o.drip_paused
                     and o.status in ('pending','processing')
                     and coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot) is not null) as ready
from public.smm_orders o
join public.services s on s.id = o.service_id;

-- 4. Do released units actually exist in tasks? ----------------------------
select t.status, count(*) as units,
       min(t.created_at) as oldest, max(t.created_at) as newest
  from public.tasks t
 where t.smm_order_id is not null
 group by t.status
 order by t.status;

-- 5. Per order: issued / completed / open / next release --------------------
select upper(substr(replace(o.id::text,'-',''),1,8)) as order_short,
       s.name as service, s.platform,
       o.status, o.drip_enabled, o.drip_paused,
       o.quantity, o.issued_quantity, o.completed_quantity, o.rejected_quantity,
       (select count(*) from public.tasks t where t.smm_order_id = o.id and t.status = 'available') as open_units,
       coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot) as worker_reward_per_1000,
       o.next_release_at, o.last_release_at,
       left(coalesce(o.admin_note,''), 120) as admin_note
  from public.smm_orders o
  join public.services s on s.id = o.service_id
 order by o.created_at desc
 limit 30;

-- 6. Would the worker feed return anything? (pool view, no RPC needed) ------
select upper(substr(replace(o.id::text,'-',''),1,8)) as order_short,
       s.name as service, s.platform,
       t.seq, t.reward, t.created_at,
       o.status as order_status, o.drip_paused
  from public.tasks t
  join public.smm_orders o on o.id = t.smm_order_id
  join public.services s on s.id = o.service_id
 where t.status = 'available' and t.worker_id is null
   and o.status in ('pending','processing') and not o.drip_paused
 order by t.created_at
 limit 20;

-- 7. Were any release notifications created? ------------------------------
select 'in_app' as channel, count(*) as rows, max(created_at) as latest
  from public.notifications where kind = 'smm_release'
union all
select 'telegram', count(*), max(created_at)
  from public.telegram_outbox where kind = 'smm_batch';

-- 8. Workers who could receive an alert ------------------------------------
select count(*) as active_workers,
       count(*) filter (where p.telegram_id is not null) as with_telegram
  from public.profiles p
 where p.is_worker and p.status = 'active';

-- Optional, NOT read-only — uncomment only when you mean it.
-- This releases a real batch for every eligible order and sends alerts.
-- Prefer: Admin → SMM panel → SMM orders & drip → Release batch now.
-- select public.smm_drip_release(null);
