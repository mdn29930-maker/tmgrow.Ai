-- ============================================================================
-- TM GROW — PRE-FLIGHT / MIGRATION STATUS (read-only)
-- Run this FIRST. It changes nothing and tells you which migrations are already
-- applied, so no migration is re-run blindly.
-- ============================================================================

-- 1. Which migration is applied? -------------------------------------------
select
  ('telegram-completion-fix' ) as migration,
  (to_regclass('public.telegram_outbox') is not null
   and exists (select 1 from information_schema.columns
                where table_schema='public' and table_name='telegram_outbox'
                  and column_name='next_attempt_at')) as applied
union all
select 'notifications-announcements',
  (to_regclass('public.announcements') is not null
   and exists (select 1 from pg_trigger
                where tgname='tasks_new_task_notify'))
union all
select 'auto-verification',
  (exists (select 1 from information_schema.columns
            where table_schema='public' and table_name='verification_queue'
              and column_name='api_state')
   and to_regprocedure('public.auto_verify_tick(int)') is not null)
union all
select 'ai-screenshot-verification',
  (to_regclass('public.proof_ai_jobs') is not null)
union all
select 'smm-drip-fix',
  (to_regclass('public.smm_release_events') is not null);

-- 2. Telegram trigger layout -----------------------------------------------
select
  exists (select 1 from pg_trigger
           where tgname='tg_notify_task_submitted'
             and tgrelid='public.submissions'::regclass) as submit_trigger_present,
  exists (select 1 from pg_trigger
           where tgname='submissions_task_completed_tg'
             and tgrelid='public.submissions'::regclass) as completion_trigger_present,
  exists (select 1 from pg_trigger
           where tgname='submissions_task_completed_tg'
             and tgrelid='public.submissions'::regclass and tgdeferrable) as completion_deferred;

-- 3. Event switches --------------------------------------------------------
select key, value from public.settings
 where key in ('telegram_bot_enabled','telegram_notify_checkin',
               'telegram_notify_task_completed','telegram_notify_task_available',
               'telegram_notify_task_submitted','telegram_notify_announcement',
               'telegram_http_timeout_ms','telegram_api_base',
               'auto_verify_enabled','ai_screenshot_enabled',
               'automation_enabled','auto_rewards')
 order by key;

-- 3b. Automation modules ---------------------------------------------------
select key, enabled from public.automation_modules
 where key in ('task_verification','auto_rewards','ai_verification')
 order by key;

-- 4. Cron jobs (duplicate detection) --------------------------------------
select jobid, jobname, schedule, active, command
  from cron.job
 where jobname like 'tmgrow-%'
 order by jobname;

-- 5. Outbox state + last error --------------------------------------------
select status, count(*) as rows, max(attempts) as max_attempts
  from public.telegram_outbox group by status order by status;

select created_at, kind, status, attempts, http_status, error_class,
       left(coalesce(last_error,''), 140) as last_error, next_attempt_at
  from public.telegram_outbox
 order by created_at desc limit 15;

-- 6. Verification queue state ---------------------------------------------
select status, count(*) as rows from public.verification_queue group by status order by status;

select exists (select 1 from information_schema.columns
                where table_schema='public' and table_name='verification_queue'
                  and column_name='api_state') as api_columns_present;

-- 7. Repair data left by an unapplied migration ----------------------------
--    (only relevant after the migrations; running before them is harmless)
select exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                where n.nspname='public' and p.proname='telegram_send_pending') as sender_present,
       exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                where n.nspname='public' and p.proname='telegram_bot_token') as token_reader_present;



-- ============================================================================
-- MACHINE-READABLE STATUS (used by Admin → Configuration → Migration status)
-- Read-only. Safe to run before or after any migration.
-- ============================================================================
create or replace function public.admin_preflight_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_migrations jsonb;
  v_settings jsonb := '{}'::jsonb;
  v_modules jsonb := '[]'::jsonb;
  v_cron jsonb := '[]'::jsonb;
  v_outbox_counts jsonb := '[]'::jsonb;
  v_outbox_recent jsonb := '[]'::jsonb;
  v_queue jsonb := '[]'::jsonb;
  v_ai jsonb := null;
  v_ann jsonb := null;
  v_secrets jsonb := '{}'::jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  v_migrations := jsonb_build_array(
    jsonb_build_object('name', 'telegram-db-sender', 'label', 'Database Telegram sender',
      'applied', to_regprocedure('public.telegram_send_pending(int)') is not null),
    jsonb_build_object('name', 'telegram-completion-fix', 'label', 'Task completion + retry',
      'applied', exists (select 1 from information_schema.columns
                          where table_schema='public' and table_name='telegram_outbox'
                            and column_name='next_attempt_at')),
    jsonb_build_object('name', 'notifications-announcements', 'label', 'Check-in / new task / announcements',
      'applied', to_regclass('public.announcements') is not null
                 and exists (select 1 from pg_trigger where tgname='tasks_new_task_notify')),
    jsonb_build_object('name', 'auto-verification', 'label', 'Comment auto verification',
      'applied', exists (select 1 from information_schema.columns
                          where table_schema='public' and table_name='verification_queue'
                            and column_name='api_state')
                 and to_regprocedure('public.auto_verify_tick(int)') is not null),
    jsonb_build_object('name', 'ai-screenshot-verification', 'label', 'AI screenshot verification',
      'applied', to_regclass('public.proof_ai_jobs') is not null
                 and to_regprocedure('public.ai_screenshot_tick(int)') is not null),
    jsonb_build_object('name', 'smm-drip-fix', 'label', 'SMM drip release + alerts',
      'applied', to_regclass('public.smm_release_events') is not null),
    jsonb_build_object('name', 'smm-drip', 'label', 'SMM drip tasks + worker feed',
      'applied', to_regprocedure('public.smm_worker_feed(int)') is not null)
  );

  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) into v_settings
    from public.settings
   where key in ('telegram_bot_enabled','telegram_notify_checkin',
                 'telegram_notify_task_completed','telegram_notify_task_available',
                 'telegram_notify_task_submitted','telegram_notify_announcement',
                 'telegram_http_timeout_ms','telegram_api_base',
                 'auto_verify_enabled','ai_screenshot_enabled',
                 'automation_enabled','auto_rewards',
                 'smm_release_notifications','smm_drip_enabled');

  if to_regclass('public.automation_modules') is not null then
    select coalesce(jsonb_agg(jsonb_build_object('key', key, 'enabled', enabled) order by key), '[]'::jsonb)
      into v_modules
      from public.automation_modules
     where key in ('task_verification','auto_rewards','ai_verification');
  end if;

  if to_regclass('cron.job') is not null then
    begin
      execute 'select coalesce(jsonb_agg(jsonb_build_object(''jobname'', jobname, ''schedule'', schedule, ''active'', active) order by jobname), ''[]''::jsonb)
                 from cron.job where jobname like ''tmgrow-%'''
        into v_cron;
    exception when others then
      v_cron := '[]'::jsonb;
    end;
  end if;

  if to_regclass('public.telegram_outbox') is not null then
    select coalesce(jsonb_agg(jsonb_build_object('status', status, 'rows', n) order by status), '[]'::jsonb)
      into v_outbox_counts
      from (select status, count(*)::int as n from public.telegram_outbox group by status) q;

    select coalesce(jsonb_agg(jsonb_build_object(
             'kind', o.kind, 'status', o.status, 'attempts', o.attempts,
             'http_status', o.http_status, 'error_class', o.error_class,
             'last_error', left(coalesce(o.last_error, ''), 140),
             'next_attempt_at', o.next_attempt_at, 'created_at', o.created_at)
             order by o.created_at desc), '[]'::jsonb)
      into v_outbox_recent
      from (select * from public.telegram_outbox order by created_at desc limit 12) o;
  end if;

  if to_regclass('public.verification_queue') is not null then
    select coalesce(jsonb_agg(jsonb_build_object('status', status, 'rows', n) order by status), '[]'::jsonb)
      into v_queue
      from (select status, count(*)::int as n from public.verification_queue group by status) q;
  end if;

  if to_regclass('public.proof_ai_jobs') is not null then
    select jsonb_build_object(
             'counters', (select coalesce(jsonb_object_agg(state, n), '{}'::jsonb)
                            from (select state, count(*)::int as n from public.proof_ai_jobs group by state) s),
             'last', (select jsonb_build_object('state', state, 'verdict', verdict,
                                                 'confidence', confidence, 'reason', reason,
                                                 'last_error', last_error, 'updated_at', updated_at)
                        from public.proof_ai_jobs order by updated_at desc limit 1))
      into v_ai;
  end if;

  if to_regclass('public.announcements') is not null then
    select jsonb_build_object(
             'counters', (select coalesce(jsonb_object_agg(status, n), '{}'::jsonb)
                            from (select status, count(*)::int as n from public.announcements group by status) s),
             'last_sent_at', (select max(sent_at) from public.announcements where status = 'sent'),
             'retrying', (select count(*) from public.telegram_outbox where kind = 'announcement' and status = 'retrying'))
      into v_ann;
  end if;

  if to_regclass('vault.secrets') is not null then
    begin
      execute 'select jsonb_build_object(
                 ''telegram_bot_token'', exists(select 1 from vault.secrets where name = ''telegram_bot_token''),
                 ''socify_api_key'', exists(select 1 from vault.secrets where name = ''socify_api_key''),
                 ''ai_verify_key'', exists(select 1 from vault.secrets where name = ''ai_verify_key''),
                 ''storage_service_key'', exists(select 1 from vault.secrets where name = ''storage_service_key''))'
        into v_secrets;
    exception when others then
      v_secrets := '{}'::jsonb;
    end;
  end if;

  return jsonb_build_object(
    'server_time', now(),
    'migrations', v_migrations,
    'triggers', jsonb_build_object(
      'submit_trigger_present', exists (select 1 from pg_trigger
                                         where tgname='tg_notify_task_submitted'
                                           and tgrelid='public.submissions'::regclass),
      'completion_trigger_present', exists (select 1 from pg_trigger
                                             where tgname='submissions_task_completed_tg'
                                               and tgrelid='public.submissions'::regclass),
      'completion_deferred', exists (select 1 from pg_trigger
                                      where tgname='submissions_task_completed_tg'
                                        and tgrelid='public.submissions'::regclass
                                        and tgdeferrable)
    ),
    'settings', v_settings,
    'modules', v_modules,
    'cron', v_cron,
    'outbox_counts', v_outbox_counts,
    'outbox_recent', v_outbox_recent,
    'verification', v_queue,
    'ai_screenshot', v_ai,
    'announcements', v_ann,
    'secrets', v_secrets
  );
end $$;

revoke all on function public.admin_preflight_status() from public, anon;
grant execute on function public.admin_preflight_status() to authenticated;

notify pgrst, 'reload schema';
