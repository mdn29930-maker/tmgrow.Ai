-- ============================================================================
-- TM GROW — SOCIFY FAILURE DIAGNOSIS + FIX
--
-- Use this when "the key is configured but no request appears".
--
-- It adds, without touching any existing data:
--   * socify_http_ready()      — is pg_net's GET callable (and with which signature)
--   * admin_socify_diag()      — one JSON with every fact needed to find the
--                                failing step (key, pg_net, endpoints, queue,
--                                pg_net responses, last errors)
--   * admin_socify_test()      — dispatches the official natgeo request as the
--                                calling admin and returns the request id
--   * admin_socify_test_result() — polls that request and returns the real
--                                HTTP code, credits, and body snippet
--   * social_profile_check()   — re-created so the reason a request could not be
--                                queued is returned to the worker UI, not hidden
--
-- The API key is read from Vault only inside SECURITY DEFINER functions. It is
-- never returned by any of these functions.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1. pg_net detection (some projects have the 4-arg signature only)
-- ---------------------------------------------------------------------------
create or replace function public.socify_http_ready()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null
      or to_regprocedure('net.http_get(text, jsonb, jsonb)') is not null;
$$;

revoke all on function public.socify_http_ready() from public, anon, authenticated;


-- ---------------------------------------------------------------------------
-- 2. Diagnostic snapshot
-- ---------------------------------------------------------------------------
create or replace function public.admin_socify_diag()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key boolean := public.socify_api_key() is not null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'key_in_vault', v_key,
    'pg_net_installed', exists (select 1 from pg_extension where extname = 'pg_net'),
    'http_get_4arg', to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null,
    'http_get_3arg', to_regprocedure('net.http_get(text, jsonb, jsonb)') is not null,
    'response_table', to_regclass('net._http_response') is not null,
    'request_queue_table', to_regclass('net.http_request_queue') is not null,
    'socify_enabled', public.setting_bool('socify_enabled', true),
    'worker_access', public.setting_bool('socify_worker_access', true),
    'endpoint_count', (select count(*) from public.socify_endpoints),
    'instagram_profile_endpoint', exists (
      select 1 from public.socify_endpoints
       where platform = 'instagram' and resource = 'profile/info' and enabled
    ),
    'request_counts', (
      select coalesce(jsonb_agg(jsonb_build_object('status', status, 'n', n) order by status), '[]'::jsonb)
        from (select status, count(*) n from public.socify_requests group by status) q
    ),
    'last_requests', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', r.id, 'platform', r.platform, 'resource', r.resource,
               'status', r.status, 'http_status', r.http_status,
               'net_request_id', r.net_request_id,
               'credits', r.credits, 'error_code', r.error_code,
               'error_message', r.error_message,
               'created_at', r.created_at
             ) order by r.created_at desc), '[]'::jsonb)
        from (select * from public.socify_requests order by created_at desc limit 10) r
    ),
    'pg_net_responses', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', r.id, 'status_code', r.status_code,
               'timed_out', r.timed_out, 'error_msg', r.error_msg,
               'created', r.created, 'body', left(coalesce(r.content, ''), 300)
             ) order by r.created desc), '[]'::jsonb)
        from (select * from net._http_response order by created desc limit 5) r
    ),
    'pg_net_queue', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', q.id, 'method', q.method,
               'url_host', split_part(split_part(q.url, '/', 3), '/', 1)
             )), '[]'::jsonb)
        from (select * from net.http_request_queue limit 5) q
    )
  );
exception when others then
  return jsonb_build_object('error', sqlerrm, 'key_in_vault', v_key,
    'pg_net_installed', exists (select 1 from pg_extension where extname = 'pg_net'));
end $$;

revoke all on function public.admin_socify_diag() from public, anon;
grant execute on function public.admin_socify_diag() to authenticated;


-- ---------------------------------------------------------------------------
-- 3. Real end-to-end test (official Instagram example)
-- ---------------------------------------------------------------------------
create or replace function public.admin_socify_test(p_user text default 'natgeo')
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_res jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if not public.socify_http_ready() then
    return jsonb_build_object('ok', false, 'code', 'PG_NET_MISSING',
      'message', 'pg_net is not enabled (or net.http_get is missing). Enable pg_net in Database → Extensions, then retry.');
  end if;

  -- Goes through the same server-side path as a worker request.
  v_res := public.socify_lookup(
    'instagram', 'profile/info',
    jsonb_build_object('user', coalesce(nullif(btrim(p_user), ''), 'natgeo'))
  );

  return v_res;
end $$;

revoke all on function public.admin_socify_test(text) from public, anon;
grant execute on function public.admin_socify_test(text) to authenticated;


create or replace function public.admin_socify_test_result(p_request_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  return public.socify_result_internal(p_request_id);
end $$;

revoke all on function public.admin_socify_test_result(uuid) from public, anon;
grant execute on function public.admin_socify_test_result(uuid) to authenticated;


-- ---------------------------------------------------------------------------
-- 4. social_profile_check: never hide why a request could not be queued
--    (same behaviour as before, with the pg_net check first and clearer codes)
-- ---------------------------------------------------------------------------
create or replace function public.social_profile_check(p_account_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  a public.social_accounts;
  v_params jsonb;
  v_res jsonb;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into a from public.social_accounts where id = p_account_id and user_id = u;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;

  if a.platform not in ('instagram','tiktok','youtube') then
    return jsonb_build_object('ok', false, 'code', 'UNSUPPORTED_PLATFORM',
      'message', 'Public profile checks are available for Instagram, TikTok and YouTube.');
  end if;

  if not public.socify_http_ready() then
    update public.social_accounts
       set public_status = 'API_ERROR',
           profile_error = 'pg_net is not enabled on this project.',
           updated_at = now()
     where id = a.id;
    return jsonb_build_object('ok', false, 'code', 'PG_NET_MISSING',
      'message', 'pg_net is not enabled. An administrator must enable it in Database → Extensions.');
  end if;

  v_params := case a.platform
    when 'tiktok' then jsonb_build_object('username', a.handle)
    when 'youtube' then jsonb_build_object('username', a.handle)
    else jsonb_build_object('user', a.handle)
  end;

  v_res := public.socify_lookup(a.platform, 'profile/info', v_params);

  if not coalesce((v_res ->> 'ok')::boolean, false) then
    update public.social_accounts
       set public_status = 'API_ERROR',
           profile_error = coalesce(v_res ->> 'message', 'The lookup could not start.'),
           updated_at = now()
     where id = a.id;
    return v_res;
  end if;

  update public.social_accounts
     set public_status = 'CHECKING',
         profile_socify_request_id = (v_res ->> 'request_id')::uuid,
         profile_error = null,
         updated_at = now()
   where id = a.id;

  perform public.audit('social.public_check', 'social_account', a.id,
    jsonb_build_object('platform', a.platform, 'request', v_res ->> 'request_id'));

  return jsonb_build_object(
    'ok', true,
    'request_id', v_res ->> 'request_id',
    'cached', coalesce((v_res ->> 'cached')::boolean, false),
    'status', coalesce(v_res ->> 'status', 'pending'),
    'data', v_res -> 'data'
  );
end $$;

revoke all on function public.social_profile_check(uuid) from public, anon;
grant execute on function public.social_profile_check(uuid) to authenticated;


notify pgrst, 'reload schema';

commit;
