-- ============================================================================
-- TM GROW — secure OWNER bootstrap and admin diagnostics
--
-- Run this file once in Supabase → SQL Editor. It is safe to re-run.
--
-- What it proves and fixes:
--   * The OWNER is configured SERVER-SIDE in settings.owner_email, seeded with
--     mdn29930@gmail.com. The browser cannot change it.
--   * public.claim_owner() grants OWNER only when the verified JWT email of the
--     caller equals that configured email. It never trusts a parameter, a
--     query string or profile data sent by the browser.
--   * It repairs a missing profile row or wallet without ever creating a
--     duplicate: ensure_profile() is insert-if-missing, wallet is on conflict
--     do nothing.
--   * Roles live on profiles.admin_role (there is no admin_members table in
--     this schema). The RPCs below report that clearly so nobody looks for a
--     table that does not exist.
-- ============================================================================

-- Server-side owner identity. Private setting: readable by service role and
-- SECURITY DEFINER functions, never returned to visitors.
insert into public.settings (key, value, is_public) values
  ('owner_email', '"mdn29930@gmail.com"'::jsonb, false)
on conflict (key) do nothing;

-- ---------------------------------------------------------------------------
-- claim_owner(): the only way an account can grant itself OWNER from the app.
-- Requires: signed in, verified email, and that email == settings.owner_email.
-- ---------------------------------------------------------------------------
create or replace function public.claim_owner()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_configured text := lower(coalesce(public.setting_text('owner_email', ''), ''));
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  if v_configured = '' then
    return jsonb_build_object('ok', false, 'reason', 'OWNER_EMAIL_NOT_CONFIGURED');
  end if;

  if v_email = '' or v_email <> v_configured then
    return jsonb_build_object('ok', false, 'reason', 'NOT_THE_OWNER_ACCOUNT');
  end if;

  -- The JWT email must belong to a confirmed auth user; a token alone is not
  -- enough proof of owning the address.
  if not exists (
    select 1 from auth.users u
     where u.id = v_uid
       and lower(u.email) = v_email
       and u.email_confirmed_at is not null
  ) then
    return jsonb_build_object('ok', false, 'reason', 'EMAIL_NOT_VERIFIED');
  end if;

  -- Repair missing rows without duplicating anything.
  perform public.ensure_profile();

  update public.profiles
     set admin_role = 'OWNER',
         status = 'active',
         is_suspended = false,
         updated_at = now()
   where id = v_uid;

  insert into public.wallets (user_id) values (v_uid)
  on conflict (user_id) do nothing;

  perform public.audit('owner.claim', 'profile', v_uid,
    jsonb_build_object('email', v_email));

  return jsonb_build_object('ok', true, 'email', v_email, 'role', 'OWNER');
end $$;

-- ---------------------------------------------------------------------------
-- admin_wallet_overview(): balances for the Wallet Management page.
-- ---------------------------------------------------------------------------
create or replace function public.admin_wallet_overview(p_limit int default 25)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'totals', (
      select jsonb_build_object(
        'available', coalesce(sum(available), 0),
        'pending', coalesce(sum(pending), 0),
        'reserved', coalesce(sum(reserved), 0),
        'tg', coalesce(sum(tg_balance), 0),
        'lifetime_earned', coalesce(sum(lifetime_earned), 0),
        'lifetime_withdrawn', coalesce(sum(lifetime_withdrawn), 0),
        'lifetime_deposited', coalesce(sum(lifetime_deposited), 0),
        'wallets', count(*)
      ) from public.wallets
    ),
    'top', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'user_id', w.user_id,
          'name', coalesce(nullif(p.full_name, ''), p.email),
          'email', p.email,
          'status', p.status,
          'is_buyer', p.is_buyer,
          'available', w.available,
          'pending', w.pending,
          'reserved', w.reserved,
          'tg_balance', w.tg_balance,
          'lifetime_earned', w.lifetime_earned
        ) x
          from public.wallets w
          join public.profiles p on p.id = w.user_id
         order by w.available desc
         limit greatest(1, least(coalesce(p_limit, 25), 100))
      ) q
    ),
    'recent', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', l.id, 'kind', l.kind,
          'available_delta', l.available_delta,
          'pending_delta', l.pending_delta,
          'reserved_delta', l.reserved_delta,
          'available_after', l.available_after,
          'note', l.note, 'created_at', l.created_at,
          'user_name', coalesce(nullif(p.full_name, ''), p.email)
        ) x
          from public.ledger_entries l
          left join public.profiles p on p.id = l.user_id
         order by l.created_at desc
         limit 20
      ) q
    )
  );
end $$;

-- ---------------------------------------------------------------------------
-- admin_system_status(): what the app is really connected to.
-- ---------------------------------------------------------------------------
create or replace function public.admin_system_status()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_owner text := lower(coalesce(public.setting_text('owner_email', ''), ''));
begin
  if not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'generated_at', now(),
    'database_size', pg_size_pretty(pg_database_size(current_database())),
    'postgres_version', current_setting('server_version'),
    'me', jsonb_build_object(
      'id', auth.uid(),
      'email', v_email,
      'role', public.admin_role(),
      'is_configured_owner', (v_email <> '' and v_email = v_owner)
    ),
    'owner', jsonb_build_object(
      'configured_email', public.setting_text('owner_email', ''),
      'owners', (select count(*) from public.profiles where admin_role = 'OWNER'),
      'matches_me', (v_email <> '' and v_email = v_owner)
    ),
    'counts', jsonb_build_object(
      'profiles', (select count(*) from public.profiles),
      'wallets', (select count(*) from public.wallets),
      'admins', (select count(*) from public.profiles where admin_role is not null),
      'tasks', (select count(*) from public.tasks),
      'submissions', (select count(*) from public.submissions),
      'proofs_pending', (select count(*) from public.submissions where status = 'pending'),
      'deposits_pending', (select count(*) from public.deposits where status = 'pending'),
      'withdrawals_open', (select count(*) from public.withdrawals where status in ('pending','approved','processing')),
      'settings', (select count(*) from public.settings),
      'notifications', (select count(*) from public.telegram_outbox)
    ),
    'schema', jsonb_build_object(
      'profiles', to_regclass('public.profiles') is not null,
      'wallets', to_regclass('public.wallets') is not null,
      'tasks', to_regclass('public.tasks') is not null,
      'telegram_users', to_regclass('public.telegram_users') is not null,
      'telegram_outbox', to_regclass('public.telegram_outbox') is not null,
      'social_accounts', to_regclass('public.social_accounts') is not null,
      'admin_members', to_regclass('public.admin_members') is not null
    ),
    'last_audit', (
      select jsonb_build_object('action', a.action, 'role', a.actor_role,
                                'at', a.created_at,
                                'actor', coalesce(nullif(p.full_name, ''), p.email))
        from public.audit_logs a
        left join public.profiles p on p.id = a.actor_id
       order by a.created_at desc limit 1
    )
  );
end $$;

-- RPC surface
revoke all on function public.claim_owner() from public, anon;
grant execute on function public.claim_owner() to authenticated;

revoke all on function public.admin_wallet_overview(int) from public, anon;
grant execute on function public.admin_wallet_overview(int) to authenticated;

revoke all on function public.admin_system_status() from public, anon;
grant execute on function public.admin_system_status() to authenticated;

-- ---------------------------------------------------------------------------
-- Verify: who is owner, and is the owner email configured?
-- ---------------------------------------------------------------------------
select key, value, is_public
  from public.settings
 where key = 'owner_email';

select email, admin_role, status
  from public.profiles
 where admin_role = 'OWNER';
