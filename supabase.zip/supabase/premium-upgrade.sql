-- ============================================================================
-- TM GROW — premium upgrade
-- Trust score from 549, ban/suspension enforcement, duplicate-submission guard
-- and the trust reward on approved work. Safe to run more than once.
--
--   Supabase → SQL Editor → New query → paste → Run
-- ============================================================================

begin;

-- ----------------------------------------------------------------------------
-- 1. Trust score: 549 by default, 0..1000 scale
-- ----------------------------------------------------------------------------
alter table public.profiles alter column trust_score set default 549;

-- Older installs started everyone at 100 (a 0-100 scale). Move only the
-- untouched default to the new base; real scores are left alone.
update public.profiles set trust_score = 549 where trust_score = 100;

alter table public.profiles drop constraint if exists profiles_trust_chk;
alter table public.profiles
  add constraint profiles_trust_chk check (trust_score between 0 and 1000);

comment on column public.profiles.trust_score is
  'Worker trust, 0-1000. New accounts start at 549. Approved tasks add +1, rewards >= 0.5 USDT add +2.';

-- Approved work nudges the score up. Rejections are handled by
-- review_submission, which lowers it.
create or replace function public.award_trust_on_approval()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.worker_id is null then return new; end if;
  if new.status = 'approved' and coalesce(old.status, '') <> 'approved' then
    update public.profiles
       set trust_score = least(1000, greatest(0,
             trust_score + case when coalesce(new.reward, 0) >= 0.5 then 2 else 1 end)),
           updated_at = now()
     where id = new.worker_id;
  end if;
  return new;
end $$;

drop trigger if exists tasks_trust_award on public.tasks;
create trigger tasks_trust_award
  after update of status on public.tasks
  for each row execute function public.award_trust_on_approval();

-- ----------------------------------------------------------------------------
-- 2. Account status: active / suspended / banned
-- ----------------------------------------------------------------------------
update public.profiles set status = 'suspended'
 where is_suspended is true and status = 'active';

update public.profiles set status = 'active'
 where status is null or status not in ('active', 'suspended', 'banned');

alter table public.profiles drop constraint if exists profiles_status_chk;
alter table public.profiles add constraint profiles_status_chk
  check (status in ('active', 'suspended', 'banned'));

-- A single helper used by RLS. SECURITY DEFINER so a policy on profiles does
-- not re-enter itself (RLS recursion), and safe for a signed-out visitor.
create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(
    (select p.status = 'active' and coalesce(p.is_suspended, false) = false
       from public.profiles p where p.id = auth.uid()),
    false);
$$;

revoke all on function public.is_active_user() from public, anon;
grant execute on function public.is_active_user() to authenticated;

-- RLS: a suspended or banned account reads nothing through the API.
do $$
begin
  if not exists (
    select 1 from pg_policies
     where schemaname = 'public' and tablename = 'profiles'
       and policyname = 'profiles_active_only'
  ) then
    create policy profiles_active_only on public.profiles
      as restrictive for select to authenticated
      using (public.is_active_user());
  end if;

  if not exists (
    select 1 from pg_policies
     where schemaname = 'public' and tablename = 'wallets'
       and policyname = 'wallets_active_only'
  ) then
    create policy wallets_active_only on public.wallets
      as restrictive for select to authenticated
      using (public.is_active_user());
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- 3. One submission per task, and per worker + task
-- ----------------------------------------------------------------------------
create unique index if not exists submissions_task_once
  on public.submissions (task_id);

create unique index if not exists submissions_worker_task_once
  on public.submissions (worker_id, task_id);

-- ----------------------------------------------------------------------------
-- 4. Ask PostgREST to reload its schema cache
-- ----------------------------------------------------------------------------
notify pgrst, 'reload schema';

commit;
