-- TM GROW — Advanced admin control upgrade (safe migration, re-runnable)
--
-- Run once in Supabase → SQL Editor, after supabase/schema.sql.
--
-- Adds, without deleting anything:
--   * wallet freeze (freeze outflows, keep balances and history)
--   * suspension reason keys + evidence screenshots
--   * internal admin notes per user
--   * login history (user agent / platform) recorded by the app
--   * a richer admin_user_detail (tasks, proofs, notes, logins, suspension)
--   * admin-triggered fraud scan + risk overview (flag, never auto-ban)
--   * server-side enforcement of freeze / suspension inside wallet_move
--
-- Nothing here drops a table, deletes a user, touches a wallet balance or
-- approves anything automatically.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Columns
--    The suspension kind/reason/date columns are created by the suspension
--    section of schema.sql. They are repeated here so this migration is
--    self-contained on a database that never ran that part — the functions it
--    installs read them, and "record p has no field suspension_kind" comes from
--    exactly that gap.
-- ---------------------------------------------------------------------------
alter table public.profiles add column if not exists suspension_kind text;
alter table public.profiles add column if not exists suspension_reason text;
alter table public.profiles add column if not exists suspension_note text;
alter table public.profiles add column if not exists suspended_at timestamptz;
alter table public.profiles add column if not exists suspension_expires_at timestamptz;
alter table public.profiles add column if not exists suspension_appeal_allowed boolean not null default true;
alter table public.profiles add column if not exists suspended_by uuid references public.profiles (id) on delete set null;
alter table public.profiles add column if not exists withdrawals_blocked boolean not null default false;

alter table public.profiles add column if not exists suspension_reason_key text;
alter table public.profiles add column if not exists suspension_evidence jsonb not null default '[]'::jsonb;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_suspension_kind_chk') then
    alter table public.profiles add constraint profiles_suspension_kind_chk
      check (suspension_kind is null
             or suspension_kind in ('temporary','permanent','under_review','restricted'));
  end if;
end $$;

alter table public.wallets add column if not exists frozen boolean not null default false;
alter table public.wallets add column if not exists frozen_reason text;
alter table public.wallets add column if not exists frozen_at timestamptz;

-- ---------------------------------------------------------------------------
-- 2. Internal admin notes
-- ---------------------------------------------------------------------------
create table if not exists public.admin_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  note text not null,
  kind text not null default 'note',
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists admin_notes_user_idx on public.admin_notes (user_id, created_at desc);
alter table public.admin_notes enable row level security;
grant all on public.admin_notes to service_role;

-- ---------------------------------------------------------------------------
-- 3. Login history (what the app can actually observe: user agent + platform)
-- ---------------------------------------------------------------------------
create table if not exists public.login_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  user_agent text,
  platform text,
  created_at timestamptz not null default now()
);
create index if not exists login_events_user_idx on public.login_events (user_id, created_at desc);
alter table public.login_events enable row level security;
grant all on public.login_events to service_role;

create or replace function public.record_login_event(
  p_user_agent text default null, p_platform text default 'web'
) returns void language plpgsql security definer set search_path = public as $$
declare v uuid := auth.uid();
begin
  if v is null then return; end if;
  if not exists (select 1 from public.profiles where id = v) then return; end if;

  insert into public.login_events (user_id, user_agent, platform)
  values (v,
          left(coalesce(nullif(trim(p_user_agent), ''), 'unknown'), 300),
          left(coalesce(nullif(trim(p_platform), ''), 'web'), 40));

  -- keep the last 40 per user; this table is diagnostic, not financial
  delete from public.login_events
   where user_id = v
     and id not in (
       select id from public.login_events where user_id = v order by created_at desc limit 40
     );
end $$;

-- ---------------------------------------------------------------------------
-- 4. Wallet freeze — server enforced, ledger never touched
-- ---------------------------------------------------------------------------
create or replace function public.admin_freeze_wallet(
  p_user_id uuid, p_frozen boolean, p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_frozen boolean := coalesce(p_frozen, true);
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_user_id = auth.uid() then raise exception 'CANNOT_MODERATE_SELF'; end if;

  update public.wallets
     set frozen = v_frozen,
         frozen_reason = case when v_frozen then nullif(trim(coalesce(p_reason, '')), '') else null end,
         frozen_at = case when v_frozen then now() else null end,
         updated_at = now()
   where user_id = p_user_id;
  if not found then raise exception 'WALLET_NOT_FOUND'; end if;

  perform public.notify_user(
    p_user_id,
    case when v_frozen then 'Wallet frozen' else 'Wallet unfrozen' end,
    case when v_frozen
      then coalesce(nullif(trim(coalesce(p_reason, '')), ''), 'Your wallet cannot send funds while this is active. Your balance and history are unchanged.')
      else 'Your wallet can send funds again. Your balance is unchanged.'
    end,
    case when v_frozen then 'error' else 'success' end, '#/wallet');

  perform public.audit('wallet.freeze', 'profile', p_user_id,
    jsonb_build_object('frozen', v_frozen, 'reason', p_reason));
  return jsonb_build_object('ok', true, 'frozen', v_frozen);
end $$;

create or replace function public.admin_add_note(
  p_user_id uuid, p_note text, p_kind text default 'note'
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','SUPPORT','FINANCE','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'EMPTY_MESSAGE'; end if;
  if not exists (select 1 from public.profiles where id = p_user_id) then
    raise exception 'USER_NOT_FOUND';
  end if;

  insert into public.admin_notes (user_id, note, kind, created_by)
  values (p_user_id, trim(p_note), coalesce(nullif(trim(p_kind), ''), 'note'), auth.uid());

  perform public.audit('user.note', 'profile', p_user_id,
    jsonb_build_object('kind', p_kind, 'note', left(trim(p_note), 200)));
  return jsonb_build_object('ok', true);
end $$;

-- ---------------------------------------------------------------------------
-- 5. wallet_move: suspend / freeze enforcement
--    Positive credits (rewards, refunds, admin credits) always pass.
--    Outflows (withdrawal, campaign funding) are refused for a suspended
--    account or a frozen wallet. Admins and the service role bypass the freeze.
-- ---------------------------------------------------------------------------
create or replace function public.wallet_move(
  p_user uuid,
  p_available numeric,
  p_pending numeric,
  p_reserved numeric,
  p_lifetime numeric,
  p_kind text,
  p_ref_type text default null,
  p_ref_id uuid default null,
  p_note text default null
) returns void language plpgsql security definer set search_path = public as $$
declare
  w public.wallets;
  v_status text;
  v_privileged boolean := (auth.role() = 'service_role' or public.is_admin());
begin
  select * into w from public.wallets where user_id = p_user for update;
  if not found then
    raise exception 'WALLET_NOT_FOUND';
  end if;

  select status into v_status from public.profiles where id = p_user;

  if not v_privileged
     and (coalesce(p_available, 0) < 0 or coalesce(p_reserved, 0) < 0) then
    if coalesce(w.frozen, false) then
      raise exception 'WALLET_FROZEN';
    end if;
    if v_status is not null and v_status <> 'active' then
      raise exception 'ACCOUNT_RESTRICTED';
    end if;
  end if;

  if w.available + coalesce(p_available, 0) < 0
     or w.pending + coalesce(p_pending, 0) < 0
     or w.reserved + coalesce(p_reserved, 0) < 0 then
    raise exception 'INSUFFICIENT_BALANCE';
  end if;

  update public.wallets
     set available = available + coalesce(p_available, 0),
         pending = pending + coalesce(p_pending, 0),
         reserved = reserved + coalesce(p_reserved, 0),
         lifetime_earned = lifetime_earned + coalesce(p_lifetime, 0),
         updated_at = now()
   where user_id = p_user
   returning * into w;

  insert into public.ledger_entries (
    user_id, kind, available_delta, pending_delta, reserved_delta,
    available_after, pending_after, reserved_after,
    ref_type, ref_id, note, created_by
  ) values (
    p_user, p_kind, coalesce(p_available, 0), coalesce(p_pending, 0), coalesce(p_reserved, 0),
    w.available, w.pending, w.reserved,
    p_ref_type, p_ref_id, p_note, auth.uid()
  );
end $$;

revoke all on function public.wallet_move(uuid, numeric, numeric, numeric, numeric, text, text, uuid, text)
  from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 6. Suspension with reason presets and evidence
-- ---------------------------------------------------------------------------
drop function if exists public.admin_suspend_user(uuid, text, text, timestamptz, text, boolean);

create or replace function public.admin_suspend_user(
  p_user_id uuid, p_kind text, p_reason text,
  p_expires_at timestamptz default null,
  p_note text default null,
  p_appeal_allowed boolean default true,
  p_reason_key text default null,
  p_evidence jsonb default '[]'::jsonb
) returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_user_id = auth.uid() then raise exception 'CANNOT_MODERATE_SELF'; end if;
  if p_kind not in ('temporary','permanent','under_review','restricted') then
    raise exception 'INVALID_STATUS';
  end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'REASON_REQUIRED'; end if;
  if p_kind = 'temporary' and (p_expires_at is null or p_expires_at <= now()) then
    raise exception 'INVALID_EXPIRY';
  end if;

  select * into p from public.profiles where id = p_user_id for update;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;
  if p.admin_role = 'OWNER' then raise exception 'FORBIDDEN'; end if;

  update public.profiles
     set status = case when p_kind = 'restricted' then 'active' else 'suspended' end,
         is_suspended = (p_kind <> 'restricted'),
         suspension_kind = p_kind,
         suspension_reason_key = nullif(trim(coalesce(p_reason_key, '')), ''),
         suspension_reason = trim(p_reason),
         suspension_note = nullif(trim(coalesce(p_note, '')), ''),
         suspension_evidence = case
           when p_evidence is null or jsonb_typeof(p_evidence) <> 'array' then coalesce(p.suspension_evidence, '[]'::jsonb)
           else p_evidence
         end,
         suspended_at = case when p_kind = 'restricted' then null else now() end,
         suspension_expires_at = case when p_kind = 'temporary' then p_expires_at else null end,
         suspension_appeal_allowed = coalesce(p_appeal_allowed, true),
         suspended_by = auth.uid(),
         withdrawals_blocked = (p_kind = 'restricted'),
         updated_at = now()
   where id = p_user_id;

  update public.tasks
     set status = 'available', worker_id = null, claimed_at = null, expires_at = null
   where worker_id = p_user_id and status = 'claimed';

  perform public.notify_user(p_user_id,
    case when p_kind = 'restricted' then 'Account restricted' else 'Account suspended' end,
    trim(p_reason), 'error', '#/dashboard');

  perform public.audit('user.suspend', 'profile', p_user_id,
    jsonb_build_object('kind', p_kind, 'reason_key', p_reason_key,
                       'reason', p_reason, 'expires_at', p_expires_at,
                       'note', p_note,
                       'evidence_count', coalesce(jsonb_array_length(p_evidence), 0)));
  return jsonb_build_object('ok', true, 'kind', p_kind, 'status',
    case when p_kind = 'restricted' then 'active' else 'suspended' end);
end $$;

-- ---------------------------------------------------------------------------
-- 7. Richer admin user detail: tasks, proofs, notes, logins, suspension
-- ---------------------------------------------------------------------------
create or replace function public.admin_user_detail(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles; w public.wallets;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select * into p from public.profiles where id = p_user_id;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;
  select * into w from public.wallets where user_id = p_user_id;

  return jsonb_build_object(
    'profile', to_jsonb(p),
    'wallet', to_jsonb(w),
    'suspension', jsonb_build_object(
      'kind', p.suspension_kind,
      'reason_key', p.suspension_reason_key,
      'reason', p.suspension_reason,
      'note', p.suspension_note,
      'evidence', coalesce(p.suspension_evidence, '[]'::jsonb),
      'suspended_at', p.suspended_at,
      'expires_at', p.suspension_expires_at,
      'appeal_allowed', p.suspension_appeal_allowed,
      'withdrawals_blocked', p.withdrawals_blocked
    ),
    'stats', jsonb_build_object(
      'approved_tasks', (select count(*) from public.tasks where worker_id = p.id and status = 'approved'),
      'rejected_tasks', (select count(*) from public.tasks where worker_id = p.id and status = 'rejected'),
      'pending_submissions', (select count(*) from public.submissions where worker_id = p.id and status = 'pending'),
      'campaigns', (select count(*) from public.campaigns where buyer_id = p.id),
      'referrals', (select count(*) from public.referrals where referrer_id = p.id),
      'open_withdrawals', (select count(*) from public.withdrawals where user_id = p.id and status in ('pending','approved','processing'))
    ),
    'ledger', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object('id', l.id, 'kind', l.kind, 'available_delta', l.available_delta,
                                  'pending_delta', l.pending_delta, 'reserved_delta', l.reserved_delta,
                                  'available_after', l.available_after, 'note', l.note,
                                  'created_at', l.created_at,
                                  'admin_name', coalesce(nullif(cp.full_name, ''), cp.email))
          from public.ledger_entries l
          left join public.profiles cp on cp.id = l.created_by
         where l.user_id = p.id
         order by l.created_at desc limit 30
      ) q
    ),
    'tasks', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', t.id, 'status', t.status, 'reward', t.reward,
          'campaign', c.title, 'platform', sv.platform,
          'claimed_at', t.claimed_at, 'submitted_at', t.submitted_at,
          'reviewed_at', t.reviewed_at, 'created_at', t.created_at
        ) x
          from public.tasks t
          join public.campaigns c on c.id = t.campaign_id
          join public.services sv on sv.id = c.service_id
         where t.worker_id = p.id
         order by t.created_at desc limit 20
      ) q
    ),
    'submissions', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', s.id, 'status', s.status, 'proof_path', s.proof_path,
          'proof_paths', s.proof_paths, 'proof_link', s.proof_link,
          'note', s.note, 'review_note', s.review_note,
          'duplicate_hash', (s.proof_hash is not null and exists (
             select 1 from public.submissions s2
              where s2.proof_hash = s.proof_hash and s2.id <> s.id)),
          'campaign', c.title, 'reward', t.reward,
          'created_at', s.created_at, 'reviewed_at', s.reviewed_at
        ) x
          from public.submissions s
          join public.tasks t on t.id = s.task_id
          join public.campaigns c on c.id = t.campaign_id
         where s.worker_id = p.id
         order by s.created_at desc limit 20
      ) q
    ),
    'notes', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', n.id, 'note', n.note, 'kind', n.kind, 'created_at', n.created_at,
          'admin_name', coalesce(nullif(cp.full_name, ''), cp.email)
        ) x
          from public.admin_notes n
          left join public.profiles cp on cp.id = n.created_by
         where n.user_id = p.id
         order by n.created_at desc limit 30
      ) q
    ),
    'logins', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object('id', e.id, 'user_agent', e.user_agent,
                                  'platform', e.platform, 'created_at', e.created_at) x
          from public.login_events e
         where e.user_id = p.id
         order by e.created_at desc limit 20
      ) q
    ),
    'withdrawals', (
      select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc), '[]'::jsonb)
        from (select * from public.withdrawals where user_id = p.id order by created_at desc limit 10) x
    ),
    'deposits', (
      select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc), '[]'::jsonb)
        from (select * from public.deposits where user_id = p.id order by created_at desc limit 10) x
    )
  );
end $$;

-- ---------------------------------------------------------------------------
-- 8. Fraud detection — flags only, never a ban
-- ---------------------------------------------------------------------------
create or replace function public.admin_scan_fraud()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_dup int := 0; v_rej int := 0; v_fast int := 0; v_ref int := 0; v_wd int := 0;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  -- identical proof screenshots
  with dup as (
    select proof_hash from public.submissions
     where proof_hash is not null
     group by proof_hash having count(*) > 1
  )
  insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
  select s.worker_id, 'duplicate_proof', 3,
         jsonb_build_object('proof_hash', s.proof_hash), s.id
    from public.submissions s
    join dup d on d.proof_hash = s.proof_hash
   where not exists (
     select 1 from public.fraud_flags f
      where f.kind = 'duplicate_proof'
        and f.details ->> 'proof_hash' = s.proof_hash
   )
   limit 100;
  get diagnostics v_dup = row_count;

  -- repeated rejections
  insert into public.fraud_flags (user_id, kind, severity, details)
  select s.worker_id, 'high_rejection_rate', 2,
         jsonb_build_object('rejected_last_7_days', count(*))
    from public.submissions s
   where s.status = 'rejected' and s.created_at >= now() - interval '7 days'
   group by s.worker_id
  having count(*) >= 3
     and not exists (
       select 1 from public.fraud_flags f
        where f.user_id = s.worker_id
          and f.kind = 'high_rejection_rate'
          and f.status in ('open','reviewing')
     );
  get diagnostics v_rej = row_count;

  -- implausibly fast completions (only where the timer was recorded)
  insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
  select s.worker_id, 'suspicious_speed', 2,
         jsonb_build_object('time_spent_seconds', s.time_spent_seconds), s.id
    from public.submissions s
   where s.time_spent_seconds is not null
     and s.time_spent_seconds < 5
     and s.created_at >= now() - interval '14 days'
     and not exists (
       select 1 from public.fraud_flags f
        where f.kind = 'suspicious_speed' and f.ref_id = s.id
     )
   limit 100;
  get diagnostics v_fast = row_count;

  -- referral bursts
  insert into public.fraud_flags (user_id, kind, severity, details)
  select r.referrer_id, 'referral_burst', 2,
         jsonb_build_object('referrals_24h', count(*))
    from public.referrals r
   where r.created_at >= now() - interval '24 hours'
   group by r.referrer_id
  having count(*) >= 10
     and not exists (
       select 1 from public.fraud_flags f
        where f.user_id = r.referrer_id
          and f.kind = 'referral_burst'
          and f.status in ('open','reviewing')
     );
  get diagnostics v_ref = row_count;

  -- withdrawal bursts
  insert into public.fraud_flags (user_id, kind, severity, details)
  select w.user_id, 'withdrawal_burst', 2,
         jsonb_build_object('withdrawals_24h', count(*))
    from public.withdrawals w
   where w.created_at >= now() - interval '24 hours'
   group by w.user_id
  having count(*) >= 5
     and not exists (
       select 1 from public.fraud_flags f
        where f.user_id = w.user_id
          and f.kind = 'withdrawal_burst'
          and f.status in ('open','reviewing')
     );
  get diagnostics v_wd = row_count;

  perform public.audit('fraud.scan', 'fraud_flag', null,
    jsonb_build_object('duplicate', v_dup, 'rejections', v_rej,
                       'speed', v_fast, 'referrals', v_ref, 'withdrawals', v_wd));

  return jsonb_build_object('ok', true, 'flagged', jsonb_build_object(
    'duplicate_proof', v_dup, 'high_rejection_rate', v_rej,
    'suspicious_speed', v_fast, 'referral_burst', v_ref, 'withdrawal_burst', v_wd));
end $$;

create or replace function public.admin_fraud_overview()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  return jsonb_build_object(
    'counts', jsonb_build_object(
      'open', (select count(*) from public.fraud_flags where status in ('open','reviewing')),
      'low', (select count(*) from public.fraud_flags where status in ('open','reviewing') and severity <= 1),
      'medium', (select count(*) from public.fraud_flags where status in ('open','reviewing') and severity = 2),
      'high', (select count(*) from public.fraud_flags where status in ('open','reviewing') and severity = 3),
      'critical', (select count(*) from public.fraud_flags where status in ('open','reviewing') and severity >= 4),
      'suspended', (select count(*) from public.profiles where status = 'suspended'),
      'restricted', (select count(*) from public.profiles where coalesce(withdrawals_blocked, false)),
      'frozen_wallets', (select count(*) from public.wallets where coalesce(frozen, false))
    ),
    'kinds', (
      select coalesce(jsonb_agg(jsonb_build_object('kind', kind, 'count', n, 'max_severity', sev)
                                order by n desc), '[]'::jsonb)
        from (
          select kind, count(*) n, max(severity) sev
            from public.fraud_flags
           where status in ('open','reviewing')
           group by kind
        ) q
    ),
    'users', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'user_id', f.user_id,
          'name', coalesce(nullif(p.full_name, ''), p.email),
          'email', p.email,
          'status', p.status,
          'flags', count(*),
          'max_severity', max(f.severity)
        ) x
          from public.fraud_flags f
          left join public.profiles p on p.id = f.user_id
         where f.status in ('open','reviewing') and f.user_id is not null
         group by f.user_id, p.full_name, p.email, p.status
         order by max(f.severity) desc, count(*) desc
         limit 20
      ) q
    )
  );
end $$;

-- ---------------------------------------------------------------------------
-- 9. Grants
-- ---------------------------------------------------------------------------
revoke all on function public.record_login_event(text, text) from public, anon;
grant execute on function public.record_login_event(text, text) to authenticated;

revoke all on function public.admin_freeze_wallet(uuid, boolean, text) from public, anon;
grant execute on function public.admin_freeze_wallet(uuid, boolean, text) to authenticated;

revoke all on function public.admin_add_note(uuid, text, text) from public, anon;
grant execute on function public.admin_add_note(uuid, text, text) to authenticated;

revoke all on function public.admin_scan_fraud() from public, anon;
grant execute on function public.admin_scan_fraud() to authenticated;

revoke all on function public.admin_fraud_overview() from public, anon;
grant execute on function public.admin_fraud_overview() to authenticated;

revoke all on function public.admin_suspend_user(uuid, text, text, timestamptz, text, boolean, text, jsonb) from public, anon;
grant execute on function public.admin_suspend_user(uuid, text, text, timestamptz, text, boolean, text, jsonb) to authenticated;

-- ---------------------------------------------------------------------------
-- Verify
-- ---------------------------------------------------------------------------
select column_name, data_type
  from information_schema.columns
 where table_schema = 'public'
   and ((table_name = 'wallets' and column_name in ('frozen','frozen_reason','frozen_at'))
     or (table_name = 'profiles' and column_name in ('suspension_reason_key','suspension_evidence')))
 order by table_name, column_name;
