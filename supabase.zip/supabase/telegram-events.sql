-- TM GROW — Telegram Mini App auth repair + missing bot notifications
-- 1) telegram_user_id_by_email(): lets the Edge Function recover when the auth
--    user already exists but the profile mapping is missing (the usual cause of
--    CREATE_USER_FAILED -> HTTP 500 on a retry).
-- 2) Task submitted / withdrawal requested notifications via triggers on the
--    rows that actually commit, with a unique dedupe key each.

-- ---------------------------------------------------------------------------
-- 1. Duplicate-user lookup for the service role only
-- ---------------------------------------------------------------------------
create or replace function public.telegram_user_id_by_email(p_email text)
returns uuid language sql stable security definer set search_path = public as $$
  select u.id from auth.users u
   where lower(u.email) = lower(coalesce(p_email, ''))
   limit 1;
$$;

revoke all on function public.telegram_user_id_by_email(text) from public, anon, authenticated;
grant execute on function public.telegram_user_id_by_email(text) to service_role;

-- ---------------------------------------------------------------------------
-- 2. Notification settings for the two new events
-- ---------------------------------------------------------------------------
insert into public.settings (key, value, is_public) values
  ('telegram_notify_task_submitted', 'true'::jsonb, false),
  ('telegram_notify_withdrawal_requested', 'true'::jsonb, false)
on conflict (key) do nothing;

insert into public.settings (key, value, is_public) values
  ('telegram_tpl_task_submitted', to_jsonb($tpl$📤 Task Submitted

Your task has been submitted successfully!

📌 Task: {{task}}
💰 Reward: {{reward}} USDT
🕒 Status: {{status}}

You will receive another notification when your proof is reviewed.$tpl$::text), false),
  ('telegram_tpl_withdrawal_requested', to_jsonb($tpl$🧾 Withdrawal Requested

We received your withdrawal request.

💸 Amount: {{amount}} USDT
📮 Address: {{address}}
🏦 Network: {{network}}
🕒 Status: Waiting for review

You will be notified when finance updates it.$tpl$::text), false)
on conflict (key) do nothing;

-- ---------------------------------------------------------------------------
-- 3. Task submitted (fires only after the submissions row is committed)
-- ---------------------------------------------------------------------------
create or replace function public.tg_notify_task_submitted()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  t public.tasks;
  c public.campaigns;
begin
  select * into t from public.tasks where id = new.task_id;
  if t.id is null then return new; end if;
  select * into c from public.campaigns where id = t.campaign_id;

  perform public.telegram_enqueue(
    new.worker_id,
    'task_submitted',
    jsonb_build_object(
      'task', coalesce(c.title, 'Task'),
      'reward', public.telegram_money(t.reward),
      'status', 'Under review'
    ),
    'task_submitted:' || new.id
  );

  return new;
end $$;

drop trigger if exists tg_notify_task_submitted on public.submissions;
create trigger tg_notify_task_submitted after insert on public.submissions
  for each row execute function public.tg_notify_task_submitted();

-- ---------------------------------------------------------------------------
-- 4. Withdrawal requested
-- ---------------------------------------------------------------------------
create or replace function public.tg_notify_withdrawal_requested()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.telegram_enqueue(
    new.user_id,
    'withdrawal_requested',
    jsonb_build_object(
      'amount', public.telegram_money(new.amount),
      'address', new.address,
      'network', coalesce(new.network, public.setting_text('network_name', 'BEP20'))
    ),
    'withdrawal_requested:' || new.id
  );
  return new;
end $$;

drop trigger if exists tg_notify_withdrawal_requested on public.withdrawals;
create trigger tg_notify_withdrawal_requested after insert on public.withdrawals
  for each row execute function public.tg_notify_withdrawal_requested();

notify pgrst, 'reload schema';
