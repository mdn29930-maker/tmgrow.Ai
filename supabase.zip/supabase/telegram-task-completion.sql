-- ============================================================================
-- TM GROW — FoxiGrow-style "Task Completed" Telegram notification
--
-- Uses the existing pipeline only:
--   submissions.status -> 'approved'  (set by review_submission after the
--                                      wallet reward + TG Coin are credited)
--   -> telegram_enqueue()  -> telegram_outbox -> telegram-notify (Edge Function)
--
-- Adds:
--   * reward_ranks setting (real, configurable thresholds)
--   * telegram_reward_progress() — remaining amount / next rank / bonus
--   * a trigger that queues ONE message per approved submission (dedupe key)
--   * the message template
--   * disables the old `task_approved` copy so the worker is not messaged twice
--
-- Safe to re-run. No table is dropped, no balance is written here.
-- ============================================================================

begin;

-- ----------------------------------------------------------------------------
-- 1. Rank ladder (configurable; used only for the progress line)
-- ----------------------------------------------------------------------------
insert into public.settings (key, value, is_public) values
  ('reward_ranks', '[
      {"rank":"Rising","min":10,"bonus_usdt":1,"bonus_coin":5},
      {"rank":"Pro","min":50,"bonus_usdt":3,"bonus_coin":15},
      {"rank":"Elite","min":200,"bonus_usdt":10,"bonus_coin":50}
    ]'::jsonb, false)
on conflict (key) do nothing;

-- ----------------------------------------------------------------------------
-- 2. Progress calculation from the worker's real lifetime earnings
-- ----------------------------------------------------------------------------
create or replace function public.telegram_reward_progress(p_user uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_life numeric := 0;
  v_ranks jsonb := '[]'::jsonb;
  r jsonb;
  v_next jsonb := null;
begin
  select coalesce(lifetime_earned, 0) into v_life
    from public.wallets where user_id = p_user;

  select coalesce(value, '[]'::jsonb) into v_ranks
    from public.settings where key = 'reward_ranks';

  if jsonb_typeof(v_ranks) <> 'array' then v_ranks := '[]'::jsonb; end if;

  for r in select * from jsonb_array_elements(v_ranks) order by (value ->> 'min')::numeric
  loop
    if (r ->> 'min')::numeric > v_life then
      v_next := r;
      exit;
    end if;
  end loop;

  if v_next is null then
    return jsonb_build_object(
      'lifetime', v_life,
      'next_rank', null,
      'remaining', 0,
      'bonus_usdt', 0,
      'bonus_coin', 0,
      'line', '🏆 You have reached the top rank. Keep earning!'
    );
  end if;

  return jsonb_build_object(
    'lifetime', v_life,
    'next_rank', v_next ->> 'rank',
    'remaining', round(greatest(0, (v_next ->> 'min')::numeric - v_life), 6),
    'bonus_usdt', (v_next ->> 'bonus_usdt')::numeric,
    'bonus_coin', (v_next ->> 'bonus_coin')::numeric,
    'line', '🎯 ' || public.telegram_money(greatest(0, (v_next ->> 'min')::numeric - v_life)) || ' USDT more unlocks '
            || (v_next ->> 'rank') || ' — you’ll get +' || public.telegram_money((v_next ->> 'bonus_usdt')::numeric)
            || ' USDT +' || public.telegram_money((v_next ->> 'bonus_coin')::numeric) || ' TM Coin'
  );
end $$;

revoke all on function public.telegram_reward_progress(uuid) from public, anon, authenticated;

-- ----------------------------------------------------------------------------
-- 3. Queue the message once per approved submission
-- ----------------------------------------------------------------------------
create or replace function public.tg_task_completed_notify()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_task text;
  v_reward numeric;
  v_coin numeric;
  v_progress jsonb;
begin
  /* Only the transition pending -> approved. Pending, rejected and expired
     submissions never reach this branch. */
  if new.status <> 'approved' or coalesce(old.status, '') = 'approved' then
    return new;
  end if;

  select c.title, t.reward
    into v_task, v_reward
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
   where t.id = new.task_id;

  if v_task is null then return new; end if;

  v_coin := coalesce(public.setting_num('tg_per_task', 1), 0);
  v_progress := public.telegram_reward_progress(new.worker_id);

  /* telegram_enqueue() itself skips users without a linked Telegram id, a
     disabled bot/event or an opt-out. The dedupe key makes repeat processing
     impossible. */
  perform public.telegram_enqueue(
    new.worker_id,
    'task_completed',
    jsonb_build_object(
      'task', v_task,
      'reward', public.telegram_money(v_reward),
      'coin', public.telegram_money(v_coin),
      'progress_line', v_progress ->> 'line',
      'next_rank', v_progress ->> 'next_rank',
      'remaining', v_progress ->> 'remaining'
    ),
    'task_completed:' || new.id
  );

  return new;
end $$;

drop trigger if exists submissions_task_completed_tg on public.submissions;
create trigger submissions_task_completed_tg
  after update of status on public.submissions
  for each row execute function public.tg_task_completed_notify();

revoke all on function public.tg_task_completed_notify() from public, anon, authenticated;

-- ----------------------------------------------------------------------------
-- 4. Message template (exact requested format)
-- ----------------------------------------------------------------------------
insert into public.settings (key, value, is_public) values
  ('telegram_tpl_task_completed',
   to_jsonb('🎉 Task Completed!

✅ Task: {{task}}
💰 Reward: +{{reward}} USDT
🪙 TM Coin: +{{coin}}

{{progress_line}}

Keep completing tasks to earn more rewards!'::text),
   false)
on conflict (key) do update set value = excluded.value, updated_at = now();

-- One notification per completed task: retire the older approval message.
insert into public.settings (key, value, is_public) values
  ('telegram_notify_task_approved', 'false'::jsonb, false)
on conflict (key) do update set value = 'false'::jsonb, updated_at = now();

insert into public.settings (key, value, is_public) values
  ('telegram_notify_task_completed', 'true'::jsonb, false)
on conflict (key) do update set value = 'true'::jsonb, updated_at = now();

notify pgrst, 'reload schema';

commit;
