-- ============================================================================
-- TM GROW — MASTER ADMIN CONTROL ROOM (Phase 2)
-- User Activity, Risk History and Login History
--
-- Additive only. Reads existing records; creates no tables and changes no
-- wallet, task, auth or Telegram logic. Safe to re-run.
--
-- RPCs:
--   admin_user_activity(user, kind, from, to, limit, offset)
--   admin_login_history(query, limit, offset)
--   admin_risk_profile(user)
--   admin_risk_board(limit, offset)
--
-- login_events is created by advanced-management.sql. When it is missing these
-- functions still work and say so, instead of inventing history.
-- ============================================================================

begin;

-- ============================================================================
-- 0. LOGIN EVENTS (idempotent)
-- advanced-management.sql creates the same table. This copy exists so the
-- activity timeline can reference the table safely even on a database where
-- that migration was never run. It never alters an existing table.
-- ============================================================================
create table if not exists public.login_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  user_agent text,
  platform text,
  created_at timestamptz not null default now()
);
create index if not exists login_events_user_idx on public.login_events (user_id, created_at desc);
alter table public.login_events enable row level security;
grant all on public.login_events to service_role;


-- ============================================================================
-- 1. USER ACTIVITY — one real timeline from recorded rows
-- ============================================================================
create or replace function public.admin_user_activity(
  p_user uuid default null,
  p_kind text default null,
  p_from timestamptz default null,
  p_to timestamptz default null,
  p_limit int default 50,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
  v_limit int := greatest(1, least(coalesce(p_limit, 50), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_from timestamptz := coalesce(p_from, now() - interval '90 days');
  v_to timestamptz := coalesce(p_to, now());
  v_kind text := nullif(btrim(coalesce(p_kind, '')), '');
  v_has_logins boolean := to_regclass('public.login_events') is not null;
begin
  if not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  with events as (
    -- Account created
    select 'registration'::text as kind,
           'Account created'::text as title,
           p.status::text as status,
           null::numeric as amount,
           p.created_at as at,
           p.id as user_id,
           null::text as actor,
           jsonb_build_object('worker', p.is_worker, 'buyer', p.is_buyer) as meta
      from public.profiles p
     where (p_user is null or p.id = p_user)

    union all
    -- Recorded logins
    select 'login', 'Signed in', coalesce(e.platform, 'web'), null,
           e.created_at, e.user_id, null,
           jsonb_build_object('user_agent', e.user_agent)
      from public.login_events e
     where to_regclass('public.login_events') is not null
       and (p_user is null or e.user_id = p_user)

    union all
    -- Tasks claimed / submitted
    select case when t.submitted_at is not null then 'task_submitted' else 'task_claimed' end,
           coalesce(c.title, 'Task'), t.status::text, t.reward,
           coalesce(t.submitted_at, t.claimed_at), t.worker_id, null,
           jsonb_build_object('task_id', t.id, 'campaign', c.title, 'platform', s.platform)
      from public.tasks t
      left join public.campaigns c on c.id = t.campaign_id
      left join public.services s on s.id = c.service_id
     where t.worker_id is not null
       and coalesce(t.submitted_at, t.claimed_at) is not null
       and (p_user is null or t.worker_id = p_user)

    union all
    -- Proof submitted
    select 'proof_submitted', coalesce(c.title, 'Proof'), sub.status::text, t.reward,
           sub.created_at, sub.worker_id, null,
           jsonb_build_object('submission_id', sub.id, 'task_id', sub.task_id,
                              'screenshots', coalesce(array_length(sub.proof_paths, 1), 0))
      from public.submissions sub
      join public.tasks t on t.id = sub.task_id
      left join public.campaigns c on c.id = t.campaign_id
     where (p_user is null or sub.worker_id = p_user)

    union all
    -- Proof reviewed (approve / reject)
    select 'proof_reviewed', coalesce(c.title, 'Proof review'), sub.status::text, t.reward,
           coalesce(sub.reviewed_at, sub.created_at), sub.worker_id,
           coalesce(nullif(rp.full_name, ''), rp.email),
           jsonb_build_object('submission_id', sub.id, 'note', sub.review_note)
      from public.submissions sub
      join public.tasks t on t.id = sub.task_id
      left join public.campaigns c on c.id = t.campaign_id
      left join public.profiles rp on rp.id = sub.reviewer_id
     where sub.reviewed_at is not null
       and (p_user is null or sub.worker_id = p_user)

    union all
    -- Deposits
    select 'deposit', 'Deposit', d.status::text, d.amount, d.created_at, d.user_id, null,
           jsonb_build_object('tx_hash', d.tx_hash, 'method', d.method)
      from public.deposits d
     where (p_user is null or d.user_id = p_user)

    union all
    -- Withdrawals
    select 'withdrawal', 'Withdrawal', w.status::text, w.amount, w.created_at, w.user_id, null,
           jsonb_build_object('fee', w.fee, 'net', w.net_amount, 'network', w.network,
                              'tx_hash', w.tx_hash)
      from public.withdrawals w
     where (p_user is null or w.user_id = p_user)

    union all
    -- Buyer campaigns created
    select 'campaign', coalesce(c.title, 'Campaign'), c.status::text, c.total_budget,
           c.created_at, c.buyer_id, null,
           jsonb_build_object('campaign_id', c.id, 'quantity', c.quantity,
                              'approved', c.approved_count)
      from public.campaigns c
     where (p_user is null or c.buyer_id = p_user)

    union all
    -- Referrals: joined with someone's code, and referrals earned
    select 'referral_join', 'Joined through a referral', null, null,
           r.created_at, r.referred_id, rp.email,
           jsonb_build_object('referrer_id', r.referrer_id, 'rate', r.rate)
      from public.referrals r
      left join public.profiles rp on rp.id = r.referrer_id
     where (p_user is null or r.referred_id = p_user)

    union all
    select 'referral', 'Invited a new member', null, null,
           r.created_at, r.referrer_id, rp.email,
           jsonb_build_object('referred_id', r.referred_id, 'rate', r.rate)
      from public.referrals r
      left join public.profiles rp on rp.id = r.referred_id
     where (p_user is null or r.referrer_id = p_user)

    union all
    -- Support tickets
    select 'support', coalesce(st.subject, 'Support ticket'), st.status::text, null,
           st.created_at, st.user_id, null,
           jsonb_build_object('ticket_id', st.id, 'category', st.category)
      from public.support_tickets st
     where (p_user is null or st.user_id = p_user)

    union all
    -- Admin audit entries that concern the user (actor or subject)
    select 'admin_action', a.action, a.actor_role, null,
           a.created_at,
           coalesce(a.entity_id, a.actor_id),
           coalesce(nullif(ap.full_name, ''), ap.email),
           a.details
      from public.audit_logs a
      left join public.profiles ap on ap.id = a.actor_id
     where (p_user is null or a.actor_id = p_user or a.entity_id = p_user)

    union all
    -- Recorded risk flags
    select 'risk_flag', f.kind, f.status, null,
           f.created_at, f.user_id, null,
           jsonb_build_object('severity', f.severity, 'flag_id', f.id, 'details', f.details)
      from public.fraud_flags f
     where (p_user is null or f.user_id = p_user)
  ),
  filtered as (
    select * from events
     where at >= v_from and at <= v_to
       and (v_kind is null or kind = v_kind)
  )
  select count(*) into v_total from filtered;

  with events as (
    select 'registration'::text as kind, 'Account created'::text as title,
           p.status::text as status, null::numeric as amount, p.created_at as at,
           p.id as user_id, null::text as actor,
           jsonb_build_object('worker', p.is_worker, 'buyer', p.is_buyer) as meta
      from public.profiles p where (p_user is null or p.id = p_user)
    union all
    select 'login', 'Signed in', coalesce(e.platform, 'web'), null,
           e.created_at, e.user_id, null, jsonb_build_object('user_agent', e.user_agent)
      from public.login_events e
     where to_regclass('public.login_events') is not null
       and (p_user is null or e.user_id = p_user)
    union all
    select case when t.submitted_at is not null then 'task_submitted' else 'task_claimed' end,
           coalesce(c.title, 'Task'), t.status::text, t.reward,
           coalesce(t.submitted_at, t.claimed_at), t.worker_id, null,
           jsonb_build_object('task_id', t.id, 'campaign', c.title, 'platform', s.platform)
      from public.tasks t
      left join public.campaigns c on c.id = t.campaign_id
      left join public.services s on s.id = c.service_id
     where t.worker_id is not null
       and coalesce(t.submitted_at, t.claimed_at) is not null
       and (p_user is null or t.worker_id = p_user)
    union all
    select 'proof_submitted', coalesce(c.title, 'Proof'), sub.status::text, t.reward,
           sub.created_at, sub.worker_id, null,
           jsonb_build_object('submission_id', sub.id, 'task_id', sub.task_id,
                              'screenshots', coalesce(array_length(sub.proof_paths, 1), 0))
      from public.submissions sub
      join public.tasks t on t.id = sub.task_id
      left join public.campaigns c on c.id = t.campaign_id
     where (p_user is null or sub.worker_id = p_user)
    union all
    select 'proof_reviewed', coalesce(c.title, 'Proof review'), sub.status::text, t.reward,
           coalesce(sub.reviewed_at, sub.created_at), sub.worker_id,
           coalesce(nullif(rp.full_name, ''), rp.email),
           jsonb_build_object('submission_id', sub.id, 'note', sub.review_note)
      from public.submissions sub
      join public.tasks t on t.id = sub.task_id
      left join public.campaigns c on c.id = t.campaign_id
      left join public.profiles rp on rp.id = sub.reviewer_id
     where sub.reviewed_at is not null
       and (p_user is null or sub.worker_id = p_user)
    union all
    select 'deposit', 'Deposit', d.status::text, d.amount, d.created_at, d.user_id, null,
           jsonb_build_object('tx_hash', d.tx_hash, 'method', d.method)
      from public.deposits d where (p_user is null or d.user_id = p_user)
    union all
    select 'withdrawal', 'Withdrawal', w.status::text, w.amount, w.created_at, w.user_id, null,
           jsonb_build_object('fee', w.fee, 'net', w.net_amount, 'network', w.network,
                              'tx_hash', w.tx_hash)
      from public.withdrawals w where (p_user is null or w.user_id = p_user)
    union all
    select 'campaign', coalesce(c.title, 'Campaign'), c.status::text, c.total_budget,
           c.created_at, c.buyer_id, null,
           jsonb_build_object('campaign_id', c.id, 'quantity', c.quantity,
                              'approved', c.approved_count)
      from public.campaigns c where (p_user is null or c.buyer_id = p_user)
    union all
    select 'referral_join', 'Joined through a referral', null, null,
           r.created_at, r.referred_id, rp.email,
           jsonb_build_object('referrer_id', r.referrer_id, 'rate', r.rate)
      from public.referrals r left join public.profiles rp on rp.id = r.referrer_id
     where (p_user is null or r.referred_id = p_user)
    union all
    select 'referral', 'Invited a new member', null, null,
           r.created_at, r.referrer_id, rp.email,
           jsonb_build_object('referred_id', r.referred_id, 'rate', r.rate)
      from public.referrals r left join public.profiles rp on rp.id = r.referred_id
     where (p_user is null or r.referrer_id = p_user)
    union all
    select 'support', coalesce(st.subject, 'Support ticket'), st.status::text, null,
           st.created_at, st.user_id, null,
           jsonb_build_object('ticket_id', st.id, 'category', st.category)
      from public.support_tickets st where (p_user is null or st.user_id = p_user)
    union all
    select 'admin_action', a.action, a.actor_role, null,
           a.created_at, coalesce(a.entity_id, a.actor_id),
           coalesce(nullif(ap.full_name, ''), ap.email), a.details
      from public.audit_logs a
      left join public.profiles ap on ap.id = a.actor_id
     where (p_user is null or a.actor_id = p_user or a.entity_id = p_user)
    union all
    select 'risk_flag', f.kind, f.status, null,
           f.created_at, f.user_id, null,
           jsonb_build_object('severity', f.severity, 'flag_id', f.id, 'details', f.details)
      from public.fraud_flags f where (p_user is null or f.user_id = p_user)
  ),
  filtered as (
    select * from events
     where at >= v_from and at <= v_to
       and (v_kind is null or kind = v_kind)
  ),
  paged as (
    select * from filtered
     order by at desc
     limit v_limit offset v_offset
  )
  select coalesce(jsonb_agg(jsonb_build_object(
           'kind', e.kind,
           'title', e.title,
           'status', e.status,
           'amount', e.amount,
           'at', e.at,
           'user_id', e.user_id,
           'user_name', coalesce(nullif(pr.full_name, ''), pr.email),
           'actor', e.actor,
           'meta', e.meta
         ) order by e.at desc), '[]'::jsonb)
    into v_items
    from paged e
    left join public.profiles pr on pr.id = e.user_id;

  return jsonb_build_object(
    'items', v_items,
    'total', v_total,
    'from', v_from,
    'to', v_to,
    'logins_recorded', v_has_logins,
    'missing', case when v_has_logins then '[]'::jsonb
                    else jsonb_build_array('table public.login_events (run supabase/advanced-management.sql)') end
  );
end $$;

revoke all on function public.admin_user_activity(uuid, text, timestamptz, timestamptz, int, int) from public, anon;
grant execute on function public.admin_user_activity(uuid, text, timestamptz, timestamptz, int, int) to authenticated;


-- ============================================================================
-- 2. LOGIN HISTORY — admin-wide, real recorded sessions only
-- ============================================================================
create or replace function public.admin_login_history(
  p_query text default null, p_limit int default 50, p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
  v_q text := nullif(btrim(coalesce(p_query, '')), '');
begin
  if not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  if to_regclass('public.login_events') is null then
    return jsonb_build_object(
      'items', '[]'::jsonb, 'total', 0,
      'missing', jsonb_build_array('table public.login_events'),
      'note', 'Run supabase/advanced-management.sql once: login_events is what records this history.'
    );
  end if;

  select count(*) into v_total
    from public.login_events e
    join public.profiles p on p.id = e.user_id
   where v_q is null
      or p.full_name ilike '%' || v_q || '%'
      or p.email ilike '%' || v_q || '%'
      or coalesce(e.user_agent, '') ilike '%' || v_q || '%';

  select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) into v_items from (
    select jsonb_build_object(
             'id', e.id,
             'user_id', e.user_id,
             'user_name', coalesce(nullif(p.full_name, ''), p.email),
             'email', p.email,
             'platform', e.platform,
             'user_agent', e.user_agent,
             'created_at', e.created_at
           ) as x
      from public.login_events e
      join public.profiles p on p.id = e.user_id
     where v_q is null
        or p.full_name ilike '%' || v_q || '%'
        or p.email ilike '%' || v_q || '%'
        or coalesce(e.user_agent, '') ilike '%' || v_q || '%'
     order by e.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', v_items, 'total', v_total, 'missing', '[]'::jsonb);
end $$;

revoke all on function public.admin_login_history(text, int, int) from public, anon;
grant execute on function public.admin_login_history(text, int, int) to authenticated;


-- ============================================================================
-- 3. RISK PROFILE — recorded signals with an explicit, rule-based score
--    Nothing here bans, freezes or pays. It explains what was observed.
-- ============================================================================
create or replace function public.admin_risk_profile(p_user uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  p public.profiles;
  w public.wallets;
  v_flags jsonb;
  v_notes jsonb;
  v_dups int := 0;
  v_rejected_7d int := 0;
  v_rejected_30d int := 0;
  v_submitted_30d int := 0;
  v_withdrawals_24h int := 0;
  v_withdrawals_7d int := 0;
  v_referrals_7d int := 0;
  v_devices_30d int := 0;
  v_logins_7d int := 0;
  v_linked_accounts int := 0;
  v_score int := 0;
  v_reasons jsonb := '[]'::jsonb;
  v_level text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into p from public.profiles where id = p_user;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;
  select * into w from public.wallets where user_id = p_user;

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', f.id, 'kind', f.kind, 'severity', f.severity, 'status', f.status,
           'details', f.details, 'created_at', f.created_at,
           'resolved_at', f.resolved_at
         ) order by f.created_at desc), '[]'::jsonb)
    into v_flags
    from public.fraud_flags f
   where f.user_id = p_user;

  if to_regclass('public.admin_notes') is not null then
    execute 'select coalesce(jsonb_agg(jsonb_build_object(
               ''id'', n.id, ''note'', n.note, ''kind'', n.kind, ''created_at'', n.created_at
             ) order by n.created_at desc), ''[]''::jsonb)
               from public.admin_notes n where n.user_id = $1'
      into v_notes using p_user;
  else
    v_notes := '[]'::jsonb;
  end if;

  select count(*) into v_dups
    from public.submissions s
   where s.worker_id = p_user
     and s.proof_hash is not null
     and exists (
       select 1 from public.submissions s2
        where s2.proof_hash = s.proof_hash and s2.id <> s.id
     );

  select count(*) into v_rejected_7d
    from public.submissions s
   where s.worker_id = p_user and s.status = 'rejected'
     and coalesce(s.reviewed_at, s.created_at) >= now() - interval '7 days';

  select count(*) into v_rejected_30d
    from public.submissions s
   where s.worker_id = p_user and s.status = 'rejected'
     and coalesce(s.reviewed_at, s.created_at) >= now() - interval '30 days';

  select count(*) into v_submitted_30d
    from public.submissions s
   where s.worker_id = p_user
     and coalesce(s.reviewed_at, s.created_at) >= now() - interval '30 days';

  select count(*) into v_withdrawals_24h
    from public.withdrawals wd
   where wd.user_id = p_user and wd.created_at >= now() - interval '24 hours';
  select count(*) into v_withdrawals_7d
    from public.withdrawals wd
   where wd.user_id = p_user and wd.created_at >= now() - interval '7 days';

  select count(*) into v_referrals_7d
    from public.referrals r
   where r.referrer_id = p_user and r.created_at >= now() - interval '7 days';

  select count(*) into v_linked_accounts
    from public.linked_accounts la
   where la.user_id = p_user;

  if to_regclass('public.login_events') is not null then
    execute 'select count(distinct coalesce(nullif(e.user_agent, ''''), ''unknown''))
               from public.login_events e
              where e.user_id = $1 and e.created_at >= now() - interval ''30 days'''
      into v_devices_30d using p_user;
    execute 'select count(*) from public.login_events e
              where e.user_id = $1 and e.created_at >= now() - interval ''7 days'''
      into v_logins_7d using p_user;
  end if;

  /* Rule-based points. Each one is a recorded signal, never a verdict. */
  if v_dups > 0 then
    v_score := v_score + least(30, v_dups * 10);
    v_reasons := v_reasons || jsonb_build_object('points', least(30, v_dups * 10),
      'text', v_dups || ' submission(s) reuse a proof hash that another submission also uses.');
  end if;

  if v_rejected_7d >= 3 then
    v_score := v_score + least(25, v_rejected_7d * 4);
    v_reasons := v_reasons || jsonb_build_object('points', least(25, v_rejected_7d * 4),
      'text', v_rejected_7d || ' rejected proof(s) in the last 7 days.');
  end if;

  if v_submitted_30d >= 10 and v_rejected_30d::numeric / v_submitted_30d >= 0.5 then
    v_score := v_score + 15;
    v_reasons := v_reasons || jsonb_build_object('points', 15,
      'text', 'Rejection rate above 50% over the last 30 days.');
  end if;

  if v_withdrawals_24h >= 3 then
    v_score := v_score + least(15, v_withdrawals_24h * 3);
    v_reasons := v_reasons || jsonb_build_object('points', least(15, v_withdrawals_24h * 3),
      'text', v_withdrawals_24h || ' withdrawal request(s) in 24 hours.');
  end if;

  if v_referrals_7d >= 10 then
    v_score := v_score + 10;
    v_reasons := v_reasons || jsonb_build_object('points', 10,
      'text', v_referrals_7d || ' referred sign-ups in 7 days.');
  end if;

  if v_devices_30d >= 5 then
    v_score := v_score + 10;
    v_reasons := v_reasons || jsonb_build_object('points', 10,
      'text', v_devices_30d || ' distinct recorded user agents in 30 days.');
  end if;

  if w.frozen is true then
    v_score := v_score + 10;
    v_reasons := v_reasons || jsonb_build_object('points', 10,
      'text', 'Wallet outflows were frozen by an administrator.');
  end if;

  if p.status <> 'active' then
    v_score := v_score + 10;
    v_reasons := v_reasons || jsonb_build_object('points', 10,
      'text', 'Account status is ' || p.status || '.');
  end if;

  v_score := least(100, v_score);
  v_level := case
    when v_score >= 70 then 'critical'
    when v_score >= 45 then 'high'
    when v_score >= 20 then 'medium'
    else 'low'
  end;

  return jsonb_build_object(
    'profile', jsonb_build_object(
      'id', p.id,
      'name', coalesce(nullif(p.full_name, ''), p.email),
      'email', p.email,
      'status', p.status,
      'admin_role', p.admin_role,
      'is_worker', p.is_worker,
      'is_buyer', p.is_buyer,
      'trust_score', p.trust_score,
      'created_at', p.created_at,
      'telegram_linked', p.telegram_id is not null
    ),
    'wallet', jsonb_build_object(
      'available', coalesce(w.available, 0),
      'pending', coalesce(w.pending, 0),
      'reserved', coalesce(w.reserved, 0),
      'lifetime_earned', coalesce(w.lifetime_earned, 0),
      'lifetime_withdrawn', coalesce(w.lifetime_withdrawn, 0),
      'frozen', coalesce(w.frozen, false),
      'frozen_reason', w.frozen_reason
    ),
    'suspension', jsonb_build_object(
      'kind', p.suspension_kind,
      'reason', p.suspension_reason,
      'expires_at', p.suspension_expires_at,
      'withdrawals_blocked', p.withdrawals_blocked
    ),
    'signals', jsonb_build_object(
      'duplicate_proofs', v_dups,
      'rejected_7d', v_rejected_7d,
      'rejected_30d', v_rejected_30d,
      'submitted_30d', v_submitted_30d,
      'withdrawals_24h', v_withdrawals_24h,
      'withdrawals_7d', v_withdrawals_7d,
      'referrals_7d', v_referrals_7d,
      'logins_7d', v_logins_7d,
      'devices_30d', v_devices_30d,
      'linked_accounts', v_linked_accounts,
      'login_recording', to_regclass('public.login_events') is not null
    ),
    'score', v_score,
    'level', v_level,
    'reasons', v_reasons,
    'flags', v_flags,
    'notes', v_notes,
    'policy', 'Signals and a rule-based score. Never an automatic ban, freeze or payout decision.'
  );
end $$;

revoke all on function public.admin_risk_profile(uuid) from public, anon;
grant execute on function public.admin_risk_profile(uuid) to authenticated;


-- ============================================================================
-- 4. RISK BOARD — users with real recorded signals, highest first
-- ============================================================================
create or replace function public.admin_risk_board(
  p_limit int default 25, p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  with suspects as (
    select f.user_id, count(*)::int as flag_count, max(f.severity)::int as max_severity,
           max(f.created_at) as last_flag_at
      from public.fraud_flags f
     where f.user_id is not null and f.status in ('open', 'reviewing')
     group by f.user_id
    union all
    select s.worker_id, count(*)::int, 2, max(s.created_at)
      from public.submissions s
     where s.proof_hash is not null
       and exists (select 1 from public.submissions s2
                    where s2.proof_hash = s.proof_hash and s2.id <> s.id)
     group by s.worker_id
    union all
    select s.worker_id, count(*)::int, 2, max(coalesce(s.reviewed_at, s.created_at))
      from public.submissions s
     where s.status = 'rejected' and coalesce(s.reviewed_at, s.created_at) >= now() - interval '7 days'
     group by s.worker_id
    having count(*) >= 3
    union all
    select w.user_id, count(*)::int, 2, max(w.created_at)
      from public.withdrawals w
     where w.created_at >= now() - interval '24 hours'
     group by w.user_id
    having count(*) >= 3
  ),
  merged as (
    select user_id,
           sum(flag_count)::int as signals,
           max(max_severity)::int as max_severity,
           max(last_flag_at) as last_signal_at
      from suspects
     where user_id is not null
     group by user_id
  ),
  paged as (
    select * from merged
     order by max_severity desc, signals desc, last_signal_at desc
     limit greatest(1, least(coalesce(p_limit, 25), 100))
    offset greatest(0, coalesce(p_offset, 0))
  )
  select
    (select count(*) from merged),
    coalesce(jsonb_agg(jsonb_build_object(
      'user_id', m.user_id,
      'name', coalesce(nullif(p.full_name, ''), p.email, 'User'),
      'email', p.email,
      'status', p.status,
      'trust_score', p.trust_score,
      'signals', m.signals,
      'max_severity', m.max_severity,
      'last_signal_at', m.last_signal_at,
      'open_flags', (select count(*) from public.fraud_flags f
                      where f.user_id = m.user_id and f.status in ('open', 'reviewing')),
      'wallet_frozen', coalesce(w.frozen, false)
    ) order by m.max_severity desc, m.signals desc, m.last_signal_at desc), '[]'::jsonb)
    into v_total, v_items
    from paged m
    left join public.profiles p on p.id = m.user_id
    left join public.wallets w on w.user_id = m.user_id;

  return jsonb_build_object(
    'items', v_items,
    'total', v_total,
    'policy', 'Recorded signals only. Human review decides.'
  );
end $$;

revoke all on function public.admin_risk_board(int, int) from public, anon;
grant execute on function public.admin_risk_board(int, int) to authenticated;


notify pgrst, 'reload schema';

commit;
