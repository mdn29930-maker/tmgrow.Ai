-- ============================================================================
-- TM GROW — SMM DRIP FIX (release alerts, cron auth, worker feed)
--
-- Idempotent, additive. Run AFTER supabase/smm-drip.sql.
-- Nothing is dropped, reset or deleted. No wallet or ledger row is touched.
--
-- What was actually broken (verified by reading the deployed functions):
--   1. smm_drip_release() created tasks and returned a count, but it never
--      wrote a single notification row and never called telegram_enqueue().
--      So no "batch released" alert could ever exist, in-app or Telegram.
--   2. smm_drip_scheduled() impersonated an OWNER profile to pass the role
--      check. With no active OWNER/SUPER_ADMIN row it returned
--      NO_ACTIVE_OWNER and released nothing, silently.
--   3. The worker Task Bag (/tasks) calls list_available_tasks(), which INNER
--      JOINs campaigns. SMM tasks have campaign_id NULL, so they could never
--      appear there even when they existed.
--   4. A worker whose proof was rejected could claim the replacement unit of
--      the same order again.
--
-- New supporting objects (not duplicates of anything that exists):
--   * public.smm_release_events — one row per released seq range; the unique
--     (order_id, first_seq, last_seq) key makes a duplicate release
--     announcement impossible and gives the diagnostics a real trail.
-- ============================================================================

begin;

-- ============================================================================
-- 1. RELEASE EVENT TRAIL
-- ============================================================================
create table if not exists public.smm_release_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.smm_orders (id) on delete cascade,
  first_seq int not null check (first_seq > 0),
  last_seq int not null check (last_seq >= first_seq),
  released int not null check (released > 0),
  created_at timestamptz not null default now(),
  constraint smm_release_events_range_key unique (order_id, first_seq, last_seq)
);

alter table public.smm_release_events enable row level security;

create index if not exists smm_release_events_recent_idx
  on public.smm_release_events (created_at desc);

create index if not exists notifications_kind_recent_idx
  on public.notifications (kind, created_at desc);

-- ============================================================================
-- 2. SETTINGS + TELEGRAM TEMPLATE
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('smm_release_notifications', 'true'::jsonb, false),
  ('smm_notify_worker_limit', '200'::jsonb, false),
  ('smm_notify_min_gap_minutes', '15'::jsonb, false),
  ('telegram_tpl_smm_batch', to_jsonb($tpl$🚀 New TM GROW tasks are live

{{batches}}

Reward: from {{reward}} USDT per task · {{total}} unit(s) in total

Open the app → SMM tasks to claim yours.$tpl$::text), false)
on conflict (key) do nothing;


-- ============================================================================
-- 3. RELEASE: real notifications, docker-proof auth, duplicate-proof events
-- ============================================================================
create or replace function public.smm_drip_release(p_order_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.smm_orders;
  s public.services;
  v_open int;
  v_remaining int;
  v_batch int;
  v_today int;
  v_released int := 0;
  v_skipped int := 0;
  v_orders int := 0;
  v_worker_reward numeric;
  v_seq int;
  v_first int;
  v_event uuid;
  v_last_event uuid;
  v_notified int := 0;
  v_tg int := 0;
  v_notify boolean := public.setting_bool('smm_release_notifications', true);
  v_limit int;
  v_gap int;
  v_lines text[] := '{}'::text[];
  v_batches_text text;
  v_reward_min numeric;
  v_reward_max numeric;
  v_reward_text text;
  v_targets uuid[] := '{}'::uuid[];
  v_w uuid;
  i int;
begin
  /* Trusted callers only: pg_cron runs with no JWT at all (auth.uid() is
     null), service_role is trusted, and an admin is allowed to press the
     button. A signed-in non-admin is refused. This removes the old
     dependency on finding an active OWNER profile. */
  if auth.uid() is not null
     and auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  v_limit := greatest(1, least(coalesce(public.setting_num('smm_notify_worker_limit', 100), 100)::int, 300));
  v_gap := greatest(0, coalesce(public.setting_num('smm_notify_min_gap_minutes', 15), 15)::int);

  for o in
    select * from public.smm_orders
     where (p_order_id is null or id = p_order_id)
       and drip_enabled and not drip_paused
       and status in ('pending', 'processing')
       and completed_quantity < quantity
       and (p_order_id is not null or next_release_at <= now())
     order by created_at
     for update skip locked
  loop
    v_orders := v_orders + 1;

    select * into s from public.services where id = o.service_id;
    v_worker_reward := coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot);

    if v_worker_reward is null or v_worker_reward <= 0 then
      update public.smm_orders
         set admin_note = 'Fulfilment blocked: worker reward per 1K is not configured for this service.',
             drip_paused = true
       where id = o.id;
      v_skipped := v_skipped + 1;
      continue;
    end if;

    select count(*) into v_open
      from public.tasks
     where smm_order_id = o.id and status in ('available', 'claimed', 'submitted');

    v_remaining := o.quantity - o.completed_quantity - v_open;
    if v_remaining <= 0 then
      update public.smm_orders
         set next_release_at = now() + make_interval(mins => greatest(1, o.drip_interval_minutes))
       where id = o.id;
      continue;
    end if;

    select count(*) into v_today
      from public.tasks
     where smm_order_id = o.id and released_at >= date_trunc('day', now());
    v_today := greatest(0, o.drip_daily_limit - v_today);

    v_batch := least(o.drip_batch_size, v_remaining, greatest(0, o.drip_max_active - v_open), v_today);
    if v_batch <= 0 then
      update public.smm_orders
         set next_release_at = now() + make_interval(mins => greatest(1, o.drip_interval_minutes))
       where id = o.id;
      continue;
    end if;

    /* One released task = one unit. The reward is the configured per-1K rate
       divided by 1000, never below the tasks.reward minimum. */
    v_seq := o.issued_quantity;
    v_first := v_seq + 1;
    for i in 1..v_batch loop
      v_seq := v_seq + 1;
      insert into public.tasks (campaign_id, smm_order_id, seq, status, reward, released_at)
      values (null, o.id, v_seq, 'available',
              greatest(round(v_worker_reward / 1000.0, 6), 0.000001), now());
    end loop;

    /* One row per released seq range. A repeated call can never announce or
       count the same units twice. */
    v_event := null;
    insert into public.smm_release_events (order_id, first_seq, last_seq, released)
    values (o.id, v_first, v_seq, v_batch)
    on conflict on constraint smm_release_events_range_key do nothing
    returning id into v_event;

    update public.smm_orders
       set issued_quantity = v_seq,
           worker_reward_snapshot = v_worker_reward,
           status = case when status = 'pending' then 'processing' else status end,
           last_release_at = now(),
           next_release_at = now() + make_interval(mins => greatest(1, drip_interval_minutes)),
           processed_at = coalesce(processed_at, now())
     where id = o.id;

    v_released := v_released + v_batch;

    if v_event is not null then
      v_last_event := v_event;
      v_reward_min := least(coalesce(v_reward_min, v_worker_reward), v_worker_reward);
      v_reward_max := greatest(coalesce(v_reward_max, v_worker_reward), v_worker_reward);
      v_lines := v_lines || (
        s.name || ' · ' || initcap(coalesce(s.platform, 'social')) || ' · ' ||
        v_batch || ' unit(s) · ' ||
        public.telegram_money(greatest(round(v_worker_reward / 1000.0, 6), 0.000001)) || ' USDT each'
      );
    end if;

    perform public.audit('smm_drip.release', 'smm_order', o.id,
      jsonb_build_object('released', v_batch, 'issued', v_seq,
                         'first_seq', v_first, 'open_before', v_open,
                         'worker_reward_per_1000', v_worker_reward));
  end loop;

  /* ---- One aggregated alert per release run -------------------------- */
  if v_released > 0 and v_notify and coalesce(array_length(v_lines, 1), 0) > 0 then
    select coalesce(array_agg(q.id), '{}'::uuid[]) into v_targets
      from (
        select w.id
          from public.profiles w
         where w.is_worker
           and w.status = 'active'
           and not exists (
             select 1 from public.notifications n
              where n.user_id = w.id
                and n.kind = 'smm_release'
                and n.created_at > now() - make_interval(mins => v_gap)
           )
         order by w.created_at desc
         limit v_limit
      ) q;

    if coalesce(array_length(v_targets, 1), 0) > 0 then
      v_batches_text := array_to_string(v_lines[1:least(6, array_length(v_lines, 1))], E'\n');
      if array_length(v_lines, 1) > 6 then
        v_batches_text := v_batches_text || E'\n+' || (array_length(v_lines, 1) - 6) || ' more batch(es)';
      end if;
      v_reward_text := public.telegram_money(greatest(round(coalesce(v_reward_min, 0) / 1000.0, 6), 0.000001));

      insert into public.notifications (user_id, title, body, kind, link)
      select t.user_id,
             'New SMM tasks available',
             v_released || ' new unit(s) released.' || E'\n' || v_batches_text,
             'smm_release',
             '#/smm-tasks'
        from unnest(v_targets) as t(user_id);

      v_notified := array_length(v_targets, 1);

      foreach v_w in array v_targets loop
        if public.telegram_enqueue(
             v_w,
             'smm_batch',
             jsonb_build_object(
               'batches', v_batches_text,
               'reward', v_reward_text,
               'total', v_released
             ),
             'smm_batch:' || coalesce(v_last_event::text, 'run') || ':' || v_w::text
           ) is not null then
          v_tg := v_tg + 1;
        end if;
      end loop;
    end if;
  end if;

  perform public.audit('smm_drip.run', 'smm_order', p_order_id,
    jsonb_build_object('released', v_released, 'skipped', v_skipped,
                       'orders_checked', v_orders, 'notified', v_notified,
                       'telegram_queued', v_tg,
                       'from_cron', auth.uid() is null));

  return jsonb_build_object(
    'ok', true,
    'released', v_released,
    'skipped', v_skipped,
    'orders_checked', v_orders,
    'notified', v_notified,
    'telegram_queued', v_tg
  );
end $$;

revoke all on function public.smm_drip_release(uuid) from public, anon, authenticated;


-- ============================================================================
-- 4. SCHEDULER: no owner impersonation, errors captured, every run logged
-- ============================================================================
create or replace function public.smm_drip_scheduled()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_res jsonb;
  v_err text;
begin
  begin
    v_res := public.smm_drip_release(null);
  exception when others then
    v_err := sqlerrm;
  end;

  if v_err is not null then
    perform public.audit('smm_drip.run', 'smm_order', null,
      jsonb_build_object('error', v_err, 'from_cron', auth.uid() is null));
    return jsonb_build_object('ok', false, 'error', v_err);
  end if;

  return coalesce(v_res, jsonb_build_object('ok', true));
end $$;

revoke all on function public.smm_drip_scheduled() from public, anon, authenticated;

/* Re-schedule so the job points at the fixed function. cron.schedule updates
   an existing job with the same name. */
do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-smm-drip', '* * * * *',
      $cron$select public.smm_drip_scheduled();$cron$);
    raise notice 'pg_cron: tmgrow-smm-drip scheduled every minute.';
  else
    raise notice 'pg_cron missing: use Admin → SMM orders & drip → Release batch now.';
  end if;
end $$;


-- ============================================================================
-- 5. WORKER FEED: rejected-order guard + full task bag fields
-- ============================================================================
create or replace function public.smm_worker_feed(p_limit int default 20)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  items jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;

  select coalesce(jsonb_agg(x order by sort_reward desc, sort_created desc), '[]'::jsonb)
    into items
    from (
      select jsonb_build_object(
               'id', t.id,
           'reward', t.reward,
           'created_at', t.created_at,
           'seq', t.seq,
           'smm_order_id', o.id,
           'order_short', upper(substr(replace(o.id::text, '-', ''), 1, 8)),
           'title', s.name,
           'service_name', s.name,
           'platform', s.platform,
           'instructions_preview', left(coalesce(s.description, ''), 200),
           'target_url', o.target_link,
           'reward_per_1000', coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot),
           'quantity_left', (select count(*) from public.tasks t2
                              where t2.smm_order_id = o.id and t2.status = 'available')
             ) as x,
             t.reward as sort_reward,
             t.created_at as sort_created
        from public.tasks t
        join public.smm_orders o on o.id = t.smm_order_id
        join public.services s on s.id = o.service_id
       where t.status = 'available'
         and t.worker_id is null
         and o.status in ('pending', 'processing')
         and not o.drip_paused
         and s.platform is not null
         and p.is_worker
         and p.status = 'active'
         /* A worker whose proof was rejected or whose claim expired on this
            order does not see that order again. Other workers still do. */
         and not exists (
           select 1 from public.tasks prev
            where prev.smm_order_id = o.id
              and prev.worker_id = u
              and prev.status in ('rejected', 'expired')
         )
       order by t.reward desc, t.created_at
       limit greatest(1, least(coalesce(p_limit, 20), 50))
    ) q;

  return jsonb_build_object('items', items);
end $$;

revoke all on function public.smm_worker_feed(int) from public, anon;
grant execute on function public.smm_worker_feed(int) to authenticated;


-- ============================================================================
-- 6. CLAIM: same guard server-side (the feed is not the only door)
-- ============================================================================
create or replace function public.smm_claim_task(p_task_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  p public.profiles;
  o public.smm_orders;
  mins int;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_worker then raise exception 'WORKER_MODE_DISABLED'; end if;

  if (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')) >= 25 then
    raise exception 'TOO_MANY_ACTIVE_TASKS';
  end if;

  select * into t from public.tasks where id = p_task_id and smm_order_id is not null for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status <> 'available' or t.worker_id is not null then raise exception 'TASK_UNAVAILABLE'; end if;

  select * into o from public.smm_orders where id = t.smm_order_id;
  if o.status not in ('pending', 'processing') or o.drip_paused then raise exception 'ORDER_NOT_ACTIVE'; end if;

  if exists (
    select 1 from public.tasks prev
     where prev.smm_order_id = o.id
       and prev.worker_id = u
       and prev.status in ('rejected', 'expired')
  ) then
    raise exception 'SMM_ORDER_LOCKED';
  end if;

  mins := greatest(5, least(coalesce(public.setting_num('claim_window_minutes', 30), 30), 240));
  update public.tasks
     set worker_id = u, status = 'claimed', claimed_at = now(),
         expires_at = now() + make_interval(mins => mins)
   where id = t.id and status = 'available' and worker_id is null;
  if not found then raise exception 'TASK_UNAVAILABLE'; end if;

  return jsonb_build_object('ok', true, 'task_id', t.id,
                            'expires_at', now() + make_interval(mins => mins));
end $$;

revoke all on function public.smm_claim_task(uuid) from public, anon;
grant execute on function public.smm_claim_task(uuid) to authenticated;


-- ============================================================================
-- 7. DIAGNOSTICS (admin only, read-only)
-- ============================================================================
create or replace function public.admin_smm_diag()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_job jsonb;
  v_last jsonb;
  v_last_error jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  begin
    select to_jsonb(j) into v_job from cron.job j
     where j.jobname = 'tmgrow-smm-drip' limit 1;
  exception when others then
    v_job := null;
  end;

  select jsonb_build_object('at', a.created_at, 'action', a.action,
                            'actor', a.actor_id, 'details', a.details)
    into v_last
    from public.audit_logs a
   where a.action = 'smm_drip.run'
   order by a.created_at desc limit 1;

  select jsonb_build_object('at', a.created_at, 'error', a.details ->> 'error')
    into v_last_error
    from public.audit_logs a
   where a.action = 'smm_drip.run'
     and a.details ? 'error'
   order by a.created_at desc limit 1;

  return jsonb_build_object(
    'server_time', now(),
    'cron_installed', to_regclass('cron.job') is not null,
    'cron_job', v_job,
    'last_run', v_last,
    'last_error', v_last_error,
    'release_notifications_enabled', public.setting_bool('smm_release_notifications', true),
    'telegram_bot_enabled', public.setting_bool('telegram_bot_enabled', false),
    'orders_total', (select count(*) from public.smm_orders),
    'orders_open', (select count(*) from public.smm_orders where status in ('pending','processing')),
    'orders_paused', (select count(*) from public.smm_orders where drip_paused),
    'orders_eligible_now', (select count(*) from public.smm_orders o
                             where o.drip_enabled and not o.drip_paused
                               and o.status in ('pending','processing')
                               and o.completed_quantity < o.quantity
                               and o.next_release_at <= now()),
    'orders_blocked_no_reward', (select count(*) from public.smm_orders o
                                  join public.services s on s.id = o.service_id
                                 where o.drip_enabled and not o.drip_paused
                                   and o.status in ('pending','processing')
                                   and coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot) is null),
    'units_available', (select count(*) from public.tasks where smm_order_id is not null and status = 'available'),
    'units_claimed', (select count(*) from public.tasks where smm_order_id is not null and status = 'claimed'),
    'units_submitted', (select count(*) from public.tasks where smm_order_id is not null and status = 'submitted'),
    'units_approved', (select count(*) from public.tasks where smm_order_id is not null and status = 'approved'),
    'units_rejected', (select count(*) from public.tasks where smm_order_id is not null and status = 'rejected'),
    'release_events_today', (select count(*) from public.smm_release_events where created_at >= date_trunc('day', now())),
    'notifications_today', (select count(*) from public.notifications
                             where kind = 'smm_release' and created_at >= date_trunc('day', now())),
    'telegram_rows_today', (select count(*) from public.telegram_outbox
                             where kind = 'smm_batch' and created_at >= date_trunc('day', now())),
    'active_workers', (select count(*) from public.profiles where is_worker and status = 'active'),
    'sample_pool', (select coalesce(jsonb_agg(jsonb_build_object(
                        'task_id', t.id, 'seq', t.seq, 'order_short',
                        upper(substr(replace(o.id::text, '-', ''), 1, 8)),
                        'service', s.name, 'platform', s.platform,
                        'reward', t.reward, 'order_status', o.status,
                        'drip_paused', o.drip_paused)), '[]'::jsonb)
                       from (
                         select * from public.tasks
                          where smm_order_id is not null and status = 'available'
                          order by created_at limit 5
                       ) t
                       join public.smm_orders o on o.id = t.smm_order_id
                       join public.services s on s.id = o.service_id)
  );
end $$;

revoke all on function public.admin_smm_diag() from public, anon;
grant execute on function public.admin_smm_diag() to authenticated;


notify pgrst, 'reload schema';

commit;
