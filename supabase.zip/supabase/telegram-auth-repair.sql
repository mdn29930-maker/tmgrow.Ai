-- ============================================================================
-- TM GROW — telegram-auth repair
-- Ensures the objects the Mini App login Edge Function depends on exist.
-- Safe to run more than once; nothing is dropped and no data is reset.
-- Supabase → SQL Editor → paste → Run
-- ============================================================================

begin;

-- 1. Stable Telegram identity per auth user -----------------------------------
alter table public.profiles add column if not exists telegram_id bigint;

create unique index if not exists profiles_telegram_id_key
  on public.profiles (telegram_id) where telegram_id is not null;

-- 2. Telegram → Supabase user mapping -----------------------------------------
create table if not exists public.telegram_users (
  telegram_id bigint primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  username text,
  first_name text,
  last_name text,
  photo_url text,
  language_code text,
  created_at timestamptz not null default now(),
  last_login_at timestamptz not null default now()
);

create index if not exists telegram_users_user_idx on public.telegram_users (user_id);

-- Written only by the service role. No policies = no browser access.
alter table public.telegram_users enable row level security;

-- 3. Recovery helper used when the auth user already exists but the mapping
--    row was lost. Service role only: it can look up any profile by email.
create or replace function public.telegram_user_id_by_email(p_email text)
returns uuid language sql stable security definer set search_path = public as $$
  select p.id from public.profiles p where lower(p.email) = lower(trim(p_email)) limit 1;
$$;

revoke all on function public.telegram_user_id_by_email(text) from public, anon, authenticated;
grant execute on function public.telegram_user_id_by_email(text) to service_role;

-- 4. Refresh PostgREST
notify pgrst, 'reload schema';

commit;
