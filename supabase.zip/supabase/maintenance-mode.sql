-- ============================================================================
-- TM GROW — SMART MAINTENANCE MODE (additive, idempotent)
-- Review only: the agent has executed nothing.
--
-- Reuses the existing settings table, audit_logs, notifications and the
-- database-native Telegram outbox (telegram_enqueue). No new bot, no Edge
-- Function, no duplicate table. Wallet, ledger, tasks and orders untouched.
-- ============================================================================

begin;

insert into public.settings (key, value, is_public) values
  ('maintenance', 'false'::jsonb, true),
  ('maintenance_scope', to_jsonb('all'::text), true),
  ('maintenance_start_at', 'null'::jsonb, true),
  ('maintenance_end_at', 'null'::jsonb, true),
  ('maintenance_tz', to_jsonb('Asia/Dhaka'::text), true),
  ('maintenance_short', to_jsonb('TM GROW is currently undergoing scheduled maintenance to improve your experience. We expect services to be restored soon. Thank you for your patience!'::text), true),
  ('maintenance_detail', to_jsonb(''::text), true),
  ('maintenance_updated_at', 'null'::jsonb, true)
on conflict (key) do nothing;

insert into public.settings (key, value, is_public) values
  ('telegram_tpl_maintenance_start', to_jsonb($tpl$🛠 Scheduled maintenance

{{message}}

Starts: {{start}}
Expected back: {{end}} ({{tz}})

Service updates continue in the app.$tpl$::text), false),
  ('telegram_tpl_maintenance_end', to_jsonb($tpl$✅ TM GROW is back online

Maintenance finished. All balances, tasks and orders are intact.

Thank you for your patience.$tpl$::text), false)
on conflict (key) do nothing;

-- ---------------------------------------------------------------------------
-- Admin control
-- ---------------------------------------------------------------------------
create or replace function public.admin_maintenance_set(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_enabled boolean := coalesce((p_payload ->> 'enabled')::boolean, false);
  v_scope text := lower(coalesce(nullif(btrim(p_payload ->> 'scope'), ''), 'all'));
  v_start timestamptz := nullif(btrim(coalesce(p_payload ->> 'start_at', '')), '')::timestamptz;
  v_end timestamptz := nullif(btrim(coalesce(p_payload ->> 'end_at', '')), '')::timestamptz;
  v_tz text := coalesce(nullif(btrim(p_payload ->> 'timezone'), ''), 'Asia/Dhaka');
  v_short text := left(coalesce(nullif(btrim(p_payload ->> 'short_message'), ''), ''), 600);
  v_detail text := left(coalesce(p_payload ->> 'detail_message', ''), 3000);
  v_was boolean := public.setting_bool('maintenance', false);
  v_old_end timestamptz;
  v_targets uuid[];
  v_key text;
  v_w uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if v_scope not in ('all','worker','buyer') then raise exception 'INVALID_SCOPE'; end if;
  if v_enabled and v_end is not null and v_start is not null and v_end <= v_start then
    raise exception 'INVALID_SCHEDULE';
  end if;
  if v_enabled and v_end is not null and v_end <= now() then
    raise exception 'INVALID_SCHEDULE';
  end if;

  v_old_end := nullif(public.setting_text('maintenance_end_at', ''), '')::timestamptz;

  insert into public.settings (key, value, is_public)
  values ('maintenance', to_jsonb(v_enabled), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_scope', to_jsonb(v_scope), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_start_at', to_jsonb(case when v_start is null then null else v_start::text end), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_end_at', to_jsonb(case when v_end is null then null else v_end::text end), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_tz', to_jsonb(v_tz), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_short', to_jsonb(v_short), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_detail', to_jsonb(v_detail), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();
  insert into public.settings (key, value, is_public)
  values ('maintenance_updated_at', to_jsonb(now()::text), true)
  on conflict (key) do update set value = excluded.value, updated_at = now();

  perform public.audit('maintenance.set', 'setting', null,
    jsonb_build_object('enabled', v_enabled, 'scope', v_scope, 'start', v_start,
                       'end', v_end, 'timezone', v_tz, 'was_enabled', v_was,
                       'actor', auth.uid()));

  /* One Telegram event per schedule change, never per refresh. New maintenance
     or an extension produces a distinct dedupe key. */
  if v_enabled and (not v_was or v_end is distinct from v_old_end) then
    v_key := 'maintenance:' || coalesce(v_end::text, 'open') || ':' || coalesce(v_start::text, 'now');

    select coalesce(array_agg(id), '{}'::uuid[]) into v_targets
      from (select id from public.profiles where status = 'active' order by created_at desc limit 500) p;

    if coalesce(array_length(v_targets, 1), 0) > 0 then
      insert into public.notifications (user_id, title, body, kind, link)
      select t.id, 'Scheduled maintenance', v_short, 'info', '#/notifications'
        from unnest(v_targets) as t(id);

      foreach v_w in array v_targets loop
        perform public.telegram_enqueue(
          v_w, 'maintenance_start',
          jsonb_build_object(
            'message', v_short,
            'start', to_char(coalesce(v_start, now()) at time zone v_tz, 'DD Mon YYYY HH24:MI'),
            'end', case when v_end is null then 'to be announced'
                        else to_char(v_end at time zone v_tz, 'DD Mon YYYY HH24:MI') end,
            'tz', v_tz
          ),
          v_key || ':' || v_w::text
        );
      end loop;
    end if;
  end if;

  return jsonb_build_object('ok', true, 'enabled', v_enabled, 'scope', v_scope,
                            'end_at', v_end, 'notified', coalesce(array_length(v_targets, 1), 0));
end $$;

revoke all on function public.admin_maintenance_set(jsonb) from public, anon;
grant execute on function public.admin_maintenance_set(jsonb) to authenticated;

-- ---------------------------------------------------------------------------
-- Automatic expiry (pg_cron, no admin needed)
-- ---------------------------------------------------------------------------
create or replace function public.maintenance_auto_end()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_end timestamptz;
  v_targets uuid[];
  v_w uuid;
  v_key text;
begin
  if auth.uid() is not null and auth.role() is distinct from 'service_role' then
    raise exception 'FORBIDDEN';
  end if;
  if not public.setting_bool('maintenance', false) then
    return jsonb_build_object('ok', true, 'skipped', 'NOT_ACTIVE');
  end if;

  v_end := nullif(public.setting_text('maintenance_end_at', ''), '')::timestamptz;
  if v_end is null or v_end > now() then
    return jsonb_build_object('ok', true, 'skipped', 'NOT_DUE', 'end_at', v_end);
  end if;

  v_key := 'maintenance_end:' || v_end::text;

  update public.settings set value = to_jsonb(false), updated_at = now() where key = 'maintenance';

  select coalesce(array_agg(id), '{}'::uuid[]) into v_targets
    from (select id from public.profiles where status = 'active' order by created_at desc limit 500) p;

  if coalesce(array_length(v_targets, 1), 0) > 0 then
    insert into public.notifications (user_id, title, body, kind, link)
    select t.id, 'TM GROW is back online', 'Maintenance finished. All balances, tasks and orders are intact.', 'success', '#/dashboard'
      from unnest(v_targets) as t(id);
    foreach v_w in array v_targets loop
      perform public.telegram_enqueue(v_w, 'maintenance_end', '{}'::jsonb, v_key || ':' || v_w::text);
    end loop;
  end if;

  perform public.audit('maintenance.auto_end', 'setting', null,
    jsonb_build_object('end_at', v_end, 'notified', coalesce(array_length(v_targets, 1), 0)));
  return jsonb_build_object('ok', true, 'ended', true, 'notified', coalesce(array_length(v_targets, 1), 0));
end $$;

revoke all on function public.maintenance_auto_end() from public, anon, authenticated;

create or replace function public.maintenance_status()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'enabled', public.setting_bool('maintenance', false),
    'scope', coalesce(nullif(public.setting_text('maintenance_scope', ''), ''), 'all'),
    'start_at', public.setting_text('maintenance_start_at', ''),
    'end_at', public.setting_text('maintenance_end_at', ''),
    'timezone', coalesce(nullif(public.setting_text('maintenance_tz', ''), ''), 'Asia/Dhaka'),
    'short_message', coalesce(public.setting_text('maintenance_short', ''), ''),
    'detail_message', coalesce(public.setting_text('maintenance_detail', ''), ''),
    'updated_at', public.setting_text('maintenance_updated_at', ''),
    'server_time', now()
  );
$$;

revoke all on function public.maintenance_status() from public, anon;
grant execute on function public.maintenance_status() to authenticated, anon;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-maintenance', '* * * * *',
      $cron$select public.maintenance_auto_end();$cron$);
    raise notice 'pg_cron: tmgrow-maintenance every minute.';
  end if;
end $$;

notify pgrst, 'reload schema';

commit;
