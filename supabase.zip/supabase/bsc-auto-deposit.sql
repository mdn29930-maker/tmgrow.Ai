-- ============================================================================
-- TM GROW — AUTOMATIC BEP-20 USDT DEPOSITS (Etherscan API V2, chainid 56)
--
-- READ-ONLY DESIGN MIGRATION — RUN ONLY AFTER REVIEW. Nothing here is executed
-- by the agent. No wallet, ledger, deposit or auth row is modified by running
-- this file: it only adds objects and settings. The first credit can only
-- happen when the cron tick finds a real, confirmed, matched on-chain transfer.
--
-- Security model
--   * The browser is never trusted for an amount, a hash or a user.
--   * Credits are created only by bsc_credit_transfer(), from a transfer row
--     that was discovered by the server-side watcher, receipt-verified,
--     confirmation-checked and matched to a registered deposit intent.
--   * tx_hash is unique in public.deposits; credit runs once under FOR UPDATE.
--   * The API key lives only in Vault (bscscan_api_key).
--
-- Matching model (no per-user private keys, no HD wallet)
--   The platform keeps its existing single deposit address. A buyer records a
--   deposit intent BEFORE sending, with the BEP-20 address they will send from.
--   A transfer is credited only when its `from` matches an open intent. Anything
--   else is stored as unmatched for an admin to resolve — never auto-credited.
--
-- API calls (Etherscan V2, one key for every chain)
--   POST-less GET https://api.etherscan.io/v2/api
--     ?chainid=56&module=account&action=tokentx
--     &address=<deposit>&contractaddress=<USDT>
--     &startblock=&endblock=&page=1&offset=100&sort=asc&apikey=<key>
--     ?chainid=56&module=proxy&action=eth_getTransactionReceipt&txhash=<hash>&apikey=<key>
--     ?chainid=56&module=proxy&action=eth_blockNumber&apikey=<key>
-- ============================================================================

begin;

-- ============================================================================
-- 1. SETTINGS
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('bsc_auto_deposit_enabled', 'false'::jsonb, false),
  ('bscscan_api_base', to_jsonb('https://api.etherscan.io/v2/api'::text), false),
  ('bsc_watch_lookback_blocks', '50000'::jsonb, false),
  ('bsc_watch_batch', '5'::jsonb, false),
  ('deposit_confirmations', '12'::jsonb, true)
on conflict (key) do nothing;

-- The official Binance-Peg BSC-USD (USDT) contract. Verified independently by
-- the watcher from tokenSymbol/tokenDecimal on every transfer, not assumed.
insert into public.settings (key, value, is_public) values
  ('usdt_contract', to_jsonb('0x55d398326f99059ff775485246999027b3197955'::text), true)
on conflict (key) do nothing;

-- ============================================================================
-- 2. DEPOSIT INTENTS (who is sending, from which address, before they send)
-- ============================================================================
create table if not exists public.deposit_intents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  from_address text not null,
  expected_amount numeric(18, 6) check (expected_amount is null or expected_amount > 0),
  status text not null default 'open'
    check (status in ('open', 'used', 'expired', 'cancelled')),
  used_transfer_id uuid,
  expires_at timestamptz not null default now() + interval '24 hours',
  created_at timestamptz not null default now(),
  constraint deposit_intents_from_lower check (from_address = lower(from_address))
);

create unique index if not exists deposit_intents_open_from_key
  on public.deposit_intents (from_address)
  where status = 'open';

create index if not exists deposit_intents_user_idx
  on public.deposit_intents (user_id, created_at desc);

alter table public.deposit_intents enable row level security;

-- ============================================================================
-- 3. WATCHER STATE + DISCOVERED TRANSFERS
-- ============================================================================
create table if not exists public.bsc_watch_state (
  id int primary key default 1 check (id = 1),
  last_block bigint not null default 0,
  phase text not null default 'init' check (phase in ('init', 'tokentx', 'idle')),
  request_id bigint,
  last_run_at timestamptz,
  last_error text,
  updated_at timestamptz not null default now()
);

insert into public.bsc_watch_state (id) values (1) on conflict (id) do nothing;

create table if not exists public.bsc_transfers (
  id uuid primary key default gen_random_uuid(),
  tx_hash text not null,
  from_address text not null,
  to_address text not null,
  contract_address text not null,
  token_symbol text,
  token_decimal int,
  value_raw numeric(78, 0) not null,
  amount numeric(18, 6) not null,
  block_number bigint not null,
  confirmations int,
  receipt_request_id bigint,
  receipt_status text,
  status text not null default 'detected'
    check (status in ('detected', 'receipt_sent', 'confirmed', 'credited', 'unmatched', 'failed')),
  user_id uuid references public.profiles (id) on delete set null,
  intent_id uuid references public.deposit_intents (id) on delete set null,
  deposit_id uuid references public.deposits (id) on delete set null,
  error_text text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  /* tokentx does not return a log index. The stable dedupe key is the tx plus
     the exact transfer identity, so a re-scan can never insert or credit the
     same transfer twice. Two byte-identical transfers in one transaction are
     merged: under-crediting is resolved by an admin, double-crediting is not. */
  constraint bsc_transfers_unique unique (tx_hash, from_address, to_address, value_raw)
);

create index if not exists bsc_transfers_status_idx
  on public.bsc_transfers (status, created_at);
create index if not exists bsc_transfers_from_idx
  on public.bsc_transfers (from_address, created_at desc);

alter table public.bsc_transfers enable row level security;

-- Deposit rows created by the watcher gain a source pointer (no data change).
alter table public.deposits add column if not exists source_transfer_id uuid;
alter table public.deposits add column if not exists credit_source text;

-- ============================================================================
-- 4. HELPERS
-- ============================================================================
create or replace function public.bsc_secret(p_name text)
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v text;
begin
  if to_regclass('vault.decrypted_secrets') is null then return null; end if;
  execute 'select decrypted_secret from vault.decrypted_secrets where name = $1 limit 1'
    into v using p_name;
  return v;
end $$;

revoke all on function public.bsc_secret(text) from public, anon, authenticated;

create or replace function public.bsc_addr()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select lower(coalesce(nullif(public.setting_text('deposit_address', ''), ''),
                        nullif(public.setting_text('deposit_address_bep20', ''), '')));
$$;

revoke all on function public.bsc_addr() from public, anon, authenticated;

create or replace function public.bsc_usdt()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select lower(coalesce(nullif(public.setting_text('usdt_contract', ''), ''),
                        '0x55d398326f99059ff775485246999027b3197955'));
$$;

revoke all on function public.bsc_usdt() from public, anon, authenticated;

-- Safe raw-value -> token amount using the token's own decimals from the API.
create or replace function public.bsc_token_amount(p_raw numeric, p_decimals int)
returns numeric
language sql
immutable
as $$
  select case
           when p_raw is null then 0
           when coalesce(p_decimals, 18) <= 0 then p_raw
           else round(p_raw / power(10::numeric, coalesce(p_decimals, 18)), 6)
         end;
$$;

revoke all on function public.bsc_token_amount(numeric, int) from public, anon, authenticated;


-- ============================================================================
-- 5. INTENT RPC (the buyer records the sending address before sending)
-- ============================================================================
create or replace function public.deposit_intent_create(
  p_from_address text,
  p_expected_amount numeric default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  v_addr text := lower(btrim(coalesce(p_from_address, '')));
  v_row public.deposit_intents;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;
  if v_addr !~ '^0x[0-9a-f]{40}$' then raise exception 'INVALID_BEP20_ADDRESS'; end if;
  if coalesce(public.bsc_addr(), '') = '' then
    raise exception 'DEPOSIT_ADDRESS_NOT_CONFIGURED';
  end if;
  if v_addr = public.bsc_addr() then raise exception 'INVALID_BEP20_ADDRESS'; end if;

  update public.deposit_intents
     set status = 'expired'
   where user_id = u and status = 'open' and expires_at < now();

  if exists (select 1 from public.deposit_intents
              where from_address = v_addr and status = 'open' and user_id <> u) then
    raise exception 'INTENT_ADDRESS_IN_USE';
  end if;

  insert into public.deposit_intents (user_id, from_address, expected_amount)
  values (u, v_addr, nullif(p_expected_amount, 0))
  on conflict (from_address) where status = 'open'
  do update set expected_amount = excluded.expected_amount,
                expires_at = now() + interval '24 hours'
  returning * into v_row;

  return jsonb_build_object('ok', true, 'intent_id', v_row.id, 'from_address', v_addr,
    'expires_at', v_row.expires_at);
end $$;

revoke all on function public.deposit_intent_create(text, numeric) from public, anon;
grant execute on function public.deposit_intent_create(text, numeric) to authenticated;


-- ============================================================================
-- 6. WATCHER: init → tokentx → receipt → confirm → credit
-- ============================================================================
create or replace function public.bsc_watch_tick()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.bsc_watch_state;
  v_key text := public.bsc_secret('bscscan_api_key');
  v_base text := coalesce(nullif(public.setting_text('bscscan_api_base', ''), ''), 'https://api.etherscan.io/v2/api');
  v_addr text := public.bsc_addr();
  v_usdt text := public.bsc_usdt();
  v_min numeric := greatest(0, coalesce(public.setting_num('min_deposit', 5), 5));
  v_conf int := greatest(1, coalesce(public.setting_num('deposit_confirmations', 12), 12)::int);
  v_batch int := greatest(1, least(coalesce(public.setting_num('bsc_watch_batch', 5), 5)::int, 10));
  v_lookback bigint := greatest(0, coalesce(public.setting_num('bsc_watch_lookback_blocks', 50000), 50000)::bigint);
  v_params jsonb;
  v_req bigint;
  v_raw record;
  v_body jsonb;
  v_items jsonb;
  v_item jsonb;
  v_occ int;
  v_raw_value numeric;
  v_dec int;
  v_amount numeric;
  v_ins int := 0;
  v_matched int := 0;
  v_credited int := 0;
  tr record;
  v_intent public.deposit_intents;
  v_dep public.deposits;
begin
  if auth.uid() is not null and auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if not public.setting_bool('bsc_auto_deposit_enabled', false) then
    return jsonb_build_object('ok', true, 'skipped', 'DISABLED');
  end if;
  if coalesce(v_key, '') = '' or coalesce(v_addr, '') = '' then
    return jsonb_build_object('ok', false, 'error', 'MISSING_KEY_OR_ADDRESS');
  end if;

  select * into st from public.bsc_watch_state where id = 1 for update;

  /* ---- poll an outstanding request ------------------------------------ */
  if st.request_id is not null then
    select * into v_raw from net._http_response where id = st.request_id;
    if v_raw.id is null then
      update public.bsc_watch_state set last_run_at = now(), updated_at = now() where id = 1;
      return jsonb_build_object('ok', true, 'waiting', true, 'phase', st.phase);
    end if;

    if v_raw.timed_out or coalesce(v_raw.status_code, 0) not between 200 and 299 then
      update public.bsc_watch_state
         set request_id = null, phase = 'idle', last_error = 'HTTP/Network: ' || coalesce(v_raw.error_msg, 'timeout'),
             last_run_at = now(), updated_at = now()
       where id = 1;
      return jsonb_build_object('ok', false, 'error', 'REQUEST_FAILED');
    end if;

    v_body := public.socify_json(v_raw.content);

    if st.phase = 'init' then
      update public.bsc_watch_state
         set last_block = greatest(0, (v_body ->> 'result')::bigint - v_lookback),
             request_id = null, phase = 'idle', last_error = null, updated_at = now()
       where id = 1;
      return jsonb_build_object('ok', true, 'initialised_block', (select last_block from public.bsc_watch_state where id = 1));
    end if;

    if st.phase = 'tokentx' then
      if (v_body ->> 'status') <> '1' or jsonb_typeof(v_body -> 'result') <> 'array' then
        update public.bsc_watch_state
           set request_id = null, phase = 'idle',
               last_error = left(coalesce(v_body ->> 'message', '') || ' ' || coalesce(v_body ->> 'result', ''), 300),
               updated_at = now()
         where id = 1;
        return jsonb_build_object('ok', false, 'error', 'API_NOT_OK');
      end if;

      v_items := v_body -> 'result';
      for v_item in select jsonb_array_elements(v_items) loop
        continue when lower(coalesce(v_item ->> 'to', '')) <> v_addr;
        continue when lower(coalesce(v_item ->> 'contractAddress', '')) <> v_usdt;
        continue when upper(coalesce(v_item ->> 'tokenSymbol', '')) <> 'USDT';

        v_dec := coalesce(nullif(v_item ->> 'tokenDecimal', '')::int, 18);
        v_raw_value := coalesce(nullif(v_item ->> 'value', '')::numeric, 0);
        if v_raw_value <= 0 then continue; end if;
        v_amount := public.bsc_token_amount(v_raw_value, v_dec);
        if v_amount <= 0 then continue; end if;

        insert into public.bsc_transfers (
          tx_hash, from_address, to_address, contract_address,
          token_symbol, token_decimal, value_raw, amount, block_number, confirmations
        ) values (
          lower(v_item ->> 'hash'), lower(v_item ->> 'from'), v_addr, v_usdt,
          upper(v_item ->> 'tokenSymbol'), v_dec, v_raw_value, v_amount,
          coalesce(nullif(v_item ->> 'blockNumber', '')::bigint, 0),
          coalesce(nullif(v_item ->> 'confirmations', '')::int, 0)
        )
        on conflict (tx_hash, from_address, to_address, value_raw) do nothing;
        v_ins := v_ins + 1;
      end loop;

      update public.bsc_watch_state
         set last_block = greatest(last_block, coalesce((
               select max(block_number) from public.bsc_transfers
                where created_at > now() - interval '10 minutes'), last_block)),
             request_id = null, phase = 'idle', last_run_at = now(), last_error = null, updated_at = now()
       where id = 1;
      return jsonb_build_object('ok', true, 'inserted', v_ins);
    end if;

    if st.phase = 'receipt' then
      update public.bsc_transfers
         set receipt_status = coalesce(v_body -> 'result' ->> 'status', '0x0'),
             receipt_request_id = null,
             status = case when coalesce(v_body -> 'result' ->> 'status', '0x0') = '0x1'
                           then 'confirmed' else 'failed' end,
             error_text = case when coalesce(v_body -> 'result' ->> 'status', '0x0') = '0x1'
                               then null else 'Transaction reverted on-chain' end,
             updated_at = now()
       where receipt_request_id = st.request_id;

      update public.bsc_watch_state set request_id = null, phase = 'idle', updated_at = now() where id = 1;
      return jsonb_build_object('ok', true, 'receipts_checked', 1);
    end if;
  end if;

  /* ---- send the receipt request for one detected transfer ------------- */
  select * into tr from public.bsc_transfers
   where status = 'detected' and receipt_request_id is null
   order by created_at limit 1 for update skip locked;

  if tr.id is not null then
    v_req := net.http_get(
      v_base,
      jsonb_build_object('chainid', '56', 'module', 'proxy',
                         'action', 'eth_getTransactionReceipt',
                         'txhash', tr.tx_hash, 'apikey', v_key),
      '{}'::jsonb, 20000);
    update public.bsc_transfers
       set status = 'receipt_sent', receipt_request_id = v_req, updated_at = now()
     where id = tr.id;
    update public.bsc_watch_state
       set request_id = v_req, phase = 'receipt', last_run_at = now(), updated_at = now()
     where id = 1;
    return jsonb_build_object('ok', true, 'receipt_requested', tr.tx_hash);
  end if;

  /* ---- send the scan request ------------------------------------------ */
  if st.last_block = 0 then
    v_req := net.http_get(v_base,
      jsonb_build_object('chainid', '56', 'module', 'proxy',
                         'action', 'eth_blockNumber', 'apikey', v_key),
      '{}'::jsonb, 20000);
    update public.bsc_watch_state set request_id = v_req, phase = 'init', updated_at = now() where id = 1;
    return jsonb_build_object('ok', true, 'initialising', true);
  end if;

  v_params := jsonb_build_object(
    'chainid', '56', 'module', 'account', 'action', 'tokentx',
    'address', v_addr, 'contractaddress', v_usdt,
    'startblock', st.last_block + 1, 'endblock', 999999999,
    'page', 1, 'offset', 100, 'sort', 'asc', 'apikey', v_key);

  v_req := net.http_get(v_base, v_params, '{}'::jsonb, 20000);
  update public.bsc_watch_state
     set request_id = v_req, phase = 'tokentx', last_run_at = now(), updated_at = now()
   where id = 1;

  /* ---- credit confirmed transfers (exactly once) ----------------------- */
  for tr in
    select * from public.bsc_transfers
     where status = 'confirmed' and deposit_id is null
     order by block_number
     limit v_batch
     for update skip locked
  loop
    if coalesce(tr.confirmations, 0) < v_conf then
      update public.bsc_transfers set status = 'detected', receipt_status = 'confirmed', updated_at = now()
       where id = tr.id;
      continue;
    end if;

    if tr.amount < v_min then
      update public.bsc_transfers
         set status = 'unmatched', error_text = 'Below the minimum deposit (' || v_min || ' USDT)',
             updated_at = now()
       where id = tr.id;
      continue;
    end if;

    select * into v_intent
      from public.deposit_intents
     where from_address = tr.from_address and status = 'open' and expires_at > now()
     order by created_at desc limit 1
     for update;

    if v_intent.id is null then
      update public.bsc_transfers
         set status = 'unmatched', error_text = 'No deposit intent for this sending address', updated_at = now()
       where id = tr.id;
      v_matched := v_matched + 1;
      continue;
    end if;

    insert into public.deposits (
      user_id, amount, method, tx_hash, status, verified_at, confirmations,
      from_address, block_number, reviewed_at, source_transfer_id, credit_source
    ) values (
      v_intent.user_id, tr.amount, 'USDT_BEP20', tr.tx_hash, 'approved', now(),
      tr.confirmations, tr.from_address, tr.block_number, now(), tr.id, 'bsc_watcher'
    )
    returning * into v_dep;

    perform public.wallet_move(v_intent.user_id, v_dep.amount, 0, 0, 0, 'deposit', 'deposit', v_dep.id,
                               'Deposit verified on BNB Smart Chain (automatic)');
    update public.wallets
       set lifetime_deposited = lifetime_deposited + v_dep.amount
     where user_id = v_intent.user_id;

    update public.deposit_intents set status = 'used', used_transfer_id = tr.id where id = v_intent.id;
    update public.bsc_transfers
       set status = 'credited', user_id = v_intent.user_id, intent_id = v_intent.id,
           deposit_id = v_dep.id, updated_at = now()
     where id = tr.id;

    perform public.notify_user(v_intent.user_id, 'Deposit credited',
      v_dep.amount || ' USDT was verified on BNB Smart Chain and added to your balance.',
      'success', '#/history');
    perform public.audit('deposit.bsc.auto', 'deposit', v_dep.id,
      jsonb_build_object('tx_hash', tr.tx_hash, 'amount', v_dep.amount,
                         'from', tr.from_address, 'confirmations', tr.confirmations));
    v_credited := v_credited + 1;
  end loop;

  return jsonb_build_object('ok', true, 'scan_requested', true,
                            'credited', v_credited, 'unmatched', v_matched);
exception when others then
  update public.bsc_watch_state
     set request_id = null, phase = 'idle', last_error = left(sqlerrm, 300), updated_at = now()
   where id = 1;
  raise;
end $$;

revoke all on function public.bsc_watch_tick() from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-bsc-deposits', '* * * * *',
      $cron$select public.bsc_watch_tick();$cron$);
    raise notice 'pg_cron: tmgrow-bsc-deposits every minute.';
  end if;
end $$;


-- ============================================================================
-- 7. ADMIN
-- ============================================================================
create or replace function public.admin_bsc_deposit_state()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.bsc_watch_state;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into st from public.bsc_watch_state where id = 1;

  return jsonb_build_object(
    'enabled', public.setting_bool('bsc_auto_deposit_enabled', false),
    'api_key_set', coalesce(public.bsc_secret('bscscan_api_key'), '') <> '',
    'deposit_address', public.bsc_addr(),
    'usdt_contract', public.bsc_usdt(),
    'confirmations_required', coalesce(public.setting_num('deposit_confirmations', 12), 12),
    'state', jsonb_build_object('last_block', st.last_block, 'phase', st.phase,
                                'request_id', st.request_id, 'last_run_at', st.last_run_at,
                                'last_error', st.last_error),
    'counters', jsonb_build_object(
      'detected', (select count(*) from public.bsc_transfers where status = 'detected'),
      'confirmed', (select count(*) from public.bsc_transfers where status = 'confirmed'),
      'credited', (select count(*) from public.bsc_transfers where status = 'credited'),
      'unmatched', (select count(*) from public.bsc_transfers where status = 'unmatched'),
      'failed', (select count(*) from public.bsc_transfers where status = 'failed'),
      'open_intents', (select count(*) from public.deposit_intents where status = 'open' and expires_at > now())
    ),
    'recent', (select coalesce(jsonb_agg(jsonb_build_object(
                 'tx_hash', t.tx_hash, 'from', t.from_address, 'amount', t.amount,
                 'status', t.status, 'confirmations', t.confirmations,
                 'error', t.error_text, 'created_at', t.created_at)
                 order by t.created_at desc), '[]'::jsonb)
               from (select * from public.bsc_transfers order by created_at desc limit 15) t)
  );
end $$;

revoke all on function public.admin_bsc_deposit_state() from public, anon;
grant execute on function public.admin_bsc_deposit_state() to authenticated;

create or replace function public.admin_bsc_deposit_tick()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  return public.bsc_watch_tick();
end $$;

revoke all on function public.admin_bsc_deposit_tick() from public, anon;
grant execute on function public.admin_bsc_deposit_tick() to authenticated;

create or replace function public.admin_bsc_transfer_assign(p_transfer_id uuid, p_user_id uuid, p_note text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  tr public.bsc_transfers;
  v_dep public.deposits;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into tr from public.bsc_transfers where id = p_transfer_id for update;
  if tr.id is null then raise exception 'TRANSFER_NOT_FOUND'; end if;
  if tr.status <> 'unmatched' then raise exception 'TRANSFER_NOT_UNMATCHED'; end if;
  if tr.confirmations < coalesce(public.setting_num('deposit_confirmations', 12), 12) then
    raise exception 'NOT_ENOUGH_CONFIRMATIONS';
  end if;

  insert into public.deposits (
    user_id, amount, method, tx_hash, status, verified_at, confirmations,
    from_address, block_number, reviewed_at, reviewed_by, admin_note,
    source_transfer_id, credit_source
  ) values (
    p_user_id, tr.amount, 'USDT_BEP20', tr.tx_hash, 'approved', now(), tr.confirmations,
    tr.from_address, tr.block_number, now(), auth.uid(), left(p_note, 300),
    tr.id, 'bsc_watcher_manual'
  ) returning * into v_dep;

  perform public.wallet_move(p_user_id, v_dep.amount, 0, 0, 0, 'deposit', 'deposit', v_dep.id,
                             'Deposit verified on BNB Smart Chain (manual match)');
  update public.wallets set lifetime_deposited = lifetime_deposited + v_dep.amount where user_id = p_user_id;
  update public.bsc_transfers set status = 'credited', user_id = p_user_id, deposit_id = v_dep.id,
         updated_at = now() where id = tr.id;

  perform public.audit('deposit.bsc.manual', 'deposit', v_dep.id,
    jsonb_build_object('tx_hash', tr.tx_hash, 'user', p_user_id, 'amount', v_dep.amount));
  return jsonb_build_object('ok', true, 'deposit_id', v_dep.id);
end $$;

revoke all on function public.admin_bsc_transfer_assign(uuid, uuid, text) from public, anon;
grant execute on function public.admin_bsc_transfer_assign(uuid, uuid, text) to authenticated;

notify pgrst, 'reload schema';

commit;
