-- ============================================================================
-- TM GROW — MAXIMUM AUTOMATION ENGINE (additive migration)
--
-- Builds on what already exists:
--   automation_jobs / automation_runs / automation_execute / automation_overview
--   telegram_outbox / telegram_enqueue / telegram-notify
--   review_submission / wallet_move / audit / fraud_flags
--
-- Adds:
--   * automation_modules  — per-module ON/OFF + emergency stop
--   * verification_queue  — idempotent, retryable, dead-letter queue
--   * trigger that enqueues every submitted proof exactly once
--   * claim / decide / fail / retry / dead-letter RPCs
--   * automation_engine_status() for the admin dashboard
--
-- Nothing is dropped or reset. Safe to run more than once.
-- ============================================================================

begin;

-- ----------------------------------------------------------------------------
-- 1. Modules and emergency stop
-- ----------------------------------------------------------------------------
create table if not exists public.automation_modules (
  key text primary key,
  name text not null,
  description text,
  enabled boolean not null default false,
  critical boolean not null default false,
  config jsonb not null default '{}'::jsonb,
  last_run_at timestamptz,
  updated_at timestamptz not null default now()
);

insert into public.automation_modules (key, name, description, enabled, critical, config) values
  ('task_verification', 'Task verification', 'Runs deterministic and platform checks on submitted proofs.', false, true, '{}'::jsonb),
  ('auto_rewards', 'Automatic rewards', 'Applies an automated approve/reject decision through review_submission.', false, true, '{}'::jsonb),
  ('fraud_engine', 'Fraud engine', 'Duplicate screenshots, reused proofs and abuse patterns.', true, false, '{"max_rejections_7d": 5, "auto_restrict": false}'::jsonb),
  ('telegram_notify', 'Telegram notifications', 'Outbox delivery for task, wallet and account events.', true, false, '{}'::jsonb),
  ('withdrawal_safety', 'Withdrawal safety', 'Limits, duplicate-payment checks and reconciliation.', true, true, '{"auto_approve_max": 0}'::jsonb),
  ('ai_verification', 'AI screenshot analysis', 'Optional AI provider. Off unless a provider is configured.', false, false, '{"provider": "", "cost_per_check": 0.02, "min_confidence": 0.9}'::jsonb)
on conflict (key) do update
  set name = excluded.name,
      description = excluded.description,
      critical = excluded.critical;

create index if not exists automation_modules_enabled_idx on public.automation_modules (enabled);
alter table public.automation_modules enable row level security;
grant all on public.automation_modules to service_role;

-- ----------------------------------------------------------------------------
-- 2. Verification queue (idempotent + retryable + dead letter)
-- ----------------------------------------------------------------------------
create table if not exists public.verification_queue (
  id uuid primary key default gen_random_uuid(),
  submission_id uuid not null unique references public.submissions (id) on delete cascade,
  task_id uuid not null references public.tasks (id) on delete cascade,
  worker_id uuid not null references public.profiles (id) on delete cascade,
  mode text not null default 'deterministic'
    check (mode in ('deterministic','telegram_api','ai','manual')),
  status text not null default 'queued'
    check (status in ('queued','processing','verified', 'rejected', 'manual', 'dead')),
  attempts int not null default 0,
  max_attempts int not null default 5,
  next_run_at timestamptz not null default now(),
  locked_at timestamptz,
  last_error text,
  evidence jsonb not null default '{}'::jsonb,
  decided_by text,
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists verification_queue_status_idx
  on public.verification_queue (status, next_run_at);
create index if not exists verification_queue_worker_idx
  on public.verification_queue (worker_id, created_at desc);
create index if not exists verification_queue_worker_idx2
  on public.verification_queue (status, created_at desc);

alter table public.verification_queue enable row level security;
grant all on public.verification_queue to service_role;

-- Enqueue exactly once per submission, and only when the engine is armed.
create or replace function public.verification_enqueue()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_mode text;
begin
  if not public.setting_bool('automation_enabled', false) then
    return new;
  end if;

  select case when sv.platform = 'telegram' then 'telegram_api' else 'deterministic' end
    into v_mode
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
    join public.services sv on sv.id = c.service_id
   where t.id = new.task_id;

  insert into public.verification_queue (submission_id, task_id, worker_id, mode)
  values (new.id, new.task_id, new.worker_id, coalesce(v_mode, 'manual'))
  on conflict (submission_id) do nothing;

  return new;
end $$;

drop trigger if exists submissions_verify_enqueue on public.submissions;
create trigger submissions_verify_enqueue
  after insert on public.submissions
  for each row execute function public.verification_enqueue();

-- Claim a batch atomically; SKIP LOCKED keeps two workers from colliding.
create or replace function public.verification_claim_batch(p_limit int default 10)
returns setof public.verification_queue
language plpgsql security definer set search_path = public as $$
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  return query
  with picked as (
    select q.id
      from public.verification_queue q
     where q.status = 'queued'
       and q.next_run_at <= now()
     order by q.created_at
     limit greatest(1, least(coalesce(p_limit, 10), 50))
     for update skip locked
  )
  update public.verification_queue v
     set status = 'processing',
         attempts = v.attempts + 1,
         locked_at = now(),
         updated_at = now()
    from picked p
   where v.id = p.id
  returning v.*;
end $$;

revoke all on function public.verification_claim_batch(int) from public, anon, authenticated;
grant execute on function public.verification_claim_batch(int) to service_role;

-- Read-only context for the worker (never touches money).
create or replace function public.verification_context(p_queue_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'queue', to_jsonb(q),
    'submission', to_jsonb(s),
    'task', to_jsonb(t),
    'campaign', jsonb_build_object(
      'id', c.id, 'title', c.title, 'target_url', c.target_url,
      'instructions', left(c.instructions, 800), 'platform', sv.platform,
      'quantity', c.quantity, 'approved_count', c.approved_count,
      'reward_per_task', c.reward_per_task),
    'worker', jsonb_build_object(
      'id', p.id, 'status', p.status, 'trust', p.trust_score,
      'telegram_id', p.telegram_id, 'is_suspended', p.is_suspended),
    'duplicate_hash', (s.proof_hash is not null and exists (
       select 1 from public.submissions s2
        where s2.proof_hash = s.proof_hash and s2.id <> s.id)),
    'duplicate_for_worker', (s.proof_hash is not null and exists (
       select 1 from public.submissions s2
        where s2.proof_hash = s.proof_hash
          and s2.worker_id = s.worker_id and s2.id <> s.id))
  )
  from public.verification_queue q
  join public.submissions s on s.id = q.submission_id
  join public.tasks t on t.id = q.task_id
  join public.campaigns c on c.id = t.campaign_id
  join public.services sv on sv.id = c.service_id
  join public.profiles p on p.id = q.worker_id
 where q.id = p_queue_id;
$$;

revoke all on function public.verification_context(uuid) from public, anon, authenticated;
grant execute on function public.verification_context(uuid) to service_role;

-- ----------------------------------------------------------------------------
-- 3. Decide (idempotent) — the only place an automated decision becomes money
-- ----------------------------------------------------------------------------
/* review_submission is guarded by has_admin_role(), which a service-role call
   does not satisfy. This wrapper runs the one existing ledger path with the
   platform owner's identity so the ledger stays single-sourced. The decision is
   labelled by decided_by='automation' in verification_queue and audited. */
create or replace function public.automation_review_submission(
  p_submission_id uuid, p_approve boolean, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_owner uuid;
  v_prev text;
  v_res jsonb;
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  select id into v_owner
    from public.profiles
   where admin_role = 'OWNER' and status = 'active'
   order by created_at
   limit 1;
  if v_owner is null then raise exception 'NO_OWNER_FOR_AUTOMATION'; end if;

  v_prev := coalesce(current_setting('request.jwt.claims', true), '');
  perform set_config('request.jwt.claims',
    jsonb_build_object('sub', v_owner, 'role', 'authenticated')::text, true);

  begin
    v_res := public.review_submission(p_submission_id, p_approve, p_note);
  exception when others then
    if coalesce(v_prev, '') <> '' then
      perform set_config('request.jwt.claims', v_prev, true);
    end if;
    raise;
  end;

  if coalesce(v_prev, '') <> '' then
    perform set_config('request.jwt.claims', v_prev, true);
  end if;

  perform public.audit('automation.review', 'submission', p_submission_id,
    jsonb_build_object('approve', p_approve, 'note', p_note));
  return v_res;
end $$;

revoke all on function public.automation_review_submission(uuid, boolean, text) from public, anon, authenticated;
grant execute on function public.automation_review_submission(uuid, boolean, text) to service_role;

create or replace function public.verification_decide(
  p_queue_id uuid,
  p_decision text,               -- 'approve' | 'reject' | 'manual'
  p_reason text default null,
  p_evidence jsonb default '{}'::jsonb
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  q public.verification_queue;
  v_approve boolean;
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_decision not in ('approve','reject','manual') then
    raise exception 'INVALID_DECISION';
  end if;

  select * into q from public.verification_queue where id = p_queue_id for update;
  if q.id is null then raise exception 'QUEUE_NOT_FOUND'; end if;

  -- Idempotency: a finished row is never processed twice.
  if q.status in ('verified','rejected') then
    return jsonb_build_object('ok', true, 'already', true, 'status', q.status);
  end if;

  if p_decision = 'manual' then
    update public.verification_queue
       set status = 'manual', last_error = null,
           evidence = coalesce(p_evidence, '{}'::jsonb),
           decided_by = 'automation', decided_at = now(), updated_at = now()
     where id = q.id;
    return jsonb_build_object('ok', true, 'status', 'manual');
  end if;

  v_approve := p_decision = 'approve';

  /* Wallet integrity gate: auto-rewards must be armed, and a submission can
     only be approved when the campaign still has a slot and escrow. */
  if v_approve then
    if not public.setting_bool('automation_enabled', false)
       or not exists (select 1 from public.automation_modules
                       where key = 'auto_rewards' and enabled) then
      raise exception 'AUTO_REWARDS_DISABLED';
    end if;
    if exists (select 1 from public.submissions where id = q.submission_id and status <> 'pending') then
      update public.verification_queue
         set status = 'manual', evidence = coalesce(p_evidence,'{}'::jsonb),
             decided_by = 'automation', decided_at = now(), updated_at = now()
       where id = q.id;
      return jsonb_build_object('ok', true, 'status', 'manual', 'reason', 'ALREADY_REVIEWED');
    end if;
  end if;

  perform public.automation_review_submission(q.submission_id, v_approve, p_reason);

  update public.verification_queue
     set status = case when v_approve then 'verified' else 'rejected' end,
         last_error = null,
         evidence = coalesce(p_evidence, '{}'::jsonb),
         decided_by = 'automation',
         decided_at = now(),
         updated_at = now()
   where id = q.id;

  return jsonb_build_object('ok', true, 'status', case when v_approve then 'verified' else 'rejected' end);
end $$;

revoke all on function public.verification_decide(uuid, text, text, jsonb) from public, anon, authenticated;
grant execute on function public.verification_decide(uuid, text, text, jsonb) to service_role;

create or replace function public.verification_fail(
  p_queue_id uuid, p_error text, p_retryable boolean default true
) returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.verification_queue;
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into q from public.verification_queue where id = p_queue_id for update;
  if q.id is null then raise exception 'QUEUE_NOT_FOUND'; end if;
  if q.status in ('verified','rejected') then
    return jsonb_build_object('ok', true, 'already', true);
  end if;

  if p_retryable and q.attempts < q.max_attempts then
    update public.verification_queue
       set status = 'queued',
           last_error = left(coalesce(p_error, 'unknown'), 500),
           next_run_at = now() + make_interval(secs => least(3600, power(2, q.attempts)::int * 30)),
           updated_at = now()
     where id = q.id;
    return jsonb_build_object('ok', true, 'status', 'queued', 'attempts', q.attempts);
  end if;

  update public.verification_queue
     set status = 'dead', last_error = left(coalesce(p_error, 'unknown'), 500), updated_at = now()
   where id = q.id;

  insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
  values (q.worker_id, 'automation_dead_letter', 1,
          jsonb_build_object('queue', q.id, 'error', left(coalesce(p_error,''), 300)), q.submission_id);

  if (select id from public.profiles where admin_role = 'OWNER' and status = 'active' order by created_at limit 1) is not null then
    perform public.notify_user(
      (select id from public.profiles where admin_role = 'OWNER' and status = 'active' order by created_at limit 1),
      'Verification job failed',
      'A verification job moved to the dead-letter queue: ' || left(coalesce(p_error, 'unknown'), 160),
      'error', '#/admin/automation');
  end if;

  return jsonb_build_object('ok', true, 'status', 'dead');
end $$;

revoke all on function public.verification_fail(uuid, text, boolean) from public, anon, authenticated;
grant execute on function public.verification_fail(uuid, text, boolean) to service_role;

-- Admin retry / module + emergency controls -----------------------------------
create or replace function public.verification_retry(p_queue_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.verification_queue;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  select * into q from public.verification_queue where id = p_queue_id for update;
  if q.id is null then raise exception 'QUEUE_NOT_FOUND'; end if;
  if q.status not in ('dead','manual','queued') then
    return jsonb_build_object('ok', true, 'status', q.status);
  end if;

  update public.verification_queue
     set status = 'queued', attempts = 0, next_run_at = now(),
         last_error = null, locked_at = null, updated_at = now()
   where id = q.id;

  perform public.audit('verification.retry', 'verification_queue', q.id, null);
  return jsonb_build_object('ok', true, 'status', 'queued');
end $$;

create or replace function public.automation_module_set(p_key text, p_enabled boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  update public.automation_modules
     set enabled = coalesce(p_enabled, false), updated_at = now()
   where key = p_key;
  if not found then raise exception 'MODULE_NOT_FOUND'; end if;
  perform public.audit('automation.module', 'automation_module', null,
    jsonb_build_object('key', p_key, 'enabled', p_enabled));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.automation_emergency_stop(p_on boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  insert into public.settings (key, value, is_public)
  values ('automation_enabled', to_jsonb(coalesce(p_on, true)), false)
  on conflict (key) do update
    set value = excluded.value, updated_at = now();

  if coalesce(p_on, true) then
    update public.automation_modules set enabled = false, updated_at = now();
    update public.automation_jobs set enabled = false, updated_at = now();
  end if;

  perform public.audit('automation.emergency_stop', 'setting', null,
    jsonb_build_object('on', coalesce(p_on, true)));
  return jsonb_build_object('ok', true, 'stopped', coalesce(p_on, true));
end $$;

revoke all on function public.automation_module_set(text, boolean) from public, anon;
revoke all on function public.automation_emergency_stop(boolean) from public, anon;
grant execute on function public.automation_module_set(text, boolean) to authenticated;
grant execute on function public.automation_emergency_stop(boolean) to authenticated;
revoke all on function public.verification_retry(uuid) from public, anon;
grant execute on function public.verification_retry(uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- 4. Engine status for the Automation Dashboard
-- ----------------------------------------------------------------------------
create or replace function public.automation_engine_status()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ai_cost numeric := coalesce((select (config ->> 'cost_per_check')::numeric
                                   from public.automation_modules where key = 'ai_verification'), 0);
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  return jsonb_build_object(
    'generated_at', now(),
    'enabled', public.setting_bool('automation_enabled', false),
    'modules', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'key', key, 'name', name, 'description', description,
               'enabled', enabled, 'config', config, 'last_run_at', last_run_at
             ) order by key), '[]'::jsonb)
        from public.automation_modules
    ),
    'queue', jsonb_build_object(
      'queued', (select count(*) from public.verification_queue where status = 'queued'),
      'processing', (select count(*) from public.verification_queue where status = 'processing'),
      'manual', (select count(*) from public.verification_queue where status = 'manual'),
      'dead', (select count(*) from public.verification_queue where status = 'dead'),
      'verified_today', (select count(*) from public.verification_queue
                          where status = 'verified' and decided_at::date = current_date),
      'rejected_today', (select count(*) from public.verification_queue
                          where status = 'rejected' and decided_at::date = current_date),
      'oldest_queued_minutes', coalesce((
        select round(extract(epoch from (now() - min(created_at))) / 60)
          from public.verification_queue where status in ('queued','processing')), 0)
    ),
    'money', jsonb_build_object(
      'rewards_today', coalesce((
        select round(sum(available_delta), 6) from public.ledger_entries
         where kind = 'task_reward' and created_at::date = current_date), 0),
      'pending_rewards', coalesce((
        select round(sum(pending), 6) from public.wallets), 0)
    ),
    'fraud', jsonb_build_object(
      'open_flags', (select count(*) from public.fraud_flags where status = 'open'),
      'high_severity', (select count(*) from public.fraud_flags where status = 'open' and severity >= 3),
      'duplicate_proofs_7d', (select count(*) from public.fraud_flags
                               where kind = 'duplicate_proof'
                                 and created_at >= now() - interval '7 days')
    ),
    'telegram', jsonb_build_object(
      'queued', (select count(*) from public.telegram_outbox where status in ('queued','sending')),
      'failed', (select count(*) from public.telegram_outbox where status = 'failed'),
      'sent_today', (select count(*) from public.telegram_outbox
                      where status = 'sent' and sent_at::date = current_date)
    ),
    'ai', jsonb_build_object(
      'enabled', coalesce((select enabled from public.automation_modules where key = 'ai_verification'), false),
      'checks_today', (select count(*) from public.verification_queue
                        where mode = 'ai' and created_at::date = current_date),
      'cost_per_check', coalesce(v_ai_cost, 0),
      'estimated_cost_today', round(
        (select count(*) from public.verification_queue
          where mode = 'ai' and created_at::date = current_date) * coalesce(v_ai_cost, 0), 4)
    ),
    'dead_letters', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', id, 'submission_id', submission_id, 'worker_id', worker_id,
               'attempts', attempts, 'last_error', last_error, 'updated_at', updated_at
             ) order by updated_at desc), '[]'::jsonb)
        from (select * from public.verification_queue where status = 'dead'
              order by updated_at desc limit 20) d
    )
  );
end $$;

revoke all on function public.automation_engine_status() from public, anon;
grant execute on function public.automation_engine_status() to authenticated;

-- Admin queue listing (manual + dead + recent) --------------------------------
create or replace function public.verification_list(
  p_status text default null, p_limit int default 40
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', q.id, 'status', q.status, 'mode', q.mode,
      'attempts', q.attempts, 'max_attempts', q.max_attempts,
      'last_error', q.last_error, 'evidence', q.evidence,
      'created_at', q.created_at, 'decided_at', q.decided_at,
      'task', c.title, 'platform', sv.platform,
      'reward', t.reward,
      'worker', coalesce(nullif(p.full_name, ''), p.email),
      'submission_id', q.submission_id
    ) as x
      from public.verification_queue q
      join public.submissions s on s.id = q.submission_id
      join public.tasks t on t.id = q.task_id
      join public.campaigns c on c.id = t.campaign_id
      join public.services sv on sv.id = c.service_id
      join public.profiles p on p.id = q.worker_id
     where p_status is null or p_status = '' or q.status = p_status
     order by q.created_at desc
     limit greatest(1, least(coalesce(p_limit, 40), 200))
  ) s;

  return jsonb_build_object('items', items);
end $$;

revoke all on function public.verification_list(text, int) from public, anon;
grant execute on function public.verification_list(text, int) to authenticated;

notify pgrst, 'reload schema';

commit;
