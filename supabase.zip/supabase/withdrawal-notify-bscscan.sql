-- Telegram: make the paid-withdrawal message carry the verified tx and BSCScan link.
-- It is queued only from admin_review_withdrawal(action = 'pay'), i.e. after a
-- valid 0x…64 hash is stored and the wallet movement committed.
-- Existing custom templates are left alone unless they still use the old default.

update public.settings
   set value = to_jsonb($tpl$🎉 Withdrawal Successful!

💰 Amount: {{amount}} USDT
✅ Status: Completed
🌐 Network: BNB Smart Chain (BEP-20)

📝 View on BSCScan:
https://bscscan.com/tx/{{tx}}

Funds have been transferred to your wallet.$tpl$::text),
       updated_at = now()
 where key = 'telegram_tpl_withdrawal_paid'
   and coalesce(value #>> '{}', '') not like '%bscscan.com%';

insert into public.settings (key, value, is_public) values
  ('telegram_notify_withdrawal_paid', 'true'::jsonb, false),
  ('telegram_tpl_withdrawal_paid',
   to_jsonb($tpl$🎉 Withdrawal Successful!

💰 Amount: {{amount}} USDT
✅ Status: Completed
🌐 Network: BNB Smart Chain (BEP-20)

📝 View on BSCScan:
https://bscscan.com/tx/{{tx}}

Funds have been transferred to your wallet.$tpl$::text),
   false)
on conflict (key) do nothing;

notify pgrst, 'reload schema';

-- Verify: the template contains the BSCScan URL placeholder.
select key, value #>> '{}' as template
  from public.settings
 where key = 'telegram_tpl_withdrawal_paid';
