-- ============================================================================
-- TM GROW — ADMIN PANEL UPGRADE (additive, idempotent)
-- Task categories · bulk-ready primitives · maintenance scheduler (server
-- cron) · AI Manager insights · AI proof status surfacing · user capability
-- promotion. Nothing existing is dropped, renamed or re-created.
--
-- Run once in Supabase → SQL Editor. If pg_cron is not enabled, enable it
-- (Database → Extensions) and re-run block 6 so the maintenance scheduler
-- runs every minute. Until then the scheduler can be fired manually:
--   select public.maintenance_tick();
-- ============================================================================

begin;

-- ----------------------------------------------------------------------------
-- 1. TASK CATEGORIES
-- ----------------------------------------------------------------------------
create table if not exists public.task_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  icon text not null default 'layers',
  sort_order int not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.tasks
  add column if not exists category_id uuid
  references public.task_categories (id) on delete set null;

create index if not exists tasks_category_idx
  on public.tasks (category_id);

alter table public.task_categories enable row level security;
drop policy if exists task_categories_read on public.task_categories;
create policy task_categories_read on public.task_categories
  for select to authenticated using (true);

-- ----------------------------------------------------------------------------
-- 2. CATEGORY MANAGEMENT RPCs (admin, server-checked, audited)
-- ----------------------------------------------------------------------------
create or replace function public.admin_category_list()
returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id', c.id, 'name', c.name, 'icon', c.icon,
      'sort_order', c.sort_order, 'active', c.active,
      'task_count', (select count(*) from public.tasks t where t.category_id = c.id),
      'created_at', c.created_at
    ) order by c.sort_order, c.name
  ), '[]'::jsonb)
  from public.task_categories c;
$$;

create or replace function public.admin_category_save(p_payload jsonb)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  c public.task_categories;
  v_name text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  v_name := btrim(coalesce(p_payload->>'name', ''));
  if v_name is null or length(v_name) < 2 or length(v_name) > 60 then
    raise exception 'INVALID_NAME';
  end if;

  if p_payload->>'id' is not null then
    update public.task_categories set
      name = v_name,
      icon = coalesce(nullif(p_payload->>'icon', ''), icon),
      sort_order = coalesce((p_payload->>'sort_order')::int, sort_order),
      active = coalesce((p_payload->>'active')::boolean, active),
      updated_at = now()
    where id = (p_payload->>'id')::uuid
    returning * into c;
    if c.id is null then raise exception 'NOT_FOUND'; end if;
    perform public.audit('category.update', 'task_category', c.id,
      jsonb_build_object('name', c.name, 'active', c.active));
  else
    insert into public.task_categories (name, icon, sort_order, active)
    values (v_name,
            coalesce(nullif(p_payload->>'icon', ''), 'layers'),
            coalesce((p_payload->>'sort_order')::int, 100),
            coalesce((p_payload->>'active')::boolean, true))
    returning * into c;
    perform public.audit('category.create', 'task_category', c.id,
      jsonb_build_object('name', c.name));
  end if;

  return to_jsonb(c);
end $$;

-- Deleting a category that still has tasks is refused (history stays intact);
-- disable it instead. Delete is allowed only for unused categories.
create or replace function public.admin_category_delete(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_count int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  select count(*) into v_count from public.tasks where category_id = p_id;
  if v_count > 0 then
    raise exception 'CATEGORY_IN_USE:%', v_count;
  end if;
  delete from public.task_categories where id = p_id;
  if not found then raise exception 'NOT_FOUND'; end if;
  perform public.audit('category.delete', 'task_category', p_id, '{}');
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_category_reorder(p_ids uuid[])
returns jsonb
language plpgsql security definer set search_path = public as $$
declare i int := 0;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  for i in 1..coalesce(array_length(p_ids, 1), 0) loop
    update public.task_categories set sort_order = i * 10, updated_at = now()
     where id = p_ids[i];
  end loop;
  perform public.audit('category.reorder', 'task_category', null,
    jsonb_build_object('order', to_jsonb(p_ids)));
  return jsonb_build_object('ok', true);
end $$;

-- Category of each task on a page (bulk lookup for the admin tasks table).
create or replace function public.admin_task_category_map(p_ids uuid[])
returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(
    t.id, jsonb_build_object('category_id', t.category_id, 'category', c.name)
  ), '{}'::jsonb)
  from public.tasks t
  left join public.task_categories c on c.id = t.category_id
  where t.id = any(p_ids);
$$;

-- ----------------------------------------------------------------------------
-- 3. USER CAPABILITY PROMOTION (Worker / Buyer) — OWNER only, audited
-- ----------------------------------------------------------------------------
create or replace function public.admin_set_user_caps(
  p_user_id uuid,
  p_is_worker boolean,
  p_is_buyer boolean
)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  p public.profiles;
  v_before jsonb;
begin
  if not public.has_admin_role(array['OWNER']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_user_id = auth.uid() then
    raise exception 'CANNOT_MODERATE_SELF';
  end if;

  select jsonb_build_object('is_worker', x.is_worker, 'is_buyer', x.is_buyer)
    into v_before from public.profiles x where x.id = p_user_id;
  if v_before is null then raise exception 'USER_NOT_FOUND'; end if;

  update public.profiles
     set is_worker = p_is_worker, is_buyer = p_is_buyer, updated_at = now()
   where id = p_user_id
   returning * into p;

  perform public.audit('user.capabilities', 'profile', p_user_id,
    jsonb_build_object('before', v_before,
                       'after', jsonb_build_object('is_worker', p_is_worker, 'is_buyer', p_is_buyer)));
  return to_jsonb(p);
end $$;

-- ----------------------------------------------------------------------------
-- 4. MAINTENANCE SCHEDULER (server-authoritative via settings + cron)
-- ----------------------------------------------------------------------------
create or replace function public.admin_maintenance_schedule(
  p_start_at timestamptz,
  p_end_at timestamptz,
  p_scope text default 'all',
  p_short text default null,
  p_detail text default null,
  p_tz text default 'Asia/Dhaka'
)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_start_at is null or p_end_at is null or p_end_at <= p_start_at then
    raise exception 'INVALID_WINDOW';
  end if;
  if p_scope not in ('all', 'worker', 'buyer') then
    raise exception 'INVALID_SCOPE';
  end if;

  perform public.admin_update_setting_raw('maintenance_start_at', to_jsonb(p_start_at));
  perform public.admin_update_setting_raw('maintenance_end_at', to_jsonb(p_end_at));
  perform public.admin_update_setting_raw('maintenance_scope', to_jsonb(p_scope));
  perform public.admin_update_setting_raw('maintenance_short', to_jsonb(coalesce(p_short, '')));
  perform public.admin_update_setting_raw('maintenance_detail', to_jsonb(coalesce(p_detail, '')));
  perform public.admin_update_setting_raw('maintenance_tz', to_jsonb(coalesce(p_tz, 'Asia/Dhaka')));

  perform public.audit('maintenance.schedule', 'setting', null,
    jsonb_build_object('start', p_start_at, 'end', p_end_at, 'scope', p_scope));

  return jsonb_build_object('ok', true,
    'start_at', p_start_at, 'end_at', p_end_at, 'scope', p_scope);
end $$;

-- Writes a settings row exactly like admin_update_setting does, without
-- requiring an admin JWT (used by the cron tick). Rows are upserted.
create or replace function public.admin_update_setting_raw(p_key text, p_value jsonb)
returns void
language sql security definer set search_path = public as $$
  insert into public.settings (key, value, is_public, updated_at)
  values (p_key, p_value, false, now())
  on conflict (key) do update
    set value = excluded.value, updated_at = now();
$$;

revoke all on function public.admin_update_setting_raw(text, jsonb) from public, anon;
grant execute on function public.admin_update_setting_raw(text, jsonb) to authenticated;

-- Evaluates the scheduled window using server time. Fires once per window:
-- after the end time passes, the window is cleared so a finished schedule
-- cannot re-engage. Never touches money or user accounts.
create or replace function public.maintenance_tick()
returns void
language plpgsql security definer set search_path = public as $$
declare
  v_start timestamptz;
  v_end timestamptz;
  v_on boolean;
begin
  select nullif(setting_text('maintenance_start_at', ''), '')::timestamptz into v_start;
  select nullif(setting_text('maintenance_end_at', ''), '')::timestamptz into v_end;
  v_on := public.setting_bool('maintenance', false);

  if v_start is null or v_end is null then
    return; -- no schedule configured
  end if;

  if now() >= v_start and now() < v_end and not v_on then
    update public.settings set value = 'true'::jsonb, updated_at = now()
     where key = 'maintenance';
    perform public.audit('maintenance.auto_on', 'setting', null,
      jsonb_build_object('start', v_start, 'end', v_end));
  elsif now() >= v_end and v_on then
    update public.settings set value = 'false'::jsonb, updated_at = now()
     where key = 'maintenance';
    perform public.audit('maintenance.auto_off', 'setting', null,
      jsonb_build_object('scheduled_end', v_end));
    -- one-shot: clear the finished window
    update public.settings set value = '""'::jsonb, updated_at = now()
     where key in ('maintenance_start_at', 'maintenance_end_at');
  elsif now() >= v_end and not v_on then
    -- stale finished window with maintenance already off: clear it
    update public.settings set value = '""'::jsonb, updated_at = now()
     where key in ('maintenance_start_at', 'maintenance_end_at');
  end if;
end $$;

revoke all on function public.maintenance_tick() from public, anon;
grant execute on function public.maintenance_tick() to authenticated;

-- 6. Cron (every minute) — skipped with a notice when pg_cron is disabled.
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule('tmgrow-maintenance')
      where exists (select 1 from cron.job where jobname = 'tmgrow-maintenance');
    perform cron.schedule('tmgrow-maintenance', '* * * * *',
      $cron$ select public.maintenance_tick(); $cron$);
    raise notice 'TM GROW: maintenance scheduler scheduled every minute (tmgrow-maintenance).';
  else
    raise notice 'TM GROW: pg_cron is not enabled. Enable it (Database → Extensions) and re-run this block, or call public.maintenance_tick() manually.';
  end if;
exception
  when others then
    raise notice 'TM GROW: cron schedule skipped (%).', SQLERRM;
end $$;

-- ----------------------------------------------------------------------------
-- 7. AI MANAGER INSIGHTS (read-only aggregates over real rows)
-- ----------------------------------------------------------------------------
create or replace function public.admin_ai_insights()
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_result jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  with worker_stats as (
    select s.worker_id,
           count(*) filter (where s.status = 'approved') as approved,
           count(*) filter (where s.status = 'rejected') as rejected
      from public.submissions s
     where s.created_at > now() - interval '30 days'
     group by s.worker_id
  ),
  risky_workers as (
    select jsonb_agg(jsonb_build_object(
      'worker', p.full_name,
      'approved', w.approved,
      'rejected', w.rejected,
      'rate', round(w.rejected::numeric / greatest(w.approved + w.rejected, 1), 2)
    ) order by w.rejected desc) as list
      from worker_stats w
      join public.profiles p on p.id = w.worker_id
     where (w.approved + w.rejected) >= 5
       and w.rejected::numeric / greatest(w.approved + w.rejected, 1) >= 0.6
     limit 8
  ),
  dup_hashes as (
    select jsonb_agg(jsonb_build_object(
      'hash', left(d.proof_hash, 12),
      'times', d.times,
      'last', max(d.created_at)
    ) order by d.times desc) as list
      from (
        select s.proof_hash, count(*) as times, max(s.created_at) as created_at
          from public.submissions s
         where s.proof_hash is not null
         group by s.proof_hash
        having count(*) > 1
      ) d
     limit 5
  ),
  fast_proofs as (
    select jsonb_agg(jsonb_build_object(
      'submission', left(s.id::text, 8),
      'worker', p.full_name,
      'seconds', s.time_spent_seconds,
      'reward', s_reward.v
    ) order by s.time_spent_seconds asc) as list
      from public.submissions s
      join public.tasks t on t.id = s.task_id
      join public.profiles p on p.id = s.worker_id
      cross join lateral (select t.reward as v) s_reward
     where s.status = 'approved'
       and s.time_spent_seconds is not null
       and s.time_spent_seconds < 15
       and s.reviewed_at > now() - interval '30 days'
     limit 5
  ),
  signup_days as (
    select generate_series(current_date - 6, current_date, interval '1 day')::date as d
  ),
  signup_series as (
    select sd.d, count(p.id) as c
      from signup_days sd
      left join public.profiles p on p.created_at::date = sd.d
     group by sd.d order by sd.d
  ),
  signup_stats as (
    select avg(c)::numeric as avg_c, max(c) as max_c,
           (select c from signup_series order by d desc limit 1) as today_c
      from signup_series
  )
  select jsonb_build_object(
    'generated_at', now(),
    'risky_workers', coalesce((select list from risky_workers), '[]'::jsonb),
    'duplicate_proofs', coalesce((select list from dup_hashes), '[]'::jsonb),
    'fast_proofs', coalesce((select list from fast_proofs), '[]'::jsonb),
    'withdrawals', (
      select jsonb_build_object(
        'pending', count(*) filter (where status in ('pending','approved','processing')),
        'amount', coalesce(sum(amount) filter (where status in ('pending','approved','processing')), 0),
        'oldest_hours', coalesce(round(extract(epoch from (now() - min(created_at) filter (where status = 'pending'))) / 3600), 0)
      ) from public.withdrawals
    ),
    'signup_spike', (
      select jsonb_build_object(
        'today', today_c, 'avg7', round(avg_c, 1),
        'spike', (today_c > greatest(avg_c * 3, 5))
      ) from signup_stats
    ),
    'rejections_30d', (
      select jsonb_build_object(
        'approved', count(*) filter (where status = 'approved'),
        'rejected', count(*) filter (where status = 'rejected'),
        'rate', round(count(*) filter (where status = 'rejected')::numeric
                 / greatest(count(*), 1), 2)
      ) from public.submissions where created_at > now() - interval '30 days'
    )
  ) into v_result;

  return v_result;
end $$;

revoke all on function public.admin_ai_insights() from public, anon;
grant execute on function public.admin_ai_insights() to authenticated;

-- ----------------------------------------------------------------------------
-- 8. AI PROOF STATUS (surfaced to human reviewers — never auto-approving)
-- ----------------------------------------------------------------------------
create or replace function public.admin_proof_ai_status(p_submission_ids uuid[])
returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(
    j.submission_id,
    jsonb_build_object(
      'state', j.state,
      'verdict', j.verdict,
      'confidence', j.confidence,
      'reason', j.reason,
      'attempts', j.attempts,
      'updated_at', j.updated_at
    )
  ), '{}'::jsonb)
  from public.proof_ai_jobs j
  where j.submission_id = any(p_submission_ids);
$$;

revoke all on function public.admin_proof_ai_status(uuid[]) from public, anon;
grant execute on function public.admin_proof_ai_status(uuid[]) to authenticated;

commit;

notify pgrst, 'reload schema';

-- ============================================================================
-- Verification queries (run after the migration):
--   select * from public.admin_category_list();
--   select public.admin_ai_insights();          -- as an OWNER/SUPER_ADMIN/ADMIN/MODERATOR
--   select key, value from public.settings
--     where key like 'maintenance%';
-- ============================================================================
