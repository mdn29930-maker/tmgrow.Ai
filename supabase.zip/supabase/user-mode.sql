-- TM GROW — explicit worker / buyer mode per account
-- A user can be both a worker and a buyer. The mode decides which dashboard and
-- navigation the app renders. Authorization is unchanged: worker and buyer RPCs
-- still check is_worker / is_buyer on the server.

create or replace function public.set_my_mode(p_mode text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;
  if p_mode not in ('worker','buyer') then raise exception 'INVALID_STATUS'; end if;

  select * into p from public.profiles where id = u;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;

  if p_mode = 'buyer' and not coalesce(p.is_buyer, false) then
    raise exception 'BUYER_MODE_DISABLED';
  end if;
  if p_mode = 'worker' and not coalesce(p.is_worker, false) then
    raise exception 'WORKER_MODE_DISABLED';
  end if;

  update public.profiles
     set prefs = coalesce(prefs, '{}'::jsonb) || jsonb_build_object('mode', p_mode),
         updated_at = now()
   where id = u;

  perform public.audit('profile.mode', 'profile', u, jsonb_build_object('mode', p_mode));
  return jsonb_build_object('ok', true, 'mode', p_mode);
end $$;

revoke all on function public.set_my_mode(text) from public, anon;
grant execute on function public.set_my_mode(text) to authenticated;

notify pgrst, 'reload schema';
