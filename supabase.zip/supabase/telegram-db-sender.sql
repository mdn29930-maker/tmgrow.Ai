-- ============================================================================
-- TM GROW — database-native Telegram sender (pg_net + Vault)
--
-- DRAFT — NOT APPROVED, NOT EXECUTED.
-- Goal: send telegram_outbox rows from PostgreSQL itself, with no Edge
-- Function. Reuses telegram_outbox, telegram_enqueue(), the task-completion
-- template and the existing approval flow unchanged.
--
-- Run order:
--   SECTION 0  read-only checks           (safe, run first)
--   SECTION 1  extensions                 (needs pg_net available on the project)
--   SECTION 2  Vault secret               (paste the token once, never commit it)
--   SECTION 3  outbox columns + index
--   SECTION 4  token reader (never exposed to anon/authenticated)
--   SECTION 5  helpers
--   SECTION 6  claim (internal)
--   SECTION 7  dispatch -> net.http_post
--   SECTION 8  reconcile -> net._http_response
--   SECTION 9  tick (reconcile + dispatch)
--   SECTION 10 outbox AFTER INSERT trigger (send immediately)
--   SECTION 11 task-completion trigger becomes DEFERRED (fires after credit)
--   SECTION 12 admin RPCs (drain / test / sender status / retry)
--   SECTION 13 grants
--   SECTION 14 pg_cron schedule (optional, retries + reconcile every minute)
--   SECTION 15 PostgREST schema reload
--
-- Nothing here drops a table, resets data, or changes wallet/reward logic.
-- ============================================================================


-- ============================================================================
-- SECTION 0 — READ-ONLY CHECKS (run this block alone first)
-- Expected: pg_net, pg_cron, supabase_vault listed as available/installed.
-- ============================================================================

-- 0.1 Which of the three extensions exist on this project?
select a.name,
       a.default_version as available_version,
       e.extversion       as installed_version,
       n.nspname          as installed_schema
  from pg_available_extensions a
  left join pg_extension e on e.extname = a.name
  left join pg_namespace n on n.oid = e.extnamespace
 where a.name in ('pg_net', 'pg_cron', 'supabase_vault')
 order by a.name;

-- 0.2 Is the HTTP function usable with the signatures we plan to call?
select to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') as http_post_5_args,
       to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)')          as http_post_4_args,
       to_regclass('net._http_response')                                     as response_table;

-- 0.3 Is a Telegram token already in Vault? (reports instead of failing when
-- Vault is not installed yet)
do $$
declare
  v_set boolean;
begin
  if to_regclass('vault.secrets') is null then
    raise notice 'Vault is not installed on this project (vault.secrets is missing).';
  else
    execute 'select exists (select 1 from vault.secrets where name = $1)'
      into v_set using 'telegram_bot_token';
    raise notice 'telegram_bot_token in Vault: %', v_set;
  end if;
end $$;

-- 0.4 Current outbox and settings state (no secrets, no message text)
select status, count(*) as rows
  from public.telegram_outbox
 group by status
 order by status;

select key, value
  from public.settings
 where key in ('telegram_bot_enabled',
               'telegram_notify_task_completed',
               'telegram_notify_task_approved')
 order by key;


-- ============================================================================
-- SECTION 1 — EXTENSIONS
-- ============================================================================
begin;

do $$
begin
  if not exists (select 1 from pg_available_extensions where name = 'pg_net') then
    raise exception
      'pg_net is not available on this project. Enable it in Supabase → Database → Extensions → pg_net, then run this file again.';
  end if;
end $$;

create extension if not exists pg_net;

-- Supabase Vault (already installed on most projects; this is a no-op then).
do $$
begin
  if exists (select 1 from pg_available_extensions where name = 'supabase_vault') then
    execute 'create extension if not exists supabase_vault';
  end if;

  if to_regclass('vault.secrets') is null then
    raise exception 'Supabase Vault is not installed. Enable supabase_vault in Supabase → Database → Extensions, then run this file again.';
  end if;
end $$;


-- ============================================================================
-- SECTION 2 — BOT TOKEN IN VAULT
-- Replace PASTE_TELEGRAM_BOT_TOKEN_HERE with the token from @BotFather.
-- The value below is never committed with a real token: rotate in BotFather
-- if a token ever reaches a file, a chat or a commit.
-- ============================================================================
do $$
declare
  v_token text := 'PASTE_TELEGRAM_BOT_TOKEN_HERE';
  v_exists boolean;
begin
  select exists (select 1 from vault.secrets where name = 'telegram_bot_token') into v_exists;

  if v_exists then
    raise notice 'telegram_bot_token already exists in Vault — left unchanged.';
  elsif v_token = 'PASTE_TELEGRAM_BOT_TOKEN_HERE' or length(v_token) < 20 then
    raise exception 'Replace PASTE_TELEGRAM_BOT_TOKEN_HERE with the real bot token from @BotFather, then run this file again.';
  else
    perform vault.create_secret(
      v_token,
      'telegram_bot_token',
      'TM GROW bot token used by the pg_net sender'
    );
  end if;
end $$;

-- To rotate later (never run with a real token in a file you commit):
--   select vault.update_secret(id, new_secret => '<new token>')
--     from vault.secrets where name = 'telegram_bot_token';


-- ============================================================================
-- SECTION 3 — OUTBOX COLUMNS
-- request_id  : the pg_net request id used to match the HTTP response
-- http_status : last HTTP status, kept as a delivery log
-- ============================================================================
alter table public.telegram_outbox add column if not exists request_id bigint;
alter table public.telegram_outbox add column if not exists http_status integer;

create index if not exists telegram_outbox_request_idx
  on public.telegram_outbox (request_id)
  where request_id is not null;


-- ============================================================================
-- SECTION 4 — TOKEN READER
-- SECURITY DEFINER + revoked from anon/authenticated/public: only functions
-- owned by the same role can read it, and none of them returns it.
-- ============================================================================
create or replace function public.telegram_bot_token()
returns text
language sql
security definer
set search_path = public
as $$
  select decrypted_secret
    from vault.decrypted_secrets
   where name = 'telegram_bot_token'
   limit 1;
$$;

revoke all on function public.telegram_bot_token() from public, anon, authenticated;


-- ============================================================================
-- SECTION 5 — HELPERS
-- ============================================================================

-- Safe pull of result.message_id out of a Telegram response body.
create or replace function public.telegram_json_message_id(p_content text)
returns bigint
language plpgsql
immutable
as $$
declare
  v bigint;
begin
  if p_content is null or btrim(p_content) = '' then
    return null;
  end if;

  begin
    v := nullif(p_content::jsonb #>> '{result,message_id}', '')::bigint;
  exception when others then
    v := null;
  end;

  return v;
end $$;

revoke all on function public.telegram_json_message_id(text) from public, anon, authenticated;


-- ============================================================================
-- SECTION 6 — CLAIM (internal)
-- Same selection rules as the existing telegram_claim(), but with no
-- auth.role() gate, because it now runs inside SECURITY DEFINER functions and
-- triggers. Revoked from every API role; used only by the functions below.
-- ============================================================================
create or replace function public.telegram_claim_internal(p_limit int default 25)
returns setof public.telegram_outbox
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  update public.telegram_outbox o
     set status = 'sending',
         attempts = o.attempts + 1,
         attempted_at = now(),
         request_id = null,
         http_status = null
   where o.id in (
     select id
       from public.telegram_outbox
      where status = 'queued'
         or (status = 'failed' and attempts < 5)
         or (status = 'sending'
             and coalesce(attempted_at, created_at) < now() - interval '10 minutes')
      order by created_at
      limit greatest(1, least(coalesce(p_limit, 25), 50))
      for update skip locked
   )
  returning o.*;
end $$;

revoke all on function public.telegram_claim_internal(int) from public, anon, authenticated;


-- ============================================================================
-- SECTION 7 — DISPATCH
-- Claims rows and hands each message to pg_net. The HTTP request itself runs
-- after commit, in pg_net's background worker; this function only queues it.
-- Returns counts, never the token.
--
-- Security note: Telegram's Bot API takes the token in the URL path, so the
-- built URL exists briefly in pg_net's own queue table until the worker picks
-- it up. That schema is not exposed through PostgREST and is readable only by
-- database-level roles (which can already read Vault). The token is never
-- returned by any function here and never reaches the browser.
-- ============================================================================
create or replace function public.telegram_send_pending(p_limit int default 25)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_token      text := public.telegram_bot_token();
  v_has_net    boolean;
  v_row        public.telegram_outbox;
  v_request    bigint;
  v_url        text;
  v_payload    jsonb;
  v_headers    jsonb := '{"Content-Type": "application/json"}'::jsonb;
  v_dispatched int := 0;
  v_failed     int := 0;
begin
  if coalesce(btrim(v_token), '') = '' then
    return jsonb_build_object(
      'ok', false,
      'error', 'TELEGRAM_BOT_TOKEN_MISSING',
      'dispatched', 0, 'failed', 0
    );
  end if;

  v_has_net := to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
               or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;

  if not v_has_net then
    return jsonb_build_object(
      'ok', false,
      'error', 'PG_NET_NOT_INSTALLED',
      'dispatched', 0, 'failed', 0
    );
  end if;

  for v_row in select * from public.telegram_claim_internal(p_limit) loop
    begin
      v_url := 'https://api.telegram.org/bot' || v_token || '/sendMessage';
      v_payload := jsonb_build_object(
        'chat_id', v_row.telegram_id::text,
        'text', v_row.message,
        'disable_web_page_preview', true
      );

      if to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null then
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers, 10000);
      else
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers);
      end if;

      update public.telegram_outbox
         set request_id = v_request
       where id = v_row.id;

      v_dispatched := v_dispatched + 1;
    exception when others then
      v_failed := v_failed + 1;
      update public.telegram_outbox
         set status = 'failed',
             last_error = left('PG_NET_ERROR: ' || sqlerrm, 500),
             request_id = null
       where id = v_row.id;
    end;
  end loop;

  return jsonb_build_object(
    'ok', v_failed = 0,
    'dispatched', v_dispatched,
    'failed', v_failed
  );
end $$;

revoke all on function public.telegram_send_pending(int) from public, anon, authenticated;


-- ============================================================================
-- SECTION 8 — RECONCILE
-- Matches outbox.request_id to net._http_response and writes the real result:
-- sent (2xx), failed (anything else), or failed after 10 minutes with no
-- response row at all.
-- ============================================================================
create or replace function public.telegram_reconcile()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sent   int := 0;
  v_failed int := 0;
  v_stale  int := 0;
begin
  if to_regclass('net._http_response') is null then
    return jsonb_build_object(
      'ok', false,
      'error', 'PG_NET_NOT_INSTALLED',
      'sent', 0, 'failed', 0
    );
  end if;

  with done as (
    update public.telegram_outbox o
       set status = 'sent',
           sent_at = now(),
           message_id = public.telegram_json_message_id(r.content),
           http_status = r.status_code,
           last_error = null
      from net._http_response r
     where o.request_id = r.id
       and o.status = 'sending'
       and coalesce(r.status_code, 0) between 200 and 299
    returning 1
  )
  select count(*) into v_sent from done;

  with failed as (
    update public.telegram_outbox o
       set status = 'failed',
           http_status = r.status_code,
           last_error = left(
             coalesce(
               nullif(r.error_msg, ''),
               case when r.timed_out then 'Timed out waiting for Telegram' end,
               r.content,
               'HTTP ' || coalesce(r.status_code::text, 'unknown')
             ),
             500
           )
      from net._http_response r
     where o.request_id = r.id
       and o.status = 'sending'
       and not (coalesce(r.status_code, 0) between 200 and 299)
    returning 1
  )
  select count(*) into v_failed from failed;

  with stale as (
    update public.telegram_outbox
       set status = 'failed',
           last_error = coalesce(last_error, 'No HTTP response from pg_net'),
           request_id = null
     where status = 'sending'
       and coalesce(attempted_at, created_at) < now() - interval '10 minutes'
    returning 1
  )
  select count(*) into v_stale from stale;

  return jsonb_build_object(
    'ok', true,
    'sent', v_sent,
    'failed', v_failed + v_stale
  );
end $$;

revoke all on function public.telegram_reconcile() from public, anon, authenticated;


-- ============================================================================
-- SECTION 9 — TICK (what cron calls)
-- ============================================================================
create or replace function public.telegram_tick()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recon  jsonb;
  v_disp   jsonb;
begin
  v_recon := public.telegram_reconcile();
  v_disp  := public.telegram_send_pending(25);
  return jsonb_build_object('reconcile', v_recon, 'dispatch', v_disp);
end $$;

revoke all on function public.telegram_tick() from public, anon, authenticated;


-- ============================================================================
-- SECTION 10 — SEND IMMEDIATELY AFTER ENQUEUE
-- AFTER INSERT on telegram_outbox: the same transaction that queued the
-- message also queues the pg_net request. If that transaction rolls back, the
-- outbox row and the pg_net request both disappear — no phantom message.
-- Errors are swallowed: a notification must never fail a payment.
-- ============================================================================
create or replace function public.tg_telegram_outbox_dispatch()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  begin
    perform public.telegram_send_pending(5);
  exception when others then
    null;  -- the cron tick retries; never block the caller
  end;
  return new;
end $$;

revoke all on function public.tg_telegram_outbox_dispatch() from public, anon, authenticated;

drop trigger if exists telegram_outbox_dispatch on public.telegram_outbox;
create trigger telegram_outbox_dispatch
  after insert on public.telegram_outbox
  for each row execute function public.tg_telegram_outbox_dispatch();


-- ============================================================================
-- SECTION 11 — TASK-COMPLETION TRIGGER: DEFERRED
-- Why: review_submission() sets submissions.status = 'approved' BEFORE it
-- calls wallet_move(). Today the trigger fires at that UPDATE, so
-- telegram_reward_progress() reads lifetime_earned *before* the reward is in
-- it, and the progress line is wrong (0 USDT on a first task).
-- A deferred constraint trigger fires at COMMIT, after every wallet write.
-- The function body also gains an exception block so a notification problem
-- can never roll back a credited reward.
-- ============================================================================
create or replace function public.tg_task_completed_notify()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_task     text;
  v_reward   numeric;
  v_coin     numeric;
  v_progress jsonb;
begin
  if new.status <> 'approved' or coalesce(old.status, '') = 'approved' then
    return new;
  end if;

  select c.title, t.reward
    into v_task, v_reward
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
   where t.id = new.task_id;

  if v_task is null then return new; end if;

  v_coin := coalesce(public.setting_num('tg_per_task', 1), 0);
  v_progress := public.telegram_reward_progress(new.worker_id);

  perform public.telegram_enqueue(
    new.worker_id,
    'task_completed',
    jsonb_build_object(
      'task', v_task,
      'reward', public.telegram_money(v_reward),
      'coin', public.telegram_money(v_coin),
      'progress_line', v_progress ->> 'line',
      'next_rank', v_progress ->> 'next_rank',
      'remaining', v_progress ->> 'remaining'
    ),
    'task_completed:' || new.id
  );

  return new;
exception when others then
  raise warning 'task_completed notification skipped for submission %: %', new.id, sqlerrm;
  return new;
end $$;

revoke all on function public.tg_task_completed_notify() from public, anon, authenticated;

drop trigger if exists submissions_task_completed_tg on public.submissions;
create constraint trigger submissions_task_completed_tg
  after update on public.submissions
  deferrable initially deferred
  for each row execute function public.tg_task_completed_notify();


-- ============================================================================
-- SECTION 12 — ADMIN RPCs (replace the Edge Function calls in the panel)
-- ============================================================================

-- Send queued/retryable now, after reconciling whatever already came back.
create or replace function public.admin_telegram_drain(p_limit int default 50)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recon jsonb;
  v_disp  jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  v_recon := public.telegram_reconcile();
  v_disp  := public.telegram_send_pending(greatest(1, least(coalesce(p_limit, 50), 50)));

  perform public.audit('telegram.drain', 'telegram_outbox', null, jsonb_build_object(
    'reconcile', v_recon, 'dispatch', v_disp
  ));

  return v_disp || jsonb_build_object(
    'reconcile', v_recon,
    'pending', (select count(*) from public.telegram_outbox where status in ('queued','sending')),
    'failed_total', (select count(*) from public.telegram_outbox where status = 'failed')
  );
end $$;

revoke all on function public.admin_telegram_drain(int) from public, anon;
grant execute on function public.admin_telegram_drain(int) to authenticated;


-- Send one real test message to the caller's linked Telegram.
create or replace function public.admin_telegram_test()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_tg  bigint;
  v_tpl text;
  v_id  uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select telegram_id into v_tg from public.profiles where id = v_uid;
  if v_tg is null then
    raise exception 'NO_TELEGRAM_LINK';
  end if;

  v_tpl := coalesce(
    nullif(public.setting_text('telegram_tpl_test', ''), ''),
    '✅ TM GROW notifications are working'
  );

  insert into public.telegram_outbox (user_id, telegram_id, kind, message, dedupe_key)
  values (v_uid, v_tg, 'test', v_tpl, 'test:' || v_uid::text || ':' || gen_random_uuid()::text)
  returning id into v_id;

  perform public.telegram_send_pending(1);
  perform public.audit('telegram.test', 'telegram_outbox', v_id, null);

  return jsonb_build_object('ok', true, 'id', v_id);
end $$;

revoke all on function public.admin_telegram_test() from public, anon;
grant execute on function public.admin_telegram_test() to authenticated;


-- What the panel shows instead of "Check function".
create or replace function public.admin_telegram_sender_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_vault_table   boolean := to_regclass('vault.secrets') is not null;
  v_secret_set    boolean := false;
  v_cron_installed boolean := to_regclass('cron.job') is not null;
  v_cron_schedule text;
  v_net_ok        boolean :=
    to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
    or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  if v_vault_table then
    execute 'select exists (select 1 from vault.secrets where name = $1)'
      into v_secret_set using 'telegram_bot_token';
  end if;

  if v_cron_installed then
    execute 'select schedule from cron.job where jobname = $1'
      into v_cron_schedule using 'tmgrow-telegram-tick';
  end if;

  return jsonb_build_object(
    'pg_net', v_net_ok,
    'pg_cron', v_cron_installed,
    'vault', v_vault_table,
    'secret_set', v_secret_set,
    'dispatch_trigger', exists (
      select 1 from pg_trigger
       where tgname = 'telegram_outbox_dispatch'
         and tgrelid = 'public.telegram_outbox'::regclass
    ),
    'completion_trigger_deferred', exists (
      select 1 from pg_trigger
       where tgname = 'submissions_task_completed_tg'
         and tgrelid = 'public.submissions'::regclass
         and tgdeferrable
    ),
    'cron_schedule', v_cron_schedule,
    'bot_enabled', public.setting_bool('telegram_bot_enabled', false),
    'task_completed_enabled', public.setting_bool('telegram_notify_task_completed', true),
    'queued', (select count(*) from public.telegram_outbox where status = 'queued'),
    'sending', (select count(*) from public.telegram_outbox where status = 'sending'),
    'failed', (select count(*) from public.telegram_outbox where status = 'failed'),
    'sent_24h', (select count(*) from public.telegram_outbox
                  where status = 'sent' and sent_at >= now() - interval '24 hours'),
    'last_sent_at', (select max(sent_at) from public.telegram_outbox where status = 'sent'),
    'last_error', (select last_error from public.telegram_outbox
                    where last_error is not null
                    order by created_at desc limit 1)
  );
end $$;

revoke all on function public.admin_telegram_sender_status() from public, anon;
grant execute on function public.admin_telegram_sender_status() to authenticated;


-- Retry: unchanged behaviour, plus the new columns are reset.
create or replace function public.admin_telegram_retry(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  update public.telegram_outbox
     set status = 'queued',
         last_error = null,
         attempted_at = null,
         request_id = null,
         http_status = null
   where id = p_id and status <> 'sent';
  if not found then raise exception 'TELEGRAM_ALREADY_SENT'; end if;

  perform public.audit('telegram.retry', 'telegram_outbox', p_id, null);
  perform public.telegram_send_pending(1);
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_telegram_retry(uuid) from public, anon;
grant execute on function public.admin_telegram_retry(uuid) to authenticated;


-- Delivery log: the existing shape plus the real HTTP status and pg_net id,
-- so the panel can show what Telegram actually answered.
create or replace function public.admin_telegram_list(
  p_status text default null,
  p_limit int default 30,
  p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.telegram_outbox o
   where (p_status is null or p_status = '' or o.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_items from (
    select jsonb_build_object(
      'id', o.id, 'kind', o.kind, 'status', o.status, 'message', o.message,
      'attempts', o.attempts, 'last_error', o.last_error, 'message_id', o.message_id,
      'telegram_id', o.telegram_id, 'created_at', o.created_at, 'sent_at', o.sent_at,
      'request_id', o.request_id, 'http_status', o.http_status,
      'user_id', o.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), p.email, 'User')
    ) x
      from public.telegram_outbox o
      left join public.profiles p on p.id = o.user_id
     where (p_status is null or p_status = '' or o.status = p_status)
     order by o.created_at desc
     limit greatest(1, least(coalesce(p_limit, 30), 100))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_telegram_list(text, int, int) from public, anon;
grant execute on function public.admin_telegram_list(text, int, int) to authenticated;


-- ============================================================================
-- SECTION 13 — EXTENSION-SIDE GRANTS (keep the API roles out)
-- ============================================================================
revoke all on function public.telegram_bot_token() from public, anon, authenticated;
revoke all on function public.telegram_json_message_id(text) from public, anon, authenticated;
revoke all on function public.telegram_claim_internal(int) from public, anon, authenticated;
revoke all on function public.telegram_send_pending(int) from public, anon, authenticated;
revoke all on function public.telegram_reconcile() from public, anon, authenticated;
revoke all on function public.telegram_tick() from public, anon, authenticated;
revoke all on function public.tg_telegram_outbox_dispatch() from public, anon, authenticated;


-- ============================================================================
-- SECTION 14 — PG_CRON (optional but recommended: retries + reconcile)
-- Minimum Supabase interval is one minute.
-- ============================================================================
do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule(
      'tmgrow-telegram-tick',
      '* * * * *',
      $cron$select public.telegram_tick();$cron$
    );
  else
    raise notice 'pg_cron is not installed; deferred sends still work, retries need Admin → Telegram → Send queued now.';
  end if;
end $$;


-- ============================================================================
-- SECTION 15 — PostgREST
-- ============================================================================
notify pgrst, 'reload schema';

commit;

-- ============================================================================
-- Rollback to the Edge Function path (only if ever needed):
--   drop trigger if exists telegram_outbox_dispatch on public.telegram_outbox;
--   drop trigger if exists submissions_task_completed_tg on public.submissions;
--   create trigger submissions_task_completed_tg
--     after update of status on public.submissions
--     for each row execute function public.tg_task_completed_notify();
--   select cron.unschedule('tmgrow-telegram-tick');
--   -- telegram_outbox rows and Vault secret are kept; nothing is deleted.
-- ============================================================================
