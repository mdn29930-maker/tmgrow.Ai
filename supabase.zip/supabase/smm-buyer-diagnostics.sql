-- ============================================================================
-- TM GROW — BUYER SMM DIAGNOSTICS (100% READ-ONLY)
--
-- Why this exists: the buyer section reports (a) "database error" when
-- creating a new SMM order and (b) an empty Services list. The application
-- code and supabase/smm-orders.sql are internally consistent (frontend
-- create_smm_order(p_service_id, p_target_link, p_quantity, p_idempotency_key)
-- matches the deployed RPC signature; wallet_move, ensure_profile,
-- notify_user, audit, telegram_enqueue and telegram_money all exist in
-- schema.sql). So the failure must be in the deployed database state.
--
-- Paste this whole file into the Supabase SQL editor and run it. Every
-- statement is a SELECT (plus safe catalog reads); nothing is inserted,
-- updated, deleted or altered. Send the output back and each result names
-- one possible cause. If any statement errors, that error IS the diagnosis.
-- ============================================================================

-- 1. Do the SMM tables exist at all? -----------------------------------------
--    'null' for either one means supabase/smm-orders.sql was never (fully) run
--    -> that alone explains BOTH bugs.
select
  to_regclass('public.smm_orders')    as smm_orders_table,
  to_regclass('public.smm_categories') as smm_categories_table;

-- 2. Do the SMM columns exist on the shared services table? -------------------
--    A missing row here = the services part of smm-orders.sql was not applied
--    -> buyer list errors, order creation errors.
select column_name, data_type, column_default
  from information_schema.columns
 where table_schema = 'public' and table_name = 'services'
   and column_name in ('is_smm','smm_active','category_id','rate_per_1000',
                       'cost_price_per_1000','language','estimated_time',
                       'features','archived_at')
 order by column_name;

-- 3. Which SMM RPC signatures are actually deployed? --------------------------
--    Expected: create_smm_order(uuid, text, int, text) and
--              create_smm_orders_bulk(jsonb, text). An OLD signature here
--              means an older migration version is live.
select p.proname,
       pg_get_function_identity_arguments(p.oid) as args,
       p.prosrc is not null as has_body
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public'
   and p.proname in ('create_smm_order','create_smm_orders_bulk',
                     'smm_list_services','my_smm_orders',
                     'smm_platform_counts','smm_categories_list')
 order by p.proname, args;

-- 4. Dependencies used INSIDE create_smm_order — all four must exist ----------
--    wallet_move must be (uuid, numeric, numeric, numeric, numeric, text, text,
--    uuid, text). If only an older overload exists, the charge fails and the
--    whole order transaction rolls back (money is NOT deducted twice — the RPC
--    is one transaction).
select p.proname,
       pg_get_function_identity_arguments(p.oid) as args
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public'
   and p.proname in ('wallet_move','ensure_profile','notify_user',
                     'audit','telegram_enqueue','telegram_money')
 order by p.proname, args;

-- 5. Can an authenticated buyer actually EXECUTE the RPCs? --------------------
--    false on create_smm_order = missing grant -> "database error" for buyers.
select p.proname,
       has_function_privilege('authenticated', p.oid, 'execute') as authenticated_can_execute
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public'
   and p.proname in ('create_smm_order','create_smm_orders_bulk',
                     'smm_list_services','my_smm_orders',
                     'smm_platform_counts','smm_categories_list')
 order by p.proname;

-- 6. THE CATALOGUE — why the buyer Services list is empty ---------------------
--    visible_to_buyers is exactly what smm_list_services() returns.
--    If smm_services = 0: the catalogue is genuinely empty. Nothing is broken;
--    create real services in Admin -> SMM panel -> "SMM services"
--    (Admin -> "Campaign services & pricing" creates worker-task services,
--    which are deliberately invisible to the SMM panel).
--    If smm_services > 0 but visible_to_buyers = 0: services exist but are
--    paused (smm_active), archived, or unpriced — toggle them Live in the
--    admin SMM services page.
select
  count(*)                                              as smm_services,
  count(*) filter (where smm_active)                    as active_flag,
  count(*) filter (where archived_at is not null)       as archived,
  count(*) filter (where rate_per_1000 is null)         as unpriced,
  count(*) filter (where smm_active
                     and archived_at is null
                     and rate_per_1000 is not null)     as visible_to_buyers
  from public.services
 where is_smm;

-- 7. Catalogue detail — every SMM row with the flags that gate visibility -----
select s.platform, s.name,
       s.smm_active,
       (s.archived_at is not null) as archived,
       s.rate_per_1000,
       s.min_quantity, s.max_quantity,
       c.name as category
  from public.services s
  left join public.smm_categories c on c.id = s.category_id
 where s.is_smm
 order by s.platform, s.sort_order, s.name;

-- 8. Buyer categories (what the buyer filter dropdown reads) ------------------
select count(*) as categories, count(*) filter (where is_active) as active_categories
  from public.smm_categories;

-- 9. Existing orders (must be preserved; confirms the table is live) ----------
select count(*) as total_orders,
       count(*) filter (where status = 'pending') as pending,
       max(created_at) as latest_order
  from public.smm_orders;

-- 10. VERDICT — read the Messages tab. One line per known cause. --------------
do $$
declare
  v_tables   text;
  v_cols     int;
  v_rpc      int;
  v_grant    boolean;
  wmove      int;
  visible    int;
  total      int;
begin
  select coalesce(to_regclass('public.smm_orders')::text,'none') || ' / ' ||
         coalesce(to_regclass('public.smm_categories')::text,'none')
    into v_tables;

  select count(*) into v_cols
    from information_schema.columns
   where table_schema='public' and table_name='services' and column_name='is_smm';

  select count(distinct p.proname) into v_rpc
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname='public'
     and p.proname in ('create_smm_order','create_smm_orders_bulk','smm_list_services');

  select coalesce(bool_and(has_function_privilege('authenticated', p.oid, 'execute')), false)
    into v_grant
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname='public' and p.proname in ('create_smm_order','smm_list_services');

  select count(distinct p.oid) into wmove
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname='public' and p.proname='wallet_move'
     and pg_get_function_identity_arguments(p.oid)
         = 'p_user uuid, p_available numeric, p_pending numeric, p_reserved numeric, p_bonus numeric, p_kind text, p_ref_kind text, p_ref_id uuid, p_note text';

  begin
    select count(*) filter (where smm_active and archived_at is null and rate_per_1000 is not null),
           count(*)
      into visible, total
      from public.services where is_smm;
  exception when others then
    visible := -1; total := -1;  -- is_smm column missing
  end;

  if v_tables like 'null%' then
    raise notice 'VERDICT: smm_orders table MISSING -> run supabase/smm-orders.sql once. Explains both bugs.';
  elsif v_cols = 0 then
    raise notice 'VERDICT: services.is_smm column MISSING -> run supabase/smm-orders.sql once. Explains both bugs.';
  elsif v_rpc < 3 then
    raise notice 'VERDICT: SMM RPCs missing (% of 3 core present) -> run supabase/smm-orders.sql once, then reload the API schema cache.', v_rpc;
  elsif not v_grant then
    raise notice 'VERDICT: execute GRANT missing on an SMM RPC -> run supabase/smm-orders.sql once (re-grants are included).';
  elsif wmove = 0 then
    raise notice 'VERDICT: wallet_move(uuid,numeric x4,text,text,uuid,text) overload MISSING -> run supabase/advanced-management.sql once; order creation rolls back without it.';
  elsif total = 0 then
    raise notice 'VERDICT: catalogue is EMPTY (no is_smm services). Backend is fine — create real services in Admin -> SMM panel -> SMM services.';
  elsif visible = 0 then
    raise notice 'VERDICT: % SMM services exist but NONE is visible (all paused/archived/unpriced). Set them Live in the admin SMM services page.', total;
  else
    raise notice 'VERDICT: backend and catalogue look correct (% services visible). The exact order error should now be visible in the buyer toast text — paste it back.', visible;
  end if;
end $$;

-- 11. Final safety net for a stale PostgREST schema cache (safe, no data) -----
--     Uncomment the next line and run it alone if every check above passes but
--     the app still says "Could not find the function":
-- notify pgrst, 'reload schema';

-- ============================================================================
-- REPAIR (only if a VERDICT above says so) — nothing destructive, ever:
--   * Re-run supabase/smm-orders.sql  (additive + idempotent by design:
--     create table if not exists, add column if not exists,
--     create or replace function, on conflict do nothing. Existing orders,
--     services, balances and ledger rows are untouched.)
--   * If VERDICT mentions wallet_move: also run supabase/advanced-management.sql
--     (also create-or-replace, backward compatible).
--   * Then reload the API schema cache: Supabase -> Project Settings -> API ->
--     "Reload", or run:  notify pgrst, 'reload schema';
-- ============================================================================
