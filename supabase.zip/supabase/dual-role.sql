-- TM GROW — dual roles: worker + buyer on the same account
-- A buyer who is also a worker must be able to switch between the two modes.
-- Mode is only a view preference; is_worker / is_buyer decide authorization.

-- set_my_mode: switching to worker only requires is_worker to be true, and
-- switching to buyer only requires is_buyer. The account is never "locked" in.
create or replace function public.set_my_mode(p_mode text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;
  if p_mode not in ('worker','buyer') then raise exception 'INVALID_STATUS'; end if;

  select * into p from public.profiles where id = u;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;

  if p_mode = 'buyer' and not coalesce(p.is_buyer, false) then
    raise exception 'BUYER_MODE_DISABLED';
  end if;
  if p_mode = 'worker' and not coalesce(p.is_worker, false) then
    raise exception 'WORKER_MODE_DISABLED';
  end if;

  update public.profiles
     set prefs = coalesce(prefs, '{}'::jsonb) || jsonb_build_object('mode', p_mode),
         updated_at = now()
   where id = u;

  perform public.audit('profile.mode', 'profile', u, jsonb_build_object('mode', p_mode));
  return jsonb_build_object('ok', true, 'mode', p_mode, 'is_worker', p.is_worker, 'is_buyer', p.is_buyer);
end $$;

-- Opening a buyer account must never remove worker access or force buyer mode.
create or replace function public.enable_buyer_mode()
returns jsonb language plpgsql security definer set search_path = public as $$
declare u uuid := auth.uid(); p public.profiles;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;
  perform public.ensure_profile();

  update public.profiles
     set is_buyer = true,
         updated_at = now()
   where id = u
   returning * into p;

  return to_jsonb(p);
end $$;

revoke all on function public.set_my_mode(text) from public, anon;
grant execute on function public.set_my_mode(text) to authenticated;
revoke all on function public.enable_buyer_mode() from public, anon;
grant execute on function public.enable_buyer_mode() to authenticated;

notify pgrst, 'reload schema';

-- ---------------------------------------------------------------------------
-- Your account: make sure BOTH flags are true, then verify.
-- Replace the email only if your owner account differs.
-- ---------------------------------------------------------------------------
update public.profiles
   set is_worker = true,
       is_buyer = true,
       updated_at = now()
 where lower(email) = lower('mdn29930@gmail.com');

select id, email, is_worker, is_buyer, status,
       coalesce(prefs ->> 'mode', '(none)') as mode
  from public.profiles
 where lower(email) = lower('mdn29930@gmail.com');
