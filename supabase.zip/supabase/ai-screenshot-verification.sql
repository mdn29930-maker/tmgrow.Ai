-- ============================================================================
-- TM GROW — AI SCREENSHOT VERIFICATION (database-native, pg_net)
--
-- Pipeline per submission:
--   1. queue job (trigger on submissions, only when enabled)
--   2. sign the private proof image with the Storage REST API (pg_net)
--   3. send the signed https URL to an OpenAI-compatible vision endpoint
--   4. poll both requests, parse the JSON verdict
--   5. decide through the existing verification_decide() path
--
-- Approval rules (deliberately strict, no "confidence alone"):
--   APPROVE only when verdict = approve AND confidence >= threshold AND the
--   model returned a concrete reason. A verdict alone never approves.
--   REJECT only on verdict = reject AND confidence >= 0.98.
--   Everything else → manual review with the model's reason recorded.
--
-- Secrets (Supabase Vault only, never returned to a client):
--   storage_service_key  service_role key, used ONLY to sign a proof URL
--   ai_verify_key        the vision API key
-- Settings: ai_screenshot_enabled, ai_verify_url, ai_verify_model,
--           ai_verify_min_confidence, ai_screenshot_max_attempts
--
-- If either secret is missing the job is routed to manual with a clear reason
-- instead of pretending to verify.
-- ============================================================================

begin;

insert into public.settings (key, value, is_public) values
  ('ai_screenshot_enabled', 'false'::jsonb, false),
  ('ai_verify_url', to_jsonb(''::text), false),
  ('ai_verify_model', to_jsonb('gpt-4o-mini'::text), false),
  ('ai_verify_min_confidence', '0.92'::jsonb, false),
  ('ai_screenshot_max_attempts', '3'::jsonb, false)
on conflict (key) do nothing;

create table if not exists public.proof_ai_jobs (
  id uuid primary key default gen_random_uuid(),
  submission_id uuid not null unique references public.submissions (id) on delete cascade,
  queue_id uuid references public.verification_queue (id) on delete set null,
  state text not null default 'queued'
    check (state in ('queued', 'signing', 'signed', 'asking', 'poll_ai', 'done', 'manual', 'dead')),
  sign_request_id bigint,
  ai_request_id bigint,
  signed_url text,
  verdict text,
  confidence numeric(4, 3),
  reason text,
  evidence jsonb not null default '{}'::jsonb,
  attempts int not null default 0,
  next_run_at timestamptz not null default now(),
  locked_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists proof_ai_jobs_state_idx
  on public.proof_ai_jobs (state, next_run_at);

-- One job per submission, exactly once.
create or replace function public.ai_screenshot_enqueue()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_queue uuid;
begin
  if not public.setting_bool('ai_screenshot_enabled', false) then
    return new;
  end if;

  insert into public.verification_queue (submission_id, task_id, worker_id, mode)
  values (new.id, new.task_id, new.worker_id, 'ai')
  on conflict (submission_id) do nothing;

  select id into v_queue from public.verification_queue where submission_id = new.id;

  insert into public.proof_ai_jobs (submission_id, queue_id)
  values (new.id, v_queue)
  on conflict (submission_id) do nothing;

  return new;
end $$;

revoke all on function public.ai_screenshot_enqueue() from public, anon, authenticated;

drop trigger if exists submissions_ai_screenshot on public.submissions;
create trigger submissions_ai_screenshot
  after insert on public.submissions
  for each row execute function public.ai_screenshot_enqueue();


-- ---------------------------------------------------------------------------
-- Stage helpers
-- ---------------------------------------------------------------------------
create or replace function public.proof_ai_secret(p_name text)
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v text;
begin
  if to_regclass('vault.decrypted_secrets') is null then
    return null;
  end if;
  execute 'select decrypted_secret from vault.decrypted_secrets where name = $1 limit 1'
    into v using p_name;
  return v;
end $$;

revoke all on function public.proof_ai_secret(text) from public, anon, authenticated;


create or replace function public.ai_screenshot_decide(
  p_job_id uuid, p_verdict text, p_confidence numeric, p_reason text, p_evidence jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  j public.proof_ai_jobs;
  v_min numeric := coalesce(public.setting_num('ai_verify_min_confidence', 0.92), 0.92);
  v_reason text := left(coalesce(nullif(btrim(p_reason), ''), ''), 400);
  v_decision text;
begin
  select * into j from public.proof_ai_jobs where id = p_job_id for update;
  if j.id is null then
    return jsonb_build_object('ok', false, 'code', 'JOB_NOT_FOUND');
  end if;
  if j.state in ('done', 'dead') then
    return jsonb_build_object('ok', true, 'already', true, 'state', j.state);
  end if;

  if p_verdict = 'approve' and p_confidence >= v_min and length(v_reason) >= 10 then
    v_decision := 'approve';
  elsif p_verdict = 'reject' and p_confidence >= 0.98 and length(v_reason) >= 10 then
    v_decision := 'reject';
  else
    v_decision := 'manual';
  end if;

  if j.queue_id is null then
    select id into j.queue_id from public.verification_queue where submission_id = j.submission_id;
  end if;

  if j.queue_id is not null then
    begin
      perform public.verification_decide(
        j.queue_id,
        v_decision,
        case v_decision
          when 'approve' then 'AI screenshot check: ' || v_reason
          when 'reject' then 'AI screenshot check: ' || v_reason
          else coalesce(nullif('AI was not certain enough: ' || v_reason, 'AI was not certain enough: '), 'AI could not verify the screenshot with enough evidence.')
        end,
        coalesce(p_evidence, '{}'::jsonb) || jsonb_build_object(
          'rule', 'ai_screenshot', 'verdict', p_verdict,
          'confidence', p_confidence, 'model', public.setting_text('ai_verify_model', '')
        )
      );
    exception when others then
      -- e.g. AUTO_REWARDS_DISABLED: keep it for a human instead of guessing.
      begin
        perform public.verification_decide(j.queue_id, 'manual',
          'AI approved but auto rewards are off: ' || left(sqlerrm, 200),
          coalesce(p_evidence, '{}'::jsonb));
      exception when others then null; end;
      v_decision := 'manual';
    end;
  end if;

  update public.proof_ai_jobs
     set state = case when v_decision = 'manual' then 'manual' else 'done' end,
         verdict = p_verdict, confidence = p_confidence, reason = v_reason,
         evidence = coalesce(p_evidence, '{}'::jsonb),
         last_error = null, updated_at = now()
   where id = j.id;

  return jsonb_build_object('ok', true, 'decision', v_decision);
end $$;

revoke all on function public.ai_screenshot_decide(uuid, text, numeric, text, jsonb) from public, anon, authenticated;


-- ---------------------------------------------------------------------------
-- Tick: one state machine, no duplicate requests, no stuck jobs
-- ---------------------------------------------------------------------------
create or replace function public.ai_screenshot_tick(p_limit int default 3)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  v_service text;
  v_ai_key text;
  v_ai_url text := nullif(public.setting_text('ai_verify_url', ''), '');
  v_supabase text;
  v_path text;
  v_ctx record;
  v_res jsonb;
  v_req bigint;
  v_raw record;
  v_content jsonb;
  v_max int := greatest(1, least(coalesce(public.setting_num('ai_screenshot_max_attempts', 3), 3)::int, 6));
  v_sent int := 0;
  v_decided int := 0;
  v_fail int := 0;
begin
  if auth.uid() is not null and auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if not public.setting_bool('ai_screenshot_enabled', false) then
    return jsonb_build_object('ok', true, 'skipped', 'DISABLED');
  end if;

  v_service := public.proof_ai_secret('storage_service_key');
  v_ai_key  := public.proof_ai_secret('ai_verify_key');
  v_supabase := public.setting_text('supabase_url', 'https://uqynletitbcksggunubs.supabase.co');

  for r in
    update public.proof_ai_jobs j
       set locked_at = now(), updated_at = now()
     where j.id in (
       select id from public.proof_ai_jobs
        where (state in ('queued', 'signed') and next_run_at <= now())
           or (state in ('signing', 'asking', 'poll_ai')
               and coalesce(locked_at, updated_at) < now() - interval '30 seconds')
        order by next_run_at
        limit greatest(1, least(coalesce(p_limit, 3), 5))
        for update skip locked
     )
    returning j.*
  loop
    begin
      /* ---- poll the signed-URL request ------------------------------- */
      if r.state = 'signing' and r.sign_request_id is not null then
        select * into v_raw from net._http_response where id = r.sign_request_id;
        if v_raw.id is null then continue; end if;
        if v_raw.timed_out or coalesce(v_raw.status_code, 0) not between 200 and 299 then
          raise exception 'SIGN_FAILED: %', coalesce(v_raw.error_msg, v_raw.status_code::text);
        end if;
        v_content := public.socify_json(v_raw.content);
        r.signed_url := v_supabase || '/storage/v1' || coalesce(v_content ->> 'signedURL', '');
        update public.proof_ai_jobs set state = 'signed', signed_url = r.signed_url,
               updated_at = now() where id = r.id;
        r.state := 'signed';
      end if;

      /* ---- poll the AI request --------------------------------------- */
      if (r.state = 'asking' or r.state = 'poll_ai') and r.ai_request_id is not null then
        select * into v_raw from net._http_response where id = r.ai_request_id;
        if v_raw.id is null then
          update public.proof_ai_jobs set state = 'poll_ai', updated_at = now() where id = r.id;
          continue;
        end if;
        if v_raw.timed_out or coalesce(v_raw.status_code, 0) not between 200 and 299 then
          raise exception 'AI_HTTP_%', coalesce(v_raw.status_code::text, 'timeout');
        end if;
        v_content := public.socify_json(v_raw.content);
        v_res := public.socify_json(coalesce(v_content #>> '{choices,0,message,content}', ''));
        if v_res is null then
          raise exception 'AI_BAD_JSON';
        end if;
        perform public.ai_screenshot_decide(
          r.id, lower(coalesce(v_res ->> 'verdict', 'uncertain')),
          coalesce((v_res ->> 'confidence')::numeric, 0),
          v_res ->> 'reason',
          jsonb_build_object('model', public.setting_text('ai_verify_model', ''),
                             'verdict', v_res ->> 'verdict',
                             'confidence', v_res ->> 'confidence')
        );
        v_decided := v_decided + 1;
        continue;
      end if;

      /* ---- stage 3: ask the vision model ----------------------------- */
      if r.state = 'signed' and coalesce(r.signed_url, '') <> '' then
        if v_ai_url is null or coalesce(v_ai_key, '') = '' then
          update public.proof_ai_jobs
             set state = 'manual', last_error = 'AI endpoint or key is not configured',
                 updated_at = now()
           where id = r.id;
          continue;
        end if;

        select c.title, c.instructions, c.target_url, sv.platform, sa.handle
          into v_ctx
          from public.verification_queue q
          join public.tasks t on t.id = q.task_id
          join public.campaigns c on c.id = t.campaign_id
          join public.services sv on sv.id = c.service_id
          left join public.social_accounts sa
                 on sa.user_id = q.worker_id and sa.platform = sv.platform and sa.status = 'linked'
         where q.id = r.queue_id;

        v_req := net.http_post(
          v_ai_url,
          jsonb_build_object(
            'model', public.setting_text('ai_verify_model', 'gpt-4o-mini'),
            'response_format', jsonb_build_object('type', 'json_object'),
            'messages', jsonb_build_array(
              jsonb_build_object('role', 'system',
                'content', 'You verify social-task screenshots for TM GROW. Reply with JSON only: '
                        || '{"verdict":"approve|reject|uncertain","confidence":0-1,"reason":"short"} '
                        || 'Approve only when the image visibly proves the exact requested action by the '
                        || 'worker account. Otherwise uncertain.'),
              jsonb_build_object('role', 'user', 'content', jsonb_build_array(
                jsonb_build_object('type', 'text',
                  'text', 'Task: ' || coalesce(v_ctx.title, '')
                        || E'\nPlatform: ' || coalesce(v_ctx.platform, '')
                        || E'\nTarget: ' || coalesce(v_ctx.target_url, '')
                        || E'\nWorker handle: ' || coalesce(v_ctx.handle, 'unknown')
                        || E'\nInstructions: ' || coalesce(v_ctx.instructions, '')),
                jsonb_build_object('type', 'image_url',
                  'image_url', jsonb_build_object('url', r.signed_url))
              ))
            )
          ),
          '{}'::jsonb,
          jsonb_build_object('Content-Type', 'application/json',
                             'Authorization', 'Bearer ' || v_ai_key),
          45000
        );

        update public.proof_ai_jobs
           set state = 'poll_ai', ai_request_id = v_req,
               attempts = attempts + 1, locked_at = now(), updated_at = now()
         where id = r.id;
        v_sent := v_sent + 1;
        continue;
      end if;

      /* ---- stage 2: sign the private proof path ----------------------- */
      if r.state in ('queued', 'signed') and coalesce(v_service, '') <> '' then
        select coalesce(s.proof_paths[1], s.proof_path) into v_path
          from public.submissions s where s.id = r.submission_id;
        if coalesce(v_path, '') = '' then
          update public.proof_ai_jobs set state = 'manual',
                 last_error = 'No screenshot path on this submission', updated_at = now()
           where id = r.id;
          continue;
        end if;

        v_req := net.http_post(
          v_supabase || '/storage/v1/object/sign/proofs/' || v_path,
          jsonb_build_object('expiresIn', 3600),
          '{}'::jsonb,
          jsonb_build_object('Content-Type', 'application/json',
                             'Authorization', 'Bearer ' || v_service),
          20000
        );
        update public.proof_ai_jobs
           set state = 'signing', sign_request_id = v_req,
               attempts = attempts + 1, locked_at = now(), updated_at = now()
         where id = r.id;
        v_sent := v_sent + 1;
        continue;
      end if;

      /* No secrets at all: keep it for a human, never guess. */
      update public.proof_ai_jobs
         set state = 'manual',
             last_error = 'storage_service_key or ai_verify_key is missing in Vault',
             updated_at = now()
       where id = r.id;
    exception when others then
      v_fail := v_fail + 1;
      update public.proof_ai_jobs
         set state = case when attempts >= v_max then 'dead' else 'queued' end,
             sign_request_id = null, ai_request_id = null, signed_url = null,
             last_error = left(sqlerrm, 300),
             next_run_at = now() + make_interval(secs => 60 * (2 ^ greatest(0, attempts - 1))::int),
             updated_at = now()
       where id = r.id;
    end;
  end loop;

  return jsonb_build_object('ok', true, 'dispatched', v_sent, 'decided', v_decided,
                            'failed', v_fail, 'ran_at', now());
end $$;

revoke all on function public.ai_screenshot_tick(int) from public, anon, authenticated;


create or replace function public.ai_screenshot_pipeline()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v jsonb;
begin
  v := public.ai_screenshot_tick(3);
  if (v ->> 'dispatched')::int > 0 or (v ->> 'decided')::int > 0 then
    perform public.audit('ai_screenshot.tick', 'proof_ai_job', null, v);
  end if;
  return v;
end $$;

revoke all on function public.ai_screenshot_tick(int) from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-ai-screenshot', '* * * * *',
      $cron$select public.ai_screenshot_tick(3);$cron$);
    raise notice 'pg_cron: tmgrow-ai-screenshot every minute.';
  end if;
end $$;


-- ---------------------------------------------------------------------------
-- Admin
-- ---------------------------------------------------------------------------
create or replace function public.admin_ai_screenshot_state()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'enabled', public.setting_bool('ai_screenshot_enabled', false),
    'endpoint_set', coalesce(public.setting_text('ai_verify_url', ''), '') <> '',
    'ai_key_set', coalesce(public.proof_ai_secret('ai_verify_key'), '') <> '',
    'storage_key_set', coalesce(public.proof_ai_secret('storage_service_key'), '') <> '',
    'model', public.setting_text('ai_verify_model', ''),
    'min_confidence', coalesce(public.setting_num('ai_verify_min_confidence', 0.92), 0.92),
    'counters', jsonb_build_object(
      'queued', (select count(*) from public.proof_ai_jobs where state in ('queued','signed')),
      'asking', (select count(*) from public.proof_ai_jobs where state in ('signing','asking','poll_ai')),
      'done', (select count(*) from public.proof_ai_jobs where state = 'done'),
      'manual', (select count(*) from public.proof_ai_jobs where state = 'manual'),
      'dead', (select count(*) from public.proof_ai_jobs where state = 'dead')
    ),
    'recent', (select coalesce(jsonb_agg(jsonb_build_object(
                 'id', j.id, 'state', j.state, 'verdict', j.verdict,
                 'confidence', j.confidence, 'reason', j.reason,
                 'attempts', j.attempts, 'last_error', j.last_error,
                 'updated_at', j.updated_at) order by j.updated_at desc), '[]'::jsonb)
               from (select * from public.proof_ai_jobs order by updated_at desc limit 15) j)
  );
end $$;

revoke all on function public.admin_ai_screenshot_state() from public, anon;
grant execute on function public.admin_ai_screenshot_state() to authenticated;


create or replace function public.admin_ai_screenshot_run()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  return public.ai_screenshot_tick(5);
end $$;

revoke all on function public.admin_ai_screenshot_run() from public, anon;
grant execute on function public.admin_ai_screenshot_run() to authenticated;


create or replace function public.admin_ai_screenshot_retry(p_job_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  update public.proof_ai_jobs
     set state = 'queued', attempts = 0, next_run_at = now(),
         sign_request_id = null, ai_request_id = null, signed_url = null,
         locked_at = null, last_error = null, updated_at = now()
   where id = p_job_id and state in ('manual', 'dead', 'queued');
  if not found then raise exception 'AI_JOB_NOT_RETRYABLE'; end if;
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_ai_screenshot_retry(uuid) from public, anon;
grant execute on function public.admin_ai_screenshot_retry(uuid) to authenticated;


notify pgrst, 'reload schema';

commit;
