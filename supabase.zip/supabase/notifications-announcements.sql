-- ============================================================================
-- TM GROW — NOTIFICATIONS + ANNOUNCEMENTS
--
-- Idempotent, additive. Run after:
--   telegram-completion-fix.sql  (sender, retry, outbox states)
--   smm-drip.sql                 (SMM orders/tasks)
--
-- Adds only these worker Telegram events:
--   checkin          → after a real check-in reward credit
--   task_completed   → already implemented (approval + credited ledger only)
--   task_available   → after real campaign / SMM units are released
--   announcement     → admin broadcasts
--
-- Removes nothing. Wallet and ledger logic is untouched. The existing
-- telegram_outbox, dedupe key, retry and sender functions are reused.
-- ============================================================================

begin;

-- ============================================================================
-- 1. SETTINGS
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('telegram_notify_checkin', 'true'::jsonb, false),
  ('telegram_notify_task_available', 'true'::jsonb, false),
  ('telegram_notify_announcement', 'true'::jsonb, false),
  ('telegram_footer_text', to_jsonb('🔔 @BTCsignal777 | 📢 @Tmgrowglobal'::text), false),
  ('announcement_max_recipients', '500'::jsonb, false),
  ('task_available_notify_limit', '100'::jsonb, false)
on conflict (key) do nothing;

-- The per-order SMM alert is replaced by the task_available trigger below,
-- so the old aggregated sender is switched off to avoid two messages.
insert into public.settings (key, value, is_public) values
  ('smm_release_notifications', 'false'::jsonb, false)
on conflict (key) do update set value = 'false'::jsonb, updated_at = now();

-- ============================================================================
-- 2. TEMPLATES (English only, real TM GROW values)
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('telegram_tpl_checkin',
   to_jsonb($tpl$📅 Check-in Successful!

🔥 Streak: {{streak_days}} days
🪙 Reward: +{{reward_amount}} {{coin}}

Check in tomorrow for more rewards! 🎉$tpl$::text), false),

  ('telegram_tpl_task_completed',
   to_jsonb($tpl$🎉 Task Completed!

✅ Task: {{task}}
💰 Reward: +{{reward}} USDT
🪙 {{coin}}: +{{coin_reward}}

Keep completing tasks to earn more rewards!$tpl$::text), false),

  ('telegram_tpl_task_available',
   to_jsonb($tpl$🆕 New Task Available!

📋 Task: {{task_title}} #{{task_id}}
📌 Type: {{task_type}}
👤 Requirements: {{requirements}}
👥 Slots: {{available_slots}}
💰 Reward: +{{usdt_reward}} USDT & +{{coin_reward}} {{coin}}

Complete the task to earn more rewards!

⏱️ {{release_interval_text}}

━━━━━━━━━━━━━━━
{{footer}}$tpl$::text), false),

  ('telegram_tpl_announcement',
   to_jsonb($tpl$📣 {{title}}

{{body}}

{{link_line}}
━━━━━━━━━━━━━━━
{{footer}}$tpl$::text), false)
on conflict (key) do update set value = excluded.value, updated_at = now();


-- ============================================================================
-- 3. CHECK-IN NOTIFICATION (after the reward credit, in the same transaction)
-- ============================================================================
create or replace function public.claim_daily_checkin()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  streak_yesterday int;
  v_streak int := 1;
  v_reward numeric;
  v_total int;
  w public.wallets;
  v_coin text := coalesce(nullif(public.setting_text('coin_name', ''), ''), 'TG Coin');
begin
  perform public.ensure_profile();
  if exists (select 1 from public.daily_checkins where user_id = uid and day = current_date) then
    raise exception 'ALREADY_CHECKED_IN';
  end if;

  select streak into v_streak from (
    select streak from public.daily_checkins
     where user_id = uid and day = current_date - 1
  ) s;
  if v_streak is null then v_streak := 1; else v_streak := v_streak + 1; end if;

  v_reward := greatest(0, coalesce(public.setting_num('daily_checkin_tg', 0.5), 0.5));

  insert into public.daily_checkins (user_id, day, reward_tg, streak)
  values (uid, current_date, v_reward, v_streak);

  if v_reward > 0 then
    update public.wallets
       set tg_balance = tg_balance + v_reward,
           lifetime_tg = lifetime_tg + v_reward,
           updated_at = now()
     where user_id = uid
     returning * into w;
  end if;

  select count(*) into v_total from public.daily_checkins where user_id = uid;

  /* Telegram: only after the coin reward was written above. */
  perform public.telegram_enqueue(
    uid, 'checkin',
    jsonb_build_object(
      'streak_days', v_streak,
      'reward_amount', public.telegram_money(v_reward),
      'coin', v_coin
    ),
    'checkin:' || uid::text || ':' || current_date::text
  );

  return jsonb_build_object(
    'ok', true,
    'streak', v_streak,
    'total_days', v_total,
    'reward_tg', v_reward,
    'tg_balance', coalesce(w.tg_balance, 0)
  );
end $$;

revoke all on function public.claim_daily_checkin() from public, anon;
grant execute on function public.claim_daily_checkin() to authenticated;


-- ============================================================================
-- 4. NEW TASK AVAILABLE
--    Statement-level trigger: one message per released batch, never per row.
--    Campaign batches and SMM drip batches are both covered. Worker rewards
--    only; buyer price and profit are never included.
-- ============================================================================
create or replace function public.tg_new_tasks_notify()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_coin     text := coalesce(nullif(public.setting_text('coin_name', ''), ''), 'TG Coin');
  v_footer   text := coalesce(nullif(public.setting_text('telegram_footer_text', ''), ''), '');
  v_coin_task numeric := coalesce(public.setting_num('tg_per_task', 1), 0);
  v_cap      int := greatest(1, least(coalesce(public.setting_num('task_available_notify_limit', 100), 100)::int, 200));
  v_interval int := greatest(1, coalesce(public.setting_num('smm_drip_interval_minutes', 5), 5)::int);
  r          record;
begin
  /* ---- campaign tasks ------------------------------------------------- */
  for r in
    select c.id                as campaign_id,
           c.title             as title,
           c.reward_per_task   as reward,
           c.countries         as countries,
           c.min_trust_score   as min_trust,
           c.require_linked_account as needs_account,
           s.platform          as platform,
           s.name              as service_name,
           count(*)            as batch_slots,
           (select count(*) from public.tasks t2
             where t2.campaign_id = c.id and t2.status = 'available') as open_slots,
           md5(string_agg(t.id::text, ',' order by t.id::text)) as batch_key
      from new_tasks nt
      join public.tasks t on t.id = nt.id
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
     where nt.status = 'available' and nt.campaign_id is not null
     group by c.id, c.title, c.reward_per_task, c.countries, c.min_trust_score,
              c.require_linked_account, s.platform, s.name
  loop
    perform public.tg_task_available_broadcast(
      'campaign:' || r.campaign_id::text,
      substr(r.campaign_id::text, 1, 8),
      r.title,
      r.platform,
      initcap(coalesce(r.platform, 'task')) || ' task',
      case
        when r.needs_account then 'Verified ' || initcap(coalesce(r.platform, 'social')) || ' account'
        when coalesce(array_length(r.countries, 1), 0) > 0 then 'Selected countries only'
        when coalesce(r.min_trust, 0) > 0 then 'Trust score ' || r.min_trust || '+'
        else 'Open to all active workers'
      end,
      greatest(r.open_slots, r.batch_slots),
      r.reward,
      v_coin_task,
      v_coin,
      'New batches are released as buyers fund more slots.',
      v_footer,
      r.batch_key,
      v_cap,
      null,
      null,
      null,
      null,
      null,
      null,
      null
    );
  end loop;

  /* ---- SMM drip tasks -------------------------------------------------- */
  for r in
    select o.id                as order_id,
           s.name              as service_name,
           s.platform          as platform,
           round(coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot) / 1000.0, 6) as reward,
           coalesce(o.drip_interval_minutes, v_interval) as interval_minutes,
           count(*)            as batch_slots,
           (select count(*) from public.tasks t2
             where t2.smm_order_id = o.id and t2.status = 'available') as open_slots,
           md5(string_agg(t.id::text, ',' order by t.id::text)) as batch_key
      from new_tasks nt
      join public.tasks t on t.id = nt.id
      join public.smm_orders o on o.id = t.smm_order_id
      join public.services s on s.id = o.service_id
     where nt.status = 'available' and nt.smm_order_id is not null
       and not o.drip_paused
     group by o.id, s.name, s.platform, s.worker_reward_per_1000,
              o.worker_reward_snapshot, o.drip_interval_minutes
  loop
    perform public.tg_task_available_broadcast(
      'smm:' || r.order_id::text,
      substr(r.order_id::text, 1, 8),
      r.service_name,
      r.platform,
      initcap(coalesce(r.platform, 'social')) || ' action',
      'Open to all active workers',
      greatest(r.open_slots, r.batch_slots),
      greatest(r.reward, 0.000001),
      0,
      v_coin,
      'New units are released every ' || r.interval_minutes || ' min while the order is active.',
      v_footer,
      r.batch_key,
      v_cap,
      null,
      null,
      null,
      null,
      null,
      null,
      null
    );
  end loop;

  return null;
end $$;

revoke all on function public.tg_new_tasks_notify() from public, anon, authenticated;

drop trigger if exists tasks_new_task_notify on public.tasks;
create trigger tasks_new_task_notify
  after insert on public.tasks
  referencing new table as new_tasks
  for each statement execute function public.tg_new_tasks_notify();


-- Shared broadcaster: in-app + Telegram, dedupe per batch per worker.
-- Extra parameters are accepted so announcements can reuse the same routine.
create or replace function public.tg_task_available_broadcast(
  p_source       text,
  p_task_id      text,
  p_title        text,
  p_platform     text,
  p_type         text,
  p_requirements text,
  p_slots        int,
  p_usdt_reward  numeric,
  p_coin_reward  numeric,
  p_coin         text,
  p_interval_text text,
  p_footer       text,
  p_batch_key    text,
  p_limit        int default 2000,
  p_audience     text default null,
  p_image_url    text default null,
  p_link_url     text default null,
  p_body_override text default null,
  p_title_override text default null,
  p_channel      text default 'both',
  p_kind         text default 'task_available',
  p_dedupe_scope text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_targets uuid[];
  v_msg     text;
  v_key     text := coalesce(p_dedupe_scope, p_batch_key);
  v_scope   text := coalesce(p_kind, 'task_available') || ':' || p_source || ':' || v_key;
  v_n int := 0;
  v_w uuid;
  v_audience text := coalesce(p_audience, 'workers');
begin
  p_channel := coalesce(nullif(p_channel, ''), 'both');

  if not public.setting_bool(
       case when p_kind = 'task_available' then 'telegram_notify_task_available'
            when p_kind = 'announcement' then 'telegram_notify_announcement'
            else 'telegram_notify_' || p_kind end, true) then
    return jsonb_build_object('ok', true, 'skipped', 'EVENT_DISABLED');
  end if;

  select coalesce(array_agg(v.id), '{}'::uuid[]) into v_targets
    from (
      select w.id
        from public.profiles w
       where w.status = 'active'
         and ((v_audience = 'workers' and w.is_worker)
           or (v_audience = 'buyers' and w.is_buyer)
           or (v_audience = 'all' and (w.is_worker or w.is_buyer)))
         and not exists (
           select 1 from public.notifications n
            where n.user_id = w.id
              and n.kind = coalesce(p_kind, 'task_available')
              and n.body like '%' || v_key || '%'
              and n.created_at > now() - interval '1 minute'
         )
       order by w.created_at desc
       limit greatest(1, least(coalesce(p_limit, 200), 500))
    ) v;

  if coalesce(array_length(v_targets, 1), 0) = 0 then
    return jsonb_build_object('ok', true, 'recipients', 0);
  end if;

  v_msg := coalesce(p_body_override,
    'New tasks are available in TM GROW.');

  if p_kind = 'task_available' then
    v_msg := 'New units available · ' || coalesce(p_title, '') || ' (' || v_key || ')';
  elsif p_kind = 'announcement' then
    v_msg := coalesce(p_title_override, p_title, 'Announcement');
  end if;

  if p_channel in ('in_app', 'both') then
    insert into public.notifications (user_id, title, body, kind, link)
    select t.id,
           case when p_kind = 'announcement' then coalesce(p_title_override, p_title, 'Announcement')
                else 'New task available' end,
           coalesce(p_body_override, v_msg),
           coalesce(p_kind, 'task_available'),
           case when p_kind = 'announcement' then coalesce(p_link_url, '#/notifications')
                else '#/tasks' end
      from unnest(v_targets) as t(id);
  end if;

  if p_channel in ('telegram', 'both') then
    foreach v_w in array v_targets loop
      declare
        v_outbox uuid;
      begin
        v_outbox := public.telegram_enqueue(
           v_w,
           coalesce(p_kind, 'task_available'),
           case when p_kind = 'announcement' then
             jsonb_build_object(
               'title', coalesce(p_title_override, p_title, 'Announcement'),
               'body', coalesce(p_body_override, ''),
               'link_line', case when p_link_url is not null then '👉 ' || p_link_url else '' end,
               'footer', coalesce(p_footer, '')
             )
           else
             jsonb_build_object(
               'task_title', coalesce(p_title, 'Task'),
               'task_id', coalesce(p_task_id, ''),
               'task_type', coalesce(p_type, ''),
               'requirements', coalesce(p_requirements, ''),
               'available_slots', p_slots,
               'usdt_reward', public.telegram_money(p_usdt_reward),
               'coin_reward', public.telegram_money(coalesce(p_coin_reward, 0)),
               'coin', coalesce(p_coin, 'TG Coin'),
               'release_interval_text', coalesce(p_interval_text, ''),
               'footer', coalesce(p_footer, '')
             )
           end,
           coalesce(p_kind, 'task_available') || ':' || coalesce(p_dedupe_scope, p_source || ':' || v_key) || ':' || v_w::text
        );

        if v_outbox is not null then
          if coalesce(p_image_url, '') ~* '^https://' then
            update public.telegram_outbox set media_url = p_image_url where id = v_outbox;
          end if;
          v_n := v_n + 1;
        end if;
      end;
    end loop;
  end if;

  return jsonb_build_object('ok', true, 'recipients', array_length(v_targets, 1),
                            'notified', v_n, 'scope', v_scope);
end $$;

revoke all on function public.tg_task_available_broadcast(
  text, text, text, text, text, text, int, numeric, numeric, text, text, text, text,
  int, text, text, text, text, text, text, text, text
) from public, anon, authenticated;


-- ============================================================================
-- 5. ADMIN ANNOUNCEMENTS
-- ============================================================================
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  image_url text,
  link_url text,
  audience text not null default 'all' check (audience in ('all', 'workers', 'buyers')),
  channel text not null default 'both' check (channel in ('telegram', 'in_app', 'both')),
  status text not null default 'draft'
    check (status in ('draft', 'scheduled', 'sending', 'sent', 'failed', 'cancelled')),
  scheduled_at timestamptz,
  sent_at timestamptz,
  recipients int not null default 0,
  telegram_queued int not null default 0,
  error_text text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.announcements enable row level security;
-- No policies: SECURITY DEFINER RPCs only.

create index if not exists announcements_status_idx
  on public.announcements (status, scheduled_at);
create index if not exists announcements_created_idx
  on public.announcements (created_at desc);

drop trigger if exists announcements_set_updated_at on public.announcements;
create trigger announcements_set_updated_at
  before update on public.announcements
  for each row execute function public.tg_set_updated_at();


create or replace function public.admin_announcement_save(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_title text := nullif(btrim(coalesce(p_payload ->> 'title', '')), '');
  v_body text := nullif(btrim(coalesce(p_payload ->> 'body', '')), '');
  v_image text := nullif(btrim(coalesce(p_payload ->> 'image_url', '')), '');
  v_link text := nullif(btrim(coalesce(p_payload ->> 'link_url', '')), '');
  v_audience text := lower(coalesce(nullif(btrim(p_payload ->> 'audience'), ''), 'all'));
  v_channel text := lower(coalesce(nullif(btrim(p_payload ->> 'channel'), ''), 'both'));
  v_sched timestamptz;
  v_row public.announcements;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if v_title is null or char_length(v_title) < 3 then raise exception 'INVALID_TITLE'; end if;
  if v_body is null or char_length(v_body) < 10 then raise exception 'INVALID_BODY'; end if;
  if char_length(v_title) > 140 or char_length(v_body) > 3000 then raise exception 'INVALID_BODY'; end if;
  if v_image is not null and v_image !~* '^https://' then raise exception 'INVALID_IMAGE_URL'; end if;
  if v_link is not null and v_link !~* '^https?://' then raise exception 'INVALID_URL'; end if;
  if v_audience not in ('all', 'workers', 'buyers') then raise exception 'INVALID_AUDIENCE'; end if;
  if v_channel not in ('telegram', 'in_app', 'both') then raise exception 'INVALID_CHANNEL'; end if;

  begin
    v_sched := nullif(btrim(coalesce(p_payload ->> 'scheduled_at', '')), '')::timestamptz;
  exception when others then
    raise exception 'INVALID_SCHEDULE_TIME';
  end;

  begin
    v_id := nullif(btrim(coalesce(p_payload ->> 'id', '')), '')::uuid;
  exception when others then
    v_id := null;
  end;

  if v_id is null then
    insert into public.announcements (title, body, image_url, link_url, audience, channel, status, scheduled_at, created_by)
    values (v_title, v_body, v_image, v_link, v_audience, v_channel,
            case when v_sched is not null and v_sched > now() then 'scheduled' else 'draft' end,
            v_sched, auth.uid())
    returning * into v_row;
  else
    update public.announcements
       set title = v_title,
           body = v_body,
           image_url = v_image,
           link_url = v_link,
           audience = v_audience,
           channel = v_channel,
           scheduled_at = v_sched,
           status = case when status in ('draft', 'scheduled')
                         then case when v_sched is not null and v_sched > now() then 'scheduled' else 'draft' end
                         else status end
     where id = v_id and status in ('draft', 'scheduled')
     returning * into v_row;
    if v_row.id is null then raise exception 'ANNOUNCEMENT_NOT_EDITABLE'; end if;
  end if;

  perform public.audit('announcement.save', 'announcement', v_row.id,
    jsonb_build_object('title', v_row.title, 'audience', v_row.audience,
                       'channel', v_row.channel, 'scheduled_at', v_row.scheduled_at));
  return jsonb_build_object('ok', true, 'announcement', to_jsonb(v_row));
end $$;

revoke all on function public.admin_announcement_save(jsonb) from public, anon;
grant execute on function public.admin_announcement_save(jsonb) to authenticated;


create or replace function public.admin_announcement_list(p_limit int default 30, p_offset int default 0)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total from public.announcements;

  select coalesce(jsonb_agg(to_jsonb(a) order by a.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select * from public.announcements
       order by created_at desc
       limit greatest(1, least(coalesce(p_limit, 30), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) a;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_announcement_list(int, int) from public, anon;
grant execute on function public.admin_announcement_list(int, int) to authenticated;


create or replace function public.admin_announcement_preview(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  a public.announcements;
  v_audience int;
  v_footer text := coalesce(nullif(public.setting_text('telegram_footer_text', ''), ''), '');
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into a from public.announcements where id = p_id;
  if a.id is null then raise exception 'ANNOUNCEMENT_NOT_FOUND'; end if;

  select count(*) into v_audience
    from public.profiles w
   where w.status = 'active'
     and ((a.audience = 'workers' and w.is_worker)
       or (a.audience = 'buyers' and w.is_buyer)
       or (a.audience = 'all' and (w.is_worker or w.is_buyer)));

  return jsonb_build_object(
    'id', a.id, 'title', a.title, 'body', a.body,
    'audience', a.audience, 'channel', a.channel,
    'audience_count', v_audience,
    'rendered', public.telegram_render(
      coalesce(nullif(public.setting_text('telegram_tpl_announcement', ''), ''),
               public.setting_default_announcement()),
      jsonb_build_object(
        'title', a.title,
        'body', a.body,
        'link_line', case when a.link_url is not null then '👉 ' || a.link_url else '' end,
        'footer', v_footer
      )
    )
  );
end $$;

revoke all on function public.admin_announcement_preview(uuid) from public, anon;
grant execute on function public.admin_announcement_preview(uuid) to authenticated;


create or replace function public.admin_announcement_publish(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  a public.announcements;
  v_footer text := coalesce(nullif(public.setting_text('telegram_footer_text', ''), ''), '');
  v_res jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into a from public.announcements where id = p_id for update;
  if a.id is null then raise exception 'ANNOUNCEMENT_NOT_FOUND'; end if;
  if a.status in ('sent', 'sending') then raise exception 'ANNOUNCEMENT_ALREADY_SENT'; end if;
  if a.status = 'cancelled' then raise exception 'ANNOUNCEMENT_CANCELLED'; end if;

  update public.announcements set status = 'sending' where id = a.id;

  begin
    v_res := public.tg_task_available_broadcast(
      'announcement:' || a.id::text,
      null, a.title, null, 'announcement', null, 0, 0, 0,
      coalesce(nullif(public.setting_text('coin_name', ''), ''), 'TG Coin'),
      null, v_footer, a.id::text,
      coalesce(public.setting_num('announcement_max_recipients', 2000), 2000)::int,
      a.audience, a.image_url, a.link_url,
      a.body, a.title, a.channel, 'announcement', a.id::text
    );

    update public.announcements
       set status = 'sent',
           sent_at = now(),
           recipients = coalesce((v_res ->> 'recipients')::int, 0),
           telegram_queued = coalesce((v_res ->> 'notified')::int, 0),
           error_text = null
     where id = a.id;
  exception when others then
    update public.announcements
       set status = 'failed', error_text = left(sqlerrm, 300)
     where id = a.id;
    perform public.audit('announcement.publish_failed', 'announcement', a.id,
      jsonb_build_object('error', left(sqlerrm, 300)));
    raise;
  end;

  perform public.audit('announcement.publish', 'announcement', a.id, v_res);
  return jsonb_build_object('ok', true, 'announcement', (
    select to_jsonb(x) from public.announcements x where x.id = a.id
  ));
end $$;

revoke all on function public.admin_announcement_publish(uuid) from public, anon;
grant execute on function public.admin_announcement_publish(uuid) to authenticated;


create or replace function public.admin_announcement_cancel(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  update public.announcements
     set status = 'cancelled'
   where id = p_id and status in ('draft', 'scheduled');
  if not found then raise exception 'ANNOUNCEMENT_NOT_CANCELLABLE'; end if;

  perform public.audit('announcement.cancel', 'announcement', p_id, null);
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_announcement_cancel(uuid) from public, anon;
grant execute on function public.admin_announcement_cancel(uuid) to authenticated;


-- Default announcement template when the setting is missing.
create or replace function public.setting_default_announcement()
returns text
language sql
immutable
as $$
  select $tpl$📣 {{title}}

{{body}}

{{link_line}}
━━━━━━━━━━━━━━━
{{footer}}$tpl$;
$$;

revoke all on function public.setting_default_announcement() from public, anon, authenticated;


-- Scheduled publishing (one per row, guarded by the status transition).
create or replace function public.announcements_scheduled()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  v_sent int := 0;
  v_failed int := 0;
  v_admin uuid;
  v_prev text;
begin
  /* The publisher checks the admin role through auth.uid(). A cron run has no
     session, so it runs as the first active OWNER / SUPER_ADMIN exactly like
     the other schedulers. */
  select id into v_admin
    from public.profiles
   where admin_role in ('OWNER', 'SUPER_ADMIN') and status = 'active'
   order by case when admin_role = 'OWNER' then 0 else 1 end, created_at
   limit 1;

  if v_admin is null then
    return jsonb_build_object('ok', false, 'reason', 'NO_ACTIVE_OWNER');
  end if;

  v_prev := coalesce(current_setting('request.jwt.claims', true), '');
  perform set_config('request.jwt.claims',
    jsonb_build_object('sub', v_admin::text, 'role', 'authenticated')::text, true);

  for r in
    select id from public.announcements
     where status = 'scheduled' and scheduled_at is not null and scheduled_at <= now()
     order by scheduled_at
     limit 10
     for update skip locked
  loop
    begin
      perform public.admin_announcement_publish(r.id);
      v_sent := v_sent + 1;
    exception when others then
      v_failed := v_failed + 1;
    end;
  end loop;

  if v_prev <> '' then
    perform set_config('request.jwt.claims', v_prev, true);
  end if;

  return jsonb_build_object('ok', true, 'sent', v_sent, 'failed', v_failed);
end $$;

revoke all on function public.announcements_scheduled() from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-announcements', '* * * * *',
      $cron$select public.announcements_scheduled();$cron$);
    raise notice 'pg_cron: tmgrow-announcements every minute.';
  end if;
end $$;


-- ============================================================================
-- 6. IMAGE SUPPORT IN THE EXISTING OUTBOX SENDER
--    media_url is optional. Without it the sender still uses sendMessage.
-- ============================================================================
alter table public.telegram_outbox add column if not exists media_url text;

create or replace function public.telegram_send_pending(p_limit int default 25)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_token      text := public.telegram_bot_token();
  v_has_net    boolean;
  v_timeout    int;
  v_base       text;
  v_max        int;
  v_row        public.telegram_outbox;
  v_request    bigint;
  v_url        text;
  v_payload    jsonb;
  v_headers    jsonb := '{"Content-Type": "application/json"}'::jsonb;
  v_dispatched int := 0;
  v_failed     int := 0;
begin
  if coalesce(btrim(v_token), '') = '' then
    return jsonb_build_object('ok', false, 'error', 'TELEGRAM_BOT_TOKEN_MISSING',
                              'dispatched', 0, 'failed', 0);
  end if;

  v_has_net := to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
            or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;
  if not v_has_net then
    return jsonb_build_object('ok', false, 'error', 'PG_NET_NOT_INSTALLED',
                              'dispatched', 0, 'failed', 0);
  end if;

  v_timeout := greatest(5000, least(coalesce(public.setting_num('telegram_http_timeout_ms', 30000), 30000)::int, 120000));
  v_base := rtrim(coalesce(nullif(public.setting_text('telegram_api_base', ''), ''), 'https://api.telegram.org'), '/');
  v_max := greatest(1, least(coalesce(public.setting_num('telegram_max_attempts', 6), 6)::int, 20));

  for v_row in select * from public.telegram_claim_internal(p_limit) loop
    begin
      if coalesce(v_row.media_url, '') ~* '^https://' then
        v_url := v_base || '/bot' || v_token || '/sendPhoto';
        v_payload := jsonb_build_object(
          'chat_id', v_row.telegram_id::text,
          'photo', v_row.media_url,
          'caption', v_row.message
        );
      else
        v_url := v_base || '/bot' || v_token || '/sendMessage';
        v_payload := jsonb_build_object(
          'chat_id', v_row.telegram_id::text,
          'text', v_row.message,
          'disable_web_page_preview', false
        );
      end if;

      if to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null then
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers, v_timeout);
      else
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers);
      end if;

      update public.telegram_outbox set request_id = v_request where id = v_row.id;
      v_dispatched := v_dispatched + 1;
    exception when others then
      v_failed := v_failed + 1;
      update public.telegram_outbox
         set status = case when v_row.attempts >= v_max then 'failed' else 'retrying' end,
             error_class = 'transient',
             last_error = public.telegram_redact('PG_NET_ERROR: ' || sqlerrm),
             request_id = null,
             next_attempt_at = case when v_row.attempts >= v_max then null
               else now() + make_interval(secs => public.telegram_backoff_seconds(v_row.attempts)) end
       where id = v_row.id;
    end;
  end loop;

  return jsonb_build_object('ok', v_failed = 0, 'dispatched', v_dispatched,
                            'failed', v_failed, 'timeout_ms', v_timeout);
end $$;

revoke all on function public.telegram_send_pending(int) from public, anon, authenticated;


notify pgrst, 'reload schema';

commit;
