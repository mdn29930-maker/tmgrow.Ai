-- ============================================================================
-- TM GROW — set the admin password and make the account OWNER, in one run
--
-- Run the whole file in Supabase Dashboard -> SQL Editor -> New query.
-- It does three things:
--   1. writes a new bcrypt password for auth.users
--   2. confirms the email, so "Confirm your email first" cannot block sign-in
--   3. upserts the profile as OWNER / active and creates its wallet row
--
-- Then sign in on the app with that email + password (Sign in, not Sign up).
--
-- WARNING: the password below is written in plain text in this file. Change it
-- to a strong one after the first login (Authentication -> Users -> Reset
-- password). Do not publish this repository with a real password in it: a
-- static host serves every file, .sql included.
--
-- If it reports "no auth user": the account was never created. Create it in
-- Authentication -> Users -> "Add user" with this email and any password,
-- tick "Auto Confirm User", then run this file again.
-- ============================================================================

do $$
declare
  v_email  text := 'mdn29930@gmail.com';  -- <-- account to fix
  v_pass   text := 'miraj0088';           -- <-- password to sign in with
  v_uid    uuid;
  v_schema text;
begin
  if coalesce(trim(v_pass), '') = '' then
    raise exception 'v_pass is empty: put a password in reset-admin-password.sql.';
  end if;

  select id into v_uid from auth.users where lower(email) = lower(v_email);
  if v_uid is null then
    raise notice 'TM GROW: no auth user for %. Create it in Authentication -> Users -> Add user (Auto Confirm), then run this file again.', v_email;
    return;
  end if;

  -- pgcrypto lives in "extensions" on most Supabase projects, sometimes in
  -- "public". Detect it instead of guessing.
  select n.nspname into v_schema
    from pg_extension e
    join pg_namespace n on n.oid = e.extnamespace
   where e.extname = 'pgcrypto'
   limit 1;

  if v_schema is null then
    execute 'create extension if not exists pgcrypto';
    select n.nspname into v_schema
      from pg_extension e
      join pg_namespace n on n.oid = e.extnamespace
     where e.extname = 'pgcrypto'
     limit 1;
  end if;

  execute format(
    'update auth.users
        set encrypted_password = %1$I.crypt($1, %1$I.gen_salt(''bf'')),
            email_confirmed_at = coalesce(email_confirmed_at, now()),
            updated_at = now()
      where id = $2',
    v_schema
  ) using v_pass, v_uid;

  insert into public.profiles (id, email, full_name, referral_code, admin_role, status, is_suspended)
  select u.id,
         u.email,
         coalesce(u.raw_user_meta_data ->> 'full_name',
                  u.raw_user_meta_data ->> 'name',
                  'TM GROW Owner'),
         'TM' || upper(substr(replace(u.id::text, '-', ''), 1, 8)),
         'OWNER',
         'active',
         false
    from auth.users u
   where u.id = v_uid
  on conflict (id) do update
     set email = excluded.email,
         admin_role = 'OWNER',
         status = 'active',
         is_suspended = false,
         referral_code = coalesce(profiles.referral_code, excluded.referral_code),
         updated_at = now();

  insert into public.wallets (user_id) values (v_uid)
  on conflict (user_id) do nothing;

  raise notice 'TM GROW: password set and OWNER granted for %. Sign in with email + password.', v_email;
end $$;

-- ---------------------------------------------------------------------------
-- Verify: email_confirmed = t, admin_role = OWNER, status = active
-- ---------------------------------------------------------------------------
select u.email,
       (u.email_confirmed_at is not null) as email_confirmed,
       p.admin_role,
       p.status,
       p.referral_code
  from auth.users u
  left join public.profiles p on p.id = u.id
 where lower(u.email) = lower('mdn29930@gmail.com');

-- ---------------------------------------------------------------------------
-- If the verify query returns no row, the auth user does not exist yet.
-- List what does exist:
--
--   select email, email_confirmed_at, created_at
--     from auth.users order by created_at desc limit 20;
--
-- Change the password later by editing v_pass above and running the file again.
-- ---------------------------------------------------------------------------
