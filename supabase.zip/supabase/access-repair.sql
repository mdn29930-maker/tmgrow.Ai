-- TM GROW — repair admin access resolution
-- Fixes the case where public.profiles says OWNER/active but the app still
-- reports "not an admin": the auth helper functions (is_admin, has_admin_role,
-- admin_role, my_context) in that database are an older definition, so they
-- disagree with the row. This re-creates the current definitions and adds a
-- debug RPC that shows exactly which function returns what.

-- 1. Legacy compatibility (optional, enum-safe).
--    Some databases have profiles.role as the enum type user_role. Comparing an
--   enum to '' raises: invalid input value for enum user_role: "". Admin access
--    never depends on this column, so the update below only runs when 'admin'
--    really is a label of that enum; otherwise it is skipped.
do $$
declare
  v_udt text;
  v_has_admin boolean := false;
begin
  select udt_name into v_udt
    from information_schema.columns
   where table_schema = 'public'
     and table_name = 'profiles'
     and column_name = 'role';

  if v_udt is null then
    return;
  end if;

  if v_udt = 'user_role' then
    select exists (
      select 1 from pg_enum e join pg_type t on t.oid = e.enumtypid
       where t.typname = 'user_role' and e.enumlabel = 'admin'
    ) into v_has_admin;
    if v_has_admin then
      execute 'update public.profiles set role = ''admin''::user_role
                where admin_role is not null and role is distinct from ''admin''::user_role';
    else
      raise notice 'user_role has no "admin" label; skipped the legacy role update (not needed for access).';
    end if;
  elsif v_udt in ('text', 'varchar', 'bpchar') then
    execute 'update public.profiles set role = ''admin''
              where admin_role is not null and coalesce(role, '''') <> ''admin''';
  end if;
end $$;

-- 2. Current definitions (safe to re-run)
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
     where p.id = auth.uid()
       and p.admin_role is not null
       and p.status = 'active'
  );
$$;

create or replace function public.admin_role()
returns text language sql stable security definer set search_path = public as $$
  select p.admin_role from public.profiles p where p.id = auth.uid();
$$;

create or replace function public.has_admin_role(p_roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
     where p.id = auth.uid()
       and p.status = 'active'
       and p.admin_role = any (p_roles)
  );
$$;

create or replace function public.my_context()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  w public.wallets;
  counts jsonb;
  ref jsonb;
  buyer jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  select * into w from public.wallets where user_id = u;
  perform public.expire_stale_tasks();

  counts := jsonb_build_object(
    'available_tasks', (select count(*) from public.tasks t join public.campaigns c on c.id = t.campaign_id
                         where t.status = 'available' and c.status = 'active'),
    'my_pending_submissions', (select count(*) from public.submissions where worker_id = u and status = 'pending'),
    'my_active_claims', (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')),
    'my_approved_tasks', (select count(*) from public.tasks where worker_id = u and status = 'approved'),
    'my_rejected_tasks', (select count(*) from public.tasks where worker_id = u and status = 'rejected'),
    'unread_notifications', (select count(*) from public.notifications where user_id = u and read_at is null),
    'open_tickets', (select count(*) from public.support_tickets where user_id = u and status in ('open','pending'))
  );

  ref := jsonb_build_object(
    'code', p.referral_code,
    'count', (select count(*) from public.referrals where referrer_id = u),
    'earned', (select coalesce(sum(available_delta), 0) from public.ledger_entries
                where user_id = u and kind = 'referral_bonus'),
    'rate', p.referral_rate
  );

  buyer := jsonb_build_object(
    'active_campaigns', (select count(*) from public.campaigns where buyer_id = u and status = 'active'),
    'pending_deposits', (select count(*) from public.deposits where user_id = u and status = 'pending'),
    'open_withdrawals', (select count(*) from public.withdrawals where user_id = u and status in ('pending','approved','processing'))
  );

  return jsonb_build_object(
    'profile', to_jsonb(p),
    'wallet', to_jsonb(w),
    'counts', counts,
    'referral', ref,
    'buyer', buyer,
    'is_admin', (p.admin_role is not null and p.status = 'active')
  );
end $$;

-- 3. Debug: every layer in one response, so a disagreement is visible.
create or replace function public.my_access_debug()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
begin
  if u is null then
    return jsonb_build_object(
      'authenticated', false,
      'note', 'No JWT in the SQL editor. Call this from the app (or set request.jwt.claims first).'
    );
  end if;

  select * into p from public.profiles where id = u;

  return jsonb_build_object(
    'authenticated', true,
    'uid', u,
    'profile_found', (p.id is not null),
    'profile_email', p.email,
    'admin_role_column', p.admin_role,
    'status_column', p.status,
    'role_column', p.role,
    'is_admin_function', public.is_admin(),
    'admin_role_function', public.admin_role(),
    'has_owner_role_function', public.has_admin_role(array['OWNER']),
    'my_context_is_admin', (public.my_context() ->> 'is_admin')
  );
end $$;

revoke all on function public.my_access_debug() from public, anon;
grant execute on function public.my_access_debug() to authenticated;

-- 4. Make the API see the new definitions immediately.
notify pgrst, 'reload schema';

-- 5. Diagnostics (runs fine in the SQL editor, no JWT needed).
select p.id, p.email, p.admin_role, p.status, p.role, p.updated_at
  from public.profiles p
 where p.admin_role is not null
 order by p.admin_role, p.email;

select proname, pg_get_function_identity_arguments(oid) as args
  from pg_proc
 where pronamespace = 'public'::regnamespace
   and proname in ('is_admin','admin_role','has_admin_role','my_context','my_access_debug','claim_owner')
 order by proname;


-- 6. Inspect the enum type (read-only). If 'admin' is missing from user_role,
--    the legacy update is skipped — access uses profiles.admin_role, not role.
select t.typname, e.enumlabel
  from pg_type t
  join pg_enum e on e.enumtypid = t.oid
 where t.typname = 'user_role'
 order by e.enumsortorder;
