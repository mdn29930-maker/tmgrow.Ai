-- ============================================================================
-- TM GROW — AUTO VERIFICATION (existing Socify API, no new provider)
--
-- What the configured API can actually prove
-- ------------------------------------------
-- socify_endpoints (supabase/socify-integration.sql) is a public-data reader.
-- It exposes: profile info, profile media, media info, media comments,
-- video comments, channel info/videos, search. It does NOT expose follower
-- lists, likes or subscriptions, so follow/like/subscribe tasks can never be
-- verified honestly by it. This file therefore auto-verifies only:
--
--   * comment tasks on youtube / instagram / tiktok
--     → the worker's linked handle must appear as a comment author on the
--       target post, read from the real comments endpoint.
--
-- Everything else stays manual (the existing deterministic sweep already
-- routes it there). No HTTP 200 is treated as success: the response body is
-- parsed and the handle must match an author field.
--
-- Reuses: socify_endpoints, socify_requests, net.http_get, socify_result_internal,
-- verification_queue, verification_decide (the same idempotent approval path
-- that credits the reward exactly once). Nothing is auto-approved unless the
-- auto_rewards module and automation_enabled are both armed.
-- ============================================================================

begin;

-- ============================================================================
-- 1. SWITCHES + QUEUE COLUMNS
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('auto_verify_enabled', 'false'::jsonb, false),
  ('auto_verify_max_attempts', '3'::jsonb, false),
  ('auto_verify_comment_actions', 'comment'::jsonb, false)
on conflict (key) do nothing;

alter table public.verification_queue add column if not exists api_state text;
alter table public.verification_queue add column if not exists api_request_id uuid;
alter table public.verification_queue add column if not exists api_platform text;
alter table public.verification_queue add column if not exists api_resource text;
alter table public.verification_queue add column if not exists api_params jsonb;
alter table public.verification_queue add column if not exists api_attempts int not null default 0;
alter table public.verification_queue add column if not exists api_checked_at timestamptz;

create index if not exists verification_queue_api_idx
  on public.verification_queue (api_state, status, next_run_at);


-- ============================================================================
-- 2. HANDLE MATCHER (defensive, recursive, author fields only)
--    Returns true only when a value under an author-style key equals the
--    worker handle. A title or caption that happens to contain the handle
--    does not match.
-- ============================================================================
create or replace function public.jsonb_author_match(p_json jsonb, p_handle text)
returns boolean
language plpgsql
immutable
as $$
declare
  k text;
  v jsonb;
  h text := lower(btrim(replace(coalesce(p_handle, ''), '@', '')));
begin
  if h = '' or p_json is null then return false; end if;

  if jsonb_typeof(p_json) = 'array' then
    for v in select * from jsonb_array_elements(p_json) loop
      if public.jsonb_author_match(v, p_handle) then return true; end if;
    end loop;
    return false;
  end if;

  if jsonb_typeof(p_json) <> 'object' then return false; end if;

  for k, v in select e.key, e.value from jsonb_each(p_json) e loop
    if lower(k) in ('username','user_name','handle','author','author_username',
                    'owner_username','unique_id','screen_name','account')
       and jsonb_typeof(v) = 'string'
       and lower(btrim(replace(v #>> '{}', '@', ''))) = h then
      return true;
    end if;
    if jsonb_typeof(v) in ('object', 'array')
       and public.jsonb_author_match(v, p_handle) then
      return true;
    end if;
  end loop;

  return false;
end $$;

revoke all on function public.jsonb_author_match(jsonb, text) from public, anon, authenticated;


-- ============================================================================
-- 3. INTERNAL DISPATCH (same endpoint catalog, same Vault key, same 20s net)
-- ============================================================================
create or replace function public.socify_dispatch_internal(
  p_user uuid, p_platform text, p_resource text, p_params jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ep public.socify_endpoints;
  v_key text := public.socify_api_key();
  v_id uuid;
  v_net bigint;
  v_url text;
  v_headers jsonb;
  v_params jsonb := coalesce(p_params, '{}'::jsonb);
begin
  if auth.role() is distinct from 'service_role' and auth.uid() is not null then
    raise exception 'FORBIDDEN';
  end if;

  if coalesce(btrim(v_key), '') = '' then
    return jsonb_build_object('ok', false, 'code', 'NOT_CONFIGURED');
  end if;

  if to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is null then
    return jsonb_build_object('ok', false, 'code', 'PG_NET_MISSING');
  end if;

  select * into v_ep
    from public.socify_endpoints
   where platform = lower(btrim(p_platform))
     and resource = btrim(p_resource)
     and enabled;
  if v_ep.platform is null then
    return jsonb_build_object('ok', false, 'code', 'UNSUPPORTED');
  end if;

  insert into public.socify_requests (user_id, platform, resource, params, request_key, status)
  values (p_user, v_ep.platform, v_ep.resource, v_params,
          md5('auto|' || v_ep.platform || '|' || v_ep.resource || '|' || v_params::text),
          'pending')
  returning id into v_id;

  v_url := 'https://trysocify.com/api/v1/' || v_ep.platform || '/' || v_ep.resource;
  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key);

  begin
    v_net := net.http_get(v_url, v_params, v_headers, 20000);
  exception when others then
    update public.socify_requests
       set status = 'failed', error_code = 'DISPATCH_FAILED',
           error_message = 'Could not start the upstream request.',
           updated_at = now(), completed_at = now()
     where id = v_id;
    return jsonb_build_object('ok', false, 'code', 'DISPATCH_FAILED', 'request_id', v_id);
  end;

  update public.socify_requests set net_request_id = v_net, updated_at = now() where id = v_id;

  return jsonb_build_object('ok', true, 'request_id', v_id, 'status', 'pending');
end $$;

revoke all on function public.socify_dispatch_internal(uuid, text, text, jsonb) from public, anon, authenticated;


-- ============================================================================
-- 4. COMMENT VERIFICATION PLANNER
--    Only comment tasks. Only platforms whose catalog has a comments resource.
-- ============================================================================
create or replace function public.auto_verify_plan(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  v_text text;
  v_resource text;
  v_param text;
  v_params jsonb;
  v_handle text;
begin
  select q.id, q.task_id, q.worker_id,
         c.title, c.instructions, c.target_url,
         lower(sv.platform) as platform
    into r
    from public.verification_queue q
    join public.tasks t on t.id = q.task_id
    join public.campaigns c on c.id = t.campaign_id
    join public.services sv on sv.id = c.service_id
   where q.id = p_queue_id;
  if r.platform is null then
    return jsonb_build_object('ok', false, 'code', 'NO_CONTEXT');
  end if;

  v_text := lower(coalesce(r.title, '') || ' ' || coalesce(r.instructions, ''));
  if v_text !~ '\mcomment' then
    return jsonb_build_object('ok', false, 'code', 'NOT_A_COMMENT_TASK');
  end if;

  select sa.handle into v_handle
    from public.social_accounts sa
   where sa.user_id = r.worker_id and sa.platform = r.platform and sa.status = 'linked'
   limit 1;
  if coalesce(v_handle, '') = '' then
    return jsonb_build_object('ok', false, 'code', 'NO_LINKED_HANDLE');
  end if;

  case r.platform
    when 'youtube' then v_resource := 'videos/comments'; v_param := 'url';
    when 'tiktok'  then v_resource := 'videos/comments'; v_param := 'url';
    when 'instagram' then v_resource := 'media/comments'; v_param := 'media';
    else return jsonb_build_object('ok', false, 'code', 'UNSUPPORTED_PLATFORM');
  end case;

  if coalesce(r.target_url, '') = '' then
    return jsonb_build_object('ok', false, 'code', 'NO_TARGET_URL');
  end if;

  v_params := jsonb_build_object(v_param, r.target_url);

  return jsonb_build_object('ok', true, 'platform', r.platform,
    'resource', v_resource, 'params', v_params, 'handle', v_handle,
    'target_url', r.target_url);
end $$;

revoke all on function public.auto_verify_plan(uuid) from public, anon, authenticated;


-- ============================================================================
-- 5. TICK: dispatch → poll → approve only on a real author match
-- ============================================================================
create or replace function public.auto_verify_tick(p_limit int default 5)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  v_plan jsonb;
  v_res jsonb;
  v_attempts int;
  v_max int := greatest(1, least(coalesce(public.setting_num('auto_verify_max_attempts', 3), 3)::int, 10));
  v_sent int := 0;
  v_ok int := 0;
  v_fail int := 0;
  v_manual int := 0;
begin
  if auth.uid() is not null and auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if not public.setting_bool('auto_verify_enabled', false) then
    return jsonb_build_object('ok', true, 'skipped', 'DISABLED');
  end if;

  /* Claim queued rows for the automatic planner (the sweep runs afterwards).
     Rows already waiting on a pg_net response are re-claimed for polling, and
     a job can never stay stuck in processing. */
  for r in
    update public.verification_queue q
       set status = 'processing', locked_at = now(), updated_at = now()
     where q.id in (
       select id from public.verification_queue
        where (status = 'queued'
               and next_run_at <= now()
               and coalesce(api_state, '') <> 'skip')
           or (status = 'processing' and api_state = 'polling'
               and coalesce(locked_at, updated_at) < now() - interval '20 seconds')
           or (status = 'processing' and coalesce(api_state, '') = ''
               and coalesce(locked_at, updated_at) < now() - interval '5 minutes')
        order by coalesce(next_run_at, created_at)
        limit greatest(1, least(coalesce(p_limit, 5), 10))
        for update skip locked
     )
    returning q.*
  loop
    begin
      /* --- poll phase ------------------------------------------------- */
      if r.api_request_id is not null then
        v_res := public.socify_result_internal(r.api_request_id);

        if (v_res ->> 'status') = 'pending' then
          update public.verification_queue
             set locked_at = now(), api_checked_at = now(), updated_at = now()
           where id = r.id;
          continue;
        end if;

        if coalesce((v_res ->> 'ok')::boolean, false) and (v_res ->> 'status') = 'done' then
          v_plan := public.auto_verify_plan(r.id);
          if coalesce((v_plan ->> 'ok')::boolean, false)
             and public.jsonb_author_match(v_res -> 'data', v_plan ->> 'handle') then
            perform public.verification_decide(
              r.id, 'approve',
              'Automatic check: the linked handle was found in the public comments of the target post.',
              jsonb_build_object('rule', 'socify_comments', 'platform', r.api_platform,
                                 'request_id', r.api_request_id,
                                 'handle', v_plan ->> 'handle', 'by', 'socify'));
            v_ok := v_ok + 1;
            continue;
          end if;

          perform public.verification_decide(
            r.id, 'manual',
            'The linked handle was not found in the public comments returned by the API. A human will review the screenshot.',
            jsonb_build_object('rule', 'socify_comments_no_match', 'platform', r.api_platform,
                               'request_id', r.api_request_id, 'by', 'socify'));
          v_manual := v_manual + 1;
          continue;
        end if;

        /* Upstream failed: retry with backoff, then hand to a human. */
        v_attempts := coalesce(r.api_attempts, 0) + 1;
        if v_attempts < v_max then
          update public.verification_queue
             set status = 'queued', api_state = null, api_request_id = null,
                 api_attempts = v_attempts,
                 next_run_at = now() + make_interval(secs => 60 * (2 ^ (v_attempts - 1))::int),
                 last_error = left(coalesce(v_res ->> 'message', 'API failure'), 300),
                 updated_at = now()
           where id = r.id;
        else
          perform public.verification_decide(
            r.id, 'manual',
            'Automatic verification could not reach the API. A human will review the screenshot.',
            jsonb_build_object('rule', 'socify_unavailable', 'attempts', v_attempts, 'by', 'socify'));
          v_manual := v_manual + 1;
        end if;
        v_fail := v_fail + 1;
        continue;
      end if;

      /* --- dispatch phase --------------------------------------------- */
      v_plan := public.auto_verify_plan(r.id);
      if not coalesce((v_plan ->> 'ok')::boolean, false) then
        update public.verification_queue
           set status = 'queued', api_state = 'skip', updated_at = now()
         where id = r.id;
        continue;  -- not provable by this API: the deterministic sweep decides
      end if;

      v_res := public.socify_dispatch_internal(r.worker_id, v_plan ->> 'platform',
                                               v_plan ->> 'resource', v_plan -> 'params');
      if coalesce((v_res ->> 'ok')::boolean, false) then
        update public.verification_queue
           set api_state = 'polling', api_request_id = (v_res ->> 'request_id')::uuid,
               api_platform = v_plan ->> 'platform', api_resource = v_plan ->> 'resource',
               api_params = v_plan -> 'params', api_attempts = coalesce(api_attempts, 0) + 1,
               api_checked_at = now(), locked_at = now(), updated_at = now()
         where id = r.id;
        v_sent := v_sent + 1;
      else
        v_attempts := coalesce(r.api_attempts, 0) + 1;
        update public.verification_queue
           set status = 'queued',
               api_attempts = v_attempts,
               next_run_at = now() + make_interval(secs => 60 * (2 ^ (v_attempts - 1))::int),
               last_error = left(coalesce(v_res ->> 'code', 'DISPATCH_FAILED'), 300),
               updated_at = now()
         where id = r.id;
        v_fail := v_fail + 1;
      end if;
    exception when others then
      begin
        update public.verification_queue
           set status = 'queued', locked_at = null,
               last_error = left(sqlerrm, 300), updated_at = now()
         where id = r.id;
      exception when others then null; end;
      v_fail := v_fail + 1;
    end;
  end loop;

  return jsonb_build_object('ok', true, 'dispatched', v_sent, 'approved', v_ok,
                            'failed', v_fail, 'manual', v_manual, 'ran_at', now());
end $$;

revoke all on function public.auto_verify_tick(int) from public, anon, authenticated;


-- ============================================================================
-- 6. PIPELINE (one cron job: auto verifier, then the deterministic sweep)
-- ============================================================================
create or replace function public.verification_pipeline()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_auto jsonb;
  v_sweep jsonb;
begin
  v_auto := public.auto_verify_tick(5);
  v_sweep := public.automation_verification_tick(10);
  perform public.audit('verification.pipeline', 'verification_queue', null,
    jsonb_build_object('auto', v_auto, 'sweep', v_sweep));
  return jsonb_build_object('auto', v_auto, 'sweep', v_sweep);
end $$;

revoke all on function public.verification_pipeline() from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-verification-sweep', '* * * * *',
      $cron$select public.verification_pipeline();$cron$);
    raise notice 'pg_cron: verification pipeline every minute.';
  end if;
end $$;


-- ============================================================================
-- 7. ADMIN RPCs
-- ============================================================================
create or replace function public.admin_auto_verify_state()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key boolean := public.socify_api_key() is not null;
  v_run jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  select jsonb_build_object('at', a.created_at, 'details', a.details)
    into v_run
    from public.audit_logs a
   where a.action = 'verification.pipeline'
   order by a.created_at desc limit 1;

  return jsonb_build_object(
    'enabled', public.setting_bool('auto_verify_enabled', false),
    'api_configured', v_key,
    'pg_net', to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null,
    'socify_enabled', public.setting_bool('socify_enabled', true),
    'max_attempts', coalesce(public.setting_num('auto_verify_max_attempts', 3), 3)::int,
    'automation_enabled', public.setting_bool('automation_enabled', false),
    'auto_rewards', coalesce((select enabled from public.automation_modules where key = 'auto_rewards'), false),
    'counters', jsonb_build_object(
      'queued', (select count(*) from public.verification_queue where status = 'queued'),
      'processing', (select count(*) from public.verification_queue where status = 'processing'),
      'api_polling', (select count(*) from public.verification_queue where api_state = 'polling'),
      'verified', (select count(*) from public.verification_queue where status = 'verified'),
      'rejected', (select count(*) from public.verification_queue where status = 'rejected'),
      'manual', (select count(*) from public.verification_queue where status = 'manual'),
      'failed', (select count(*) from public.verification_queue where status = 'dead'),
      'api_requests_today', (select count(*) from public.socify_requests
                              where created_at >= date_trunc('day', now()))
    ),
    'last_run', v_run,
    'recent', (select coalesce(jsonb_agg(jsonb_build_object(
                 'id', q.id, 'status', q.status, 'api_state', q.api_state,
                 'api_platform', q.api_platform, 'api_resource', q.api_resource,
                 'api_attempts', q.api_attempts, 'last_error', q.last_error,
                 'updated_at', q.updated_at) order by q.updated_at desc), '[]'::jsonb)
               from (select * from public.verification_queue
                      where api_request_id is not null or api_attempts > 0
                      order by updated_at desc limit 15) q)
  );
end $$;

revoke all on function public.admin_auto_verify_state() from public, anon;
grant execute on function public.admin_auto_verify_state() to authenticated;


create or replace function public.admin_auto_verify_run()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  perform public.audit('verification.manual_run', 'verification_queue', null, null);
  return public.verification_pipeline();
end $$;

revoke all on function public.admin_auto_verify_run() from public, anon;
grant execute on function public.admin_auto_verify_run() to authenticated;


create or replace function public.admin_verification_retry(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  update public.verification_queue
     set status = 'queued', api_state = null, api_request_id = null,
         api_attempts = 0, next_run_at = now(),
         locked_at = null, last_error = null, updated_at = now()
   where id = p_queue_id
     and status in ('manual', 'dead', 'queued');
  if not found then raise exception 'VERIFICATION_NOT_RETRYABLE'; end if;

  perform public.audit('verification.retry', 'verification_queue', p_queue_id, null);
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_verification_retry(uuid) from public, anon;
grant execute on function public.admin_verification_retry(uuid) to authenticated;


notify pgrst, 'reload schema';

commit;
