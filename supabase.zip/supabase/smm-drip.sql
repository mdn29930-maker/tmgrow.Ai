-- ============================================================================
-- TM GROW — SMM DRIP RELEASE + WORKER FULFILMENT + REASSIGNMENT
--
-- Additive. Existing campaigns, tasks, wallets, reviews and auth untouched.
-- Depends on: smm-orders.sql (already run) and task-duration-rules.sql.
--
-- SMM tasks use the existing tasks/submissions tables with campaign_id NULL
-- and smm_order_id set. Campaign tasks keep campaign_id and smm_order_id NULL.
-- ============================================================================

begin;

-- ============================================================================
-- 1. COLUMNS
-- ============================================================================
alter table public.services add column if not exists worker_reward_per_1000 numeric(18, 6);

alter table public.smm_orders add column if not exists drip_enabled boolean not null default true;
alter table public.smm_orders add column if not exists drip_paused boolean not null default false;
alter table public.smm_orders add column if not exists drip_batch_size int not null default 10;
alter table public.smm_orders add column if not exists drip_interval_minutes int not null default 5;
alter table public.smm_orders add column if not exists drip_max_active int not null default 50;
alter table public.smm_orders add column if not exists drip_daily_limit int not null default 100;
alter table public.smm_orders add column if not exists worker_reward_snapshot numeric(18, 6);
alter table public.smm_orders add column if not exists issued_quantity int not null default 0;
alter table public.smm_orders add column if not exists completed_quantity int not null default 0;
alter table public.smm_orders add column if not exists rejected_quantity int not null default 0;
alter table public.smm_orders add column if not exists last_release_at timestamptz;
alter table public.smm_orders add column if not exists next_release_at timestamptz not null default now();

alter table public.tasks alter column campaign_id drop not null;
alter table public.tasks add column if not exists smm_order_id uuid references public.smm_orders (id) on delete cascade;
alter table public.tasks add column if not exists seq int;
alter table public.tasks add column if not exists released_at timestamptz not null default now();

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'tasks_exactly_one_source') then
    alter table public.tasks add constraint tasks_exactly_one_source
      check ((campaign_id is null) <> (smm_order_id is null));
  end if;
end $$;

create unique index if not exists tasks_smm_order_seq_key
  on public.tasks (smm_order_id, seq)
  where smm_order_id is not null;

create index if not exists tasks_smm_order_idx on public.tasks (smm_order_id, status);

-- ============================================================================
-- 2. SETTINGS (admin-tunable defaults, no per-service timer configuration)
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('smm_drip_enabled', 'true'::jsonb, false),
  ('smm_drip_batch_size', '10'::jsonb, false),
  ('smm_drip_interval_minutes', '5'::jsonb, false),
  ('smm_drip_max_active', '50'::jsonb, false),
  ('smm_drip_daily_limit', '100'::jsonb, false)
on conflict (key) do nothing;


-- ============================================================================
-- 3. COUNTERS ON APPROVAL / REJECTION (exactly once, transition guarded)
-- ============================================================================
create or replace function public.tg_smm_task_counters()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.smm_order_id is null then return new; end if;

  if new.status = 'approved' and coalesce(old.status, '') <> 'approved' then
    update public.smm_orders
       set completed_quantity = least(quantity, completed_quantity + 1),
           status = case when completed_quantity + 1 >= quantity then 'completed' else 'processing' end,
           completed_at = case when completed_quantity + 1 >= quantity then now() else completed_at end,
           next_release_at = least(next_release_at, now())
     where id = new.smm_order_id;
  end if;

  if new.status in ('rejected', 'expired') and coalesce(old.status, '') not in ('rejected', 'expired') then
    update public.smm_orders
       set rejected_quantity = rejected_quantity + 1,
           next_release_at = least(next_release_at, now())
     where id = new.smm_order_id;
  end if;

  return new;
end $$;

drop trigger if exists tasks_smm_counters on public.tasks;
create trigger tasks_smm_counters
  after update of status on public.tasks
  for each row execute function public.tg_smm_task_counters();

revoke all on function public.tg_smm_task_counters() from public, anon, authenticated;


-- ============================================================================
-- 4. DRIP SCHEDULER
-- ============================================================================
create or replace function public.smm_drip_release(p_order_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.smm_orders;
  s public.services;
  v_open int;
  v_remaining int;
  v_batch int;
  v_today int;
  v_released int := 0;
  v_skipped int := 0;
  v_worker_reward numeric;
  v_seq int;
  i int;
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  for o in
    select * from public.smm_orders
     where (p_order_id is null or id = p_order_id)
       and drip_enabled and not drip_paused
       and status in ('pending', 'processing')
       and completed_quantity < quantity
       and (p_order_id is not null or next_release_at <= now())
     order by created_at
     for update skip locked
  loop
    select * into s from public.services where id = o.service_id;
    v_worker_reward := coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot);

    if v_worker_reward is null or v_worker_reward <= 0 then
      update public.smm_orders
         set admin_note = 'Fulfilment blocked: worker reward per 1K is not configured for this service.',
             drip_paused = true
       where id = o.id;
      v_skipped := v_skipped + 1;
      continue;
    end if;

    select count(*) into v_open
      from public.tasks
     where smm_order_id = o.id and status in ('available', 'claimed', 'submitted');

    v_remaining := o.quantity - o.completed_quantity - v_open;
    if v_remaining <= 0 then
      update public.smm_orders
         set next_release_at = now() + make_interval(mins => greatest(1, o.drip_interval_minutes))
       where id = o.id;
      continue;
    end if;

    select count(*) into v_today
      from public.tasks
     where smm_order_id = o.id and released_at >= date_trunc('day', now());
    v_today := greatest(0, o.drip_daily_limit - v_today);

    v_batch := least(o.drip_batch_size, v_remaining, greatest(0, o.drip_max_active - v_open), v_today);
    if v_batch <= 0 then
      update public.smm_orders
         set next_release_at = now() + make_interval(mins => greatest(1, o.drip_interval_minutes))
       where id = o.id;
      continue;
    end if;

    /* One released task = one unit of the order. The worker reward is the
       configured per-1K rate divided by 1000, never below the tasks.reward
       minimum of 0.000001. */
    v_seq := o.issued_quantity;
    for i in 1..v_batch loop
      v_seq := v_seq + 1;
      insert into public.tasks (campaign_id, smm_order_id, seq, status, reward, released_at)
      values (null, o.id, v_seq, 'available',
              greatest(round(v_worker_reward / 1000.0, 6), 0.000001), now());
    end loop;

    v_released := v_released + v_batch;

    update public.smm_orders
       set issued_quantity = v_seq,
           worker_reward_snapshot = v_worker_reward,
           status = case when status = 'pending' then 'processing' else status end,
           last_release_at = now(),
           next_release_at = now() + make_interval(mins => greatest(1, drip_interval_minutes)),
           processed_at = coalesce(processed_at, now())
     where id = o.id;

    perform public.audit('smm_drip.release', 'smm_order', o.id,
      jsonb_build_object('released', v_batch, 'issued', v_seq, 'open_before', v_open));
  end loop;

  return jsonb_build_object('ok', true, 'released', v_released, 'skipped', v_skipped);
end $$;

revoke all on function public.smm_drip_release(uuid) from public, anon, authenticated;


create or replace function public.smm_drip_scheduled()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_owner uuid;
  v_prev text;
  v_res jsonb;
begin
  select id into v_owner from public.profiles
   where admin_role in ('OWNER','SUPER_ADMIN') and status = 'active'
   order by case when admin_role = 'OWNER' then 0 else 1 end, created_at limit 1;
  if v_owner is null then
    return jsonb_build_object('ok', false, 'reason', 'NO_ACTIVE_OWNER');
  end if;

  v_prev := coalesce(current_setting('request.jwt.claims', true), '');
  perform set_config('request.jwt.claims',
    jsonb_build_object('sub', v_owner::text, 'role', 'authenticated')::text, true);
  begin
    v_res := public.smm_drip_release(null);
  exception when others then
    if v_prev <> '' then perform set_config('request.jwt.claims', v_prev, true); end if;
    raise;
  end;
  if v_prev <> '' then perform set_config('request.jwt.claims', v_prev, true); end if;
  return v_res;
end $$;

revoke all on function public.smm_drip_scheduled() from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-smm-drip', '* * * * *',
      $cron$select public.smm_drip_scheduled();$cron$);
    raise notice 'pg_cron: tmgrow-smm-drip every minute.';
  else
    raise notice 'pg_cron missing: drip runs only from the Admin Release button.';
  end if;
end $$;


-- ============================================================================
-- 5. WORKER FEED + CLAIM + START + PROOF (SMM tasks only)
-- ============================================================================
create or replace function public.smm_worker_feed(p_limit int default 20)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  items jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id, 'reward', t.reward, 'created_at', t.created_at,
      'smm_order_id', o.id,
      'title', s.name,
      'instructions_preview', left(coalesce(s.description, ''), 140),
      'platform', s.platform,
      'service_name', s.name,
      'target_url', o.target_link,
      'quantity_left', (select count(*) from public.tasks t2
                         where t2.smm_order_id = o.id and t2.status = 'available')
    ) as x
      from public.tasks t
      join public.smm_orders o on o.id = t.smm_order_id
      join public.services s on s.id = o.service_id
     where t.status = 'available'
       and o.status in ('pending', 'processing')
       and not o.drip_paused
       and s.platform is not null
       and p.is_worker
       and p.status = 'active'
     order by t.reward desc, t.created_at
     limit greatest(1, least(coalesce(p_limit, 20), 50))
  ) q;

  return jsonb_build_object('items', items);
end $$;

revoke all on function public.smm_worker_feed(int) from public, anon;
grant execute on function public.smm_worker_feed(int) to authenticated;


create or replace function public.smm_claim_task(p_task_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  p public.profiles;
  o public.smm_orders;
  mins int;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_worker then raise exception 'WORKER_MODE_DISABLED'; end if;

  if (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')) >= 25 then
    raise exception 'TOO_MANY_ACTIVE_TASKS';
  end if;

  select * into t from public.tasks where id = p_task_id and smm_order_id is not null for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status <> 'available' or t.worker_id is not null then raise exception 'TASK_UNAVAILABLE'; end if;

  select * into o from public.smm_orders where id = t.smm_order_id;
  if o.status not in ('pending', 'processing') or o.drip_paused then raise exception 'ORDER_NOT_ACTIVE'; end if;

  mins := greatest(5, least(coalesce(public.setting_num('claim_window_minutes', 30), 30), 240));
  update public.tasks
     set worker_id = u, status = 'claimed', claimed_at = now(),
         expires_at = now() + make_interval(mins => mins)
   where id = t.id and status = 'available' and worker_id is null;
  if not found then raise exception 'TASK_UNAVAILABLE'; end if;

  return jsonb_build_object('ok', true, 'task_id', t.id, 'expires_at', now() + make_interval(mins => mins));
end $$;

revoke all on function public.smm_claim_task(uuid) from public, anon;
grant execute on function public.smm_claim_task(uuid) to authenticated;


create or replace function public.smm_start_task(p_task_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  o public.smm_orders;
  s public.services;
  v_rule jsonb;
begin
  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null or t.smm_order_id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;
  if t.expires_at is not null and t.expires_at < now() then raise exception 'TASK_EXPIRED'; end if;

  if t.required_seconds is null then
    select * into o from public.smm_orders where id = t.smm_order_id;
    select * into s from public.services where id = o.service_id;
    v_rule := public.task_duration(s.platform, coalesce(s.name, '') || ' ' || coalesce(s.description, ''));
    update public.tasks
       set started_at = now(), required_seconds = (v_rule ->> 'seconds')::int,
           timer_started_at = now(),
           timer_ends_at = now() + make_interval(secs => (v_rule ->> 'seconds')::int),
           duration_rule = v_rule ->> 'rule'
     where id = t.id returning * into t;
  end if;

  return jsonb_build_object('ok', true,
    'started_at', t.timer_started_at,
    'required_seconds', t.required_seconds,
    'timer_ends_at', t.timer_ends_at,
    'seconds_left', greatest(0, ceil(extract(epoch from (t.timer_ends_at - now())))::int),
    'rule', t.duration_rule);
end $$;

revoke all on function public.smm_start_task(uuid) from public, anon;
grant execute on function public.smm_start_task(uuid) to authenticated;


create or replace function public.smm_submit_proof(
  p_task_id uuid, p_proof_paths text[], p_proof_link text default null,
  p_note text default null, p_proof_hash text default null, p_time_spent int default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  sub public.submissions;
  v_paths text[] := p_proof_paths;
  v_count int;
  v_link text;
begin
  v_count := coalesce(array_length(v_paths, 1), 0);
  if v_count < 1 then raise exception 'PROOF_REQUIRED'; end if;
  if v_count > 6 then raise exception 'TOO_MANY_FILES'; end if;
  if exists (select 1 from unnest(v_paths) p
              where p is null or p = '' or split_part(p, '/', 1) <> u::text) then
    raise exception 'INVALID_PROOF_PATH';
  end if;
  v_link := nullif(trim(coalesce(p_proof_link, '')), '');
  if v_link is not null and v_link !~* '^https?://' then raise exception 'INVALID_URL'; end if;

  select * into t from public.tasks where id = p_task_id and smm_order_id is not null for update;
  if t.id is null or t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;
  if t.expires_at is not null and t.expires_at < now() then raise exception 'TASK_EXPIRED'; end if;
  if t.required_seconds is not null and (t.timer_ends_at is null or now() < t.timer_ends_at) then
    raise exception 'TIMER_NOT_FINISHED';
  end if;

  insert into public.submissions (task_id, worker_id, note, proof_path, proof_paths, proof_link, time_spent_seconds, proof_hash)
  values (t.id, u, nullif(trim(coalesce(p_note, '')), ''), v_paths[1], v_paths, v_link,
          greatest(0, least(coalesce(p_time_spent, 0), 86400)),
          nullif(lower(trim(coalesce(p_proof_hash, ''))), ''))
  returning * into sub;

  update public.tasks set status = 'submitted', submitted_at = now(), expires_at = null where id = t.id;

  perform public.notify_user(u, 'Proof submitted', 'Your SMM task proof is waiting for review.', 'info', '#/smm-tasks');
  return jsonb_build_object('ok', true, 'submission_id', sub.id);
end $$;

revoke all on function public.smm_submit_proof(uuid, text[], text, text, text, int) from public, anon;
grant execute on function public.smm_submit_proof(uuid, text[], text, text, text, int) to authenticated;


-- ============================================================================
-- 6. ADMIN REVIEW + FULFILMENT
-- ============================================================================
create or replace function public.admin_smm_review_task(
  p_task_id uuid, p_approve boolean, p_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  t public.tasks;
  sub public.submissions;
  o public.smm_orders;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into t from public.tasks where id = p_task_id and smm_order_id is not null for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status <> 'submitted' then raise exception 'TASK_NOT_SUBMITTED'; end if;
  select * into sub from public.submissions where task_id = t.id for update;
  if sub.id is null then raise exception 'SUBMISSION_NOT_FOUND'; end if;
  if sub.status <> 'pending' then raise exception 'ALREADY_REVIEWED'; end if;
  select * into o from public.smm_orders where id = t.smm_order_id;

  if p_approve then
    update public.submissions set status = 'approved', reviewer_id = auth.uid(),
           review_note = nullif(trim(coalesce(p_note, '')), ''), reviewed_at = now()
     where id = sub.id;
    update public.tasks set status = 'approved', reviewed_at = now() where id = t.id;

    perform public.wallet_move(t.worker_id, t.reward, 0, 0, t.reward,
      'smm_task_reward', 'task', t.id,
      'SMM task approved — ' || coalesce(o.id::text, ''));

    perform public.notify_user(t.worker_id, 'SMM task approved',
      t.reward || ' USDT was credited.', 'success', '#/wallet');
  else
    update public.submissions set status = 'rejected', reviewer_id = auth.uid(),
           review_note = nullif(trim(coalesce(p_note, '')), ''), reviewed_at = now()
     where id = sub.id;
    update public.tasks set status = 'rejected', reviewed_at = now() where id = t.id;

    perform public.notify_user(t.worker_id, 'SMM task rejected',
      coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Your proof did not match the task.'),
      'error', '#/smm-tasks');
  end if;

  perform public.audit('smm_task.review', 'task', t.id,
    jsonb_build_object('approve', p_approve, 'order', t.smm_order_id, 'worker', t.worker_id));

  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_smm_review_task(uuid, boolean, text) from public, anon;
grant execute on function public.admin_smm_review_task(uuid, boolean, text) to authenticated;


create or replace function public.admin_smm_fulfilment(p_status text default null, p_limit int default 40)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare items jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id, 'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8)),
           'user_name', coalesce(nullif(p.full_name, ''), p.email),
           'service_name', s.name, 'platform', s.platform,
           'target_link', o.target_link, 'quantity', o.quantity,
           'completed_quantity', o.completed_quantity,
           'rejected_quantity', o.rejected_quantity,
           'issued_quantity', o.issued_quantity,
           'remaining', greatest(0, o.quantity - o.completed_quantity),
           'open', (select count(*) from public.tasks t where t.smm_order_id = o.id and t.status in ('available','claimed','submitted')),
           'status', o.status, 'drip_enabled', o.drip_enabled, 'drip_paused', o.drip_paused,
           'drip_batch_size', o.drip_batch_size, 'drip_interval_minutes', o.drip_interval_minutes,
           'drip_max_active', o.drip_max_active, 'drip_daily_limit', o.drip_daily_limit,
           'next_release_at', o.next_release_at, 'last_release_at', o.last_release_at,
           'worker_reward', coalesce(s.worker_reward_per_1000, o.worker_reward_snapshot),
           'admin_note', o.admin_note, 'created_at', o.created_at
         ) order by o.created_at desc), '[]'::jsonb)
    into items
    from (select * from public.smm_orders
           where (p_status is null or p_status = '' or status = p_status)
           order by created_at desc limit greatest(1, least(coalesce(p_limit, 40), 100))) o
    join public.services s on s.id = o.service_id
    left join public.profiles p on p.id = o.user_id;

  return jsonb_build_object('items', items);
end $$;

revoke all on function public.admin_smm_fulfilment(text, int) from public, anon;
grant execute on function public.admin_smm_fulfilment(text, int) to authenticated;


create or replace function public.admin_smm_set_drip(
  p_order_id uuid, p_enabled boolean default null, p_paused boolean default null,
  p_batch int default null, p_interval int default null,
  p_max_active int default null, p_daily int default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare o public.smm_orders;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then raise exception 'FORBIDDEN'; end if;
  update public.smm_orders
     set drip_enabled = coalesce(p_enabled, drip_enabled),
         drip_paused = coalesce(p_paused, drip_paused),
         drip_batch_size = greatest(1, least(coalesce(p_batch, drip_batch_size), 500)),
         drip_interval_minutes = greatest(1, least(coalesce(p_interval, drip_interval_minutes), 1440)),
         drip_max_active = greatest(1, least(coalesce(p_max_active, drip_max_active), 2000)),
         drip_daily_limit = greatest(1, least(coalesce(p_daily, drip_daily_limit), 100000)),
         next_release_at = case when coalesce(p_paused, drip_paused) then next_release_at else least(next_release_at, now()) end
   where id = p_order_id returning * into o;
  if o.id is null then raise exception 'ORDER_NOT_FOUND'; end if;
  perform public.audit('smm_order.drip', 'smm_order', o.id,
    jsonb_build_object('enabled', o.drip_enabled, 'paused', o.drip_paused,
                       'batch', o.drip_batch_size, 'interval', o.drip_interval_minutes));
  return jsonb_build_object('ok', true, 'order', to_jsonb(o));
end $$;

revoke all on function public.admin_smm_set_drip(uuid, boolean, boolean, int, int, int, int) from public, anon;
grant execute on function public.admin_smm_set_drip(uuid, boolean, boolean, int, int, int, int) to authenticated;


create or replace function public.admin_smm_release_now(p_order_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then raise exception 'FORBIDDEN'; end if;
  return public.smm_drip_release(p_order_id);
end $$;

revoke all on function public.admin_smm_release_now(uuid) from public, anon;
grant execute on function public.admin_smm_release_now(uuid) to authenticated;


create or replace function public.admin_smm_tasks(p_order_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare items jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', t.id, 'seq', t.seq, 'status', t.status, 'reward', t.reward,
           'worker_id', t.worker_id,
           'worker_name', coalesce(nullif(pr.full_name, ''), pr.email),
           'claimed_at', t.claimed_at, 'submitted_at', t.submitted_at,
           'reviewed_at', t.reviewed_at,
           'required_seconds', t.required_seconds, 'duration_rule', t.duration_rule,
           'submission_id', sub.id, 'submission_status', sub.status,
           'proof_paths', sub.proof_paths, 'proof_path', sub.proof_path,
           'proof_link', sub.proof_link, 'review_note', sub.review_note,
           'created_at', t.created_at
         ) order by t.seq), '[]'::jsonb)
    into items
    from public.tasks t
    left join public.profiles pr on pr.id = t.worker_id
    left join public.submissions sub on sub.task_id = t.id
   where t.smm_order_id = p_order_id;
  return jsonb_build_object('items', items);
end $$;

revoke all on function public.admin_smm_tasks(uuid) from public, anon;
grant execute on function public.admin_smm_tasks(uuid) to authenticated;


-- Buyer-visible progress, real counts only.
create or replace function public.smm_order_progress(p_order_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare o public.smm_orders;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into o from public.smm_orders where id = p_order_id;
  if o.id is null then raise exception 'ORDER_NOT_FOUND'; end if;
  if o.user_id <> auth.uid() and not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  return jsonb_build_object(
    'order_id', o.id,
    'quantity', o.quantity,
    'completed', o.completed_quantity,
    'rejected', o.rejected_quantity,
    'issued', o.issued_quantity,
    'status', o.status,
    'pending', (select count(*) from public.tasks where smm_order_id = o.id and status = 'available'),
    'claimed', (select count(*) from public.tasks where smm_order_id = o.id and status = 'claimed'),
    'verification', (select count(*) from public.tasks where smm_order_id = o.id and status = 'submitted'),
    'rejected_open', (select count(*) from public.tasks where smm_order_id = o.id and status = 'rejected'),
    'next_release_at', o.next_release_at
  );
end $$;

revoke all on function public.smm_order_progress(uuid) from public, anon;
grant execute on function public.smm_order_progress(uuid) to authenticated;


-- ============================================================================
-- 7. WORKER + ADMIN READ RPCs FOR DRIP TASKS
-- ============================================================================
create or replace function public.smm_task_detail(p_task_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  o public.smm_orders;
  s public.services;
  v_sub public.submissions;
  v_mine boolean;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into t from public.tasks where id = p_task_id and smm_order_id is not null;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;

  v_mine := (t.worker_id = u);
  /* An available task may be previewed by any worker. Anything else is
     visible only to the worker the task belongs to. */
  if not v_mine and t.status <> 'available' then
    raise exception 'TASK_NOT_FOUND';
  end if;

  select * into o from public.smm_orders where id = t.smm_order_id;
  select * into s from public.services where id = o.service_id;
  select * into v_sub from public.submissions where task_id = t.id;

  return jsonb_build_object(
    'task', jsonb_build_object(
      'id', t.id,
      'status', t.status,
      'reward', t.reward,
      'seq', t.seq,
      'smm_order_id', t.smm_order_id,
      'claimed_at', t.claimed_at,
      'expires_at', t.expires_at,
      'submitted_at', t.submitted_at,
      'reviewed_at', t.reviewed_at,
      'required_seconds', t.required_seconds,
      'timer_started_at', t.timer_started_at,
      'timer_ends_at', t.timer_ends_at,
      'duration_rule', t.duration_rule,
      'mine', v_mine,
      'seconds_left', case when t.timer_ends_at is null then null
                           else greatest(0, ceil(extract(epoch from (t.timer_ends_at - now())))::int) end
    ),
    'service', jsonb_build_object(
      'id', s.id,
      'name', s.name,
      'platform', s.platform,
      'instructions', s.description,
      'estimated_time', s.estimated_time,
      'worker_reward_per_1000', s.worker_reward_per_1000
    ),
    'order', jsonb_build_object(
      'id', o.id,
      'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8)),
      'target_link', o.target_link,
      'quantity', o.quantity,
      'status', o.status
    ),
    'submission', case when v_sub.id is null then null else jsonb_build_object(
      'id', v_sub.id,
      'status', v_sub.status,
      'review_note', v_sub.review_note,
      'proof_paths', v_sub.proof_paths,
      'proof_path', v_sub.proof_path,
      'proof_link', v_sub.proof_link,
      'note', v_sub.note,
      'time_spent_seconds', v_sub.time_spent_seconds,
      'created_at', v_sub.created_at,
      'reviewed_at', v_sub.reviewed_at
    ) end
  );
end $$;

revoke all on function public.smm_task_detail(uuid) from public, anon;
grant execute on function public.smm_task_detail(uuid) to authenticated;


create or replace function public.smm_my_tasks(
  p_status text default null, p_limit int default 20, p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  v_items jsonb;
  v_total int;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.tasks t
   where t.worker_id = u
     and t.smm_order_id is not null
     and (p_status is null or p_status = '' or t.status = p_status);

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', q.id, 'status', q.status, 'reward', q.reward, 'seq', q.seq,
           'service_name', q.service_name, 'platform', q.platform,
           'service_id', q.service_id,
           'order_id', q.smm_order_id,
           'order_short', upper(substr(replace(q.smm_order_id::text, '-', ''), 1, 8)),
           'target_link', q.target_link,
           'created_at', q.created_at, 'claimed_at', q.claimed_at,
           'submitted_at', q.submitted_at, 'reviewed_at', q.reviewed_at,
           'expires_at', q.expires_at,
           'required_seconds', q.required_seconds,
           'timer_ends_at', q.timer_ends_at,
           'review_note', q.review_note,
           'submission_status', q.submission_status
         ) order by q.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select t.*, s.name as service_name, s.platform, s.id as service_id,
             o.target_link, sub.review_note, sub.status as submission_status
        from public.tasks t
        join public.smm_orders o on o.id = t.smm_order_id
        join public.services s on s.id = o.service_id
        left join public.submissions sub on sub.task_id = t.id
       where t.worker_id = u
         and t.smm_order_id is not null
         and (p_status is null or p_status = '' or t.status = p_status)
       order by t.created_at desc
       limit greatest(1, least(coalesce(p_limit, 20), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) q;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.smm_my_tasks(text, int, int) from public, anon;
grant execute on function public.smm_my_tasks(text, int, int) to authenticated;


create or replace function public.admin_smm_proof_queue(p_limit int default 40)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare items jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
           'task_id', q.id, 'seq', q.seq, 'reward', q.reward,
           'order_id', q.smm_order_id,
           'order_short', upper(substr(replace(q.smm_order_id::text, '-', ''), 1, 8)),
           'service_name', q.service_name, 'platform', q.platform,
           'target_link', q.target_link,
           'worker_id', q.worker_id,
           'worker_name', coalesce(nullif(q.full_name, ''), q.email),
           'submitted_at', q.submitted_at,
           'submission_id', q.submission_id,
           'proof_paths', q.proof_paths, 'proof_path', q.proof_path,
           'proof_link', q.proof_link, 'note', q.note,
           'time_spent_seconds', q.time_spent_seconds
         ) order by q.submitted_at asc), '[]'::jsonb)
    into items
    from (
      select t.id, t.seq, t.reward, t.smm_order_id, t.worker_id, t.submitted_at,
             s.name as service_name, s.platform, o.target_link,
             p.full_name, p.email,
             sub.id as submission_id, sub.proof_paths, sub.proof_path,
             sub.proof_link, sub.note, sub.time_spent_seconds
        from public.tasks t
        join public.smm_orders o on o.id = t.smm_order_id
        join public.services s on s.id = o.service_id
        left join public.profiles p on p.id = t.worker_id
        left join public.submissions sub on sub.task_id = t.id
       where t.status = 'submitted'
       order by t.submitted_at asc
       limit greatest(1, least(coalesce(p_limit, 40), 100))
    ) q;

  return jsonb_build_object('items', items);
end $$;

revoke all on function public.admin_smm_proof_queue(int) from public, anon;
grant execute on function public.admin_smm_proof_queue(int) to authenticated;


create or replace function public.admin_smm_set_worker_reward(
  p_service_id uuid, p_reward numeric
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare s public.services;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_reward is null or p_reward <= 0 then raise exception 'INVALID_REWARD'; end if;

  update public.services
     set worker_reward_per_1000 = round(p_reward, 6)
   where id = p_service_id and is_smm
   returning * into s;

  if s.id is null then raise exception 'SERVICE_NOT_FOUND'; end if;

  perform public.audit('smm_service.worker_reward', 'service', s.id,
    jsonb_build_object('name', s.name, 'worker_reward_per_1000', s.worker_reward_per_1000));

  return jsonb_build_object('ok', true, 'service', to_jsonb(s));
end $$;

revoke all on function public.admin_smm_set_worker_reward(uuid, numeric) from public, anon;
grant execute on function public.admin_smm_set_worker_reward(uuid, numeric) to authenticated;


/* Re-created with the filters applied BEFORE pagination: the earlier version
   limited the page first and filtered it afterwards, so a platform or search
   filter could hide every row of a page. */
create or replace function public.admin_smm_orders(
  p_status text default null,
  p_platform text default null,
  p_search text default null,
  p_limit int default 30,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','FINANCE','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.smm_orders o
    join public.services s on s.id = o.service_id
   where (p_status is null or p_status = '' or o.status = p_status)
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%'
          or s.name ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id, 'user_id', o.user_id,
           'user_name', coalesce(nullif(p.full_name, ''), p.email),
           'service_name', s.name, 'platform', s.platform,
           'target_link', o.target_link, 'quantity', o.quantity,
           'rate_snapshot', o.rate_snapshot, 'total_cost', o.total_cost,
           'refunded_total', o.refunded_total, 'status', o.status,
           'admin_note', o.admin_note,
           'created_at', o.created_at, 'updated_at', o.updated_at,
           'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8))
         ) order by o.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select o.*
        from public.smm_orders o
        join public.services s on s.id = o.service_id
       where (p_status is null or p_status = '' or o.status = p_status)
         and (p_platform is null or p_platform = '' or s.platform = p_platform)
         and (p_search is null or p_search = ''
              or o.id::text ilike '%' || p_search || '%'
              or o.target_link ilike '%' || p_search || '%'
              or s.name ilike '%' || p_search || '%')
       order by o.created_at desc
       limit greatest(1, least(coalesce(p_limit, 30), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) o
    join public.services s on s.id = o.service_id
    left join public.profiles p on p.id = o.user_id;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_smm_orders(text, text, text, int, int) from public, anon;
grant execute on function public.admin_smm_orders(text, text, text, int, int) to authenticated;


create or replace function public.admin_smm_services(
  p_search text default null, p_platform text default null,
  p_limit int default 50, p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.services s
   where s.is_smm
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or s.name ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', x.id, 'platform', x.platform, 'name', x.name,
           'description', x.description, 'category_id', x.category_id,
           'category_name', x.category_name, 'language', x.language,
           'rate_per_1000', x.rate_per_1000,
           'worker_reward_per_1000', x.worker_reward_per_1000,
           'cost_price_per_1000', x.cost_price_per_1000,
           'min_quantity', x.min_quantity, 'max_quantity', x.max_quantity,
           'estimated_time', x.estimated_time, 'features', x.features,
           'smm_active', x.smm_active, 'archived_at', x.archived_at,
           'orders_count', coalesce(o.n, 0),
           'revenue', coalesce(o.rev, 0),
           'short_id', upper(substr(replace(x.id::text, '-', ''), 1, 6))
         ) order by x.platform, x.sort_order, x.name), '[]'::jsonb)
    into v_items
    from (
      select s.*, c.name as category_name
        from public.services s
        left join public.smm_categories c on c.id = s.category_id
       where s.is_smm
         and (p_platform is null or p_platform = '' or s.platform = p_platform)
         and (p_search is null or p_search = '' or s.name ilike '%' || p_search || '%')
       order by s.platform, s.sort_order, s.name
       limit greatest(1, least(coalesce(p_limit, 50), 200))
      offset greatest(0, coalesce(p_offset, 0))
    ) x
    left join (
      select service_id, count(*)::int n, sum(total_cost) rev
        from public.smm_orders group by service_id
    ) o on o.service_id = x.id;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_smm_services(text, text, int, int) from public, anon;
grant execute on function public.admin_smm_services(text, text, int, int) to authenticated;


/* Buyer order list with the live delivery counters, so progress can be seen
   without opening every order. */
create or replace function public.my_smm_orders(
  p_status text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_items jsonb;
  v_total integer;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.smm_orders o
   where o.user_id = v_uid
     and (p_status is null or p_status = '' or o.status = p_status)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id,
           'service_id', o.service_id,
           'service_name', s.name,
           'platform', s.platform,
           'target_link', o.target_link,
           'quantity', o.quantity,
           'rate_snapshot', o.rate_snapshot,
           'total_cost', o.total_cost,
           'refunded_total', o.refunded_total,
           'status', o.status,
           'admin_note', o.admin_note,
           'created_at', o.created_at,
           'updated_at', o.updated_at,
           'processed_at', o.processed_at,
           'completed_at', o.completed_at,
           'completed_quantity', o.completed_quantity,
           'issued_quantity', o.issued_quantity,
           'rejected_quantity', o.rejected_quantity,
           'drip_paused', o.drip_paused,
           'next_release_at', o.next_release_at,
           'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8))
         ) order by o.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select * from public.smm_orders
       where user_id = v_uid
         and (p_status is null or p_status = '' or status = p_status)
         and (p_search is null or p_search = ''
              or id::text ilike '%' || p_search || '%'
              or target_link ilike '%' || p_search || '%')
       order by created_at desc
       limit greatest(1, least(coalesce(p_limit, 20), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) o
    join public.services s on s.id = o.service_id;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.my_smm_orders(text, text, int, int) from public, anon;
grant execute on function public.my_smm_orders(text, text, int, int) to authenticated;


/* Re-created with a role check: the original version was readable by any
   authenticated account. */
create or replace function public.admin_smm_stats()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','FINANCE','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'orders', (select count(*) from public.smm_orders),
    'pending', (select count(*) from public.smm_orders where status = 'pending'),
    'processing', (select count(*) from public.smm_orders where status = 'processing'),
    'completed', (select count(*) from public.smm_orders where status = 'completed'),
    'revenue', (select coalesce(sum(total_cost), 0) from public.smm_orders),
    'refunded', (select coalesce(sum(refunded_total), 0) from public.smm_orders),
    'services', (select count(*) from public.services where is_smm and archived_at is null),
    'active_services', (select count(*) from public.services where is_smm and smm_active and archived_at is null),
    'categories', (select count(*) from public.smm_categories),
    'cost_configured', (select count(*) from public.services
                         where is_smm and cost_price_per_1000 is not null)
  );
end $$;

revoke all on function public.admin_smm_stats() from public, anon;
grant execute on function public.admin_smm_stats() to authenticated;


notify pgrst, 'reload schema';

commit;
