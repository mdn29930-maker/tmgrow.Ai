-- ============================================================================
-- TM GROW — SMM ORDER SYSTEM (Phase 1: database + backend RPCs)
--
-- Additive only. Nothing is dropped, deleted, renamed or reset.
-- Existing worker tasks, buyer campaigns, wallets, ledger, auth, deposits,
-- support and Telegram delivery are untouched.
--
-- Separation of concepts:
--   services        existing worker-task catalogue (is_smm = false)
--   services        also hosts SMM catalogue rows (is_smm = true, active = false
--                   so they never appear in worker/buyer campaign flows)
--   smm_categories  new, database-driven categories per platform
--   smm_orders      new, one row per purchased SMM order (no worker tasks)
--   campaigns       unchanged, used only by the Worker Campaign system
--
-- Money: every charge and refund goes through public.wallet_move(), which locks
-- the wallet row and writes an immutable ledger_entries row. No other path
-- changes a balance.
--
-- Idempotency: unique (user_id, idempotency_key) on smm_orders; a repeated
-- Order Now with the same key returns the existing order and charges nothing.
-- ============================================================================

begin;

-- ============================================================================
-- 1. CATEGORIES
-- ============================================================================
create table if not exists public.smm_categories (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  name text not null,
  icon text,
  sort_order int not null default 100,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint smm_categories_platform_name_key unique (platform, name)
);

create index if not exists smm_categories_platform_idx
  on public.smm_categories (platform, is_active, sort_order);

alter table public.smm_categories enable row level security;

drop trigger if exists smm_categories_set_updated_at on public.smm_categories;
create trigger smm_categories_set_updated_at
  before update on public.smm_categories
  for each row execute function public.tg_set_updated_at();

-- Categories are readable through an RPC only; no direct table grants.


-- ============================================================================
-- 2. SMM COLUMNS ON THE EXISTING services TABLE
--    is_smm rows keep active = false so existing worker/buyer campaign
--    queries (which filter active) never see them.
-- ============================================================================
alter table public.services add column if not exists is_smm boolean not null default false;
alter table public.services add column if not exists smm_active boolean not null default true;
alter table public.services add column if not exists category_id uuid references public.smm_categories (id) on delete set null;
alter table public.services add column if not exists rate_per_1000 numeric(18, 6);
alter table public.services add column if not exists cost_price_per_1000 numeric(18, 6);
alter table public.services add column if not exists language text;
alter table public.services add column if not exists estimated_time text;
alter table public.services add column if not exists features jsonb not null default '[]'::jsonb;
alter table public.services add column if not exists archived_at timestamptz;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'services_rate_per_1000_chk') then
    alter table public.services add constraint services_rate_per_1000_chk
      check (rate_per_1000 is null or rate_per_1000 > 0);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'services_cost_price_chk') then
    alter table public.services add constraint services_cost_price_chk
      check (cost_price_per_1000 is null or cost_price_per_1000 >= 0);
  end if;
end $$;

create index if not exists services_smm_idx
  on public.services (platform, smm_active, archived_at, sort_order)
  where is_smm;


-- ============================================================================
-- 3. SMM ORDERS
-- ============================================================================
create table if not exists public.smm_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  service_id uuid not null references public.services (id),
  target_link text not null,
  quantity int not null check (quantity > 0),
  rate_snapshot numeric(18, 6) not null check (rate_snapshot > 0),
  total_cost numeric(18, 6) not null check (total_cost > 0),
  refunded_total numeric(18, 6) not null default 0
    check (refunded_total >= 0 and refunded_total <= total_cost),
  status text not null default 'pending'
    check (status in ('pending','processing','completed','partial','cancelled','failed','refunded')),
  admin_note text,
  idempotency_key text,
  source text not null default 'single' check (source in ('single','bulk')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  processed_at timestamptz,
  completed_at timestamptz
);

create index if not exists smm_orders_user_idx
  on public.smm_orders (user_id, created_at desc);
create index if not exists smm_orders_status_idx
  on public.smm_orders (status, created_at desc);
create index if not exists smm_orders_service_idx
  on public.smm_orders (service_id, created_at desc);

create unique index if not exists smm_orders_idempotency_key
  on public.smm_orders (user_id, idempotency_key)
  where idempotency_key is not null;

alter table public.smm_orders enable row level security;

drop trigger if exists smm_orders_set_updated_at on public.smm_orders;
create trigger smm_orders_set_updated_at
  before update on public.smm_orders
  for each row execute function public.tg_set_updated_at();

-- No table grants: reads and writes go through the RPCs below.


-- ============================================================================
-- 4. NOTIFICATION TEMPLATES (in-app always; Telegram only when delivery is on)
-- ============================================================================
insert into public.settings (key, value, is_public) values
  ('telegram_tpl_smm_order_placed', to_jsonb('🧾 New SMM order
{{service}}
Link: {{target}}
Quantity: {{quantity}}
Charged: {{total}} USDT

Status: pending — queued for processing.'::text), false),
  ('telegram_tpl_smm_order_processing', to_jsonb('⚙️ Order processing
{{service}}
Quantity: {{quantity}}
Your order is being processed.'::text), false),
  ('telegram_tpl_smm_order_completed', to_jsonb('✅ Order delivered
{{service}}
Quantity: {{quantity}}
Thank you for choosing TM GROW.'::text), false),
  ('telegram_tpl_smm_order_partial', to_jsonb('➗ Order partially delivered
{{service}}
Quantity: {{quantity}}
Contact support if anything looks wrong.'::text), false),
  ('telegram_tpl_smm_order_cancelled', to_jsonb('⚠️ Order cancelled
{{service}}
Quantity: {{quantity}}
A refund is handled through the wallet ledger.'::text), false),
  ('telegram_tpl_smm_order_refunded', to_jsonb('💸 Refund processed
{{service}}
Amount: {{amount}} USDT
The refund was credited to your wallet.'::text), false)
on conflict (key) do nothing;


-- ============================================================================
-- 5. READ RPCs — catalogue, categories, counts, orders
-- ============================================================================
create or replace function public.smm_categories_list()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', c.id, 'platform', c.platform, 'name', c.name,
           'icon', c.icon, 'sort_order', c.sort_order
         ) order by c.platform, c.sort_order, c.name), '[]'::jsonb)
    from public.smm_categories c
   where c.is_active;
$$;

revoke all on function public.smm_categories_list() from public, anon;
grant execute on function public.smm_categories_list() to authenticated;


create or replace function public.smm_platform_counts()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_object_agg(platform, n), '{}'::jsonb)
    from (
      select s.platform, count(*)::int as n
        from public.services s
       where s.is_smm and s.smm_active and s.archived_at is null
         and s.rate_per_1000 is not null
       group by s.platform
    ) q;
$$;

revoke all on function public.smm_platform_counts() from public, anon;
grant execute on function public.smm_platform_counts() to authenticated;


create or replace function public.smm_list_services(
  p_platform text default null,
  p_category_id uuid default null,
  p_search text default null,
  p_sort text default 'default',
  p_limit int default 25,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.services s
   where s.is_smm and s.smm_active and s.archived_at is null
     and s.rate_per_1000 is not null
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_category_id is null or s.category_id = p_category_id)
     and (p_search is null or p_search = ''
          or s.name ilike '%' || p_search || '%'
          or s.platform ilike '%' || p_search || '%'
          or s.id::text = replace(lower(trim(p_search)), '#', ''));

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', x.id, 'platform', x.platform, 'name', x.name,
           'description', x.description,
           'category_id', x.category_id,
           'category_name', x.category_name,
           'language', x.language,
           'rate_per_1000', x.rate_per_1000,
           'min_quantity', x.min_quantity,
           'max_quantity', x.max_quantity,
           'estimated_time', x.estimated_time,
           'features', x.features,
           'short_id', upper(substr(replace(x.id::text, '-', ''), 1, 6)),
           'orders_count', x.orders_count
         ) order by x.sort_position), '[]'::jsonb)
    into v_items
    from (
      select s.*, c.name as category_name, coalesce(o.n, 0) as orders_count,
             row_number() over (order by
               case when p_sort = 'price_asc' then s.rate_per_1000 end asc nulls last,
               case when p_sort = 'price_desc' then s.rate_per_1000 end desc nulls last,
               coalesce(o.n, 0) desc,
               s.sort_order, s.name) as sort_position
        from public.services s
        left join public.smm_categories c on c.id = s.category_id
        left join (
          select service_id, count(*)::int n
            from public.smm_orders
           group by service_id
        ) o on o.service_id = s.id
       where s.is_smm and s.smm_active and s.archived_at is null
         and s.rate_per_1000 is not null
         and (p_platform is null or p_platform = '' or s.platform = p_platform)
         and (p_category_id is null or s.category_id = p_category_id)
         and (p_search is null or p_search = ''
              or s.name ilike '%' || p_search || '%'
              or s.platform ilike '%' || p_search || '%'
              or s.id::text = replace(lower(trim(p_search)), '#', '')
              or upper(substr(replace(s.id::text, '-', ''), 1, 6)) = upper(replace(trim(p_search), '#', '')))
       order by
         case when p_sort = 'price_asc' then s.rate_per_1000 end asc nulls last,
         case when p_sort = 'price_desc' then s.rate_per_1000 end desc nulls last,
         coalesce(o.n, 0) desc,
         s.sort_order, s.name
       limit greatest(1, least(coalesce(p_limit, 25), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) x;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.smm_list_services(text, uuid, text, text, int, int) from public, anon;
grant execute on function public.smm_list_services(text, uuid, text, text, int, int) to authenticated;


create or replace function public.my_smm_orders(
  p_status text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_items jsonb;
  v_total integer;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.smm_orders o
   where o.user_id = v_uid
     and (p_status is null or p_status = '' or o.status = p_status)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id,
           'service_id', o.service_id,
           'service_name', s.name,
           'platform', s.platform,
           'target_link', o.target_link,
           'quantity', o.quantity,
           'rate_snapshot', o.rate_snapshot,
           'total_cost', o.total_cost,
           'refunded_total', o.refunded_total,
           'status', o.status,
           'admin_note', o.admin_note,
           'created_at', o.created_at,
           'updated_at', o.updated_at,
           'processed_at', o.processed_at,
           'completed_at', o.completed_at,
           'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8))
         ) order by o.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select * from public.smm_orders
       where user_id = v_uid
         and (p_status is null or p_status = '' or status = p_status)
         and (p_search is null or p_search = ''
              or id::text ilike '%' || p_search || '%'
              or target_link ilike '%' || p_search || '%')
       order by created_at desc
       limit greatest(1, least(coalesce(p_limit, 20), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) o
    join public.services s on s.id = o.service_id;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.my_smm_orders(text, text, int, int) from public, anon;
grant execute on function public.my_smm_orders(text, text, int, int) to authenticated;


-- ============================================================================
-- 6. SINGLE ORDER
-- ============================================================================
create or replace function public.create_smm_order(
  p_service_id uuid,
  p_target_link text,
  p_quantity int,
  p_idempotency_key text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid    uuid := auth.uid();
  v_p      public.profiles;
  v_s      public.services;
  v_w      public.wallets;
  v_total  numeric;
  v_link   text := btrim(coalesce(p_target_link, ''));
  v_key    text := nullif(btrim(coalesce(p_idempotency_key, '')), '');
  v_order  public.smm_orders;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;
  if v_key is null then
    return jsonb_build_object('ok', false, 'code', 'IDEMPOTENCY_KEY_REQUIRED',
      'message', 'Reload the page and try again.');
  end if;

  perform public.ensure_profile();
  select * into v_p from public.profiles where id = v_uid;
  if v_p.status <> 'active' then
    return jsonb_build_object('ok', false, 'code', 'ACCOUNT_RESTRICTED',
      'message', 'This account cannot place orders.');
  end if;
  if not v_p.is_buyer then
    return jsonb_build_object('ok', false, 'code', 'BUYER_MODE_DISABLED',
      'message', 'Open a buyer account first.');
  end if;

  /* Duplicate tap / retry: return the existing order, never charge twice. */
  select * into v_order
    from public.smm_orders
   where user_id = v_uid and idempotency_key = v_key;
  if v_order.id is not null then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
  end if;

  select * into v_s from public.services where id = p_service_id;
  if v_s.id is null or not v_s.is_smm or not v_s.smm_active or v_s.archived_at is not null then
    return jsonb_build_object('ok', false, 'code', 'SERVICE_UNAVAILABLE',
      'message', 'This service is not available.');
  end if;
  if v_s.rate_per_1000 is null or v_s.rate_per_1000 <= 0 then
    return jsonb_build_object('ok', false, 'code', 'SERVICE_NOT_PRICED',
      'message', 'This service has no price yet.');
  end if;

  if v_link = '' or v_link !~* '^https?://' or char_length(v_link) > 500 then
    return jsonb_build_object('ok', false, 'code', 'INVALID_TARGET_URL',
      'message', 'Enter a valid http(s) link.');
  end if;
  if p_quantity is null or p_quantity < v_s.min_quantity or p_quantity > v_s.max_quantity then
    return jsonb_build_object('ok', false, 'code', 'INVALID_QUANTITY',
      'message', 'Quantity must be between ' || v_s.min_quantity || ' and ' || v_s.max_quantity || '.');
  end if;

  v_total := round(p_quantity::numeric * v_s.rate_per_1000 / 1000.0, 6);
  if v_total <= 0 then
    return jsonb_build_object('ok', false, 'code', 'INVALID_TOTAL',
      'message', 'The order total is not valid.');
  end if;

  select * into v_w from public.wallets where user_id = v_uid for update;
  if v_w.user_id is null then
    return jsonb_build_object('ok', false, 'code', 'WALLET_NOT_FOUND',
      'message', 'Wallet not found.');
  end if;
  if v_w.available < v_total then
    return jsonb_build_object('ok', false, 'code', 'INSUFFICIENT_FUNDS',
      'message', 'Not enough available balance for this order.',
      'required', v_total, 'available', v_w.available);
  end if;

  begin
    insert into public.smm_orders (
      user_id, service_id, target_link, quantity,
      rate_snapshot, total_cost, status, idempotency_key, source
    ) values (
      v_uid, v_s.id, v_link, p_quantity,
      v_s.rate_per_1000, v_total, 'pending', v_key, 'single'
    ) returning * into v_order;
  exception when unique_violation then
    select * into v_order from public.smm_orders
     where user_id = v_uid and idempotency_key = v_key;
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
  end;

  perform public.wallet_move(
    v_uid, -v_total, 0, 0, 0,
    'smm_order_charge', 'smm_order', v_order.id,
    'SMM order ' || upper(substr(replace(v_order.id::text, '-', ''), 1, 8)) || ' — ' || v_s.name
  );

  perform public.audit('smm_order.create', 'smm_order', v_order.id,
    jsonb_build_object('service', v_s.name, 'quantity', p_quantity, 'total', v_total));

  perform public.notify_user(v_uid, 'Order placed',
    v_s.name || ' · ' || p_quantity || ' · ' || v_total || ' USDT charged.',
    'success', '#/smm/orders');

  perform public.telegram_enqueue(v_uid, 'smm_order_placed',
    jsonb_build_object(
      'service', v_s.name,
      'target', v_link,
      'quantity', p_quantity,
      'total', public.telegram_money(v_total)
    ), 'smm_placed:' || v_order.id);

  select * into v_w from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'duplicate', false,
    'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
end $$;

revoke all on function public.create_smm_order(uuid, text, int, text) from public, anon;
grant execute on function public.create_smm_order(uuid, text, int, text) to authenticated;


-- ============================================================================
-- 7. MASS ORDER — validate everything first, then one atomic batch
-- ============================================================================
create or replace function public.create_smm_orders_bulk(
  p_items jsonb,
  p_idempotency_key text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid    uuid := auth.uid();
  v_p      public.profiles;
  v_w      public.wallets;
  v_key    text := nullif(btrim(coalesce(p_idempotency_key, '')), '');
  v_items  jsonb := coalesce(p_items, '[]'::jsonb);
  v_item   jsonb;
  v_s      public.services;
  v_sid    uuid;
  v_link   text;
  v_qty    int;
  v_total  numeric;
  v_sum    numeric := 0;
  v_clean  jsonb := '[]'::jsonb;
  v_errors jsonb := '[]'::jsonb;
  v_order  public.smm_orders;
  v_created jsonb := '[]'::jsonb;
  v_idx    int := 0;
  v_existing jsonb;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;
  if v_key is null then
    return jsonb_build_object('ok', false, 'code', 'IDEMPOTENCY_KEY_REQUIRED',
      'message', 'Reload the page and try again.');
  end if;
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    return jsonb_build_object('ok', false, 'code', 'EMPTY_BATCH',
      'message', 'Add at least one order line.');
  end if;
  if jsonb_array_length(v_items) > 50 then
    return jsonb_build_object('ok', false, 'code', 'BATCH_TOO_LARGE',
      'message', 'A mass order can contain at most 50 lines.');
  end if;

  perform public.ensure_profile();
  select * into v_p from public.profiles where id = v_uid;
  if v_p.status <> 'active' then
    return jsonb_build_object('ok', false, 'code', 'ACCOUNT_RESTRICTED',
      'message', 'This account cannot place orders.');
  end if;
  if not v_p.is_buyer then
    return jsonb_build_object('ok', false, 'code', 'BUYER_MODE_DISABLED',
      'message', 'Open a buyer account first.');
  end if;

  /* Already submitted with this key: return the same batch, no new charge. */
  select coalesce(jsonb_agg(to_jsonb(o) order by o.created_at), '[]'::jsonb)
    into v_existing
    from public.smm_orders o
   where o.user_id = v_uid
     and o.idempotency_key like v_key || ':%';
  if jsonb_array_length(v_existing) > 0 then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'orders', v_existing, 'balance', coalesce(v_w.available, 0));
  end if;

  /* Validate every row before any write. */
  for v_item in select * from jsonb_array_elements(v_items) loop
    v_idx := v_idx + 1;
    begin
      v_sid := (v_item ->> 'service_id')::uuid;
    exception when others then
      v_sid := null;
    end;
    v_link := btrim(coalesce(v_item ->> 'target_link', ''));
    begin
      v_qty := (v_item ->> 'quantity')::int;
    exception when others then
      v_qty := null;
    end;

    select * into v_s from public.services where id = v_sid;

    if v_s.id is null or not v_s.is_smm or not v_s.smm_active or v_s.archived_at is not null then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'SERVICE_UNAVAILABLE', 'message', 'Service ID not found or inactive.');
      continue;
    end if;
    if v_s.rate_per_1000 is null or v_s.rate_per_1000 <= 0 then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'SERVICE_NOT_PRICED', 'message', 'Service has no price.');
      continue;
    end if;
    if v_link = '' or v_link !~* '^https?://' or char_length(v_link) > 500 then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'INVALID_TARGET_URL', 'message', 'Target link is not a valid http(s) URL.');
      continue;
    end if;
    if v_qty is null or v_qty < v_s.min_quantity or v_qty > v_s.max_quantity then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'INVALID_QUANTITY',
        'message', 'Quantity must be between ' || v_s.min_quantity || ' and ' || v_s.max_quantity || '.');
      continue;
    end if;

    v_total := round(v_qty::numeric * v_s.rate_per_1000 / 1000.0, 6);
    v_sum := v_sum + v_total;
    v_clean := v_clean || jsonb_build_object(
      'line', v_idx, 'service_id', v_s.id, 'service_name', v_s.name,
      'target_link', v_link, 'quantity', v_qty,
      'rate', v_s.rate_per_1000, 'total', v_total
    );
  end loop;

  if jsonb_array_length(v_errors) > 0 then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', false, 'code', 'VALIDATION_FAILED',
      'message', 'Nothing was charged. Fix the listed lines and submit again.',
      'errors', v_errors, 'balance', coalesce(v_w.available, 0));
  end if;

  select * into v_w from public.wallets where user_id = v_uid for update;
  if v_w.available < v_sum then
    return jsonb_build_object('ok', false, 'code', 'INSUFFICIENT_FUNDS',
      'message', 'Not enough balance for the whole batch. Nothing was charged.',
      'required', v_sum, 'available', v_w.available);
  end if;

  /* From here every statement is in one transaction: all orders or none. */
  for v_item in select * from jsonb_array_elements(v_clean) loop
    insert into public.smm_orders (
      user_id, service_id, target_link, quantity,
      rate_snapshot, total_cost, status, idempotency_key, source
    ) values (
      v_uid, (v_item ->> 'service_id')::uuid, v_item ->> 'target_link',
      (v_item ->> 'quantity')::int, (v_item ->> 'rate')::numeric,
      (v_item ->> 'total')::numeric, 'pending',
      v_key || ':' || (v_item ->> 'line'), 'bulk'
    ) returning * into v_order;

    perform public.wallet_move(
      v_uid, -(v_item ->> 'total')::numeric, 0, 0, 0,
      'smm_order_charge', 'smm_order', v_order.id,
      'Mass order line ' || (v_item ->> 'line') || ' — ' || v_item ->> 'service_name'
    );

    v_created := v_created || to_jsonb(v_order);
  end loop;

  perform public.audit('smm_order.bulk', 'smm_order', null,
    jsonb_build_object('lines', jsonb_array_length(v_created), 'total', v_sum));

  perform public.notify_user(v_uid, 'Mass order placed',
    jsonb_array_length(v_created) || ' orders · ' || v_sum || ' USDT charged.',
    'success', '#/smm/orders');

  select * into v_w from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'duplicate', false,
    'orders', v_created, 'total', v_sum, 'balance', coalesce(v_w.available, 0));
end $$;

revoke all on function public.create_smm_orders_bulk(jsonb, text) from public, anon;
grant execute on function public.create_smm_orders_bulk(jsonb, text) to authenticated;


-- ============================================================================
-- 8. ADMIN: ORDER MANAGEMENT + REFUNDS
-- ============================================================================
create or replace function public.admin_smm_orders(
  p_status text default null,
  p_platform text default null,
  p_search text default null,
  p_limit int default 30,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','FINANCE','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.smm_orders o
    join public.services s on s.id = o.service_id
   where (p_status is null or p_status = '' or o.status = p_status)
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%'
          or s.name ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id, 'user_id', o.user_id,
           'user_name', coalesce(nullif(p.full_name, ''), p.email),
           'service_name', s.name, 'platform', s.platform,
           'target_link', o.target_link, 'quantity', o.quantity,
           'rate_snapshot', o.rate_snapshot, 'total_cost', o.total_cost,
           'refunded_total', o.refunded_total, 'status', o.status,
           'admin_note', o.admin_note,
           'created_at', o.created_at, 'updated_at', o.updated_at,
           'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8))
         ) order by o.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select * from public.smm_orders
       where (p_status is null or p_status = '' or status = p_status)
       order by created_at desc
       limit greatest(1, least(coalesce(p_limit, 30), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) o
    join public.services s on s.id = o.service_id
    left join public.profiles p on p.id = o.user_id
   where (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%'
          or s.name ilike '%' || p_search || '%');

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_smm_orders(text, text, text, int, int) from public, anon;
grant execute on function public.admin_smm_orders(text, text, text, int, int) to authenticated;


create or replace function public.admin_set_smm_order_status(
  p_order_id uuid, p_status text, p_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.smm_orders;
  v_from text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_status not in ('pending','processing','completed','partial','cancelled','failed','refunded') then
    raise exception 'INVALID_STATUS';
  end if;
  if p_status = 'refunded' then
    raise exception 'USE_REFUND_FUNCTION';
  end if;

  select * into o from public.smm_orders where id = p_order_id for update;
  if o.id is null then raise exception 'ORDER_NOT_FOUND'; end if;
  if o.status in ('completed','refunded') then raise exception 'ORDER_FINAL'; end if;
  if o.status = 'cancelled' and p_status <> 'cancelled' then raise exception 'ORDER_FINAL'; end if;

  v_from := o.status;

  update public.smm_orders
     set status = p_status,
         admin_note = coalesce(nullif(btrim(coalesce(p_note, '')), ''), admin_note),
         processed_at = case when p_status = 'processing' and processed_at is null then now() else processed_at end,
         completed_at = case when p_status in ('completed','partial') then now() else completed_at end
   where id = o.id
   returning * into o;

  perform public.audit('smm_order.status', 'smm_order', o.id,
    jsonb_build_object('from', v_from, 'to', p_status, 'note', left(coalesce(p_note, ''), 200)));

  perform public.notify_user(o.user_id, 'Order ' || p_status,
    'Order ' || upper(substr(replace(o.id::text, '-', ''), 1, 8)) || ' is now ' || p_status || '.',
    case when p_status in ('completed','partial') then 'success'
         when p_status in ('cancelled','failed') then 'error' else 'info' end,
    '#/smm/orders');

  if p_status in ('processing','completed','partial','cancelled') then
    perform public.telegram_enqueue(o.user_id, 'smm_order_' || p_status,
      jsonb_build_object(
        'service', (select name from public.services where id = o.service_id),
        'quantity', o.quantity,
        'target', o.target_link
      ), 'smm_status:' || o.id || ':' || p_status);
  end if;

  return jsonb_build_object('ok', true, 'order', to_jsonb(o));
end $$;

revoke all on function public.admin_set_smm_order_status(uuid, text, text) from public, anon;
grant execute on function public.admin_set_smm_order_status(uuid, text, text) to authenticated;


create or replace function public.admin_refund_smm_order(
  p_order_id uuid, p_amount numeric, p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.smm_orders;
  v_remaining numeric;
  v_amount numeric;
  v_note text := nullif(btrim(coalesce(p_reason, '')), '');
  v_w public.wallets;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then
    raise exception 'FORBIDDEN';
  end if;
  if v_note is null then raise exception 'REASON_REQUIRED'; end if;

  select * into o from public.smm_orders where id = p_order_id for update;
  if o.id is null then raise exception 'ORDER_NOT_FOUND'; end if;
  if o.status = 'pending' or o.status = 'processing' then
    raise exception 'CANCEL_OR_COMPLETE_FIRST';
  end if;

  v_remaining := round(o.total_cost - o.refunded_total, 6);
  if v_remaining <= 0 then raise exception 'FULLY_REFUNDED'; end if;

  v_amount := round(coalesce(p_amount, 0), 6);
  if v_amount <= 0 then raise exception 'INVALID_AMOUNT'; end if;
  if v_amount > v_remaining then raise exception 'REFUND_EXCEEDS_REMAINING'; end if;

  perform public.wallet_move(
    o.user_id, v_amount, 0, 0, 0,
    'smm_order_refund', 'smm_order', o.id,
    'SMM refund: ' || left(v_note, 160)
  );

  update public.smm_orders
     set refunded_total = round(refunded_total + v_amount, 6),
         status = case when round(refunded_total + v_amount, 6) >= total_cost then 'refunded' else status end,
         admin_note = v_note
   where id = o.id
   returning * into o;

  perform public.audit('smm_order.refund', 'smm_order', o.id,
    jsonb_build_object('amount', v_amount, 'reason', left(v_note, 300),
                       'refunded_total', o.refunded_total, 'total', o.total_cost));

  perform public.notify_user(o.user_id, 'Refund processed',
    v_amount || ' USDT was credited for order ' ||
      upper(substr(replace(o.id::text, '-', ''), 1, 8)) || '.',
    'success', '#/smm/orders');

  perform public.telegram_enqueue(o.user_id, 'smm_order_refunded',
    jsonb_build_object(
      'service', (select name from public.services where id = o.service_id),
      'amount', public.telegram_money(v_amount)
    ), 'smm_refund:' || o.id || ':' || o.refunded_total);

  select * into v_w from public.wallets where user_id = o.user_id;
  return jsonb_build_object('ok', true, 'order', to_jsonb(o),
    'balance', coalesce(v_w.available, 0));
end $$;

revoke all on function public.admin_refund_smm_order(uuid, numeric, text) from public, anon;
grant execute on function public.admin_refund_smm_order(uuid, numeric, text) to authenticated;


-- ============================================================================
-- 9. ADMIN: CATEGORIES + SERVICES
-- ============================================================================
create or replace function public.admin_smm_categories_list()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', c.id, 'platform', c.platform, 'name', c.name, 'icon', c.icon,
           'sort_order', c.sort_order, 'is_active', c.is_active,
           'services', (select count(*) from public.services s
                         where s.category_id = c.id and s.is_smm and s.archived_at is null)
         ) order by c.platform, c.sort_order, c.name), '[]'::jsonb)
    from public.smm_categories c;
$$;

revoke all on function public.admin_smm_categories_list() from public, anon;
grant execute on function public.admin_smm_categories_list() to authenticated;


create or replace function public.admin_upsert_smm_category(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  c public.smm_categories;
  v_id uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  begin
    v_id := nullif(p_payload ->> 'id', '')::uuid;
  exception when others then
    v_id := null;
  end;

  if coalesce(btrim(p_payload ->> 'platform'), '') = ''
     or coalesce(btrim(p_payload ->> 'name'), '') = '' then
    raise exception 'INVALID_PAYLOAD';
  end if;

  if v_id is null then
    insert into public.smm_categories (platform, name, icon, sort_order, is_active)
    values (lower(btrim(p_payload ->> 'platform')), btrim(p_payload ->> 'name'),
            nullif(btrim(coalesce(p_payload ->> 'icon', '')), ''),
            greatest(0, coalesce((p_payload ->> 'sort_order')::int, 100)),
            coalesce((p_payload ->> 'is_active')::boolean, true))
    returning * into c;
  else
    update public.smm_categories
       set platform = lower(btrim(p_payload ->> 'platform')),
           name = btrim(p_payload ->> 'name'),
           icon = nullif(btrim(coalesce(p_payload ->> 'icon', '')), ''),
           sort_order = greatest(0, coalesce((p_payload ->> 'sort_order')::int, sort_order)),
           is_active = coalesce((p_payload ->> 'is_active')::boolean, is_active)
     where id = v_id
     returning * into c;
    if c.id is null then raise exception 'CATEGORY_NOT_FOUND'; end if;
  end if;

  perform public.audit('smm_category.upsert', 'smm_category', c.id,
    jsonb_build_object('platform', c.platform, 'name', c.name, 'active', c.is_active));
  return jsonb_build_object('ok', true, 'category', to_jsonb(c));
end $$;

revoke all on function public.admin_upsert_smm_category(jsonb) from public, anon;
grant execute on function public.admin_upsert_smm_category(jsonb) to authenticated;


create or replace function public.admin_upsert_smm_service(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  s public.services;
  v_id uuid;
  v_platform text := lower(btrim(coalesce(p_payload ->> 'platform', '')));
  v_rate numeric;
  v_min int;
  v_max int;
  v_cat uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  begin
    v_id := nullif(p_payload ->> 'id', '')::uuid;
  exception when others then
    v_id := null;
  end;
  begin
    v_cat := nullif(p_payload ->> 'category_id', '')::uuid;
  exception when others then
    v_cat := null;
  end;

  v_platform := case when v_platform = 'twitter' then 'x' else v_platform end;
  if v_platform not in ('telegram','x','tiktok','instagram','facebook','youtube','threads') then
    raise exception 'INVALID_PLATFORM';
  end if;

  begin
    v_rate := (p_payload ->> 'rate_per_1000')::numeric;
    v_min := (p_payload ->> 'min_quantity')::int;
    v_max := (p_payload ->> 'max_quantity')::int;
  exception when others then
    raise exception 'INVALID_PAYLOAD';
  end;

  if v_rate is null or v_rate <= 0 then raise exception 'INVALID_RATE'; end if;
  if v_min is null or v_min <= 0 or v_max is null or v_max < v_min then
    raise exception 'INVALID_QUANTITY_RANGE';
  end if;
  if v_cat is not null and not exists (select 1 from public.smm_categories where id = v_cat) then
    raise exception 'CATEGORY_NOT_FOUND';
  end if;

  if v_id is null then
    insert into public.services (
      platform, name, description, default_reward, min_reward,
      min_quantity, max_quantity, active, sort_order,
      is_smm, smm_active, category_id, rate_per_1000, cost_price_per_1000,
      language, estimated_time, features
    ) values (
      v_platform,
      btrim(p_payload ->> 'name'),
      nullif(btrim(coalesce(p_payload ->> 'description', '')), ''),
      greatest(round(v_rate / 1000.0, 6), 0.000001),
      0.000001,
      v_min, v_max,
      false,                                     -- never in worker/buyer campaign flows
      greatest(0, coalesce((p_payload ->> 'sort_order')::int, 100)),
      true,
      coalesce((p_payload ->> 'smm_active')::boolean, true),
      v_cat, v_rate,
      nullif(p_payload ->> 'cost_price_per_1000', '')::numeric,
      nullif(btrim(coalesce(p_payload ->> 'language', '')), ''),
      nullif(btrim(coalesce(p_payload ->> 'estimated_time', '')), ''),
      coalesce(p_payload -> 'features', '[]'::jsonb)
    ) returning * into s;
  else
    update public.services
       set platform = v_platform,
           name = btrim(p_payload ->> 'name'),
           description = nullif(btrim(coalesce(p_payload ->> 'description', '')), ''),
           min_quantity = v_min,
           max_quantity = v_max,
           sort_order = greatest(0, coalesce((p_payload ->> 'sort_order')::int, sort_order)),
           smm_active = coalesce((p_payload ->> 'smm_active')::boolean, smm_active),
           category_id = v_cat,
           rate_per_1000 = v_rate,
           cost_price_per_1000 = nullif(p_payload ->> 'cost_price_per_1000', '')::numeric,
           language = nullif(btrim(coalesce(p_payload ->> 'language', '')), ''),
           estimated_time = nullif(btrim(coalesce(p_payload ->> 'estimated_time', '')), ''),
           features = coalesce(p_payload -> 'features', features),
           archived_at = case when coalesce((p_payload ->> 'archived')::boolean, false) then now() else null end
     where id = v_id and is_smm
     returning * into s;
    if s.id is null then raise exception 'SERVICE_NOT_FOUND'; end if;
  end if;

  perform public.audit('smm_service.upsert', 'service', s.id,
    jsonb_build_object('name', s.name, 'platform', s.platform,
                       'rate', s.rate_per_1000, 'active', s.smm_active));
  return jsonb_build_object('ok', true, 'service', to_jsonb(s));
end $$;

revoke all on function public.admin_upsert_smm_service(jsonb) from public, anon;
grant execute on function public.admin_upsert_smm_service(jsonb) to authenticated;


create or replace function public.admin_smm_services(
  p_search text default null, p_platform text default null,
  p_limit int default 50, p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.services s
   where s.is_smm
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or s.name ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', s.id, 'platform', s.platform, 'name', s.name,
           'description', s.description, 'category_id', s.category_id,
           'category_name', c.name, 'language', s.language,
           'rate_per_1000', s.rate_per_1000,
           'cost_price_per_1000', s.cost_price_per_1000,
           'min_quantity', s.min_quantity, 'max_quantity', s.max_quantity,
           'estimated_time', s.estimated_time, 'features', s.features,
           'smm_active', s.smm_active, 'archived_at', s.archived_at,
           'orders_count', coalesce(o.n, 0),
           'revenue', coalesce(o.rev, 0),
           'short_id', upper(substr(replace(s.id::text, '-', ''), 1, 6))
         ) order by s.platform, s.sort_order, s.name), '[]'::jsonb)
    into v_items
    from public.services s
    left join public.smm_categories c on c.id = s.category_id
    left join (
      select service_id, count(*)::int n, sum(total_cost) rev
        from public.smm_orders group by service_id
    ) o on o.service_id = s.id
   where s.is_smm
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or s.name ilike '%' || p_search || '%')
   order by s.platform, s.sort_order, s.name
   limit greatest(1, least(coalesce(p_limit, 50), 200))
  offset greatest(0, coalesce(p_offset, 0));

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_smm_services(text, text, int, int) from public, anon;
grant execute on function public.admin_smm_services(text, text, int, int) to authenticated;


create or replace function public.admin_smm_stats()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'orders', (select count(*) from public.smm_orders),
    'pending', (select count(*) from public.smm_orders where status = 'pending'),
    'processing', (select count(*) from public.smm_orders where status = 'processing'),
    'completed', (select count(*) from public.smm_orders where status = 'completed'),
    'revenue', (select coalesce(sum(total_cost), 0) from public.smm_orders),
    'refunded', (select coalesce(sum(refunded_total), 0) from public.smm_orders),
    'services', (select count(*) from public.services where is_smm and archived_at is null),
    'active_services', (select count(*) from public.services where is_smm and smm_active and archived_at is null),
    'categories', (select count(*) from public.smm_categories),
    'cost_configured', (select count(*) from public.services
                         where is_smm and cost_price_per_1000 is not null)
  );
$$;

revoke all on function public.admin_smm_stats() from public, anon;
grant execute on function public.admin_smm_stats() to authenticated;


notify pgrst, 'reload schema';

commit;
