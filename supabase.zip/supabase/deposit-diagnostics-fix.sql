-- ============================================================================
-- TM GROW — DEPOSIT MINIMUM: EXACT-STAGE DIAGNOSTICS + SAFE VALIDATION
--
-- READ BEFORE RUNNING. Nothing here is executed by the agent.
--
-- Why this exists
--   The server can only raise BELOW_MIN_DEPOSIT when the numeric value it
--   received is below the configured minimum. The previous message did not carry
--   that value, so a real amount of 10 USDT and a mis-sent amount of 0.4 looked
--   identical. This migration:
--     1. adds one authoritative deposit_minimum() used by both RPCs and the UI,
--     2. records every rejected attempt (amount received, minimum, raw setting),
--     3. makes the error carry BOTH numbers,
--     4. adds admin_deposit_diag() to show the live setting, the numeric cast,
--        the deployed function definitions and the last attempts.
--
-- It does NOT change the minimum, does NOT credit anything and does NOT touch
-- wallet, ledger or deposit rows.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1. ONE MINIMUM
-- ---------------------------------------------------------------------------
create or replace function public.deposit_minimum()
returns numeric
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_raw text;
  v_num numeric;
begin
  select value #>> '{}' into v_raw from public.settings where key = 'min_deposit';
  begin
    v_num := nullif(btrim(coalesce(v_raw, '')), '')::numeric;
  exception when others then
    v_num := null;
  end;
  return greatest(0, coalesce(v_num, 5));
end $$;

revoke all on function public.deposit_minimum() from public, anon;
grant execute on function public.deposit_minimum() to authenticated;

-- ---------------------------------------------------------------------------
-- 2. REJECTED-ATTEMPT LOG (evidence, no money)
-- ---------------------------------------------------------------------------
create table if not exists public.deposit_attempts (
  id bigserial primary key,
  user_id uuid references public.profiles (id) on delete cascade,
  source text not null check (source in ('submit_verified_deposit', 'request_deposit')),
  amount_received numeric,
  minimum numeric,
  raw_setting text,
  tx_hash text,
  reason text not null,
  created_at timestamptz not null default now()
);

create index if not exists deposit_attempts_user_idx
  on public.deposit_attempts (user_id, created_at desc);

alter table public.deposit_attempts enable row level security;
-- No policies: SECURITY DEFINER write-only evidence, admin read through RPC.

-- ---------------------------------------------------------------------------
-- 3. RPCs: validate type first, then the minimum, and report both numbers
-- ---------------------------------------------------------------------------
create or replace function public.submit_verified_deposit(
  p_tx_hash text,
  p_amount numeric,
  p_from_address text default null,
  p_block bigint default null,
  p_confirmations int default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  v_hash text;
  v_min numeric;
  v_raw text;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;

  v_hash := lower(trim(coalesce(p_tx_hash, '')));
  if v_hash !~ '^0x[0-9a-f]{64}$' then raise exception 'INVALID_TX_HASH'; end if;

  if p_amount is null or p_amount <= 0 or p_amount <> p_amount then
    insert into public.deposit_attempts (user_id, source, amount_received, reason)
    values (u, 'submit_verified_deposit', p_amount, 'invalid_amount');
    raise exception 'INVALID_AMOUNT';
  end if;

  v_min := public.deposit_minimum();
  select value #>> '{}' into v_raw from public.settings where key = 'min_deposit';
  if p_amount < v_min then
    insert into public.deposit_attempts (user_id, source, amount_received, minimum, raw_setting, tx_hash, reason)
    values (u, 'submit_verified_deposit', p_amount, v_min, v_raw, v_hash, 'below_minimum');
    raise exception 'BELOW_MIN_DEPOSIT: min=% amount=%',
      public.telegram_money(v_min), public.telegram_money(p_amount);
  end if;

  if exists (select 1 from public.deposits where lower(tx_hash) = v_hash) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (
    user_id, amount, method, tx_hash, status,
    verified_at, confirmations, from_address, block_number, reviewed_at
  ) values (
    u, round(p_amount, 6), 'USDT_BEP20', v_hash, 'approved',
    now(), p_confirmations, lower(nullif(trim(coalesce(p_from_address, '')), '')),
    p_block, now()
  ) returning * into d;

  perform public.wallet_move(u, d.amount, 0, 0, 0, 'deposit', 'deposit', d.id,
                             'Deposit verified on BNB Smart Chain');
  update public.wallets
     set lifetime_deposited = lifetime_deposited + d.amount
   where user_id = u;

  perform public.notify_user(u, 'Deposit credited',
    d.amount || ' USDT was verified on BNB Smart Chain (BEP-20) and added to your balance.',
    'success', '#/history');
  perform public.audit('deposit.verified', 'deposit', d.id,
    jsonb_build_object('tx_hash', d.tx_hash, 'amount', d.amount,
                       'confirmations', p_confirmations,
                       'from', d.from_address, 'block', p_block));

  return jsonb_build_object('deposit', to_jsonb(d));
end $$;

create or replace function public.request_deposit(
  p_amount numeric,
  p_method text default 'USDT_BEP20',
  p_tx_hash text default null,
  p_proof_path text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  v_min numeric;
  v_raw text;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if p_method not in ('USDT_BEP20','BINANCE_PAY') then raise exception 'INVALID_METHOD'; end if;

  if p_amount is null or p_amount <= 0 or p_amount <> p_amount then
    raise exception 'INVALID_AMOUNT';
  end if;

  v_min := public.deposit_minimum();
  select value #>> '{}' into v_raw from public.settings where key = 'min_deposit';
  if p_amount < v_min then
    insert into public.deposit_attempts (user_id, source, amount_received, minimum, raw_setting, tx_hash, reason)
    values (u, 'request_deposit', p_amount, v_min, v_raw, nullif(trim(coalesce(p_tx_hash, '')), ''), 'below_minimum');
    raise exception 'BELOW_MIN_DEPOSIT: min=% amount=%',
      public.telegram_money(v_min), public.telegram_money(p_amount);
  end if;

  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0 and trim(p_tx_hash) !~* '^0x[a-fA-F0-9]{64}$' then
    raise exception 'INVALID_TX_HASH';
  end if;

  if p_proof_path is not null then
    if split_part(p_proof_path, '/', 1) <> u::text then
      raise exception 'INVALID_PROOF_PATH';
    end if;
  elsif p_tx_hash is null or length(trim(p_tx_hash)) = 0 then
    raise exception 'INVALID_PROOF_PATH';
  end if;

  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0
     and exists (
       select 1 from public.deposits
        where lower(tx_hash) = lower(trim(p_tx_hash))
          and status in ('pending','approved')
     ) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (user_id, amount, method, tx_hash, proof_path)
  values (u, round(p_amount, 6), p_method, nullif(trim(coalesce(p_tx_hash, '')), ''), p_proof_path)
  returning * into d;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, 'New deposit request',
         'A buyer submitted a ' || round(p_amount, 6) || ' USDT deposit for review.', 'info', '/admin/deposits'
    from public.profiles where admin_role in ('OWNER','SUPER_ADMIN','ADMIN','FINANCE');

  return jsonb_build_object('deposit', d);
end $$;

-- deposit_limits() must return the same number.
create or replace function public.deposit_limits()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_min numeric := public.deposit_minimum();
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;

  return jsonb_build_object(
    'min_amount', v_min,
    'deposit_address', coalesce(nullif(public.setting_text('deposit_address', ''), ''), ''),
    'network', coalesce(nullif(public.setting_text('network_name', ''), ''), 'BNB Smart Chain (BEP-20)'),
    'usdt_contract', coalesce(nullif(public.setting_text('usdt_contract', ''), ''), '0x55d398326f99059fF775485246999027B3197955'),
    'confirmations', coalesce(public.setting_num('deposit_confirmations', 12), 12)
  );
end $$;

revoke all on function public.deposit_limits() from public, anon;
grant execute on function public.deposit_limits() to authenticated;

-- ---------------------------------------------------------------------------
-- 4. ADMIN DIAGNOSTIC: the exact stage values
-- ---------------------------------------------------------------------------
create or replace function public.admin_deposit_diag()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_raw jsonb;
  v_text text;
  v_num numeric;
  v_def1 text;
  v_def2 text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then
    raise exception 'FORBIDDEN';
  end if;

  select value into v_raw from public.settings where key = 'min_deposit';
  v_text := v_raw #>> '{}';
  begin
    v_num := nullif(btrim(coalesce(v_text, '')), '')::numeric;
  exception when others then
    v_num := null;
  end;

  v_def1 := pg_get_functiondef('public.submit_verified_deposit(text,numeric,text,bigint,integer)'::regprocedure);
  v_def2 := pg_get_functiondef('public.request_deposit(numeric,text,text,text)'::regprocedure);

  return jsonb_build_object(
    'setting', jsonb_build_object(
      'key', 'min_deposit',
      'raw_value', v_raw,
      'raw_text', v_text,
      'numeric_cast', v_num,
      'is_public', (select is_public from public.settings where key = 'min_deposit'),
      'deposit_minimum()', public.deposit_minimum()
    ),
    'setting_num_check', public.setting_num('min_deposit', 5),
    'deployed_functions', jsonb_build_object(
      'submit_verified_deposit', jsonb_build_object(
        'definition_md5', md5(v_def1),
        'minimum_line', (select string_agg(line, ' | ') from regexp_split_to_table(v_def1, E'\n') line
                          where line ilike '%min_deposit%' or line ilike '%BELOW_MIN_DEPOSIT%'),
        'has_number_in_error', position('telegram_money' in v_def1) > 0
      ),
      'request_deposit', jsonb_build_object(
        'definition_md5', md5(v_def2),
        'minimum_line', (select string_agg(line, ' | ') from regexp_split_to_table(v_def2, E'\n') line
                          where line ilike '%min_deposit%' or line ilike '%BELOW_MIN_DEPOSIT%'),
        'has_number_in_error', position('telegram_money' in v_def2) > 0
      )
    ),
    'last_attempts', (select coalesce(jsonb_agg(jsonb_build_object(
                        'source', a.source, 'amount_received', a.amount_received,
                        'minimum', a.minimum, 'raw_setting', a.raw_setting,
                        'reason', a.reason, 'at', a.created_at)
                        order by a.created_at desc), '[]'::jsonb)
                      from (select * from public.deposit_attempts order by created_at desc limit 10) a),
    'recent_deposits', (select coalesce(jsonb_agg(jsonb_build_object(
                          'amount', d.amount, 'status', d.status,
                          'method', d.method, 'created_at', d.created_at)
                          order by d.created_at desc), '[]'::jsonb)
                        from (select * from public.deposits order by created_at desc limit 10) d)
  );
end $$;

revoke all on function public.admin_deposit_diag() from public, anon;
grant execute on function public.admin_deposit_diag() to authenticated;

notify pgrst, 'reload schema';

commit;
