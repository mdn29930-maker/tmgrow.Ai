-- ============================================================================
-- TM GROW — MASTER ADMIN CONTROL ROOM (Phase 1)
--
-- Additive only. Nothing is dropped, renamed or reset. No wallet, reward,
-- login or Telegram-sender logic is touched.
--
-- Adds:
--   1. Safety checks (read-only, raise a clear error if the core is missing)
--   2. admin_feature_status()      real status of every admin module
--   3. admin_automation_status()   scheduler + modules + verification state
--   4. admin_automation_tick()     manual run from the panel, no Edge Function
--   5. automation_scheduled_tick() pg_cron entry point (run as the OWNER)
--   6. admin_automation_module_set() ON/OFF per automation module + audit
--   7. pg_cron schedules (guarded: only when pg_cron is installed)
--   8. Grants + PostgREST reload
--
-- Requires: schema.sql (automation_jobs/runs, automation_execute, audit),
--           advanced-management.sql (login_events) for some modules,
--           automation-engine.sql for automation_modules / verification_queue.
-- Optional: telegram-db-sender.sql (pg_net sender) — status is reported.
--
-- Safe to re-run.
-- ============================================================================

begin;

-- ============================================================================
-- 1. SAFETY CHECKS — fail loudly instead of creating half a control room
-- ============================================================================
do $$
declare
  v_missing text[] := '{}';
  t text;
  f text;
  req_tables text[] := array[
    'profiles', 'wallets', 'services', 'campaigns', 'tasks', 'submissions',
    'deposits', 'withdrawals', 'ledger_entries', 'platform_ledger',
    'settings', 'audit_logs', 'fraud_flags', 'notifications',
    'automation_jobs', 'automation_runs', 'telegram_outbox'
  ];
  req_functions text[] := array[
    'has_admin_role', 'is_admin', 'audit', 'admin_overview',
    'admin_list_users', 'admin_system_status', 'automation_execute'
  ];
begin
  foreach t in array req_tables loop
    if to_regclass('public.' || t) is null then
      v_missing := v_missing || ('table public.' || t);
    end if;
  end loop;

  foreach f in array req_functions loop
    if to_regprocedure('public.' || f || '()') is null
       and not exists (
         select 1 from pg_proc p
           join pg_namespace n on n.oid = p.pronamespace
          where n.nspname = 'public' and p.proname = f
       ) then
      v_missing := v_missing || ('function public.' || f);
    end if;
  end loop;

  if array_length(v_missing, 1) > 0 then
    raise exception 'TM GROW control room stopped. Missing: %. Run supabase/schema.sql in the SQL editor first, then re-run this file.',
      array_to_string(v_missing, ', ');
  end if;

  raise notice 'TM GROW control room: core objects present (pg_net=%, pg_cron=%, vault=%).',
    to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null,
    to_regclass('cron.job') is not null,
    to_regclass('vault.secrets') is not null;
end $$;

-- The same facts as a readable result (kept as a view-free SELECT report).
do $$
declare
  v_set boolean := false;
begin
  if to_regclass('vault.secrets') is not null then
    execute 'select exists (select 1 from vault.secrets where name = $1)'
      into v_set using 'telegram_bot_token';
  end if;

  raise notice 'Extensions: pg_net=%, pg_cron=%, vault=%, telegram_bot_token_in_vault=%.',
    to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null,
    to_regclass('cron.job') is not null,
    to_regclass('vault.secrets') is not null,
    v_set;
end $$;


-- ============================================================================
-- 2. FEATURE STATUS — one real answer per module, computed from the database
--    status: active | needs_config | disabled | error | coming_soon
-- ============================================================================
create or replace function public.admin_feature_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_modules   jsonb;
  v_pg_net    boolean := to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
                         or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;
  v_pg_cron   boolean := to_regclass('cron.job') is not null;
  v_vault     boolean := to_regclass('vault.secrets') is not null;
  v_secret    boolean := false;
  v_cron_job  text;
  v_tg_trigger boolean;
  v_auto_on   boolean := public.setting_bool('automation_enabled', false);
  v_auto_job  boolean := to_regclass('public.automation_jobs') is not null;
  v_tg_queue  boolean := to_regclass('public.telegram_outbox') is not null;
  v_auto_mod  boolean := to_regclass('public.automation_modules') is not null;
  v_verif     boolean := to_regprocedure('public.verification_list(text, int)') is not null;
  v_auto_stat text;
  v_auto_missing jsonb := '[]'::jsonb;
  v_tg_stat   text;
  v_tg_missing jsonb := '[]'::jsonb;
begin
  if not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  if v_vault then
    execute 'select exists (select 1 from vault.secrets where name = $1)'
      into v_secret using 'telegram_bot_token';
  end if;

  if v_pg_cron then
    begin
      execute 'select schedule from cron.job where jobname = $1'
        into v_cron_job using 'tmgrow-automation-sweep';
    exception when others then
      v_cron_job := null;
    end;
  end if;

  v_tg_trigger := exists (
    select 1 from pg_trigger
     where tgname = 'telegram_outbox_dispatch'
       and tgrelid = to_regclass('public.telegram_outbox')
  );

  /* Base modules: a function that does not exist is an error, a table that is
     missing means the module needs its migration. Planned modules are explicit. */
  with src(key, label, grp, grp_ord, fn, tbl, entry, detail) as (
    values
      ('overview',      'Master dashboard',      'Overview',      1, 'admin_overview',                'profiles',      false, 'Live totals, finance and a daily series from admin_overview().'),
      ('system',        'Platform health',       'Overview',      1, 'admin_system_status',           'settings',      false, 'Tables, role, database size and schema health.'),
      ('ai',            'AI assistant',          'Overview',      1, 'admin_ai_snapshot',             null,            false, null),
      ('users',         'All users',             'Users',         2, 'admin_list_users',              'profiles',      false, 'Search, filters and account state.'),
      ('workers',       'Workers',               'Users',         2, 'admin_list_users',              'profiles',      false, 'Worker accounts, earnings and approved work.'),
      ('buyers',        'Buyers',                'Users',         2, 'admin_list_users',              'campaigns',     false, 'Buyer wallets, campaigns and account state.'),
      ('suspended',     'Suspended & banned',    'Users',         2, 'admin_suspended_users',         'profiles',      false, 'Suspensions, restrictions and restores.'),
      ('user_activity', 'User activity',         'Users',         2, 'admin_user_activity',           'profiles',      false, 'One timeline of registration, logins, tasks, proofs, deposits, withdrawals, referrals and audit rows.'),
      ('risk_history',  'Risk history',          'Users',         2, 'admin_risk_profile',            'fraud_flags',   false, 'Recorded signals with a rule-based score. Never an automatic ban.'),
      ('tasks',         'Task management',       'Earning',       3, 'admin_list_tasks',              'tasks',         false, 'Task states, claims and reviews.'),
      ('proofs',        'Verification center',   'Earning',       3, 'admin_list_submissions',        'submissions',   false, 'Proof queue with screenshots and links.'),
      ('social',        'Task accounts',         'Earning',       3, 'admin_list_social_accounts',    'linked_accounts', false, 'Linked social accounts and verification.'),
      ('rewards',       'Rewards & bonuses',     'Earning',       3, 'admin_get_settings',            'settings',      false, 'Coin, commissions and fees.'),
      ('create_task',   'Create task',           'Earning',       3, null,                            null,            true,  'Planned for Phase 3 (platform-funded tasks).'),
      ('task_categories','Task categories',      'Earning',       3, null,                            null,            true,  'Planned for Phase 3.'),
      ('wallets',       'Wallet management',     'Financial',     4, 'admin_wallet_overview',         'wallets',       false, 'Balances and frozen wallets.'),
      ('ledger',        'Transaction ledger',    'Financial',     4, 'admin_list_ledger',             'ledger_entries', false, 'Immutable ledger entries.'),
      ('deposits',      'Deposits',              'Financial',     4, 'admin_list_deposits',           'deposits',      false, 'On-chain deposits and review.'),
      ('withdrawals',   'Withdrawals',           'Financial',     4, 'admin_list_withdrawals',        'withdrawals',   false, 'Payout approval and settlement.'),
      ('flags',         'Fraud & abuse',         'Financial',     4, 'admin_list_flags',              'fraud_flags',   false, 'Recorded risk flags, never automatic bans.'),
      ('financial_reports','Financial reports',  'Financial',     4, null,                            null,            true,  'Planned for Phase 5.'),
      ('services',      'Services & pricing',    'SMM panel',     5, 'admin_list_services',           'services',      false, 'Catalogue, limits and pricing.'),
      ('campaigns',     'Orders & campaigns',    'SMM panel',     5, 'admin_list_campaigns',          'campaigns',     false, 'Buyer orders and escrow.'),
      ('order_status',  'Order status',          'SMM panel',     5, null,                            null,            true,  'Planned for Phase 4.'),
      ('profit_management','Profit management',  'SMM panel',     5, null,                            null,            true,  'Planned for Phase 5 (needs a recorded service cost).'),
      ('announcements', 'Announcements',         'Automation',    6, 'admin_broadcast',               'notifications', false, 'In-app broadcast to a chosen audience.'),
      ('verification_queue','Verification queue','Automation',    6, 'admin_verification_queue',     'verification_queue', false, 'Deterministic sweep plus human review, retry and dead letters.'),
      ('failed_jobs',   'Failed jobs & logs',    'Automation',    6, null,                            null,            true,  'Planned for Phase 6.'),
      ('admins',        'Admin roles',           'Security',      7, 'admin_list_admins',             'profiles',      false, 'Roles and server-side permissions.'),
      ('audit',         'Audit log',             'Security',      7, 'admin_list_audit',              'audit_logs',    false, 'Who changed what.'),
      ('support',       'Support inbox',         'Security',      7, 'admin_list_tickets',            'support_tickets', false, 'Ticket conversations.'),
      ('login_history', 'Login history',         'Security',      7, 'admin_login_history',           'login_events',  false, 'Recorded sessions: platform and user agent, as far as the app can observe.'),
      ('settings',      'Website settings',      'Configuration', 8, 'admin_get_settings',            'settings',      false, 'Fees, limits and public copy.'),
      ('countries',     'Countries',             'Configuration', 8, 'admin_list_countries',          'countries',     false, 'Market availability.'),
      ('referrals',     'Referrals',             'Configuration', 8, 'admin_list_referrals',          'referrals',     false, 'Invite links, commissions and history.'),
      ('leaderboard',   'Rankings',              'Configuration', 8, 'leaderboard_weekly',            'wallets',       false, 'Weekly earners and rank ladder.')
  )
  select coalesce(jsonb_agg(jsonb_build_object(
           'key', key,
           'label', label,
           'group', grp,
           'status', case
                       when entry then 'coming_soon'
                       when fn is not null and not exists (
                         select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                          where n.nspname = 'public' and p.proname = fn) then 'error'
                       when tbl is not null and to_regclass('public.' || tbl) is null then 'needs_config'
                       else 'active'
                     end,
           'detail', coalesce(detail, ''),
           'missing', case
                        when entry then '[]'::jsonb
                        when fn is not null and not exists (
                          select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                           where n.nspname = 'public' and p.proname = fn)
                          then jsonb_build_array('function public.' || fn || '()')
                        when tbl is not null and to_regclass('public.' || tbl) is null
                          then jsonb_build_array('table public.' || tbl)
                        else '[]'::jsonb
                      end
         ) order by grp_ord, label), '[]'::jsonb)
    into v_modules
    from src;

  /* Automation: real scheduler state, not a hardcoded "Active". */
  if not v_auto_job then
    v_auto_stat := 'needs_config';
    v_auto_missing := v_auto_missing || to_jsonb('table public.automation_jobs'::text);
  elsif not v_pg_cron then
    v_auto_stat := 'needs_config';
    v_auto_missing := v_auto_missing || to_jsonb('extension pg_cron'::text);
  elsif v_cron_job is null then
    v_auto_stat := 'needs_config';
    v_auto_missing := v_auto_missing || to_jsonb('cron job tmgrow-automation-sweep'::text);
  elsif not v_auto_on then
    v_auto_stat := 'disabled';
  else
    v_auto_stat := 'active';
  end if;

  /* Telegram: database sender state. */
  if not v_pg_net then
    v_tg_stat := 'needs_config';
    v_tg_missing := v_tg_missing || to_jsonb('extension pg_net'::text);
  elsif not v_secret then
    v_tg_stat := 'needs_config';
    v_tg_missing := v_tg_missing || to_jsonb('vault secret telegram_bot_token'::text);
  elsif not v_tg_trigger then
    v_tg_stat := 'needs_config';
    v_tg_missing := v_tg_missing || to_jsonb('trigger telegram_outbox_dispatch'::text);
  elsif not public.setting_bool('telegram_bot_enabled', false) then
    v_tg_stat := 'disabled';
  else
    v_tg_stat := 'active';
  end if;

  v_modules := v_modules || jsonb_build_array(
    jsonb_build_object(
      'key', 'automation', 'label', 'Automation control', 'group', 'Automation',
      'status', v_auto_stat,
      'detail', case v_auto_stat
                  when 'active' then 'pg_cron runs automation_execute() on a schedule.'
                  when 'disabled' then 'Scheduled execution is off; manual runs still work.'
                  else 'Enable pg_cron and run the schedule section of supabase/admin-control-room.sql.'
                end,
      'missing', v_auto_missing
    ),
    jsonb_build_object(
      'key', 'telegram', 'label', 'Telegram & task alerts', 'group', 'Automation',
      'status', v_tg_stat,
      'detail', case v_tg_stat
                  when 'active' then 'Database sender: pg_net + Vault, no Edge Function.'
                  when 'disabled' then 'Bot delivery is switched off in the panel.'
                  else 'Run supabase/telegram-db-sender.sql after enabling pg_net.'
                end,
      'missing', v_tg_missing
    ),
    jsonb_build_object(
      'key', 'ai', 'label', 'AI assistant', 'group', 'Overview',
      'status', 'needs_config',
      'detail', 'Rule-based Auto Manager only. No AI provider is configured, so no AI analysis is claimed.',
      'missing', jsonb_build_array('AI provider key in Vault (optional)')
    ),
    jsonb_build_object(
      'key', 'verification_engine', 'label', 'Verification engine', 'group', 'Automation',
      'status', case when v_verif then 'active' else 'needs_config' end,
      'detail', case when v_verif then 'Queue, decide and dead-letter RPCs exist.' else 'Run supabase/automation-engine.sql.' end,
      'missing', case when v_verif then '[]'::jsonb else jsonb_build_array('function public.verification_list(text, int)') end
    )
  );

  return jsonb_build_object(
    'checked_at', now(),
    'extensions', jsonb_build_object(
      'pg_net', v_pg_net,
      'pg_cron', v_pg_cron,
      'vault', v_vault,
      'telegram_bot_token', v_secret
    ),
    'counts', jsonb_build_object(
      'modules', jsonb_array_length(v_modules),
      'active', (select count(*) from jsonb_array_elements(v_modules) e where e->>'status' = 'active'),
      'needs_config', (select count(*) from jsonb_array_elements(v_modules) e where e->>'status' = 'needs_config'),
      'disabled', (select count(*) from jsonb_array_elements(v_modules) e where e->>'status' = 'disabled'),
      'error', (select count(*) from jsonb_array_elements(v_modules) e where e->>'status' = 'error'),
      'coming_soon', (select count(*) from jsonb_array_elements(v_modules) e where e->>'status' = 'coming_soon')
    ),
    'modules', v_modules
  );
end $$;

revoke all on function public.admin_feature_status() from public, anon;
grant execute on function public.admin_feature_status() to authenticated;


-- ============================================================================
-- 3. AUTOMATION STATUS — what the control room reads
-- ============================================================================
create or replace function public.admin_automation_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_cron   text;
  v_mods   jsonb := '[]'::jsonb;
  v_engine jsonb := null;
  v_verif  jsonb := null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if to_regclass('cron.job') is not null then
    begin
      execute 'select schedule from cron.job where jobname = $1'
        into v_cron using 'tmgrow-automation-sweep';
    exception when others then
      v_cron := null;
    end;
  end if;

  if to_regclass('public.automation_modules') is not null then
    select coalesce(jsonb_agg(jsonb_build_object(
             'key', key, 'name', name, 'description', description,
             'enabled', enabled, 'critical', critical,
             'last_run_at', last_run_at, 'config', config
           ) order by critical desc, name), '[]'::jsonb)
      into v_mods
      from public.automation_modules;
  end if;

  if to_regprocedure('public.automation_engine_status()') is not null then
    begin
      v_engine := public.automation_engine_status();
    exception when others then
      v_engine := jsonb_build_object('error', sqlerrm);
    end;
  end if;

  if to_regprocedure('public.verification_list(text, int)') is not null then
    begin
      v_verif := public.verification_list(null, 5);
    exception when others then
      v_verif := jsonb_build_object('items', '[]'::jsonb, 'error', sqlerrm);
    end;
  end if;

  return public.automation_overview() || jsonb_build_object(
    'cron_installed', to_regclass('cron.job') is not null,
    'cron_schedule', v_cron,
    'modules', v_mods,
    'engine', v_engine,
    'verification', coalesce(v_verif, '{}'::jsonb),
    'tick_rpc', true
  );
end $$;

revoke all on function public.admin_automation_status() from public, anon;
grant execute on function public.admin_automation_status() to authenticated;


-- ============================================================================
-- 4. MANUAL RUN — the panel's replacement for the automation-tick function
-- ============================================================================
create or replace function public.admin_automation_tick(p_job text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_job text := nullif(btrim(coalesce(p_job, '')), '');
  v_res jsonb;
  v_tg  jsonb := null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if v_job is null then
    v_res := public.automation_execute(null, 'manual');
    if to_regprocedure('public.telegram_tick()') is not null then
      begin
        v_tg := public.telegram_tick();
      exception when others then
        v_tg := jsonb_build_object('ok', false, 'error', sqlerrm);
      end;
    end if;
  else
    v_res := public.automation_execute(v_job, 'manual');
  end if;

  perform public.audit('automation.tick', 'automation_job', null,
    jsonb_build_object('job', v_job, 'result', v_res, 'telegram', v_tg));

  return coalesce(v_res, '{}'::jsonb)
    || jsonb_build_object('ran_at', now(), 'telegram', v_tg);
end $$;

revoke all on function public.admin_automation_tick(text) from public, anon;
grant execute on function public.admin_automation_tick(text) to authenticated;


-- ============================================================================
-- 5. pg_cron ENTRY POINT
-- automation_execute() refuses a caller without an admin JWT, and a cron job
-- has none. This wrapper runs the existing function with the oldest active
-- OWNER identity (the same technique automation-engine.sql uses for
-- automation_review_submission) and logs nothing secret.
-- ============================================================================
create or replace function public.automation_scheduled_tick()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_owner uuid;
  v_res   jsonb;
begin
  select id into v_owner
    from public.profiles
   where admin_role in ('OWNER', 'SUPER_ADMIN')
     and status = 'active'
   order by case when admin_role = 'OWNER' then 0 else 1 end, created_at
   limit 1;

  if v_owner is null then
    return jsonb_build_object('ok', false, 'reason', 'NO_ACTIVE_OWNER');
  end if;

  perform set_config(
    'request.jwt.claims',
    json_build_object('sub', v_owner::text, 'role', 'authenticated')::text,
    true
  );

  v_res := public.automation_execute(null, 'cron');

  if to_regprocedure('public.telegram_tick()') is not null then
    begin
      perform public.telegram_tick();
    exception when others then
      v_res := v_res || jsonb_build_object('telegram_error', sqlerrm);
    end;
  end if;

  return v_res;
end $$;

revoke all on function public.automation_scheduled_tick() from public, anon, authenticated;


-- ============================================================================
-- 6. PER-MODULE ON/OFF (audited, server-checked)
-- ============================================================================
create or replace function public.admin_automation_module_set(p_key text, p_enabled boolean)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if to_regclass('public.automation_modules') is null then
    raise exception 'AUTOMATION_ENGINE_NOT_INSTALLED';
  end if;

  update public.automation_modules
     set enabled = coalesce(p_enabled, false),
         updated_at = now()
   where key = p_key;
  if not found then
    raise exception 'MODULE_NOT_FOUND';
  end if;

  perform public.audit('automation.module', 'automation_module', null,
    jsonb_build_object('key', p_key, 'enabled', p_enabled));

  return jsonb_build_object('ok', true, 'key', p_key, 'enabled', coalesce(p_enabled, false));
end $$;

revoke all on function public.admin_automation_module_set(text, boolean) from public, anon;
grant execute on function public.admin_automation_module_set(text, boolean) to authenticated;


-- ============================================================================
-- 7. SCHEDULE (guarded: no assumption that pg_cron is installed)
-- ============================================================================
do $$
begin
  if to_regclass('cron.job') is null then
    raise notice 'pg_cron is NOT installed: no scheduled automation. Enable it in Supabase → Database → Extensions, then run this file again. Manual runs from Admin → Automation still work.';
  else
    perform cron.schedule(
      'tmgrow-automation-sweep',
      '*/5 * * * *',
      $cron$select public.automation_scheduled_tick();$cron$
    );

    if to_regprocedure('public.telegram_tick()') is not null then
      perform cron.schedule(
        'tmgrow-telegram-tick',
        '* * * * *',
        $cron$select public.telegram_tick();$cron$
      );
    end if;

    raise notice 'pg_cron schedules installed: tmgrow-automation-sweep (5 min)%',
      case when to_regprocedure('public.telegram_tick()') is not null
           then ', tmgrow-telegram-tick (1 min)' else '' end;
  end if;
end $$;


-- ============================================================================
-- 8. FINISH
-- ============================================================================
notify pgrst, 'reload schema';

commit;
