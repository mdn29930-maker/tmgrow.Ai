-- ============================================================================
-- TM GROW — Supabase schema, RLS, ledger and server-side workflows
-- Target project: https://uqynletitbcksggunubs.supabase.co
--
-- Run this once in the Supabase SQL editor (Dashboard -> SQL Editor).
-- It is written to be safe on an existing project:
--   * profiles is EXTENDED, never recreated, so existing users survive
--   * wallets / tasks / campaigns are renamed to *_legacy only if their
--     shape is incompatible (they are empty today); no data is deleted
--   * every object is created with IF NOT EXISTS / CREATE OR REPLACE
--
-- It does NOT create an auth trigger (a previous build may already own one).
-- Profiles and wallets are created lazily by server functions instead.
-- ============================================================================

create extension if not exists pgcrypto;

-- ----------------------------------------------------------------------------
-- 1. PROFILES (existing table, extended in place)
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  role text default 'worker',
  telegram_id bigint,
  is_suspended boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists country_code text;
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists is_worker boolean not null default true;
alter table public.profiles add column if not exists is_buyer boolean not null default false;
alter table public.profiles add column if not exists admin_role text;
alter table public.profiles add column if not exists status text not null default 'active';
alter table public.profiles add column if not exists trust_score int not null default 100;
alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by uuid references public.profiles (id) on delete set null;
alter table public.profiles add column if not exists referral_rate numeric(5, 2) not null default 10;
alter table public.profiles add column if not exists prefs jsonb not null default '{}'::jsonb;
alter table public.profiles add column if not exists updated_at timestamptz not null default now();

-- tolerant constraints (added only when missing)
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_admin_role_chk') then
    alter table public.profiles add constraint profiles_admin_role_chk
      check (admin_role is null or admin_role in
        ('OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER','SUPPORT','FINANCE'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'profiles_status_chk') then
    alter table public.profiles add constraint profiles_status_chk
      check (status in ('active','suspended','banned'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'profiles_trust_chk') then
    alter table public.profiles add constraint profiles_trust_chk
      check (trust_score between 0 and 100);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'profiles_rate_chk') then
    alter table public.profiles add constraint profiles_rate_chk
      check (referral_rate >= 0 and referral_rate <= 20);
  end if;
end $$;

update public.profiles set status = 'suspended'
 where is_suspended is true and status = 'active';

update public.profiles
   set referral_code = 'TM' || upper(substr(replace(id::text, '-', ''), 1, 8))
 where referral_code is null;

create unique index if not exists profiles_referral_code_key
  on public.profiles (referral_code) where referral_code is not null;

create unique index if not exists profiles_telegram_id_key
  on public.profiles (telegram_id) where telegram_id is not null;

-- ----------------------------------------------------------------------------
-- 2. Legacy table protection (rename only incompatible, empty leftovers)
-- ----------------------------------------------------------------------------
do $$
declare
  t text;
  req text[];
begin
  foreach t in array array['wallets','tasks','campaigns','services']
  loop
    if exists (select 1 from information_schema.tables
                where table_schema = 'public' and table_name = t) then
      if t = 'wallets' then
        req := array['user_id','available','pending','reserved','lifetime_earned',
                     'lifetime_withdrawn','lifetime_deposited','updated_at'];
      elsif t = 'tasks' then
        req := array['campaign_id','worker_id','status','reward','claimed_at','expires_at',
                     'submitted_at','reviewed_at'];
      elsif t = 'campaigns' then
        req := array['buyer_id','service_id','title','instructions','target_url',
                     'quantity','reward_per_task','total_budget','fee_amount',
                     'reserved_remaining','approved_count','status','countries'];
      else
        req := array['platform','name','default_reward','min_reward','min_quantity',
                     'max_quantity','active','sort_order'];
      end if;

      if exists (
        select 1 from unnest(req) c
         where not exists (
           select 1 from information_schema.columns col
            where col.table_schema = 'public'
              and col.table_name = t
              and col.column_name = c
         )
      ) then
        if exists (select 1 from information_schema.tables
                    where table_schema = 'public' and table_name = t || '_legacy') then
          raise exception 'TM GROW migration stopped: public.% and public.%_legacy both exist. Rename one manually, then re-run.', t, t;
        end if;
        execute format('alter table public.%I rename to %I', t, t || '_legacy');
        raise notice 'TM GROW: public.% had an incompatible shape and was preserved as public.%_legacy', t, t;
      end if;
    end if;
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- 3. WALLETS
-- ----------------------------------------------------------------------------
create table if not exists public.wallets (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  available numeric(18, 6) not null default 0 check (available >= 0),
  pending numeric(18, 6) not null default 0 check (pending >= 0),
  reserved numeric(18, 6) not null default 0 check (reserved >= 0),
  lifetime_earned numeric(18, 6) not null default 0,
  lifetime_withdrawn numeric(18, 6) not null default 0,
  lifetime_deposited numeric(18, 6) not null default 0,
  tg_balance numeric(18, 6) not null default 0 check (tg_balance >= 0),
  lifetime_tg numeric(18, 6) not null default 0,
  updated_at timestamptz not null default now()
);

-- add the TG Coin columns when the wallet table already existed
alter table public.wallets add column if not exists tg_balance numeric(18, 6) not null default 0;
alter table public.wallets add column if not exists lifetime_tg numeric(18, 6) not null default 0;
alter table public.wallets add column if not exists lifetime_withdrawn numeric(18, 6) not null default 0;
alter table public.wallets add column if not exists lifetime_deposited numeric(18, 6) not null default 0;
alter table public.wallets add column if not exists updated_at timestamptz not null default now();

-- ----------------------------------------------------------------------------
-- 4. SERVICES (buyer catalogue)
-- ----------------------------------------------------------------------------
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  name text not null,
  description text,
  default_reward numeric(18, 6) not null check (default_reward > 0),
  min_reward numeric(18, 6) not null check (min_reward > 0),
  min_quantity int not null default 10 check (min_quantity > 0),
  max_quantity int not null default 10000 check (max_quantity >= min_quantity),
  active boolean not null default true,
  sort_order int not null default 100,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint services_platform_name_key unique (platform, name)
);

-- ----------------------------------------------------------------------------
-- 5. CAMPAIGNS
-- ----------------------------------------------------------------------------
create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles (id) on delete cascade,
  service_id uuid not null references public.services (id),
  title text not null check (char_length(title) between 3 and 120),
  instructions text not null check (char_length(instructions) between 10 and 4000),
  target_url text not null check (target_url ~* '^https?://'),
  quantity int not null check (quantity between 1 and 20000),
  reward_per_task numeric(18, 6) not null check (reward_per_task > 0),
  total_budget numeric(18, 6) not null,
  fee_amount numeric(18, 6) not null default 0,
  reserved_remaining numeric(18, 6) not null default 0 check (reserved_remaining >= 0),
  approved_count int not null default 0,
  rejected_count int not null default 0,
  status text not null default 'active'
    check (status in ('pending','active','paused','completed','cancelled','rejected')),
  countries text[] not null default '{}',
  min_trust_score int not null default 0 check (min_trust_score between 0 and 100),
  require_linked_account boolean not null default false,
  review_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);

alter table public.campaigns add column if not exists require_linked_account boolean not null default false;

create index if not exists campaigns_buyer_idx on public.campaigns (buyer_id, created_at desc);
create index if not exists campaigns_status_idx on public.campaigns (status);

-- ----------------------------------------------------------------------------
-- 6. TASKS
-- ----------------------------------------------------------------------------
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns (id) on delete cascade,
  worker_id uuid references public.profiles (id) on delete set null,
  status text not null default 'available'
    check (status in ('available','claimed','submitted','approved','rejected','expired','cancelled')),
  reward numeric(18, 6) not null check (reward > 0),
  claimed_at timestamptz,
  expires_at timestamptz,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists tasks_status_idx on public.tasks (status, created_at desc);
create index if not exists tasks_campaign_idx on public.tasks (campaign_id, status);
create index if not exists tasks_worker_idx on public.tasks (worker_id, status, created_at desc);

do $$
begin
  if not exists (select 1 from pg_indexes where indexname = 'tasks_one_per_campaign_worker') then
    create unique index tasks_one_per_campaign_worker
      on public.tasks (campaign_id, worker_id)
      where worker_id is not null
        and status in ('claimed','submitted','approved','rejected');
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- 7. SUBMISSIONS (proofs)
-- ----------------------------------------------------------------------------
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null unique references public.tasks (id) on delete cascade,
  worker_id uuid not null references public.profiles (id) on delete cascade,
  note text,
  proof_path text not null,
  proof_paths text[],
  proof_link text,
  time_spent_seconds int,
  proof_hash text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewer_id uuid references public.profiles (id),
  review_note text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

/* Databases created by an earlier version keep their rows: add the new
   multi-screenshot and proof-link columns in place. */
alter table public.submissions add column if not exists proof_paths text[];
alter table public.submissions add column if not exists proof_link text;
alter table public.submissions add column if not exists time_spent_seconds int;

create index if not exists submissions_status_idx on public.submissions (status, created_at);
create index if not exists submissions_worker_idx on public.submissions (worker_id, created_at desc);
create index if not exists submissions_hash_idx on public.submissions (proof_hash);

-- ----------------------------------------------------------------------------
-- 8. LEDGER (immutable)
-- ----------------------------------------------------------------------------
create table if not exists public.ledger_entries (
  id bigserial primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null,
  available_delta numeric(18, 6) not null default 0,
  pending_delta numeric(18, 6) not null default 0,
  reserved_delta numeric(18, 6) not null default 0,
  available_after numeric(18, 6) not null,
  pending_after numeric(18, 6) not null,
  reserved_after numeric(18, 6) not null,
  ref_type text,
  ref_id uuid,
  note text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create index if not exists ledger_user_idx on public.ledger_entries (user_id, created_at desc);
create index if not exists ledger_kind_idx on public.ledger_entries (kind, created_at desc);

create table if not exists public.platform_ledger (
  id bigserial primary key,
  kind text not null,
  amount numeric(18, 6) not null,
  ref_type text,
  ref_id uuid,
  note text,
  created_by uuid,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- 9. DEPOSITS / WITHDRAWALS
-- ----------------------------------------------------------------------------
create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  amount numeric(18, 6) not null check (amount > 0),
  method text not null default 'USDT_BEP20' check (method in ('USDT_BEP20','BINANCE_PAY')),
  tx_hash text,
  proof_path text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text,
  reviewed_by uuid references public.profiles (id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  verified_at timestamptz,
  confirmations int,
  from_address text,
  block_number bigint
);

alter table public.deposits add column if not exists verified_at timestamptz;
alter table public.deposits add column if not exists confirmations int;
alter table public.deposits add column if not exists from_address text;
alter table public.deposits add column if not exists block_number bigint;

create index if not exists deposits_status_idx on public.deposits (status, created_at);
create index if not exists deposits_user_idx on public.deposits (user_id, created_at desc);
create unique index if not exists deposits_tx_hash_key
  on public.deposits (lower(tx_hash)) where tx_hash is not null;

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  amount numeric(18, 6) not null check (amount > 0),
  fee numeric(18, 6) not null default 0 check (fee >= 0),
  net_amount numeric(18, 6) not null default 0 check (net_amount >= 0),
  network text not null default 'BEP20',
  address text not null,
  status text not null default 'pending'
    check (status in ('pending','approved','processing','paid','rejected')),
  tx_hash text,
  admin_note text,
  processed_by uuid references public.profiles (id),
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.withdrawals add column if not exists fee numeric(18, 6) not null default 0;
alter table public.withdrawals add column if not exists net_amount numeric(18, 6) not null default 0;

create index if not exists withdrawals_status_idx on public.withdrawals (status, created_at);
create index if not exists withdrawals_user_idx on public.withdrawals (user_id, created_at desc);

-- daily check-in: TG Coin only, one row per user per UTC day
create table if not exists public.checkins (
  user_id uuid not null references public.profiles (id) on delete cascade,
  day date not null default current_date,
  reward_tg numeric(18, 6) not null default 0,
  created_at timestamptz not null default now(),
  primary key (user_id, day)
);
alter table public.checkins enable row level security;

-- ----------------------------------------------------------------------------
-- 9b. NOTIFICATIONS / SUPPORT / REFERRALS / AUDIT / FLAGS / SETTINGS
-- ----------------------------------------------------------------------------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  body text,
  kind text not null default 'info',
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 160),
  category text not null default 'general',
  status text not null default 'open' check (status in ('open','pending','resolved','closed')),
  priority text not null default 'normal' check (priority in ('low','normal','high')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets (id) on delete cascade,
  sender_id uuid references public.profiles (id) on delete set null,
  body text not null,
  is_staff boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists ticket_messages_ticket_idx on public.ticket_messages (ticket_id, created_at);

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles (id) on delete cascade,
  referred_id uuid not null unique references public.profiles (id) on delete cascade,
  rate numeric(5, 2) not null default 10,
  created_at timestamptz not null default now()
);

-- Social accounts a worker links to their profile, used to match proof.
create table if not exists public.linked_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  platform text not null,
  handle text not null check (char_length(trim(handle)) between 2 and 80),
  profile_url text,
  status text not null default 'pending' check (status in ('pending', 'verified', 'rejected')),
  created_at timestamptz not null default now(),
  unique (user_id, platform, handle)
);

create index if not exists linked_accounts_user_idx
  on public.linked_accounts (user_id, created_at desc);

create table if not exists public.audit_logs (
  id bigserial primary key,
  actor_id uuid references public.profiles (id) on delete set null,
  actor_role text,
  action text not null,
  entity_type text,
  entity_id uuid,
  details jsonb,
  created_at timestamptz not null default now()
);

create index if not exists audit_logs_created_idx on public.audit_logs (created_at desc);

create table if not exists public.fraud_flags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles (id) on delete set null,
  kind text not null,
  severity int not null default 2 check (severity between 1 and 5),
  details jsonb,
  ref_id uuid,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  resolved_by uuid references public.profiles (id),
  resolved_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists fraud_flags_status_idx on public.fraud_flags (status, created_at desc);

create table if not exists public.settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default false,
  updated_at timestamptz not null default now(),
  updated_by uuid
);

create table if not exists public.countries (
  code text primary key check (code ~ '^[A-Z]{2}$'),
  name text not null,
  active boolean not null default true,
  allow_workers boolean not null default true,
  allow_buyers boolean not null default true
);

-- Social accounts a worker links for tasks (X, YouTube, Instagram, …).
create table if not exists public.social_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  platform text not null,
  handle text not null,
  profile_url text,
  trust_label text not null default 'Newbie',
  status text not null default 'linked' check (status in ('linked','unlinked')),
  last_synced_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint social_accounts_unique unique (user_id, platform)
);

create index if not exists social_accounts_user_idx on public.social_accounts (user_id);

-- ownership verification for linked task accounts
alter table public.social_accounts add column if not exists verification_code text;
alter table public.social_accounts add column if not exists verification_requested_at timestamptz;
alter table public.social_accounts add column if not exists linked_at timestamptz;
alter table public.social_accounts drop constraint if exists social_accounts_status_check;
alter table public.social_accounts add constraint social_accounts_status_check
  check (status in ('linked','pending','rejected','unlinked'));

-- Daily check-in streak (TG Coin bonus, no USDT is minted).
create table if not exists public.daily_checkins (
  user_id uuid not null references public.profiles (id) on delete cascade,
  day date not null,
  reward_tg numeric(18, 6) not null default 0,
  streak int not null default 1,
  created_at timestamptz not null default now(),
  primary key (user_id, day)
);

-- ----------------------------------------------------------------------------
-- 10. updated_at triggers
-- ----------------------------------------------------------------------------
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','services','campaigns','support_tickets','social_accounts']
  loop
    if not exists (
      select 1 from pg_trigger where tgname = t || '_set_updated_at'
    ) then
      execute format(
        'create trigger %I before update on public.%I for each row execute function public.tg_set_updated_at()',
        t || '_set_updated_at', t
      );
    end if;
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- 11. HELPERS
-- ----------------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
     where p.id = auth.uid()
       and p.admin_role is not null
       and p.status = 'active'
  );
$$;

create or replace function public.admin_role()
returns text language sql stable security definer set search_path = public as $$
  select p.admin_role from public.profiles p where p.id = auth.uid();
$$;

create or replace function public.has_admin_role(p_roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
     where p.id = auth.uid()
       and p.status = 'active'
       and p.admin_role = any (p_roles)
  );
$$;

create or replace function public.setting_num(p_key text, p_default numeric default 0)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce(
    (select nullif(value #>> '{}', '')::numeric from public.settings where key = p_key),
    p_default
  );
$$;

create or replace function public.setting_text(p_key text, p_default text default null)
returns text language sql stable security definer set search_path = public as $$
  select coalesce(
    (select nullif(value #>> '{}', '') from public.settings where key = p_key),
    p_default
  );
$$;

create or replace function public.setting_bool(p_key text, p_default boolean default false)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(
    (select (value #>> '{}')::boolean from public.settings where key = p_key),
    p_default
  );
$$;

create or replace function public.ensure_profile()
returns void language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  em text;
  fn text;
  av text;
  code text;
begin
  if u is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  if exists (select 1 from public.profiles where id = u) then
    -- name and photo always follow the sign-in provider (Google, etc.)
    update public.profiles p
       set avatar_url = coalesce(
             nullif(au.raw_user_meta_data ->> 'avatar_url', ''),
             nullif(au.raw_user_meta_data ->> 'picture', ''),
             p.avatar_url),
           full_name = coalesce(
             nullif(au.raw_user_meta_data ->> 'full_name', ''),
             nullif(au.raw_user_meta_data ->> 'name', ''),
             p.full_name)
      from auth.users au
     where p.id = u and au.id = u;

    insert into public.wallets (user_id) values (u) on conflict (user_id) do nothing;
    return;
  end if;

  select au.email,
         coalesce(au.raw_user_meta_data ->> 'full_name',
                  au.raw_user_meta_data ->> 'name',
                  split_part(coalesce(au.email, 'worker'), '@', 1)),
         coalesce(au.raw_user_meta_data ->> 'avatar_url',
                  au.raw_user_meta_data ->> 'picture')
    into em, fn, av
    from auth.users au
   where au.id = u;

  code := 'TM' || upper(substr(replace(u::text, '-', ''), 1, 8));

  insert into public.profiles (id, email, full_name, avatar_url, role, is_suspended, referral_code)
  values (u, em, fn, av, 'worker', false, code)
  on conflict (id) do nothing;

  insert into public.wallets (user_id) values (u) on conflict (user_id) do nothing;
end $$;

create or replace function public.notify_user(
  p_user uuid, p_title text, p_body text default null,
  p_kind text default 'info', p_link text default null
) returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, kind, link)
  values (p_user, p_title, p_body, coalesce(p_kind, 'info'), p_link);
$$;

create or replace function public.audit(
  p_action text, p_entity_type text default null,
  p_entity_id uuid default null, p_details jsonb default null
) returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_logs (actor_id, actor_role, action, entity_type, entity_id, details)
  values (auth.uid(),
          coalesce((select admin_role from public.profiles where id = auth.uid()), 'worker'),
          p_action, p_entity_type, p_entity_id, p_details);
end $$;

create or replace function public.expire_stale_tasks()
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.tasks
     set status = 'expired'
   where status = 'claimed'
     and expires_at is not null
     and expires_at < now();
  get diagnostics n = row_count;
  return n;
end $$;

-- Advanced admin columns (same as supabase/advanced-management.sql; both are
-- idempotent, so running either order is safe).
alter table public.profiles add column if not exists suspension_reason_key text;
alter table public.profiles add column if not exists suspension_evidence jsonb not null default '[]'::jsonb;
alter table public.wallets add column if not exists frozen boolean not null default false;
alter table public.wallets add column if not exists frozen_reason text;
alter table public.wallets add column if not exists frozen_at timestamptz;

-- Central, non-negative wallet mutation. One ledger row per move.
create or replace function public.wallet_move(
  p_user uuid,
  p_available numeric,
  p_pending numeric,
  p_reserved numeric,
  p_lifetime numeric,
  p_kind text,
  p_ref_type text default null,
  p_ref_id uuid default null,
  p_note text default null
) returns void language plpgsql security definer set search_path = public as $$
declare
  w public.wallets;
  v_status text;
  v_privileged boolean := (auth.role() = 'service_role' or public.is_admin());
begin
  select * into w from public.wallets where user_id = p_user for update;
  if not found then
    raise exception 'WALLET_NOT_FOUND';
  end if;

  select status into v_status from public.profiles where id = p_user;

  -- Suspended accounts and frozen wallets may receive credits (rewards,
  -- refunds, admin credits) but cannot send money out. Admins bypass the freeze.
  if not v_privileged
     and (coalesce(p_available, 0) < 0 or coalesce(p_reserved, 0) < 0) then
    if coalesce(w.frozen, false) then
      raise exception 'WALLET_FROZEN';
    end if;
    if v_status is not null and v_status <> 'active' then
      raise exception 'ACCOUNT_RESTRICTED';
    end if;
  end if;

  if w.available + coalesce(p_available, 0) < 0
     or w.pending + coalesce(p_pending, 0) < 0
     or w.reserved + coalesce(p_reserved, 0) < 0 then
    raise exception 'INSUFFICIENT_BALANCE';
  end if;

  update public.wallets
     set available = available + coalesce(p_available, 0),
         pending = pending + coalesce(p_pending, 0),
         reserved = reserved + coalesce(p_reserved, 0),
         lifetime_earned = lifetime_earned + coalesce(p_lifetime, 0),
         updated_at = now()
   where user_id = p_user
   returning * into w;

  insert into public.ledger_entries (
    user_id, kind, available_delta, pending_delta, reserved_delta,
    available_after, pending_after, reserved_after,
    ref_type, ref_id, note, created_by
  ) values (
    p_user, p_kind, coalesce(p_available, 0), coalesce(p_pending, 0), coalesce(p_reserved, 0),
    w.available, w.pending, w.reserved,
    p_ref_type, p_ref_id, p_note, auth.uid()
  );
end $$;

revoke all on function public.ensure_profile() from public, anon, authenticated;
revoke all on function public.notify_user(uuid, text, text, text, text) from public, anon, authenticated;
revoke all on function public.audit(text, text, uuid, jsonb) from public, anon, authenticated;
revoke all on function public.expire_stale_tasks() from public, anon, authenticated;
revoke all on function public.wallet_move(uuid, numeric, numeric, numeric, numeric, text, text, uuid, text) from public, anon, authenticated;

-- Telegram Mini App identities. Written only by the telegram-auth Edge
   Function (service role); RLS is on with no policies, so no browser can read
   or write this table directly.
create table if not exists public.telegram_users (
  telegram_id bigint primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  username text,
  first_name text,
  last_name text,
  photo_url text,
  language_code text,
  created_at timestamptz not null default now(),
  last_login_at timestamptz not null default now()
);

create index if not exists telegram_users_user_idx on public.telegram_users (user_id);

-- ----------------------------------------------------------------------------
-- 12. ROW LEVEL SECURITY
-- ----------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.services enable row level security;
alter table public.campaigns enable row level security;
alter table public.tasks enable row level security;
alter table public.submissions enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.platform_ledger enable row level security;
alter table public.deposits enable row level security;
alter table public.withdrawals enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.ticket_messages enable row level security;
alter table public.referrals enable row level security;
alter table public.audit_logs enable row level security;
alter table public.fraud_flags enable row level security;
alter table public.settings enable row level security;
alter table public.countries enable row level security;
alter table public.social_accounts enable row level security;
alter table public.daily_checkins enable row level security;
alter table public.telegram_users enable row level security;

-- Drop any pre-existing policies on the tables this script owns, so the file
-- can be re-run after a partial change without "policy already exists".
do $$
declare r record;
begin
  for r in select schemaname, tablename, policyname from pg_policies
            where schemaname = 'public'
              and tablename in (
                'profiles','wallets','services','campaigns','tasks','submissions',
                'ledger_entries','platform_ledger','deposits','withdrawals',
                'notifications','support_tickets','ticket_messages','referrals',
                'audit_logs','fraud_flags','settings','countries',
                'social_accounts','daily_checkins'
              )
  loop
    execute format('drop policy %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

create policy profiles_select_self_or_admin on public.profiles
  for select to authenticated using (id = auth.uid() or public.is_admin());
create policy wallets_select_self_or_admin on public.wallets
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy services_select on public.services
  for select to authenticated using (active or public.is_admin());
create policy countries_select on public.countries
  for select to authenticated using (true);
create policy campaigns_select_own_or_admin on public.campaigns
  for select to authenticated using (buyer_id = auth.uid() or public.is_admin());
create policy tasks_select_self_or_admin on public.tasks
  for select to authenticated using (worker_id = auth.uid() or public.is_admin());
create policy submissions_select_self_or_admin on public.submissions
  for select to authenticated using (worker_id = auth.uid() or public.is_admin());
create policy ledger_select_self_or_admin on public.ledger_entries
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy platform_ledger_admin on public.platform_ledger
  for select to authenticated using (public.is_admin());
create policy deposits_select_self_or_admin on public.deposits
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy withdrawals_select_self_or_admin on public.withdrawals
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy notifications_select_self_or_admin on public.notifications
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy tickets_select_self_or_admin on public.support_tickets
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy ticket_messages_select on public.ticket_messages
  for select to authenticated using (
    public.is_admin() or exists (
      select 1 from public.support_tickets t
       where t.id = ticket_messages.ticket_id and t.user_id = auth.uid()
    )
  );
create policy referrals_select_own_or_admin on public.referrals
  for select to authenticated using (referrer_id = auth.uid() or public.is_admin());
create policy audit_logs_admin on public.audit_logs
  for select to authenticated using (
    public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN'])
  );
create policy fraud_flags_admin on public.fraud_flags
  for select to authenticated using (public.is_admin());
create policy settings_read on public.settings
  for select to anon, authenticated using (is_public or public.is_admin());
create policy social_accounts_select_own_or_admin on public.social_accounts
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy daily_checkins_select_own_or_admin on public.daily_checkins
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- ----------------------------------------------------------------------------
-- 16b. AUTO-VERIFIED DEPOSITS + LINKED IDENTITIES
-- ----------------------------------------------------------------------------

-- Records a deposit that the app already verified against BNB Smart Chain
-- (USDT contract, recipient, amount, success and confirmations). The hash is
-- unique, so one transaction can only ever credit once.
create or replace function public.submit_verified_deposit(
  p_tx_hash text,
  p_amount numeric,
  p_from_address text default null,
  p_block bigint default null,
  p_confirmations int default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  v_hash text;
  v_min numeric;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;

  v_hash := lower(trim(coalesce(p_tx_hash, '')));
  if v_hash !~ '^0x[0-9a-f]{64}$' then raise exception 'INVALID_TX_HASH'; end if;

  v_min := coalesce(public.setting_num('min_deposit', 5), 5);
  if p_amount is null or p_amount < v_min then raise exception 'BELOW_MIN_DEPOSIT'; end if;

  if exists (select 1 from public.deposits where lower(tx_hash) = v_hash) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (
    user_id, amount, method, tx_hash, status,
    verified_at, confirmations, from_address, block_number, reviewed_at
  ) values (
    u, round(p_amount, 6), 'USDT_BEP20', v_hash, 'approved',
    now(), p_confirmations, lower(nullif(trim(coalesce(p_from_address, '')), '')),
    p_block, now()
  ) returning * into d;

  perform public.wallet_move(u, d.amount, 0, 0, 0, 'deposit', 'deposit', d.id,
                             'Deposit verified on BNB Smart Chain');
  update public.wallets
     set lifetime_deposited = lifetime_deposited + d.amount
   where user_id = u;

  perform public.notify_user(u, 'Deposit credited',
    d.amount || ' USDT was verified on BNB Smart Chain (BEP-20) and added to your balance.',
    'success', '#/history');
  perform public.audit('deposit.verified', 'deposit', d.id,
    jsonb_build_object('tx_hash', d.tx_hash, 'amount', d.amount,
                       'confirmations', p_confirmations,
                       'from', d.from_address, 'block', p_block));

  return jsonb_build_object('deposit', to_jsonb(d));
end $$;

create or replace function public.my_identities()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'provider', i.provider,
           'email', i.identity_data ->> 'email',
           'name', coalesce(i.identity_data ->> 'full_name',
                            i.identity_data ->> 'name',
                            i.identity_data ->> 'preferred_username'),
           'last_sign_in_at', i.last_sign_in_at,
           'created_at', i.created_at
         ) order by i.created_at), '[]'::jsonb)
    from auth.identities i
   where i.user_id = auth.uid();
$$;

create or replace function public.refresh_my_identity()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
begin
  perform public.ensure_profile();
  update public.profiles pr
     set full_name = coalesce(nullif(au.raw_user_meta_data ->> 'full_name', ''),
                              nullif(au.raw_user_meta_data ->> 'name', ''),
                              pr.full_name),
         avatar_url = coalesce(nullif(au.raw_user_meta_data ->> 'avatar_url', ''),
                               nullif(au.raw_user_meta_data ->> 'picture', ''),
                               pr.avatar_url)
    from auth.users au
   where pr.id = u and au.id = u
  returning * into p;

  return jsonb_build_object('profile', to_jsonb(p));
end $$;

-- ----------------------------------------------------------------------------
-- 13. STORAGE (private proofs bucket)
-- ----------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('proofs', 'proofs', false, 5242880,
        array['image/png','image/jpeg','image/webp','application/pdf'])
on conflict (id) do nothing;

drop policy if exists proofs_insert_own on storage.objects;
drop policy if exists proofs_select_own_or_admin on storage.objects;
drop policy if exists proofs_update_own on storage.objects;

create policy proofs_insert_own on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'proofs'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy proofs_select_own_or_admin on storage.objects
  for select to authenticated
  using (
    bucket_id = 'proofs'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );

create policy proofs_update_own on storage.objects
  for update to authenticated
  using (
    bucket_id = 'proofs'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ----------------------------------------------------------------------------
-- 14. WORKER RPCs
-- ----------------------------------------------------------------------------
create or replace function public.my_context()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  w public.wallets;
  counts jsonb;
  ref jsonb;
  buyer jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  select * into w from public.wallets where user_id = u;
  perform public.expire_stale_tasks();

  counts := jsonb_build_object(
    'available_tasks', (select count(*) from public.tasks t join public.campaigns c on c.id = t.campaign_id
                         where t.status = 'available' and c.status = 'active'),
    'my_pending_submissions', (select count(*) from public.submissions where worker_id = u and status = 'pending'),
    'my_active_claims', (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')),
    'my_approved_tasks', (select count(*) from public.tasks where worker_id = u and status = 'approved'),
    'my_rejected_tasks', (select count(*) from public.tasks where worker_id = u and status = 'rejected'),
    'unread_notifications', (select count(*) from public.notifications where user_id = u and read_at is null),
    'open_tickets', (select count(*) from public.support_tickets where user_id = u and status in ('open','pending'))
  );

  ref := jsonb_build_object(
    'code', p.referral_code,
    'count', (select count(*) from public.referrals where referrer_id = u),
    'earned', (select coalesce(sum(available_delta), 0) from public.ledger_entries
                where user_id = u and kind = 'referral_bonus'),
    'rate', p.referral_rate
  );

  buyer := jsonb_build_object(
    'active_campaigns', (select count(*) from public.campaigns where buyer_id = u and status = 'active'),
    'pending_deposits', (select count(*) from public.deposits where user_id = u and status = 'pending'),
    'open_withdrawals', (select count(*) from public.withdrawals where user_id = u and status in ('pending','approved','processing'))
  );

  return jsonb_build_object(
    'profile', to_jsonb(p),
    'wallet', to_jsonb(w),
    'counts', counts,
    'referral', ref,
    'buyer', buyer,
    'is_admin', (p.admin_role is not null and p.status = 'active')
  );
end $$;

create or replace function public.get_public_settings()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
    from public.settings where is_public;
$$;

create or replace function public.public_stats()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'workers', (select count(*) from public.profiles where is_worker and status = 'active'),
    'tasks_completed', (select count(*) from public.tasks where status = 'approved'),
    'rewards_paid', (select coalesce(sum(available_delta), 0) from public.ledger_entries where kind = 'task_reward'),
    'active_campaigns', (select count(*) from public.campaigns where status = 'active')
  );
$$;

create or replace function public.update_my_profile(
  p_full_name text default null,
  p_country_code text default null,
  p_avatar_url text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare u uuid := auth.uid(); p public.profiles;
begin
  perform public.ensure_profile();
  update public.profiles
     set full_name = coalesce(nullif(trim(p_full_name), ''), full_name),
         country_code = coalesce(nullif(upper(trim(p_country_code)), ''), country_code),
         avatar_url = coalesce(nullif(trim(p_avatar_url), ''), avatar_url)
   where id = u
   returning * into p;
  return to_jsonb(p);
end $$;

create or replace function public.enable_buyer_mode()
returns jsonb language plpgsql security definer set search_path = public as $$
declare u uuid := auth.uid(); p public.profiles;
begin
  perform public.ensure_profile();
  update public.profiles set is_buyer = true where id = u returning * into p;
  return to_jsonb(p);
end $$;

create or replace function public.apply_referral(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  me public.profiles;
  ref public.profiles;
  rate numeric;
begin
  perform public.ensure_profile();
  select * into me from public.profiles where id = u;
  if me.referred_by is not null then
    return jsonb_build_object('ok', false, 'reason', 'ALREADY_LINKED');
  end if;

  select * into ref from public.profiles
   where upper(referral_code) = upper(trim(coalesce(p_code, ''))) limit 1;
  if ref.id is null or ref.id = u then
    return jsonb_build_object('ok', false, 'reason', 'INVALID_CODE');
  end if;

  rate := least(greatest(public.setting_num('referral_commission_pct', 10), 0), 20);
  update public.profiles
     set referred_by = ref.id, referral_rate = rate
   where id = u returning * into me;

  insert into public.referrals (referrer_id, referred_id, rate)
  values (ref.id, u, rate) on conflict (referred_id) do nothing;

  perform public.notify_user(ref.id, 'New referral', 'A new worker joined with your code.', 'success', '#/referrals');
  return jsonb_build_object('ok', true, 'rate', rate);
end $$;

drop function if exists public.list_available_tasks(text, text, int, int);

create or replace function public.list_available_tasks(
  p_platform text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0,
  p_min_reward numeric default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  total int;
  items jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  perform public.expire_stale_tasks();

  select count(*) into total
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
    join public.services s on s.id = c.service_id
   where t.status = 'available'
     and c.status = 'active'
     and t.reward >= coalesce(p_min_reward, 0)
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
     and (c.countries = '{}' or p.country_code = any (c.countries))
     and c.min_trust_score <= p.trust_score;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id,
      'reward', t.reward,
      'created_at', t.created_at,
      'campaign_id', c.id,
      'title', c.title,
      'instructions_preview', left(c.instructions, 140),
      'platform', s.platform,
      'service_name', s.name,
      'quantity_left', (select count(*) from public.tasks t2 where t2.campaign_id = c.id and t2.status = 'available'),
      'target_url', c.target_url,
      'requires_account', c.require_linked_account,
      'account_linked', exists (
        select 1 from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
      ),
      'account_cooldown_until', (
        select a.linked_at + interval '7 days' from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
           and s.platform = 'x' and a.linked_at > now() - interval '7 days'
         limit 1
      ),
      'already_done', exists (
        select 1 from public.tasks t3
         where t3.campaign_id = c.id and t3.worker_id = u
           and t3.status in ('claimed','submitted','approved','rejected')
      )
    ) as x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
     where t.status = 'available'
       and c.status = 'active'
       and t.reward >= coalesce(p_min_reward, 0)
       and (p_platform is null or p_platform = '' or s.platform = p_platform)
       and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
       and (c.countries = '{}' or p.country_code = any (c.countries))
       and c.min_trust_score <= p.trust_score
     order by t.reward desc, t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 20), 50))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.get_task(p_task_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  c public.campaigns;
  s public.services;
  sub public.submissions;
  p public.profiles;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  select * into t from public.tasks where id = p_task_id;
  if t.id is null then
    raise exception 'TASK_NOT_FOUND';
  end if;
  if t.status <> 'available' and t.worker_id is distinct from u and not public.is_admin() then
    raise exception 'NOT_ALLOWED';
  end if;
  select * into c from public.campaigns where id = t.campaign_id;
  select * into s from public.services where id = c.service_id;
  select * into sub from public.submissions where task_id = t.id;

  return jsonb_build_object(
    'task', to_jsonb(t),
    'campaign', jsonb_build_object(
      'id', c.id, 'title', c.title, 'instructions', c.instructions,
      'target_url', c.target_url, 'quantity', c.quantity,
      'approved_count', c.approved_count, 'status', c.status,
      'created_at', c.created_at
    ),
    'service', jsonb_build_object('platform', s.platform, 'name', s.name),
    'submission', case when sub.id is null then null else to_jsonb(sub) end,
    'worker_trust', p.trust_score,
    'requires_account', coalesce(c.require_linked_account, false),
    'account_linked', exists (
      select 1 from public.social_accounts a
       where a.user_id = u and a.status = 'linked' and a.platform = s.platform
    ),
    'account_cooldown_until', (
      select a.linked_at + interval '7 days' from public.social_accounts a
       where a.user_id = u and a.status = 'linked' and a.platform = s.platform
         and s.platform = 'x' and a.linked_at > now() - interval '7 days'
       limit 1
    )
  );
end $$;

create or replace function public.claim_task(p_task_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  c public.campaigns;
  p public.profiles;
  mins int;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_worker then raise exception 'WORKER_MODE_DISABLED'; end if;
  perform public.expire_stale_tasks();

  if (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')) >= 25 then
    raise exception 'TOO_MANY_ACTIVE_TASKS';
  end if;

  select * into t from public.tasks where id = p_task_id;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status <> 'available' or t.worker_id is not null then raise exception 'TASK_UNAVAILABLE'; end if;

  select * into c from public.campaigns where id = t.campaign_id;
  if c.status <> 'active' then raise exception 'CAMPAIGN_NOT_ACTIVE'; end if;
  if p.trust_score < c.min_trust_score then raise exception 'TRUST_TOO_LOW'; end if;
  if c.countries <> '{}' and not (p.country_code = any (c.countries)) then
    raise exception 'NOT_ELIGIBLE_COUNTRY';
  end if;
  if c.approved_count >= c.quantity then raise exception 'CAMPAIGN_FULL'; end if;
  if c.require_linked_account and not exists (
    select 1 from public.social_accounts a
      join public.services sv on sv.platform = a.platform
     where a.user_id = u and a.status = 'linked' and sv.id = c.service_id
  ) then
    raise exception 'LINK_ACCOUNT_REQUIRED';
  end if;

  -- X/Twitter accounts need a 7-day warm-up after verification
  if exists (
    select 1 from public.social_accounts a
      join public.services sv on sv.platform = a.platform
     where a.user_id = u and a.status = 'linked' and sv.id = c.service_id
       and sv.platform = 'x'
       and a.linked_at is not null
       and a.linked_at > now() - interval '7 days'
  ) then
    raise exception 'ACCOUNT_COOLDOWN';
  end if;
  if exists (
    select 1 from public.tasks
     where campaign_id = c.id and worker_id = u
       and status in ('claimed','submitted','approved','rejected')
  ) then
    raise exception 'ALREADY_TAKEN_THIS_CAMPAIGN';
  end if;

  mins := greatest(5, least(coalesce(public.setting_num('claim_window_minutes', 30), 30), 240));

  update public.tasks
     set worker_id = u, status = 'claimed', claimed_at = now(),
         expires_at = now() + make_interval(mins => mins)
   where id = t.id and status = 'available' and worker_id is null;

  if not found then raise exception 'TASK_UNAVAILABLE'; end if;

  return public.get_task(t.id);
end $$;

create or replace function public.release_task(p_task_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
begin
  perform public.ensure_profile();
  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null or t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;

  update public.tasks
     set status = 'available', worker_id = null, claimed_at = null, expires_at = null
   where id = t.id;

  perform public.audit('task.give_up', 'task', t.id,
    jsonb_build_object('worker', u, 'campaign', t.campaign_id));
  return jsonb_build_object('ok', true);
end $$;

drop function if exists public.submit_proof(uuid, text, text, text);

create or replace function public.submit_proof(
  p_task_id uuid,
  p_proof_paths text[],
  p_proof_link text default null,
  p_note text default null,
  p_proof_hash text default null,
  p_time_spent int default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  c public.campaigns;
  sub public.submissions;
  v_hash text;
  v_link text;
  v_paths text[];
  v_count int;
begin
  perform public.ensure_profile();

  v_paths := p_proof_paths;
  v_count := coalesce(array_length(v_paths, 1), 0);
  if v_count < 1 then raise exception 'PROOF_REQUIRED'; end if;
  if v_count > 6 then raise exception 'TOO_MANY_FILES'; end if;
  if exists (
    select 1 from unnest(v_paths) as p
     where p is null or p = '' or split_part(p, '/', 1) <> u::text
  ) then
    raise exception 'INVALID_PROOF_PATH';
  end if;

  v_link := nullif(trim(coalesce(p_proof_link, '')), '');
  if v_link is not null and v_link !~* '^https?://' then
    raise exception 'INVALID_URL';
  end if;

  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null or t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status = 'expired' or (t.expires_at is not null and t.expires_at < now()) then
    update public.tasks set status = 'expired' where id = t.id and status in ('claimed');
    raise exception 'TASK_EXPIRED';
  end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;

  select * into c from public.campaigns where id = t.campaign_id for update;
  if c.status <> 'active' then raise exception 'CAMPAIGN_NOT_ACTIVE'; end if;
  if c.reserved_remaining < t.reward then raise exception 'CAMPAIGN_BUDGET_EXHAUSTED'; end if;
  if c.approved_count + (select count(*) from public.submissions su
                           join public.tasks tt on tt.id = su.task_id
                          where tt.campaign_id = c.id and su.status = 'pending') >= c.quantity then
    raise exception 'CAMPAIGN_FULL';
  end if;
  if (select count(*) from public.submissions
       where worker_id = u and created_at > now() - interval '1 hour') >= 20 then
    raise exception 'RATE_LIMIT_PROOF';
  end if;

  v_hash := nullif(lower(trim(coalesce(p_proof_hash, ''))), '');

  insert into public.submissions (
    task_id, worker_id, note, proof_path, proof_paths, proof_link,
    time_spent_seconds, proof_hash
  ) values (
    t.id, u, nullif(trim(coalesce(p_note, '')), ''), v_paths[1], v_paths, v_link,
    greatest(0, least(coalesce(p_time_spent, 0), 86400)), v_hash
  )
  returning * into sub;

  update public.tasks
     set status = 'submitted', submitted_at = now(), expires_at = null
   where id = t.id;

  perform public.wallet_move(u, 0, t.reward, 0, 0, 'task_pending', 'task', t.id,
                             'Reward moved to pending for verification');
  perform public.wallet_move(c.buyer_id, 0, 0, -t.reward, 0, 'escrow_release', 'submission', sub.id,
                             'Escrow released to worker pending on submission');
  update public.campaigns set reserved_remaining = reserved_remaining - t.reward where id = c.id;

  if v_hash is not null and exists (select 1 from public.submissions where proof_hash = v_hash and id <> sub.id) then
    insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
    values (u, 'duplicate_proof', 3, jsonb_build_object('submission', sub.id, 'hash', v_hash), sub.id);
    insert into public.notifications (user_id, title, body, kind, link)
    select id, 'Duplicate proof detected',
           'A proof was submitted that matches an existing image hash.', 'warning', '#/admin/proofs'
      from public.profiles where admin_role is not null;
  end if;

  perform public.notify_user(c.buyer_id, 'New submission',
    'A worker submitted proof for "' || c.title || '".', 'info', '#/buyer/campaigns/' || c.id);

  return jsonb_build_object('submission', to_jsonb(sub));
end $$;

create or replace function public.my_tasks(
  p_status text default null,
  p_limit int default 50,
  p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  items jsonb;
  total int;
begin
  perform public.ensure_profile();
  perform public.expire_stale_tasks();

  select count(*) into total from public.tasks t
   where t.worker_id = u
     and (p_status is null or p_status = '' or p_status = 'all' or t.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id,
      'status', t.status,
      'reward', t.reward,
      'claimed_at', t.claimed_at,
      'expires_at', t.expires_at,
      'submitted_at', t.submitted_at,
      'reviewed_at', t.reviewed_at,
      'created_at', t.created_at,
      'campaign_id', c.id,
      'title', c.title,
      'platform', s.platform,
      'service_name', s.name,
      'target_url', c.target_url,
      'submission_id', sub.id,
      'submission_status', sub.status,
      'review_note', sub.review_note
    ) as x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
      left join public.submissions sub on sub.task_id = t.id
     where t.worker_id = u
       and (p_status is null or p_status = '' or p_status = 'all' or t.status = p_status)
     order by t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 100))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

drop function if exists public.request_withdrawal(numeric, text);

create or replace function public.request_withdrawal(
  p_amount numeric,
  p_address text,
  p_network text default 'BEP20'
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  w public.wallets;
  wd public.withdrawals;
  v_min numeric;
  v_fee numeric;
  v_net numeric;
  v_fee_pct numeric;
  v_network text;
  open_count int;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;

  v_network := upper(coalesce(nullif(trim(coalesce(p_network, '')), ''), 'BEP20'));
  if v_network <> 'BEP20' then
    raise exception 'UNSUPPORTED_NETWORK';
  end if;

  if coalesce(p_address, '') !~ '^0x[a-fA-F0-9]{40}$' then
    raise exception 'INVALID_BEP20_ADDRESS';
  end if;

  if p_amount is null or p_amount <= 0 then raise exception 'INVALID_AMOUNT'; end if;

  select * into w from public.wallets where user_id = u for update;
  v_min := coalesce(public.setting_num('withdrawal_min', 2), 2);
  if p_amount < v_min then raise exception 'BELOW_MIN_WITHDRAWAL'; end if;
  if p_amount > w.available then raise exception 'INSUFFICIENT_BALANCE'; end if;

  select count(*) into open_count from public.withdrawals
   where user_id = u and status in ('pending','approved','processing');
  if open_count >= coalesce(public.setting_num('max_open_withdrawals', 3), 3) then
    raise exception 'TOO_MANY_OPEN_WITHDRAWALS';
  end if;

  v_fee_pct := greatest(0, least(coalesce(public.setting_num('withdrawal_fee_pct', 5), 5), 25));
  if round(p_amount, 6) < coalesce(public.setting_num('withdrawal_fee_free_min', 5), 5) then
    v_fee := round(round(p_amount, 6) * v_fee_pct / 100.0, 6);
  else
    v_fee := 0;
  end if;
  v_net := greatest(0, round(p_amount, 6) - v_fee);

  insert into public.withdrawals (user_id, amount, fee, net_amount, network, address)
  values (u, round(p_amount, 6), v_fee, v_net, 'BEP20', p_address)
  returning * into wd;

  perform public.wallet_move(u, -round(p_amount, 6), 0, round(p_amount, 6), 0,
                             'withdrawal_hold', 'withdrawal', wd.id,
                             'Funds held for withdrawal request');

  perform public.notify_user(u, 'Withdrawal requested',
    'Your withdrawal of ' || round(p_amount, 6) || ' USDT is queued for review. Fee '
      || v_fee || ' USDT, you receive ' || v_net || ' USDT.', 'info', '#/withdraw');

  return jsonb_build_object('withdrawal', to_jsonb(wd));
end $$;

create or replace function public.daily_checkin()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  v_today boolean;
  v_streak int := 0;
  v_days int;
  v_reward numeric;
  v_start date;
  i int;
begin
  perform public.ensure_profile();
  v_reward := coalesce(public.setting_num('checkin_tg_reward', 0.2), 0);
  v_today := exists (select 1 from public.checkins where user_id = u and day = current_date);
  select count(*) into v_days from public.checkins where user_id = u;

  v_start := case when v_today then current_date else current_date - 1 end;
  for i in 0..400 loop
    if exists (select 1 from public.checkins where user_id = u and day = v_start - i) then
      v_streak := v_streak + 1;
    else
      exit;
    end if;
  end loop;

  return jsonb_build_object(
    'claimed_today', v_today,
    'streak', v_streak,
    'total_days', v_days,
    'reward_tg', v_reward
  );
end $$;

create or replace function public.claim_daily_checkin()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  v_reward numeric;
begin
  perform public.ensure_profile();
  if exists (select 1 from public.checkins where user_id = u and day = current_date) then
    raise exception 'ALREADY_CHECKED_IN';
  end if;

  v_reward := coalesce(public.setting_num('checkin_tg_reward', 0.2), 0);
  insert into public.checkins (user_id, day, reward_tg) values (u, current_date, v_reward);

  if v_reward > 0 then
    update public.wallets
       set tg_balance = tg_balance + v_reward,
           lifetime_tg = lifetime_tg + v_reward,
           updated_at = now()
     where user_id = u;
  end if;

  perform public.notify_user(u, 'Daily check-in claimed',
    v_reward || ' TG Coin was added to your balance. Come back tomorrow to keep the streak.',
    'success', '#/dashboard');

  return public.daily_checkin();
end $$;

-- Real, already-paid withdrawals for the live activity ticker. Names are
-- masked on the server so no other worker's identity is exposed.
create or replace function public.recent_activity()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select jsonb_build_object(
      'masked', left(coalesce(nullif(p.full_name, ''), 'Worker'), 1) || '***'
                || right(coalesce(nullif(p.full_name, ''), 'W'), 1),
      'amount', w.amount,
      'at', w.processed_at
    ) x
    from public.withdrawals w
    join public.profiles p on p.id = w.user_id
    where w.status = 'paid'
    order by w.processed_at desc nulls last
    limit 12
  ) q;
$$;

create or replace function public.leaderboard_weekly(p_limit int default 50)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  items jsonb;
begin
  perform public.ensure_profile();

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'user_id', p.id,
      'name', coalesce(nullif(p.full_name, ''), 'Worker ' || left(p.id::text, 4)),
      'avatar_url', p.avatar_url,
      'country_code', p.country_code,
      'earned', round(sum(l.available_delta), 6),
      'tasks', (select count(*) from public.tasks t where t.worker_id = p.id and t.status = 'approved'
                 and t.reviewed_at >= date_trunc('week', now())),
      'is_me', p.id = u
    ) as x,
    row_number() over (order by sum(l.available_delta) desc) as rn
      from public.ledger_entries l
      join public.profiles p on p.id = l.user_id
     where l.kind = 'task_reward'
       and l.created_at >= date_trunc('week', now())
     group by p.id, p.full_name, p.avatar_url, p.country_code
     order by sum(l.available_delta) desc
     limit greatest(1, least(coalesce(p_limit, 50), 100))
  ) q;

  return coalesce(items, '[]'::jsonb);
end $$;

create or replace function public.mark_notifications_read(p_ids uuid[] default null)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.notifications
     set read_at = now()
   where user_id = auth.uid()
     and read_at is null
     and (p_ids is null or id = any (p_ids));
  get diagnostics n = row_count;
  return n;
end $$;

-- ----------------------------------------------------------------------------
-- 15. SUPPORT (both sides)
-- ----------------------------------------------------------------------------
create or replace function public.create_support_ticket(
  p_subject text, p_category text default 'general', p_body text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare u uuid := auth.uid(); t public.support_tickets;
begin
  perform public.ensure_profile();
  if p_subject is null or char_length(trim(p_subject)) < 3 then raise exception 'INVALID_SUBJECT'; end if;

  insert into public.support_tickets (user_id, subject, category)
  values (u, trim(p_subject), coalesce(nullif(trim(p_category), ''), 'general'))
  returning * into t;

  if p_body is not null and length(trim(p_body)) > 0 then
    insert into public.ticket_messages (ticket_id, sender_id, body, is_staff)
    values (t.id, u, trim(p_body), false);
  end if;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, 'New support ticket', trim(p_subject), 'info', '#/admin/support'
    from public.profiles where admin_role in ('OWNER','SUPER_ADMIN','ADMIN','SUPPORT');

  return jsonb_build_object('ticket', to_jsonb(t));
end $$;

create or replace function public.list_my_tickets()
returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select jsonb_build_object(
      'id', t.id, 'subject', t.subject, 'category', t.category,
      'status', t.status, 'created_at', t.created_at, 'updated_at', t.updated_at,
      'last_message', (select m.body from public.ticket_messages m where m.ticket_id = t.id order by m.created_at desc limit 1)
    ) x
    from public.support_tickets t where t.user_id = auth.uid()
    order by t.updated_at desc
  ) q;
$$;

create or replace function public.get_ticket(p_ticket_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare t public.support_tickets; msgs jsonb;
begin
  select * into t from public.support_tickets where id = p_ticket_id;
  if t.id is null then raise exception 'TICKET_NOT_FOUND'; end if;
  if t.user_id <> auth.uid() and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', m.id, 'body', m.body, 'is_staff', m.is_staff, 'created_at', m.created_at
         ) order by m.created_at), '[]'::jsonb)
    into msgs from public.ticket_messages m where m.ticket_id = t.id;

  return jsonb_build_object('ticket', to_jsonb(t), 'messages', msgs);
end $$;

create or replace function public.reply_support_ticket(p_ticket_id uuid, p_body text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare u uuid := auth.uid(); t public.support_tickets;
begin
  select * into t from public.support_tickets where id = p_ticket_id;
  if t.id is null then raise exception 'TICKET_NOT_FOUND'; end if;
  if t.user_id <> u and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if p_body is null or length(trim(p_body)) = 0 then raise exception 'EMPTY_MESSAGE'; end if;

  insert into public.ticket_messages (ticket_id, sender_id, body, is_staff)
  values (t.id, u, trim(p_body), public.is_admin());

  update public.support_tickets set updated_at = now(),
         status = case when public.is_admin() then 'pending' else 'open' end
   where id = t.id;

  return public.get_ticket(t.id);
end $$;

-- ----------------------------------------------------------------------------
-- 16. BUYER RPCs
-- ----------------------------------------------------------------------------
create or replace function public.create_campaign(
  p_service_id uuid,
  p_title text,
  p_instructions text,
  p_target_url text,
  p_quantity int,
  p_reward numeric,
  p_countries text[] default '{}',
  p_min_trust int default 0,
  p_require_linked_account boolean default false
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  s public.services;
  w public.wallets;
  c public.campaigns;
  budget numeric;
  fee numeric;
  fee_pct numeric;
  countries_clean text[];
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_buyer then raise exception 'BUYER_MODE_DISABLED'; end if;

  select * into s from public.services where id = p_service_id;
  if s.id is null or not s.active then raise exception 'SERVICE_UNAVAILABLE'; end if;

  if p_title is null or char_length(trim(p_title)) < 3 then raise exception 'INVALID_TITLE'; end if;
  if p_instructions is null or char_length(trim(p_instructions)) < 10 then raise exception 'INVALID_INSTRUCTIONS'; end if;
  if p_target_url is null or p_target_url !~* '^https?://' then raise exception 'INVALID_TARGET_URL'; end if;
  if p_quantity is null or p_quantity < s.min_quantity or p_quantity > s.max_quantity then
    raise exception 'INVALID_QUANTITY';
  end if;
  if p_reward is null or p_reward < s.min_reward or p_reward > s.min_reward * 50 then
    raise exception 'INVALID_REWARD';
  end if;

  if (select count(*) from public.campaigns where buyer_id = u and status in ('pending','active','paused')) >= 10 then
    raise exception 'TOO_MANY_ACTIVE_CAMPAIGNS';
  end if;

  select coalesce(array_agg(distinct upper(trim(cc))), '{}')
    into countries_clean
    from unnest(coalesce(p_countries, '{}')) as t(cc)
   where cc is not null and trim(cc) <> '';

  select * into w from public.wallets where user_id = u for update;
  budget := round(p_quantity::numeric * p_reward, 6);
  fee_pct := least(greatest(coalesce(public.setting_num('campaign_fee_pct', 10), 0), 0), 50);
  fee := round(budget * fee_pct / 100.0, 6);

  if w.available < budget + fee then raise exception 'INSUFFICIENT_FUNDS'; end if;

  perform public.wallet_move(u, -(budget + fee), 0, budget, 0, 'campaign_funding', 'campaign', null,
                             'Campaign budget reserved in escrow');

  insert into public.campaigns (
    buyer_id, service_id, title, instructions, target_url,
    quantity, reward_per_task, total_budget, fee_amount, reserved_remaining,
    status, countries, min_trust_score, require_linked_account
  ) values (
    u, s.id, trim(p_title), trim(p_instructions), trim(p_target_url),
    p_quantity, p_reward, budget, fee, budget,
    case when public.setting_bool('auto_approve_campaigns', true) then 'active' else 'pending' end,
    countries_clean, greatest(0, least(coalesce(p_min_trust, 0), 100)),
    coalesce(p_require_linked_account, false)
  ) returning * into c;

  insert into public.platform_ledger (kind, amount, ref_type, ref_id, note, created_by)
  values ('campaign_fee', fee, 'campaign', c.id, 'Campaign fee', u);

  update public.ledger_entries set ref_id = c.id
   where user_id = u and kind = 'campaign_funding' and ref_id is null
     and id = (select max(id) from public.ledger_entries where user_id = u and kind = 'campaign_funding');

  if c.status = 'active' then
    insert into public.tasks (campaign_id, status, reward)
    select c.id, 'available', c.reward_per_task
      from generate_series(1, c.quantity);
  end if;

  perform public.audit('campaign.create', 'campaign', c.id,
    jsonb_build_object('title', c.title, 'quantity', c.quantity, 'budget', budget, 'fee', fee));
  perform public.notify_user(u, 'Campaign created',
    '"' || c.title || '" is ' || c.status || '.', 'success', '#/buyer/campaigns/' || c.id);

  return jsonb_build_object('campaign', to_jsonb(c));
end $$;

create or replace function public.list_my_campaigns()
returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select jsonb_build_object(
      'id', c.id, 'title', c.title, 'status', c.status,
      'quantity', c.quantity, 'approved_count', c.approved_count,
      'rejected_count', c.rejected_count,
      'reward_per_task', c.reward_per_task, 'total_budget', c.total_budget,
      'reserved_remaining', c.reserved_remaining, 'fee_amount', c.fee_amount,
      'platform', s.platform, 'service_name', s.name,
      'created_at', c.created_at, 'completed_at', c.completed_at
    ) x
    from public.campaigns c join public.services s on s.id = c.service_id
    where c.buyer_id = auth.uid()
    order by c.created_at desc
  ) q;
$$;

create or replace function public.get_my_campaign(p_campaign_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.campaigns; s public.services; counts jsonb; subs jsonb;
begin
  select * into c from public.campaigns where id = p_campaign_id;
  if c.id is null then raise exception 'CAMPAIGN_NOT_FOUND'; end if;
  if c.buyer_id <> auth.uid() and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select * into s from public.services where id = c.service_id;

  counts := jsonb_build_object(
    'available', (select count(*) from public.tasks where campaign_id = c.id and status = 'available'),
    'claimed', (select count(*) from public.tasks where campaign_id = c.id and status = 'claimed'),
    'submitted', (select count(*) from public.tasks where campaign_id = c.id and status = 'submitted'),
    'approved', (select count(*) from public.tasks where campaign_id = c.id and status = 'approved'),
    'rejected', (select count(*) from public.tasks where campaign_id = c.id and status = 'rejected'),
    'expired', (select count(*) from public.tasks where campaign_id = c.id and status = 'expired')
  );

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', sub.id,
           'status', sub.status,
           'created_at', sub.created_at,
           'reviewed_at', sub.reviewed_at,
           'worker', coalesce(nullif(pr.full_name, ''), 'Worker ' || left(pr.id::text, 4))
         ) order by sub.created_at desc), '[]'::jsonb)
    into subs
    from public.submissions sub
    join public.tasks t on t.id = sub.task_id
    left join public.profiles pr on pr.id = sub.worker_id
   where t.campaign_id = c.id;

  return jsonb_build_object(
    'campaign', to_jsonb(c),
    'service', jsonb_build_object('platform', s.platform, 'name', s.name),
    'counts', counts,
    'submissions', subs
  );
end $$;

create or replace function public.set_campaign_status(p_campaign_id uuid, p_action text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  c public.campaigns;
  refund numeric;
  sub record;
  v_extra numeric := 0;
begin
  select * into c from public.campaigns where id = p_campaign_id for update;
  if c.id is null then raise exception 'CAMPAIGN_NOT_FOUND'; end if;
  if c.buyer_id <> u and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;

  if p_action = 'pause' then
    if c.status <> 'active' then raise exception 'INVALID_STATE'; end if;
    update public.campaigns set status = 'paused' where id = c.id;

  elsif p_action = 'resume' then
    if c.status <> 'paused' then raise exception 'INVALID_STATE'; end if;
    if c.approved_count >= c.quantity then raise exception 'CAMPAIGN_COMPLETE'; end if;
    update public.campaigns set status = 'active' where id = c.id;

  elsif p_action = 'cancel' then
    if c.status in ('completed','cancelled') then raise exception 'INVALID_STATE'; end if;

    -- resolve pending submissions first: their reward already left escrow
    for sub in
      select s.id, s.worker_id, t.id as task_id, t.reward
        from public.submissions s join public.tasks t on t.id = s.task_id
       where t.campaign_id = c.id and s.status = 'pending'
    loop
      perform public.wallet_move(sub.worker_id, 0, -sub.reward, 0, 0,
                                 'task_refund', 'submission', sub.id, 'Campaign cancelled — pending reversed');
      perform public.wallet_move(c.buyer_id, 0, 0, sub.reward, 0,
                                 'escrow_return', 'submission', sub.id, 'Campaign cancelled — escrow returned');
      v_extra := v_extra + sub.reward;
      update public.submissions set status = 'rejected', review_note = 'Campaign cancelled',
             reviewed_at = now() where id = sub.id;
      update public.tasks set status = 'rejected', reviewed_at = now() where id = sub.task_id;
      perform public.notify_user(sub.worker_id, 'Campaign cancelled',
        '"' || c.title || '" was cancelled; your pending reward was reversed.', 'warning', '#/tasks');
    end loop;

    update public.tasks set status = 'cancelled'
     where campaign_id = c.id and status in ('available','claimed');

    refund := c.reserved_remaining + v_extra;
    if refund > 0 then
      perform public.wallet_move(c.buyer_id, refund, 0, -refund, 0,
                                 'campaign_refund', 'campaign', c.id, 'Campaign cancelled — escrow refunded');
    end if;

    update public.campaigns
       set status = 'cancelled', reserved_remaining = 0, completed_at = now()
     where id = c.id;

    perform public.notify_user(c.buyer_id, 'Campaign cancelled',
      '"' || c.title || '" was cancelled and the remaining escrow was refunded.', 'info',
      '#/buyer/campaigns/' || c.id);
  else
    raise exception 'INVALID_ACTION';
  end if;

  perform public.audit('campaign.' || p_action, 'campaign', c.id, null);
  select * into c from public.campaigns where id = c.id;
  return jsonb_build_object('campaign', to_jsonb(c));
end $$;

create or replace function public.request_deposit(
  p_amount numeric,
  p_method text default 'USDT_BEP20',
  p_tx_hash text default null,
  p_proof_path text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  min_amount numeric;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if p_method not in ('USDT_BEP20','BINANCE_PAY') then raise exception 'INVALID_METHOD'; end if;

  min_amount := coalesce(public.setting_num('min_deposit', 5), 5);
  if p_amount is null or p_amount < min_amount then raise exception 'BELOW_MIN_DEPOSIT'; end if;
  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0 and trim(p_tx_hash) !~* '^0x[a-fA-F0-9]{64}$' then
    raise exception 'INVALID_TX_HASH';
  end if;

  -- a proof file OR a real transaction hash is required
  if p_proof_path is not null then
    if split_part(p_proof_path, '/', 1) <> u::text then
      raise exception 'INVALID_PROOF_PATH';
    end if;
  elsif p_tx_hash is null or length(trim(p_tx_hash)) = 0 then
    raise exception 'INVALID_PROOF_PATH';
  end if;

  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0
     and exists (
       select 1 from public.deposits
        where lower(tx_hash) = lower(trim(p_tx_hash))
          and status in ('pending','approved')
     ) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (user_id, amount, method, tx_hash, proof_path)
  values (u, round(p_amount, 6), p_method, nullif(trim(coalesce(p_tx_hash, '')), ''), p_proof_path)
  returning * into d;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, 'New deposit request',
         'A buyer submitted a ' || round(p_amount, 6) || ' USDT deposit for review.', 'info', '#/admin/deposits'
    from public.profiles where admin_role in ('OWNER','SUPER_ADMIN','ADMIN','FINANCE');

  return jsonb_build_object('deposit', to_jsonb(d));
end $$;

-- ----------------------------------------------------------------------------
-- 16c. SOCIAL ACCOUNT LINKING, DAILY CHECK-IN, LIVE PAYOUT FEED
-- ----------------------------------------------------------------------------
create or replace function public.my_social_accounts()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', a.id, 'platform', a.platform, 'handle', a.handle,
           'profile_url', a.profile_url, 'trust_label', a.trust_label,
           'status', a.status, 'last_synced_at', a.last_synced_at,
           'created_at', a.created_at
         ) order by a.platform), '[]'::jsonb)
    from public.social_accounts a
   where a.user_id = auth.uid();
$$;

create or replace function public.start_social_verification(
  p_platform text,
  p_handle text,
  p_profile_url text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  a public.social_accounts;
  v_platform text;
  v_handle text;
  v_url text;
  v_code text;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;

  v_platform := lower(trim(coalesce(p_platform, '')));
  if v_platform not in ('x','youtube','instagram','tiktok','facebook','telegram','reddit','spotify','discord') then
    raise exception 'INVALID_PLATFORM';
  end if;

  v_handle := trim(regexp_replace(coalesce(p_handle, ''), '^@+', ''));
  if char_length(v_handle) < 2 or char_length(v_handle) > 80 then
    raise exception 'INVALID_HANDLE';
  end if;

  v_url := nullif(trim(coalesce(p_profile_url, '')), '');
  if v_url is not null and v_url !~* '^https?://' then
    raise exception 'INVALID_URL';
  end if;

  v_code := 'TM-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));

  insert into public.social_accounts (
    user_id, platform, handle, profile_url, trust_label, status,
    verification_code, verification_requested_at, last_synced_at
  ) values (
    u, v_platform, v_handle, v_url,
    case when p.trust_score >= 80 then 'Whitelist'
         when p.trust_score >= 50 then 'Trusted' else 'Newbie' end,
    'pending', v_code, now(), now()
  )
  on conflict (user_id, platform) do update
    set handle = excluded.handle,
        profile_url = excluded.profile_url,
        status = 'pending',
        verification_code = excluded.verification_code,
        verification_requested_at = now(),
        last_synced_at = now(),
        updated_at = now()
  returning * into a;

  perform public.audit('social.start_verification', 'social_account', a.id,
    jsonb_build_object('platform', v_platform, 'handle', v_handle));
  return jsonb_build_object('account', to_jsonb(a), 'code', v_code);
end $$;

create or replace function public.submit_social_verification(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.social_accounts;
begin
  select * into a from public.social_accounts where id = p_id and user_id = auth.uid();
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;
  if a.status = 'linked' then return jsonb_build_object('account', to_jsonb(a)); end if;

  update public.social_accounts
     set status = 'pending', verification_requested_at = now(), updated_at = now()
   where id = a.id
   returning * into a;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, 'Task account awaiting verification',
         'A worker submitted ' || a.platform || ' (@' || a.handle || ') for verification.',
         'info', '#/admin/users'
    from public.profiles where admin_role is not null;

  perform public.audit('social.submit_verification', 'social_account', a.id, null);
  return jsonb_build_object('account', to_jsonb(a));
end $$;

create or replace function public.admin_list_social_accounts(
  p_status text default 'pending', p_limit int default 100
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', a.id, 'platform', a.platform, 'handle', a.handle,
           'profile_url', a.profile_url, 'status', a.status,
           'verification_code', a.verification_code,
           'created_at', a.created_at,
           'user_name', coalesce(nullif(p.full_name, ''), p.email)
         ) order by a.created_at desc), '[]'::jsonb)
    into items
    from public.social_accounts a join public.profiles p on p.id = a.user_id
   where (p_status is null or p_status = '' or a.status = p_status)
   limit greatest(1, least(coalesce(p_limit, 100), 200));
  return items;
end $$;

create or replace function public.admin_verify_social_account(
  p_id uuid, p_approve boolean
) returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.social_accounts;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;
  select * into a from public.social_accounts where id = p_id for update;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;

  update public.social_accounts
     set status = case when p_approve then 'linked' else 'rejected' end,
         linked_at = case when p_approve then now() else null end,
         last_synced_at = now(), updated_at = now()
   where id = a.id
   returning * into a;

  perform public.notify_user(a.user_id,
    case when p_approve then 'Task account verified' else 'Task account rejected' end,
    case when p_approve
      then 'Your ' || a.platform || ' account @' || a.handle || ' is verified.'
      else 'We could not verify @' || a.handle || ' on ' || a.platform || '. Check that the code is still in your profile and submit again.'
    end,
    case when p_approve then 'success' else 'error' end, '#/accounts');

  perform public.audit('social.verify', 'social_account', a.id, jsonb_build_object('approved', p_approve));
  return jsonb_build_object('account', to_jsonb(a));
end $$;

create or replace function public.link_social_account(
  p_platform text,
  p_handle text,
  p_profile_url text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  a public.social_accounts;
  v_platform text;
  v_handle text;
  v_url text;
  v_label text;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;

  v_platform := lower(trim(coalesce(p_platform, '')));
  if v_platform not in ('x','youtube','instagram','tiktok','facebook','telegram','reddit','spotify','discord') then
    raise exception 'INVALID_PLATFORM';
  end if;

  v_handle := trim(regexp_replace(coalesce(p_handle, ''), '^@+', ''));
  if char_length(v_handle) < 2 or char_length(v_handle) > 80 then
    raise exception 'INVALID_HANDLE';
  end if;

  v_url := nullif(trim(coalesce(p_profile_url, '')), '');
  if v_url is not null and v_url !~* '^https?://' then
    raise exception 'INVALID_URL';
  end if;

  v_label := case
    when p.trust_score >= 80 then 'Whitelist'
    when p.trust_score >= 50 then 'Trusted'
    else 'Newbie'
  end;

  insert into public.social_accounts (user_id, platform, handle, profile_url, trust_label, status)
  values (u, v_platform, v_handle, v_url, v_label, 'pending')
  on conflict (user_id, platform) do update
    set handle = excluded.handle,
        profile_url = excluded.profile_url,
        trust_label = excluded.trust_label,
        status = 'pending',
        last_synced_at = now(),
        updated_at = now()
  returning * into a;

  perform public.audit('social.link', 'social_account', a.id,
    jsonb_build_object('platform', v_platform, 'handle', v_handle));
  return jsonb_build_object('account', to_jsonb(a));
end $$;

create or replace function public.unlink_social_account(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  delete from public.social_accounts where id = p_id and user_id = auth.uid();
  if not found then raise exception 'SOCIAL_NOT_FOUND'; end if;
  perform public.audit('social.unlink', 'social_account', p_id, null);
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.refresh_social_account(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  p public.profiles;
  a public.social_accounts;
begin
  select * into p from public.profiles where id = auth.uid();
  update public.social_accounts
     set last_synced_at = now(),
         trust_label = case
           when p.trust_score >= 80 then 'Whitelist'
           when p.trust_score >= 50 then 'Trusted'
           else 'Newbie'
         end,
         updated_at = now()
   where id = p_id and user_id = auth.uid()
  returning * into a;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;
  return jsonb_build_object('account', to_jsonb(a));
end $$;

create or replace function public.recent_payouts(p_limit int default 8)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select jsonb_build_object(
      'name', left(coalesce(nullif(p.full_name, ''), p.email, 'User'), 1) || '***',
      'amount', w.amount,
      'at', coalesce(w.processed_at, w.created_at)
    ) x
      from public.withdrawals w
      join public.profiles p on p.id = w.user_id
     where w.status = 'paid'
     order by coalesce(w.processed_at, w.created_at) desc
     limit greatest(1, least(coalesce(p_limit, 8), 20))
  ) q;
$$;

create or replace function public.checkin_status()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  last_day date;
  v_streak int := 0;
  v_total int := 0;
begin
  perform public.ensure_profile();
  select max(day) into last_day from public.daily_checkins where user_id = auth.uid();
  if last_day = current_date then
    select streak into v_streak from public.daily_checkins
     where user_id = auth.uid() and day = current_date;
  elsif last_day = current_date - 1 then
    select streak into v_streak from public.daily_checkins
     where user_id = auth.uid() and day = last_day;
  end if;
  select count(*) into v_total from public.daily_checkins where user_id = auth.uid();
  return jsonb_build_object(
    'checked_in_today', last_day = current_date,
    'streak', coalesce(v_streak, 0),
    'total_days', coalesce(v_total, 0),
    'reward_tg', setting_num('daily_checkin_tg', 0.5)
  );
end $$;

create or replace function public.claim_daily_checkin()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  streak_yesterday int;
  v_streak int := 1;
  v_reward numeric;
  v_total int;
  w public.wallets;
begin
  perform public.ensure_profile();
  if exists (select 1 from public.daily_checkins where user_id = uid and day = current_date) then
    raise exception 'ALREADY_CHECKED_IN';
  end if;

  select streak into v_streak from (
    select streak from public.daily_checkins
     where user_id = uid and day = current_date - 1
  ) s;
  if v_streak is null then v_streak := 1; else v_streak := v_streak + 1; end if;

  v_reward := greatest(0, coalesce(public.setting_num('daily_checkin_tg', 0.5), 0.5));

  insert into public.daily_checkins (user_id, day, reward_tg, streak)
  values (uid, current_date, v_reward, v_streak);

  if v_reward > 0 then
    update public.wallets
       set tg_balance = tg_balance + v_reward,
           lifetime_tg = lifetime_tg + v_reward,
           updated_at = now()
     where user_id = uid
     returning * into w;
  end if;

  select count(*) into v_total from public.daily_checkins where user_id = uid;

  return jsonb_build_object(
    'ok', true,
    'streak', v_streak,
    'total_days', v_total,
    'reward_tg', v_reward,
    'tg_balance', coalesce(w.tg_balance, 0)
  );
end $$;

-- ----------------------------------------------------------------------------
-- 17. ADMIN RPCs
-- ----------------------------------------------------------------------------
create or replace function public.review_submission(
  p_submission_id uuid, p_approve boolean, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  s public.submissions;
  t public.tasks;
  c public.campaigns;
  w public.profiles;
  ref public.profiles;
  bonus numeric;
  rate numeric;
  v_tg numeric;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into s from public.submissions where id = p_submission_id for update;
  if s.id is null then raise exception 'SUBMISSION_NOT_FOUND'; end if;
  if s.status <> 'pending' then raise exception 'ALREADY_REVIEWED'; end if;

  select * into t from public.tasks where id = s.task_id for update;
  select * into c from public.campaigns where id = t.campaign_id for update;

  if p_approve then
    if c.approved_count >= c.quantity then raise exception 'CAMPAIGN_COMPLETE'; end if;

    update public.submissions
       set status = 'approved', reviewer_id = auth.uid(),
           review_note = nullif(trim(coalesce(p_note, '')), ''), reviewed_at = now()
     where id = s.id;
    update public.tasks set status = 'approved', reviewed_at = now() where id = t.id;

    perform public.wallet_move(s.worker_id, t.reward, -t.reward, 0, t.reward,
                               'task_reward', 'submission', s.id, 'Proof approved — reward released');

    -- TG Coin platform bonus (separate from the USDT reward, no cash value)
    v_tg := coalesce(public.setting_num('tg_per_task', 1), 0);
    if v_tg > 0 then
      update public.wallets
         set tg_balance = tg_balance + v_tg,
             lifetime_tg = lifetime_tg + v_tg,
             updated_at = now()
       where user_id = s.worker_id;
    end if;

    update public.campaigns
       set approved_count = approved_count + 1
     where id = c.id
     returning * into c;

    if c.approved_count >= c.quantity then
      update public.tasks set status = 'cancelled'
       where campaign_id = c.id and status = 'available';
      if c.reserved_remaining > 0 then
        perform public.wallet_move(c.buyer_id, c.reserved_remaining, 0, -c.reserved_remaining, 0,
                                   'campaign_refund', 'campaign', c.id,
                                   'Campaign complete — unused escrow refunded');
      end if;
      update public.campaigns
         set status = 'completed', reserved_remaining = 0, completed_at = now()
       where id = c.id;
      perform public.notify_user(c.buyer_id, 'Campaign completed',
        '"' || c.title || '" reached its target quantity.', 'success', '#/buyer/campaigns/' || c.id);
    end if;

    select * into w from public.profiles where id = s.worker_id;
    if w.referred_by is not null then
      select * into ref from public.profiles where id = w.referred_by;
      rate := least(greatest(coalesce(w.referral_rate, 10), 0), 20);
      bonus := round(t.reward * rate / 100.0, 6);
      if bonus > 0 and ref.status = 'active' then
        perform public.wallet_move(ref.id, bonus, 0, 0, 0, 'referral_bonus', 'submission', s.id,
                                   'Referral commission from ' || coalesce(nullif(w.full_name, ''), 'worker'));
        insert into public.platform_ledger (kind, amount, ref_type, ref_id, note)
        values ('referral_bonus', -bonus, 'submission', s.id, 'Referral payout');
        perform public.notify_user(ref.id, 'Referral bonus',
          'You earned ' || bonus || ' USDT from a referral task.', 'success', '#/referrals');
        perform public.telegram_enqueue(
          ref.id, 'referral_bonus',
          jsonb_build_object(
            'amount', public.telegram_money(bonus),
            'from', coalesce(nullif(w.full_name, ''), 'a worker you invited'),
            'balance', public.telegram_money((select available from public.wallets where user_id = ref.id))
          ),
          'referral_bonus:' || s.id
        );
      end if;
    end if;

    perform public.notify_user(s.worker_id, 'Proof approved',
      'You earned ' || t.reward || ' USDT for "' || c.title || '".', 'success', '#/wallet');

    -- Telegram: only after the reward and the TG Coin bonus above are committed.
    perform public.telegram_enqueue(
      s.worker_id, 'task_approved',
      jsonb_build_object(
        'task', c.title,
        'reward', public.telegram_money(t.reward),
        'bonus', public.telegram_money(coalesce(v_tg, 0)),
        'coin', coalesce(public.setting_text('coin_name', 'TG Coin'), 'TG Coin'),
        'balance', public.telegram_money((select available from public.wallets where user_id = s.worker_id))
      ),
      'task_approved:' || s.id
    );

    perform public.audit('submission.approve', 'submission', s.id,
      jsonb_build_object('task', t.id, 'reward', t.reward, 'worker', s.worker_id));
  else
    update public.submissions
       set status = 'rejected', reviewer_id = auth.uid(),
           review_note = nullif(trim(coalesce(p_note, '')), ''), reviewed_at = now()
     where id = s.id;
    update public.tasks set status = 'rejected', reviewed_at = now() where id = t.id;

    perform public.wallet_move(s.worker_id, 0, -t.reward, 0, 0,
                               'task_refund', 'submission', s.id, 'Proof rejected — pending reversed');
    perform public.wallet_move(c.buyer_id, 0, 0, t.reward, 0,
                               'escrow_return', 'submission', s.id, 'Proof rejected — escrow returned');

    update public.campaigns
       set rejected_count = rejected_count + 1,
           reserved_remaining = reserved_remaining + t.reward
     where id = c.id
     returning * into c;

    -- replenish the slot if the campaign can still be completed
    if c.status = 'active' and c.approved_count < c.quantity then
      insert into public.tasks (campaign_id, status, reward)
      values (c.id, 'available', c.reward_per_task);
    end if;

    if (select count(*) from public.submissions
         where worker_id = s.worker_id and status = 'rejected'
           and created_at > now() - interval '7 days') >= 3 then
      insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
      values (s.worker_id, 'high_rejection_rate', 2,
              jsonb_build_object('rejected_last_7_days', 3), s.id);
    end if;

    perform public.notify_user(s.worker_id, 'Proof rejected',
      coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Your proof did not meet the task requirements.'),
      'error', '#/tasks');

    perform public.telegram_enqueue(
      s.worker_id, 'task_rejected',
      jsonb_build_object(
        'task', c.title,
        'reward', t.reward,
        'note', coalesce(nullif(trim(coalesce(p_note, '')), ''),
                         'Your proof did not meet the task requirements.')
      ),
      'task_rejected:' || s.id
    );

    perform public.audit('submission.reject', 'submission', s.id,
      jsonb_build_object('task', t.id, 'worker', s.worker_id, 'note', p_note));
  end if;

  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_review_deposit(
  p_deposit_id uuid, p_approve boolean, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.deposits;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then raise exception 'FORBIDDEN'; end if;
  select * into d from public.deposits where id = p_deposit_id for update;
  if d.id is null then raise exception 'DEPOSIT_NOT_FOUND'; end if;
  if d.status <> 'pending' then raise exception 'ALREADY_REVIEWED'; end if;

  if p_approve then
    update public.deposits
       set status = 'approved', reviewed_by = auth.uid(), reviewed_at = now(),
           admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = d.id;

    perform public.wallet_move(d.user_id, d.amount, 0, 0, 0, 'deposit', 'deposit', d.id,
                               'Deposit approved');
    update public.wallets
       set lifetime_deposited = lifetime_deposited + d.amount
     where user_id = d.user_id;

    perform public.notify_user(d.user_id, 'Deposit approved',
      'Your deposit of ' || d.amount || ' USDT was credited to your available balance.',
      'success', '#/buyer/wallet');

    perform public.telegram_enqueue(
      d.user_id, 'deposit_approved',
      jsonb_build_object(
        'amount', public.telegram_money(d.amount),
        'network', coalesce(public.setting_text('network_name', 'BNB Smart Chain (BEP-20)'),
                            'BNB Smart Chain (BEP-20)'),
        'balance', public.telegram_money((select available from public.wallets where user_id = d.user_id))
      ),
      'deposit_approved:' || d.id
    );

    perform public.audit('deposit.approve', 'deposit', d.id,
      jsonb_build_object('amount', d.amount, 'user', d.user_id));
  else
    update public.deposits
       set status = 'rejected', reviewed_by = auth.uid(), reviewed_at = now(),
           admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = d.id;

    perform public.notify_user(d.user_id, 'Deposit rejected',
      coalesce(nullif(trim(coalesce(p_note, '')), ''),
               'The deposit could not be verified.') ||
      ' Contact support if you believe this is wrong.', 'error', '#/buyer/wallet');

    perform public.telegram_enqueue(
      d.user_id, 'deposit_rejected',
      jsonb_build_object(
        'amount', public.telegram_money(d.amount),
        'note', coalesce(nullif(trim(coalesce(p_note, '')), ''),
                         'The deposit could not be verified.')
      ),
      'deposit_rejected:' || d.id
    );

    perform public.audit('deposit.reject', 'deposit', d.id,
      jsonb_build_object('amount', d.amount, 'user', d.user_id, 'note', p_note));
  end if;

  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_review_withdrawal(
  p_withdrawal_id uuid, p_action text,
  p_tx_hash text default null, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare wd public.withdrawals; v_hash text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE']) then raise exception 'FORBIDDEN'; end if;
  select * into wd from public.withdrawals where id = p_withdrawal_id for update;
  if wd.id is null then raise exception 'WITHDRAWAL_NOT_FOUND'; end if;
  if wd.status in ('paid','rejected') then raise exception 'ALREADY_FINAL'; end if;

  if p_action = 'reject' then
    perform public.wallet_move(wd.user_id, wd.amount, 0, -wd.amount, 0,
                               'withdrawal_refund', 'withdrawal', wd.id,
                               'Withdrawal rejected — funds returned');
    update public.withdrawals
       set status = 'rejected', processed_by = auth.uid(), processed_at = now(),
           admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = wd.id;
    perform public.notify_user(wd.user_id, 'Withdrawal rejected',
      coalesce(nullif(trim(coalesce(p_note, '')), ''),
               'Your withdrawal request was rejected. The amount is back in your available balance.'),
      'error', '#/wallet');

    perform public.telegram_enqueue(
      wd.user_id, 'withdrawal_rejected',
      jsonb_build_object(
        'amount', public.telegram_money(wd.amount),
        'note', coalesce(nullif(trim(coalesce(p_note, '')), ''),
                         'The request did not pass finance review.')
      ),
      'withdrawal_rejected:' || wd.id
    );

  elsif p_action = 'approve' then
    update public.withdrawals
       set status = 'approved', processed_by = auth.uid(),
           admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = wd.id;
    perform public.notify_user(wd.user_id, 'Withdrawal approved',
      'Your withdrawal of ' || wd.amount || ' USDT is approved and queued for payout.',
      'info', '#/wallet');

    perform public.telegram_enqueue(
      wd.user_id, 'withdrawal_approved',
      jsonb_build_object(
        'amount', public.telegram_money(wd.amount),
        'network', coalesce(public.setting_text('network_name', 'BNB Smart Chain (BEP-20)'),
                            'BNB Smart Chain (BEP-20)'),
        'address', wd.address
      ),
      'withdrawal_approved:' || wd.id
    );

  elsif p_action = 'processing' then
    update public.withdrawals
       set status = 'processing', processed_by = auth.uid(),
           admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = wd.id;

  elsif p_action = 'pay' then
    v_hash := nullif(lower(trim(coalesce(p_tx_hash, ''))), '');
    if v_hash is null or v_hash !~ '^0x[a-f0-9]{64}$' then
      raise exception 'INVALID_TX_HASH';
    end if;

    perform public.wallet_move(wd.user_id, 0, 0, -wd.amount, 0,
                               'withdrawal_paid', 'withdrawal', wd.id,
                               'Withdrawal paid on ' || v_hash);
    update public.wallets
       set lifetime_withdrawn = lifetime_withdrawn + wd.amount
     where user_id = wd.user_id;
    update public.withdrawals
       set status = 'paid', tx_hash = v_hash, processed_by = auth.uid(),
           processed_at = now(), admin_note = nullif(trim(coalesce(p_note, '')), '')
     where id = wd.id;
    perform public.notify_user(wd.user_id, 'Withdrawal paid',
      wd.amount || ' USDT was sent on BNB Smart Chain (BEP-20).', 'success', '#/wallet');

    perform public.telegram_enqueue(
      wd.user_id, 'withdrawal_paid',
      jsonb_build_object('amount', public.telegram_money(wd.amount), 'tx', v_hash),
      'withdrawal_paid:' || wd.id
    );

  else
    raise exception 'INVALID_ACTION';
  end if;

  perform public.audit('withdrawal.' || p_action, 'withdrawal', wd.id,
    jsonb_build_object('amount', wd.amount, 'user', wd.user_id, 'tx', p_tx_hash));

  select * into wd from public.withdrawals where id = wd.id;
  return jsonb_build_object('withdrawal', to_jsonb(wd));
end $$;

create or replace function public.admin_list_withdrawals(
  p_status text default null, p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select count(*) into total from public.withdrawals w
   where (p_status is null or p_status = '' or w.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', w.id, 'amount', w.amount, 'network', w.network, 'address', w.address,
      'status', w.status, 'tx_hash', w.tx_hash, 'admin_note', w.admin_note,
      'created_at', w.created_at, 'processed_at', w.processed_at,
      'user_id', w.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), 'Worker'),
      'user_email', p.email,
      'user_status', p.status
    ) x
      from public.withdrawals w join public.profiles p on p.id = w.user_id
     where (p_status is null or p_status = '' or w.status = p_status)
     order by w.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_list_deposits(
  p_status text default null, p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select count(*) into total from public.deposits d
   where (p_status is null or p_status = '' or d.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', d.id, 'amount', d.amount, 'method', d.method, 'tx_hash', d.tx_hash,
      'proof_path', d.proof_path, 'status', d.status, 'admin_note', d.admin_note,
      'created_at', d.created_at, 'reviewed_at', d.reviewed_at,
      'user_id', d.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), 'Buyer'),
      'user_email', p.email
    ) x
      from public.deposits d join public.profiles p on p.id = d.user_id
     where (p_status is null or p_status = '' or d.status = p_status)
     order by d.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_overview(p_days int default 7)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_days int := greatest(1, least(coalesce(p_days, 7), 90));
  totals jsonb;
  finance jsonb;
  series jsonb;
  top_services jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  totals := jsonb_build_object(
    'users', (select count(*) from public.profiles),
    'workers', (select count(*) from public.profiles where is_worker),
    'buyers', (select count(*) from public.profiles where is_buyer),
    'admins', (select count(*) from public.profiles where admin_role is not null),
    'new_users', (select count(*) from public.profiles where created_at >= now() - make_interval(days => v_days)),
    'tasks_available', (select count(*) from public.tasks where status = 'available'),
    'tasks_claimed', (select count(*) from public.tasks where status = 'claimed'),
    'tasks_submitted', (select count(*) from public.tasks where status = 'submitted'),
    'tasks_approved', (select count(*) from public.tasks where status = 'approved'),
    'tasks_rejected', (select count(*) from public.tasks where status = 'rejected'),
    'approved_in_range', (select count(*) from public.tasks where status = 'approved' and reviewed_at >= now() - make_interval(days => v_days)),
    'rejected_in_range', (select count(*) from public.tasks where status = 'rejected' and reviewed_at >= now() - make_interval(days => v_days)),
    'proofs_pending', (select count(*) from public.submissions where status = 'pending'),
    'proofs_oldest_hours', (select coalesce(round(extract(epoch from (now() - min(created_at))) / 3600), 0) from public.submissions where status = 'pending'),
    'campaigns_active', (select count(*) from public.campaigns where status = 'active'),
    'campaigns_pending', (select count(*) from public.campaigns where status = 'pending'),
    'campaigns_completed', (select count(*) from public.campaigns where status = 'completed'),
    'deposits_pending', (select count(*) from public.deposits where status = 'pending'),
    'deposits_pending_amount', (select coalesce(sum(amount), 0) from public.deposits where status = 'pending'),
    'withdrawals_pending', (select count(*) from public.withdrawals where status in ('pending','approved','processing')),
    'withdrawals_pending_amount', (select coalesce(sum(amount), 0) from public.withdrawals where status in ('pending','approved','processing')),
    'open_flags', (select count(*) from public.fraud_flags where status in ('open','reviewing')),
    'open_tickets', (select count(*) from public.support_tickets where status in ('open','pending')),
    'pending_withdrawal_oldest_hours', (select coalesce(round(extract(epoch from (now() - min(created_at))) / 3600), 0) from public.withdrawals where status in ('pending','approved','processing'))
  );

  finance := jsonb_build_object(
    'available', (select coalesce(sum(available), 0) from public.wallets),
    'pending', (select coalesce(sum(pending), 0) from public.wallets),
    'reserved', (select coalesce(sum(reserved), 0) from public.wallets),
    'revenue', (select coalesce(sum(amount), 0) from public.platform_ledger),
    'rewards_paid', (select coalesce(sum(available_delta), 0) from public.ledger_entries where kind = 'task_reward'),
    'rewards_paid_in_range', (select coalesce(sum(available_delta), 0) from public.ledger_entries
                               where kind = 'task_reward' and created_at >= now() - make_interval(days => v_days)),
    'deposits_approved', (select coalesce(sum(amount), 0) from public.deposits where status = 'approved'),
    'withdrawals_paid', (select coalesce(sum(amount), 0) from public.withdrawals where status = 'paid')
  );

  select coalesce(jsonb_agg(jsonb_build_object(
           'date', to_char(d::date, 'YYYY-MM-DD'),
           'users', (select count(*) from public.profiles p where p.created_at::date = d::date),
           'approved', (select count(*) from public.tasks t where t.status = 'approved' and t.reviewed_at::date = d::date),
           'rewards', (select coalesce(sum(t.reward), 0) from public.tasks t where t.status = 'approved' and t.reviewed_at::date = d::date)
         ) order by (d::date)::date), '[]'::jsonb)
    into series
    from generate_series(current_date - (v_days - 1), current_date, interval '1 day') d;

  select coalesce(jsonb_agg(x), '[]'::jsonb) into top_services from (
    select jsonb_build_object(
      'platform', s.platform, 'service_name', s.name,
      'approved', count(*), 'spend', coalesce(sum(t.reward), 0)
    ) x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
     where t.status = 'approved'
       and t.reviewed_at >= now() - make_interval(days => v_days)
     group by s.platform, s.name
     order by count(*) desc
     limit 6
  ) q;

  return jsonb_build_object(
    'days', v_days, 'generated_at', now(),
    'totals', totals, 'finance', finance,
    'series', series, 'top_services', top_services
  );
end $$;

create or replace function public.admin_list_users(
  p_query text default null, p_status text default null, p_role text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total
    from public.profiles p
   where (p_query is null or p_query = ''
          or p.email ilike '%' || p_query || '%'
          or p.full_name ilike '%' || p_query || '%'
          or p.referral_code ilike '%' || p_query || '%')
     and (p_status is null or p_status = '' or p.status = p_status)
     and (p_role is null or p_role = ''
          or (p_role = 'admin' and p.admin_role is not null)
          or (p_role = 'buyer' and p.is_buyer)
          or (p_role = 'worker' and p.is_worker));

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', p.id, 'email', p.email, 'full_name', p.full_name,
      'avatar_url', p.avatar_url, 'country_code', p.country_code,
      'is_worker', p.is_worker, 'is_buyer', p.is_buyer,
      'admin_role', p.admin_role, 'status', p.status,
      'trust_score', p.trust_score, 'referral_code', p.referral_code,
      'created_at', p.created_at,
      'available', coalesce(w.available, 0),
      'pending', coalesce(w.pending, 0),
      'reserved', coalesce(w.reserved, 0),
      'lifetime_earned', coalesce(w.lifetime_earned, 0),
      'approved_tasks', (select count(*) from public.tasks t where t.worker_id = p.id and t.status = 'approved'),
      'active_campaigns', (select count(*) from public.campaigns c where c.buyer_id = p.id and c.status = 'active')
    ) x
      from public.profiles p
      left join public.wallets w on w.user_id = p.id
     where (p_query is null or p_query = ''
            or p.email ilike '%' || p_query || '%'
            or p.full_name ilike '%' || p_query || '%'
            or p.referral_code ilike '%' || p_query || '%')
       and (p_status is null or p_status = '' or p.status = p_status)
       and (p_role is null or p_role = ''
            or (p_role = 'admin' and p.admin_role is not null)
            or (p_role = 'buyer' and p.is_buyer)
            or (p_role = 'worker' and p.is_worker))
     order by p.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_user_detail(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles; w public.wallets;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select * into p from public.profiles where id = p_user_id;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;
  select * into w from public.wallets where user_id = p_user_id;

  return jsonb_build_object(
    'profile', to_jsonb(p),
    'wallet', to_jsonb(w),
    'stats', jsonb_build_object(
      'approved_tasks', (select count(*) from public.tasks where worker_id = p.id and status = 'approved'),
      'rejected_tasks', (select count(*) from public.tasks where worker_id = p.id and status = 'rejected'),
      'pending_submissions', (select count(*) from public.submissions where worker_id = p.id and status = 'pending'),
      'campaigns', (select count(*) from public.campaigns where buyer_id = p.id),
      'referrals', (select count(*) from public.referrals where referrer_id = p.id),
      'open_withdrawals', (select count(*) from public.withdrawals where user_id = p.id and status in ('pending','approved','processing'))
    ),
    'ledger', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object('id', l.id, 'kind', l.kind, 'available_delta', l.available_delta,
                                  'pending_delta', l.pending_delta, 'reserved_delta', l.reserved_delta,
                                  'available_after', l.available_after, 'note', l.note,
                                  'created_at', l.created_at) x
          from public.ledger_entries l where l.user_id = p.id
         order by l.created_at desc limit 30
      ) q
    ),
    'withdrawals', (
      select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc), '[]'::jsonb)
        from (select * from public.withdrawals where user_id = p.id order by created_at desc limit 10) x
    ),
    'deposits', (
      select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc), '[]'::jsonb)
        from (select * from public.deposits where user_id = p.id order by created_at desc limit 10) x
    )
  );
end $$;

create or replace function public.admin_set_user_status(
  p_user_id uuid, p_status text, p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then raise exception 'FORBIDDEN'; end if;
  if p_user_id = auth.uid() then raise exception 'CANNOT_MODERATE_SELF'; end if;
  if p_status not in ('active','suspended','banned') then raise exception 'INVALID_STATUS'; end if;
  if not exists (select 1 from public.profiles where id = p_user_id) then raise exception 'USER_NOT_FOUND'; end if;

  update public.profiles
     set status = p_status,
         is_suspended = (p_status <> 'active')
   where id = p_user_id;

  if p_status <> 'active' then
    update public.tasks
       set status = 'available', worker_id = null, claimed_at = null, expires_at = null
     where worker_id = p_user_id and status = 'claimed';
    perform public.notify_user(p_user_id, 'Account ' || p_status,
      coalesce(nullif(trim(coalesce(p_reason, '')), ''), 'Contact support for details.'),
      'error', '#/support');
  else
    perform public.notify_user(p_user_id, 'Account restored',
      'Your account is active again.', 'success', '#/dashboard');
  end if;

  perform public.audit('user.status', 'profile', p_user_id,
    jsonb_build_object('status', p_status, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_set_admin_role(p_user_id uuid, p_admin_role text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare owner_count int;
begin
  if not public.has_admin_role(array['OWNER']) then raise exception 'FORBIDDEN'; end if;
  if p_admin_role is not null and p_admin_role not in
     ('OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER','SUPPORT','FINANCE') then
    raise exception 'INVALID_ROLE';
  end if;
  if p_user_id = auth.uid() and p_admin_role is distinct from 'OWNER' then
    select count(*) into owner_count from public.profiles
     where admin_role = 'OWNER' and status = 'active' and id <> auth.uid();
    if owner_count = 0 then raise exception 'LAST_OWNER'; end if;
  end if;

  update public.profiles set admin_role = p_admin_role where id = p_user_id;
  perform public.audit('admin.role', 'profile', p_user_id, jsonb_build_object('role', p_admin_role));
  perform public.notify_user(p_user_id, 'Admin role updated',
    'Your admin role is now: ' || coalesce(p_admin_role, 'none') || '.', 'info', '#/admin');
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_list_tasks(
  p_status text default null, p_search text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
   where (p_status is null or p_status = '' or t.status = p_status)
     and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id, 'status', t.status, 'reward', t.reward,
      'claimed_at', t.claimed_at, 'expires_at', t.expires_at,
      'submitted_at', t.submitted_at, 'reviewed_at', t.reviewed_at,
      'created_at', t.created_at,
      'campaign_id', c.id, 'campaign_title', c.title,
      'platform', s.platform,
      'worker_id', t.worker_id,
      'worker_name', coalesce(nullif(pr.full_name, ''), pr.email)
    ) x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
      left join public.profiles pr on pr.id = t.worker_id
     where (p_status is null or p_status = '' or t.status = p_status)
       and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%')
     order by t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_list_campaigns(
  p_status text default null, p_search text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total from public.campaigns c
   where (p_status is null or p_status = '' or c.status = p_status)
     and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', c.id, 'title', c.title, 'status', c.status,
      'quantity', c.quantity, 'approved_count', c.approved_count,
      'rejected_count', c.rejected_count,
      'reward_per_task', c.reward_per_task, 'total_budget', c.total_budget,
      'reserved_remaining', c.reserved_remaining, 'fee_amount', c.fee_amount,
      'created_at', c.created_at, 'completed_at', c.completed_at,
      'platform', s.platform, 'service_name', s.name,
      'buyer_id', c.buyer_id,
      'buyer_name', coalesce(nullif(p.full_name, ''), p.email)
    ) x
      from public.campaigns c
      join public.services s on s.id = c.service_id
      join public.profiles p on p.id = c.buyer_id
     where (p_status is null or p_status = '' or c.status = p_status)
       and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%')
     order by c.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_review_campaign(
  p_campaign_id uuid, p_approve boolean, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.campaigns;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then raise exception 'FORBIDDEN'; end if;
  select * into c from public.campaigns where id = p_campaign_id for update;
  if c.id is null then raise exception 'CAMPAIGN_NOT_FOUND'; end if;
  if c.status <> 'pending' then raise exception 'NOT_PENDING'; end if;

  if p_approve then
    update public.campaigns
       set status = 'active', review_note = nullif(trim(coalesce(p_note, '')), '')
     where id = c.id;
    if not exists (select 1 from public.tasks where campaign_id = c.id and status = 'available') then
      insert into public.tasks (campaign_id, status, reward)
      select c.id, 'available', c.reward_per_task from generate_series(1, c.quantity);
    end if;
    perform public.notify_user(c.buyer_id, 'Campaign approved',
      '"' || c.title || '" is now live.', 'success', '#/buyer/campaigns/' || c.id);
  else
    if c.reserved_remaining > 0 then
      perform public.wallet_move(c.buyer_id, c.reserved_remaining, 0, -c.reserved_remaining, 0,
                                 'campaign_refund', 'campaign', c.id, 'Campaign rejected — escrow refunded');
    end if;
    update public.campaigns
       set status = 'rejected', reserved_remaining = 0,
           review_note = nullif(trim(coalesce(p_note, '')), ''), completed_at = now()
     where id = c.id;
    perform public.notify_user(c.buyer_id, 'Campaign rejected',
      coalesce(nullif(trim(coalesce(p_note, '')), ''), 'The campaign did not meet our guidelines.'),
      'error', '#/buyer/campaigns/' || c.id);
  end if;

  perform public.audit('campaign.review', 'campaign', c.id,
    jsonb_build_object('approved', p_approve, 'note', p_note));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_list_submissions(
  p_status text default null, p_search text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total
    from public.submissions s
    join public.tasks t on t.id = s.task_id
    join public.campaigns c on c.id = t.campaign_id
   where (p_status is null or p_status = '' or s.status = p_status)
     and (p_search is null or p_search = ''
          or c.title ilike '%' || p_search || '%'
          or c.target_url ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', s.id, 'task_id', s.task_id, 'worker_id', s.worker_id,
      'note', s.note, 'proof_path', s.proof_path, 'proof_paths', s.proof_paths,
      'proof_link', s.proof_link, 'time_spent_seconds', s.time_spent_seconds,
      'proof_hash', s.proof_hash,
      'status', s.status, 'review_note', s.review_note,
      'created_at', s.created_at, 'reviewed_at', s.reviewed_at,
      'reward', t.reward,
      'campaign_id', c.id, 'campaign_title', c.title, 'target_url', c.target_url,
      'instructions', left(c.instructions, 400),
      'platform', sv.platform,
      'worker_name', coalesce(nullif(p.full_name, ''), p.email),
      'worker_country', p.country_code,
      'duplicate_hash', (s.proof_hash is not null and exists (
         select 1 from public.submissions s2 where s2.proof_hash = s.proof_hash and s2.id <> s.id))
    ) x
      from public.submissions s
      join public.tasks t on t.id = s.task_id
      join public.campaigns c on c.id = t.campaign_id
      join public.services sv on sv.id = c.service_id
      join public.profiles p on p.id = s.worker_id
     where (p_status is null or p_status = '' or s.status = p_status)
       and (p_search is null or p_search = ''
            or c.title ilike '%' || p_search || '%'
            or c.target_url ilike '%' || p_search || '%')
     order by (s.status = 'pending') desc, s.created_at asc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_list_ledger(
  p_user_id uuid default null, p_kind text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE','SUPPORT']) then raise exception 'FORBIDDEN'; end if;

  select count(*) into total from public.ledger_entries l
   where (p_user_id is null or l.user_id = p_user_id)
     and (p_kind is null or p_kind = '' or l.kind = p_kind);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', l.id, 'kind', l.kind,
      'available_delta', l.available_delta, 'pending_delta', l.pending_delta,
      'reserved_delta', l.reserved_delta,
      'available_after', l.available_after, 'pending_after', l.pending_after,
      'reserved_after', l.reserved_after, 'note', l.note, 'created_at', l.created_at,
      'user_id', l.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), p.email)
    ) x
      from public.ledger_entries l join public.profiles p on p.id = l.user_id
     where (p_user_id is null or l.user_id = p_user_id)
       and (p_kind is null or p_kind = '' or l.kind = p_kind)
     order by l.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_adjust_balance(
  p_user_id uuid, p_available numeric default 0, p_pending numeric default 0,
  p_reserved numeric default 0, p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','FINANCE']) then raise exception 'FORBIDDEN'; end if;
  if coalesce(p_reason, '') = '' then raise exception 'REASON_REQUIRED'; end if;
  if coalesce(p_available, 0) = 0 and coalesce(p_pending, 0) = 0 and coalesce(p_reserved, 0) = 0 then
    raise exception 'NO_CHANGE';
  end if;

  perform public.wallet_move(p_user_id, coalesce(p_available, 0), coalesce(p_pending, 0),
                             coalesce(p_reserved, 0), 0, 'admin_adjustment', 'profile', p_user_id,
                             'Admin adjustment: ' || p_reason);
  perform public.notify_user(p_user_id, 'Balance adjusted',
    'An administrator adjusted your balance: ' || p_reason, 'info', '#/wallet');
  perform public.audit('wallet.adjust', 'profile', p_user_id,
    jsonb_build_object('available', p_available, 'pending', p_pending,
                       'reserved', p_reserved, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_upsert_service(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare s public.services; v_id uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then raise exception 'FORBIDDEN'; end if;

  v_id := nullif(p_payload ->> 'id', '')::uuid;

  if v_id is null then
    insert into public.services (platform, name, description, default_reward, min_reward,
                                 min_quantity, max_quantity, active, sort_order)
    values (
      lower(trim(p_payload ->> 'platform')),
      trim(p_payload ->> 'name'),
      coalesce(p_payload ->> 'description', ''),
      (p_payload ->> 'default_reward')::numeric,
      coalesce((p_payload ->> 'min_reward')::numeric, (p_payload ->> 'default_reward')::numeric),
      coalesce((p_payload ->> 'min_quantity')::int, 10),
      coalesce((p_payload ->> 'max_quantity')::int, 10000),
      coalesce((p_payload ->> 'active')::boolean, true),
      coalesce((p_payload ->> 'sort_order')::int, 100)
    ) returning * into s;
  else
    update public.services
       set platform = lower(trim(p_payload ->> 'platform')),
           name = trim(p_payload ->> 'name'),
           description = coalesce(p_payload ->> 'description', description),
           default_reward = coalesce((p_payload ->> 'default_reward')::numeric, default_reward),
           min_reward = coalesce((p_payload ->> 'min_reward')::numeric, min_reward),
           min_quantity = coalesce((p_payload ->> 'min_quantity')::int, min_quantity),
           max_quantity = coalesce((p_payload ->> 'max_quantity')::int, max_quantity),
           active = coalesce((p_payload ->> 'active')::boolean, active),
           sort_order = coalesce((p_payload ->> 'sort_order')::int, sort_order),
           updated_at = now()
     where id = v_id
     returning * into s;
    if s.id is null then raise exception 'SERVICE_NOT_FOUND'; end if;
  end if;

  if s.max_quantity < s.min_quantity then raise exception 'INVALID_QUANTITY_RANGE'; end if;
  if s.min_reward > s.default_reward * 50 then raise exception 'INVALID_REWARD_RANGE'; end if;

  perform public.audit('service.upsert', 'service', s.id, p_payload);
  return jsonb_build_object('service', to_jsonb(s));
end $$;

create or replace function public.admin_list_services()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  return (
    select coalesce(jsonb_agg(to_jsonb(s) order by s.sort_order, s.name), '[]'::jsonb)
      from public.services s
  );
end $$;

create or replace function public.admin_upsert_country(
  p_code text, p_name text, p_active boolean default true,
  p_allow_workers boolean default true, p_allow_buyers boolean default true
) returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.countries;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then raise exception 'FORBIDDEN'; end if;
  if upper(trim(p_code)) !~ '^[A-Z]{2}$' then raise exception 'INVALID_COUNTRY_CODE'; end if;

  insert into public.countries (code, name, active, allow_workers, allow_buyers)
  values (upper(trim(p_code)), trim(p_name), p_active, p_allow_workers, p_allow_buyers)
  on conflict (code) do update
    set name = excluded.name, active = excluded.active,
        allow_workers = excluded.allow_workers, allow_buyers = excluded.allow_buyers
  returning * into c;

  perform public.audit('country.upsert', 'country', null, to_jsonb(c));
  return jsonb_build_object('country', to_jsonb(c));
end $$;

create or replace function public.admin_list_countries()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  return (
    select coalesce(jsonb_agg(to_jsonb(c) order by c.name), '[]'::jsonb)
      from public.countries c
  );
end $$;

create or replace function public.admin_get_settings()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  return (
    select coalesce(jsonb_agg(jsonb_build_object('key', s.key, 'value', s.value,
                                                 'is_public', s.is_public, 'updated_at', s.updated_at)
                              order by s.key), '[]'::jsonb)
      from public.settings s
  );
end $$;

create or replace function public.admin_update_setting(
  p_key text, p_value jsonb, p_is_public boolean default null
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then raise exception 'FORBIDDEN'; end if;
  if coalesce(trim(p_key), '') = '' then raise exception 'INVALID_KEY'; end if;

  insert into public.settings (key, value, is_public, updated_by)
  values (trim(p_key), p_value, coalesce(p_is_public, false), auth.uid())
  on conflict (key) do update
    set value = excluded.value,
        is_public = coalesce(p_is_public, settings.is_public),
        updated_at = now(),
        updated_by = auth.uid();

  perform public.audit('setting.update', 'setting', null,
    jsonb_build_object('key', p_key, 'value', p_value));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_list_admins()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  return (
    select coalesce(jsonb_agg(jsonb_build_object(
             'id', p.id, 'email', p.email, 'full_name', p.full_name,
             'admin_role', p.admin_role, 'status', p.status, 'created_at', p.created_at
           ) order by p.admin_role, p.created_at), '[]'::jsonb)
      from public.profiles p where p.admin_role is not null
  );
end $$;

create or replace function public.admin_list_audit(
  p_query text default null, p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then raise exception 'FORBIDDEN'; end if;

  select count(*) into total from public.audit_logs a
   where (p_query is null or p_query = ''
          or a.action ilike '%' || p_query || '%'
          or a.entity_type ilike '%' || p_query || '%');

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', a.id, 'action', a.action, 'actor_role', a.actor_role,
      'entity_type', a.entity_type, 'entity_id', a.entity_id,
      'details', a.details, 'created_at', a.created_at,
      'actor_name', coalesce(nullif(p.full_name, ''), p.email)
    ) x
      from public.audit_logs a left join public.profiles p on p.id = a.actor_id
     where (p_query is null or p_query = ''
            or a.action ilike '%' || p_query || '%'
            or a.entity_type ilike '%' || p_query || '%')
     order by a.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_list_referrals(
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  return (
    select coalesce(jsonb_agg(x), '[]'::jsonb) from (
      select jsonb_build_object(
        'id', r.id, 'rate', r.rate, 'created_at', r.created_at,
        'referrer', coalesce(nullif(a.full_name, ''), a.email),
        'referred', coalesce(nullif(b.full_name, ''), b.email),
        'earned', (select coalesce(sum(available_delta), 0) from public.ledger_entries l
                    where l.user_id = r.referrer_id and l.kind = 'referral_bonus')
      ) x
        from public.referrals r
        join public.profiles a on a.id = r.referrer_id
        join public.profiles b on b.id = r.referred_id
       order by r.created_at desc
       limit greatest(1, least(coalesce(p_limit, 50), 200))
      offset greatest(0, coalesce(p_offset, 0))
    ) q
  );
end $$;

create or replace function public.admin_broadcast(
  p_title text, p_body text default null, p_audience text default 'all'
) returns jsonb language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then raise exception 'FORBIDDEN'; end if;
  if coalesce(trim(p_title), '') = '' then raise exception 'INVALID_TITLE'; end if;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, trim(p_title), nullif(trim(coalesce(p_body, '')), ''), 'announcement', '#/notifications'
    from public.profiles
   where (p_audience = 'all')
      or (p_audience = 'workers' and is_worker)
      or (p_audience = 'buyers' and is_buyer)
      or (p_audience = 'admins' and admin_role is not null);
  get diagnostics n = row_count;

  -- Optional Telegram copy of the announcement. Off by default; the toggle is
  -- telegram_notify_announcement in Admin -> Telegram.
  if public.setting_bool('telegram_bot_enabled', false)
     and public.setting_bool('telegram_notify_announcement', false) then
    insert into public.telegram_outbox (user_id, telegram_id, kind, message, dedupe_key)
    select p.id, p.telegram_id, 'announcement',
           public.telegram_render(
             coalesce(nullif(public.setting_text('telegram_tpl_announcement', ''), ''),
                      public.telegram_default_template('announcement')),
             jsonb_build_object('title', trim(p_title),
                                'body', coalesce(trim(coalesce(p_body, '')), ''))
           ),
           'announcement:' || gen_random_uuid()::text
      from public.profiles p
     where p.telegram_id is not null
       and p.status = 'active'
       and coalesce(p.prefs ->> 'telegram_notify', 'true') <> 'false'
       and ((p_audience = 'all')
            or (p_audience = 'workers' and p.is_worker)
            or (p_audience = 'buyers' and p.is_buyer)
            or (p_audience = 'admins' and p.admin_role is not null));
  end if;

  perform public.audit('broadcast.send', 'notification', null,
    jsonb_build_object('title', p_title, 'audience', p_audience, 'recipients', n));
  return jsonb_build_object('sent', n);
end $$;

create or replace function public.admin_list_tickets(
  p_status text default null, p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total from public.support_tickets t
   where (p_status is null or p_status = '' or t.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id, 'subject', t.subject, 'category', t.category, 'status', t.status,
      'priority', t.priority, 'created_at', t.created_at, 'updated_at', t.updated_at,
      'user_id', t.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), p.email),
      'last_message', (select m.body from public.ticket_messages m
                        where m.ticket_id = t.id order by m.created_at desc limit 1)
    ) x
      from public.support_tickets t join public.profiles p on p.id = t.user_id
     where (p_status is null or p_status = '' or t.status = p_status)
     order by t.updated_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

create or replace function public.admin_ticket_reply(
  p_ticket_id uuid, p_body text, p_status text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare t public.support_tickets;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select * into t from public.support_tickets where id = p_ticket_id;
  if t.id is null then raise exception 'TICKET_NOT_FOUND'; end if;
  if coalesce(trim(p_body), '') = '' then raise exception 'EMPTY_MESSAGE'; end if;

  insert into public.ticket_messages (ticket_id, sender_id, body, is_staff)
  values (t.id, auth.uid(), trim(p_body), true);

  update public.support_tickets
     set status = coalesce(nullif(p_status, ''), case when t.status = 'open' then 'pending' else t.status end),
         updated_at = now()
   where id = t.id;

  perform public.notify_user(t.user_id, 'Support replied',
    'There is a new reply on "' || t.subject || '".', 'info', '#/support/' || t.id);

  perform public.audit('ticket.reply', 'ticket', t.id, jsonb_build_object('status', p_status));
  return public.get_ticket(t.id);
end $$;

create or replace function public.admin_list_flags(
  p_status text default null, p_limit int default 50
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', f.id, 'kind', f.kind, 'severity', f.severity, 'details', f.details,
           'status', f.status, 'created_at', f.created_at, 'ref_id', f.ref_id,
           'user_id', f.user_id,
           'user_name', coalesce(nullif(p.full_name, ''), p.email),
           'user_status', p.status
         ) order by f.created_at desc), '[]'::jsonb)
    into items
    from public.fraud_flags f left join public.profiles p on p.id = f.user_id
   where (p_status is null or p_status = '' or f.status = p_status)
   limit greatest(1, least(coalesce(p_limit, 50), 200));
  return coalesce(items, '[]'::jsonb);
end $$;

create or replace function public.admin_resolve_flag(p_flag_id uuid, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  update public.fraud_flags
     set status = 'resolved', resolved_by = auth.uid(), resolved_at = now(),
         details = coalesce(details, '{}'::jsonb) || jsonb_build_object('resolution', p_note)
   where id = p_flag_id;
  if not found then raise exception 'FLAG_NOT_FOUND'; end if;
  perform public.audit('flag.resolve', 'fraud_flag', p_flag_id, jsonb_build_object('note', p_note));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_ai_snapshot(p_days int default 7)
returns jsonb language plpgsql security definer set search_path = public as $$
declare base jsonb;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  base := public.admin_overview(p_days);

  return base || jsonb_build_object(
    'flags', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'kind', f.kind, 'severity', f.severity, 'created_at', f.created_at,
               'user', coalesce(nullif(p.full_name, ''), p.email), 'details', f.details
             ) order by f.created_at desc), '[]'::jsonb)
        from public.fraud_flags f left join public.profiles p on p.id = f.user_id
       where f.status in ('open','reviewing')
    ),
    'withdrawal_queue', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'amount', w.amount, 'status', w.status, 'created_at', w.created_at,
          'user', coalesce(nullif(p.full_name, ''), p.email)
        ) x
          from public.withdrawals w join public.profiles p on p.id = w.user_id
         where w.status in ('pending','approved','processing')
         order by w.created_at asc limit 10
      ) q
    ),
    'pending_proofs', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', s.id, 'campaign', c.title, 'platform', sv.platform,
          'reward', t.reward, 'created_at', s.created_at,
          'worker', coalesce(nullif(p.full_name, ''), p.email),
          'duplicate_hash', (s.proof_hash is not null and exists (
             select 1 from public.submissions s2 where s2.proof_hash = s.proof_hash and s2.id <> s.id))
        ) x
          from public.submissions s
          join public.tasks t on t.id = s.task_id
          join public.campaigns c on c.id = t.campaign_id
          join public.services sv on sv.id = c.service_id
          join public.profiles p on p.id = s.worker_id
         where s.status = 'pending'
         order by s.created_at asc limit 15
      ) q
    ),
    'support_queue', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object('id', t.id, 'subject', t.subject, 'status', t.status,
                                  'created_at', t.created_at) x
          from public.support_tickets t
         where t.status in ('open','pending')
         order by t.created_at asc limit 10
      ) q
    )
  );
end $$;

-- ----------------------------------------------------------------------------
-- 17b. TELEGRAM NOTIFICATIONS
-- Every event the platform wants to deliver on Telegram is written to an
-- outbox row first. The telegram-notify Edge Function (service role) drains it
-- and only it ever sees the bot token. Nothing here trusts the browser.
--
--   review_submission / admin_review_deposit / admin_review_withdrawal /
--   referral payout / admin_broadcast  ->  telegram_enqueue()
--   telegram-notify (Edge Function)    ->  telegram_claim() then sendMessage
--
-- A dedupe key is unique, so an approval can never message the same worker
-- twice even if an RPC is retried.
-- ----------------------------------------------------------------------------
create table if not exists public.telegram_outbox (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  telegram_id bigint not null,
  kind text not null,
  message text not null,
  status text not null default 'queued'
    check (status in ('queued', 'sending', 'sent', 'failed')),
  attempts int not null default 0,
  last_error text,
  message_id bigint,
  dedupe_key text not null,
  created_at timestamptz not null default now(),
  attempted_at timestamptz,
  sent_at timestamptz
);

create unique index if not exists telegram_outbox_dedupe_key
  on public.telegram_outbox (dedupe_key);
create index if not exists telegram_outbox_status_idx
  on public.telegram_outbox (status, created_at);
create index if not exists telegram_outbox_user_idx
  on public.telegram_outbox (user_id, created_at desc);

alter table public.telegram_outbox enable row level security;
-- No policies on purpose: only SECURITY DEFINER functions and the service role
-- (the Edge Function) can read or write delivery rows.
grant all on public.telegram_outbox to service_role;

-- {{placeholder}} substitution for message templates
create or replace function public.telegram_render(p_template text, p_payload jsonb)
returns text language plpgsql immutable as $$
declare
  out text := coalesce(p_template, '');
  k text;
  v text;
begin
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    return out;
  end if;
  for k, v in select e.key, e.value #>> '{}' from jsonb_each(p_payload) e loop
    out := replace(out, '{{' || k || '}}', coalesce(v, ''));
  end loop;
  return out;
end $$;

-- Built-in copy, used when a template setting has not been created yet.
create or replace function public.telegram_default_template(p_kind text)
returns text language sql immutable as $$
  select case p_kind
    when 'task_approved' then $tpl$🎉 Task Completed!

✅ Task: {{task}}
💰 Reward: +{{reward}} USDT
🪙 Bonus: +{{bonus}} {{coin}}

Your wallet has been updated successfully.

Keep completing tasks to earn more rewards!$tpl$
    when 'task_rejected' then $tpl$⚠️ Task not approved

📌 Task: {{task}}
💬 Reason: {{note}}

The reward was returned to the campaign. Fix the issue and claim a new task, or open a support ticket if you think this is wrong.$tpl$
    when 'deposit_approved' then $tpl$💰 Deposit credited

➕ Amount: +{{amount}} USDT
🏦 Network: {{network}}
💼 Available balance: {{balance}} USDT

Your wallet has been updated successfully.$tpl$
    when 'deposit_rejected' then $tpl$⚠️ Deposit not credited

💬 Reason: {{note}}

Check the transaction hash and the network (USDT on BEP-20), then contact support if the transfer is correct.$tpl$
    when 'withdrawal_approved' then $tpl$✅ Withdrawal approved

💸 Amount: {{amount}} USDT
🏦 Network: {{network}}
📮 Address: {{address}}

Finance will pay it on-chain and the status will update to Paid.$tpl$
    when 'withdrawal_paid' then $tpl$💸 Withdrawal paid

💸 Amount: {{amount}} USDT
🔗 Transaction: {{tx}}

Sent on BNB Smart Chain (BEP-20). The hash is in your wallet history.$tpl$
    when 'withdrawal_rejected' then $tpl$⚠️ Withdrawal rejected

💸 Amount: {{amount}} USDT
💬 Reason: {{note}}

The amount is back in your available balance.$tpl$
    when 'referral_bonus' then $tpl$🎁 Referral bonus

👤 From: {{from}}
💰 Bonus: +{{amount}} USDT
💼 Available balance: {{balance}} USDT

Thanks for growing TM GROW!$tpl$
    when 'announcement' then $tpl$📣 TM GROW

{{title}}

{{body}}$tpl$
    when 'test' then $tpl$✅ TM GROW notifications are working

This is a test message from the Master Admin Panel. Task, deposit, withdrawal and referral updates will arrive here.$tpl$
    else null
  end;
$$;

/* Queue one Telegram message for a user.
   Returns the outbox id, or null when nothing should be sent:
   bot disabled, event disabled, user has no linked Telegram, the user opted
   out, or the message is empty. */
create or replace function public.telegram_enqueue(
  p_user_id uuid, p_kind text,
  p_payload jsonb default '{}'::jsonb,
  p_dedupe_key text default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_tg bigint;
  v_prefs jsonb;
  v_on boolean;
  v_tpl text;
  v_msg text;
  v_key text;
  v_id uuid;
begin
  if p_user_id is null or coalesce(trim(p_kind), '') = '' then return null; end if;
  if not public.setting_bool('telegram_bot_enabled', false) then return null; end if;
  if not public.setting_bool('telegram_notify_' || p_kind, true) then return null; end if;

  select p.telegram_id, coalesce(p.prefs, '{}'::jsonb)
    into v_tg, v_prefs
    from public.profiles p
   where p.id = p_user_id
     and p.status = 'active';
  if v_tg is null then return null; end if;

  v_on := case
            when v_prefs ? 'telegram_notify' then (v_prefs ->> 'telegram_notify') <> 'false'
            else true
          end;
  if not v_on then return null; end if;

  v_tpl := public.setting_text('telegram_tpl_' || p_kind, null);
  if coalesce(trim(v_tpl), '') = '' then
    v_tpl := public.telegram_default_template(p_kind);
  end if;
  if coalesce(trim(v_tpl), '') = '' then return null; end if;

  v_msg := trim(public.telegram_render(v_tpl, coalesce(p_payload, '{}'::jsonb)));
  if v_msg = '' then return null; end if;

  v_key := coalesce(nullif(trim(p_dedupe_key), ''), 'auto:' || gen_random_uuid()::text);

  insert into public.telegram_outbox (user_id, telegram_id, kind, message, dedupe_key)
  values (p_user_id, v_tg, p_kind, v_msg, v_key)
  on conflict (dedupe_key) do nothing
  returning id into v_id;

  return v_id;
end $$;

-- Human amount for messages: 0.040000 -> 0.04, 2.000000 -> 2
create or replace function public.telegram_money(p_value numeric)
returns text language sql stable as $$
  select case
    when p_value is null then '0'
    when p_value = trunc(p_value) then trunc(p_value)::text
    else rtrim(rtrim(to_char(p_value, 'FM999999990.000000'), '0'), '.')
  end;
$$;

revoke all on function public.telegram_render(text, jsonb) from public, anon, authenticated;
revoke all on function public.telegram_money(numeric) from public, anon, authenticated;
revoke all on function public.telegram_default_template(text) from public, anon, authenticated;
revoke all on function public.telegram_enqueue(uuid, text, jsonb, text) from public, anon, authenticated;

/* Atomic claim for the Edge Function. Queued rows, failed rows with retries
   left, and rows stuck in 'sending' for over three minutes are picked up. */
create or replace function public.telegram_claim(p_limit int default 20)
returns setof public.telegram_outbox
language plpgsql security definer set search_path = public as $$
begin
  if auth.role() is distinct from 'service_role' then
    raise exception 'FORBIDDEN';
  end if;

  return query
  update public.telegram_outbox o
     set status = 'sending',
         attempts = o.attempts + 1,
         attempted_at = now()
   where o.id in (
     select id from public.telegram_outbox
      where status = 'queued'
         or (status = 'failed' and attempts < 5)
         or (status = 'sending'
             and coalesce(attempted_at, created_at) < now() - interval '3 minutes')
      order by created_at
      limit greatest(1, least(coalesce(p_limit, 20), 50))
      for update skip locked
   )
  returning o.*;
end $$;

revoke all on function public.telegram_claim(int) from public, anon, authenticated;
grant execute on function public.telegram_claim(int) to service_role;

-- Admin: delivery health, linked users and the live templates.
create or replace function public.admin_telegram_overview()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'bot_enabled', public.setting_bool('telegram_bot_enabled', false),
    'linked_users', (select count(*) from public.telegram_users),
    'opted_out', (
      select count(*) from public.profiles p
       where p.telegram_id is not null
         and coalesce(p.prefs ->> 'telegram_notify', 'true') = 'false'
    ),
    'counts', jsonb_build_object(
      'queued',  (select count(*) from public.telegram_outbox where status in ('queued','sending')),
      'sent',    (select count(*) from public.telegram_outbox where status = 'sent'),
      'failed',  (select count(*) from public.telegram_outbox where status = 'failed'),
      'sent_24h',(select count(*) from public.telegram_outbox
                   where status = 'sent' and sent_at >= now() - interval '24 hours')
    ),
    'failed_recent', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', o.id, 'kind', o.kind, 'last_error', o.last_error,
               'attempts', o.attempts, 'created_at', o.created_at,
               'user_name', coalesce(nullif(p.full_name, ''), p.email)
             ) order by o.created_at desc), '[]'::jsonb)
        from public.telegram_outbox o
        left join public.profiles p on p.id = o.user_id
       where o.status = 'failed'
       limit 10
    ),
    'templates', (
      select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
        from public.settings where key like 'telegram_tpl_%'
    ),
    'toggles', (
      select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
        from public.settings
       where key like 'telegram_notify_%' or key = 'telegram_bot_enabled'
    )
  );
end $$;

-- Admin: delivery log.
create or replace function public.admin_telegram_list(
  p_status text default null, p_limit int default 30, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into total from public.telegram_outbox o
   where (p_status is null or p_status = '' or o.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', o.id, 'kind', o.kind, 'status', o.status, 'message', o.message,
      'attempts', o.attempts, 'last_error', o.last_error, 'message_id', o.message_id,
      'telegram_id', o.telegram_id, 'created_at', o.created_at, 'sent_at', o.sent_at,
      'user_id', o.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), p.email, 'User')
    ) x
      from public.telegram_outbox o
      left join public.profiles p on p.id = o.user_id
     where (p_status is null or p_status = '' or o.status = p_status)
     order by o.created_at desc
     limit greatest(1, least(coalesce(p_limit, 30), 100))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

-- Admin: put one failed delivery back in the queue (the Edge Function sends it).
create or replace function public.admin_telegram_retry(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  update public.telegram_outbox
     set status = 'queued', last_error = null, attempted_at = null
   where id = p_id and status <> 'sent';
  if not found then raise exception 'TELEGRAM_ALREADY_SENT'; end if;

  perform public.audit('telegram.retry', 'telegram_outbox', p_id, null);
  return jsonb_build_object('ok', true);
end $$;

-- Worker: is Telegram linked, and do they want notifications?
create or replace function public.my_telegram_status()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v uuid := auth.uid();
  v_tg bigint;
  v_prefs jsonb;
  v_username text;
begin
  if v is null then raise exception 'UNAUTHENTICATED'; end if;

  select p.telegram_id, coalesce(p.prefs, '{}'::jsonb)
    into v_tg, v_prefs
    from public.profiles p where p.id = v;

  select username into v_username
    from public.telegram_users where telegram_id = v_tg;

  return jsonb_build_object(
    'linked', v_tg is not null,
    'telegram_id', v_tg,
    'username', v_username,
    'enabled', case when v_prefs ? 'telegram_notify'
                    then (v_prefs ->> 'telegram_notify') <> 'false'
                    else true end,
    'bot_enabled', public.setting_bool('telegram_bot_enabled', false)
  );
end $$;

create or replace function public.set_my_telegram_notifications(p_enabled boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v uuid := auth.uid();
begin
  if v is null then raise exception 'UNAUTHENTICATED'; end if;

  update public.profiles
     set prefs = coalesce(prefs, '{}'::jsonb)
                 || jsonb_build_object('telegram_notify', coalesce(p_enabled, true)),
         updated_at = now()
   where id = v;

  perform public.audit('profile.telegram_notify', 'profile', v,
    jsonb_build_object('enabled', p_enabled));
  return public.my_telegram_status();
end $$;

-- Admin: generate more task slots for a funded campaign (bounded by its
-- remaining quantity) and disable / re-enable a single task.
create or replace function public.admin_create_task_slots(
  p_campaign_id uuid, p_count int default 1
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  c public.campaigns;
  open_slots int;
  make int;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into c from public.campaigns where id = p_campaign_id for update;
  if c.id is null then raise exception 'CAMPAIGN_NOT_FOUND'; end if;
  if c.status not in ('active','pending') then raise exception 'CAMPAIGN_NOT_ACTIVE'; end if;

  select count(*) into open_slots from public.tasks
   where campaign_id = c.id and status in ('available','claimed','submitted');

  if c.approved_count + open_slots >= c.quantity then raise exception 'CAMPAIGN_FULL'; end if;

  make := least(greatest(coalesce(p_count, 1), 1), c.quantity - c.approved_count - open_slots);
  if make <= 0 then raise exception 'CAMPAIGN_FULL'; end if;

  insert into public.tasks (campaign_id, status, reward)
  select c.id, 'available', c.reward_per_task from generate_series(1, make);

  perform public.audit('task.create_slots', 'campaign', c.id,
    jsonb_build_object('created', make));
  return jsonb_build_object('created', make);
end $$;

create or replace function public.admin_set_task_status(p_task_id uuid, p_status text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare t public.tasks;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_status not in ('available','cancelled') then raise exception 'INVALID_STATUS'; end if;

  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status in ('approved','rejected') then raise exception 'ALREADY_FINAL'; end if;

  if p_status = 'cancelled' then
    update public.tasks
       set status = 'cancelled', worker_id = null,
           claimed_at = null, expires_at = null
     where id = t.id;
    if t.worker_id is not null then
      perform public.notify_user(t.worker_id, 'Task withdrawn',
        'A task you claimed was withdrawn by the platform. Nothing is charged to you.',
        'info', '#/tasks');
    end if;
  else
    if t.status <> 'cancelled' then raise exception 'INVALID_STATE'; end if;
    if exists (select 1 from public.campaigns c
                where c.id = t.campaign_id and c.status not in ('active','pending')) then
      raise exception 'CAMPAIGN_NOT_ACTIVE';
    end if;
    update public.tasks set status = 'available' where id = t.id;
  end if;

  perform public.audit('task.status', 'task', t.id,
    jsonb_build_object('from', t.status, 'to', p_status));
  return jsonb_build_object('ok', true, 'status', p_status);
end $$;

-- Telegram settings and default templates (safe to re-run).
insert into public.settings (key, value, is_public) values
  ('telegram_bot_enabled', 'false'::jsonb, false),
  ('telegram_notify_task_approved', 'true'::jsonb, false),
  ('telegram_notify_task_rejected', 'true'::jsonb, false),
  ('telegram_notify_deposit_approved', 'true'::jsonb, false),
  ('telegram_notify_deposit_rejected', 'true'::jsonb, false),
  ('telegram_notify_withdrawal_approved', 'true'::jsonb, false),
  ('telegram_notify_withdrawal_paid', 'true'::jsonb, false),
  ('telegram_notify_withdrawal_rejected', 'true'::jsonb, false),
  ('telegram_notify_referral_bonus', 'true'::jsonb, false),
  ('telegram_notify_announcement', 'false'::jsonb, false)
on conflict (key) do nothing;

insert into public.settings (key, value, is_public) values
  ('telegram_tpl_task_approved', to_jsonb(public.telegram_default_template('task_approved')), false),
  ('telegram_tpl_task_rejected', to_jsonb(public.telegram_default_template('task_rejected')), false),
  ('telegram_tpl_deposit_approved', to_jsonb(public.telegram_default_template('deposit_approved')), false),
  ('telegram_tpl_deposit_rejected', to_jsonb(public.telegram_default_template('deposit_rejected')), false),
  ('telegram_tpl_withdrawal_approved', to_jsonb(public.telegram_default_template('withdrawal_approved')), false),
  ('telegram_tpl_withdrawal_paid', to_jsonb(public.telegram_default_template('withdrawal_paid')), false),
  ('telegram_tpl_withdrawal_rejected', to_jsonb(public.telegram_default_template('withdrawal_rejected')), false),
  ('telegram_tpl_referral_bonus', to_jsonb(public.telegram_default_template('referral_bonus')), false),
  ('telegram_tpl_announcement', to_jsonb(public.telegram_default_template('announcement')), false),
  ('telegram_tpl_test', to_jsonb(public.telegram_default_template('test')), false)
on conflict (key) do nothing;

-- ----------------------------------------------------------------------------
-- 17c. OWNER BOOTSTRAP + ADMIN DIAGNOSTICS
-- Roles live on profiles.admin_role. claim_owner() is the only self-service way
-- to gain OWNER: it compares the verified JWT email with settings.owner_email
-- (seeded above with the platform owner), so the browser can never promote an
-- account. Kept in sync with supabase/promote-owner.sql and
-- supabase/reset-admin-password.sql.
-- ----------------------------------------------------------------------------
create or replace function public.claim_owner()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_configured text := lower(coalesce(public.setting_text('owner_email', ''), ''));
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  if v_configured = '' then
    return jsonb_build_object('ok', false, 'reason', 'OWNER_EMAIL_NOT_CONFIGURED');
  end if;

  if v_email = '' or v_email <> v_configured then
    return jsonb_build_object('ok', false, 'reason', 'NOT_THE_OWNER_ACCOUNT');
  end if;

  if not exists (
    select 1 from auth.users u
     where u.id = v_uid
       and lower(u.email) = v_email
       and u.email_confirmed_at is not null
  ) then
    return jsonb_build_object('ok', false, 'reason', 'EMAIL_NOT_VERIFIED');
  end if;

  perform public.ensure_profile();

  update public.profiles
     set admin_role = 'OWNER',
         status = 'active',
         is_suspended = false,
         updated_at = now()
   where id = v_uid;

  insert into public.wallets (user_id) values (v_uid)
  on conflict (user_id) do nothing;

  perform public.audit('owner.claim', 'profile', v_uid,
    jsonb_build_object('email', v_email));

  return jsonb_build_object('ok', true, 'email', v_email, 'role', 'OWNER');
end $$;

create or replace function public.admin_wallet_overview(p_limit int default 25)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','FINANCE','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'totals', (
      select jsonb_build_object(
        'available', coalesce(sum(available), 0),
        'pending', coalesce(sum(pending), 0),
        'reserved', coalesce(sum(reserved), 0),
        'tg', coalesce(sum(tg_balance), 0),
        'lifetime_earned', coalesce(sum(lifetime_earned), 0),
        'lifetime_withdrawn', coalesce(sum(lifetime_withdrawn), 0),
        'lifetime_deposited', coalesce(sum(lifetime_deposited), 0),
        'wallets', count(*)
      ) from public.wallets
    ),
    'top', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'user_id', w.user_id,
          'name', coalesce(nullif(p.full_name, ''), p.email),
          'email', p.email,
          'status', p.status,
          'is_buyer', p.is_buyer,
          'available', w.available,
          'pending', w.pending,
          'reserved', w.reserved,
          'tg_balance', w.tg_balance,
          'lifetime_earned', w.lifetime_earned
        ) x
          from public.wallets w
          join public.profiles p on p.id = w.user_id
         order by w.available desc
         limit greatest(1, least(coalesce(p_limit, 25), 100))
      ) q
    ),
    'recent', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object(
          'id', l.id, 'kind', l.kind,
          'available_delta', l.available_delta,
          'pending_delta', l.pending_delta,
          'reserved_delta', l.reserved_delta,
          'available_after', l.available_after,
          'note', l.note, 'created_at', l.created_at,
          'user_name', coalesce(nullif(p.full_name, ''), p.email)
        ) x
          from public.ledger_entries l
          left join public.profiles p on p.id = l.user_id
         order by l.created_at desc
         limit 20
      ) q
    )
  );
end $$;

create or replace function public.admin_system_status()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_owner text := lower(coalesce(public.setting_text('owner_email', ''), ''));
begin
  if not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'generated_at', now(),
    'database_size', pg_size_pretty(pg_database_size(current_database())),
    'postgres_version', current_setting('server_version'),
    'me', jsonb_build_object(
      'id', auth.uid(),
      'email', v_email,
      'role', public.admin_role(),
      'is_configured_owner', (v_email <> '' and v_email = v_owner)
    ),
    'owner', jsonb_build_object(
      'configured_email', public.setting_text('owner_email', ''),
      'owners', (select count(*) from public.profiles where admin_role = 'OWNER'),
      'matches_me', (v_email <> '' and v_email = v_owner)
    ),
    'counts', jsonb_build_object(
      'profiles', (select count(*) from public.profiles),
      'wallets', (select count(*) from public.wallets),
      'admins', (select count(*) from public.profiles where admin_role is not null),
      'tasks', (select count(*) from public.tasks),
      'submissions', (select count(*) from public.submissions),
      'proofs_pending', (select count(*) from public.submissions where status = 'pending'),
      'deposits_pending', (select count(*) from public.deposits where status = 'pending'),
      'withdrawals_open', (select count(*) from public.withdrawals where status in ('pending','approved','processing')),
      'settings', (select count(*) from public.settings),
      'notifications', (select count(*) from public.telegram_outbox)
    ),
    'schema', jsonb_build_object(
      'profiles', to_regclass('public.profiles') is not null,
      'wallets', to_regclass('public.wallets') is not null,
      'tasks', to_regclass('public.tasks') is not null,
      'telegram_users', to_regclass('public.telegram_users') is not null,
      'telegram_outbox', to_regclass('public.telegram_outbox') is not null,
      'social_accounts', to_regclass('public.social_accounts') is not null,
      'admin_members', to_regclass('public.admin_members') is not null
    ),
    'last_audit', (
      select jsonb_build_object('action', a.action, 'role', a.actor_role,
                                'at', a.created_at,
                                'actor', coalesce(nullif(p.full_name, ''), p.email))
        from public.audit_logs a
        left join public.profiles p on p.id = a.actor_id
       order by a.created_at desc limit 1
    )
  );
end $$;

-- ----------------------------------------------------------------------------
-- 17d. SUSPENSION SYSTEM + AUTOMATION ENGINE
-- Suspension is enforced by BEFORE triggers on the tables every sensitive
-- operation writes to, so claiming, submitting, funding and paying are blocked
-- in the database, not just hidden in the UI. Wallet rows and ledger history
-- are never touched by a suspension.
-- ----------------------------------------------------------------------------
alter table public.profiles add column if not exists suspension_kind text;
alter table public.profiles add column if not exists suspension_reason text;
alter table public.profiles add column if not exists suspension_note text;
alter table public.profiles add column if not exists suspended_at timestamptz;
alter table public.profiles add column if not exists suspension_expires_at timestamptz;
alter table public.profiles add column if not exists suspension_appeal_allowed boolean not null default true;
alter table public.profiles add column if not exists suspended_by uuid references public.profiles (id) on delete set null;
alter table public.profiles add column if not exists withdrawals_blocked boolean not null default false;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_suspension_kind_chk') then
    alter table public.profiles add constraint profiles_suspension_kind_chk
      check (suspension_kind is null or suspension_kind in ('temporary','permanent','under_review','restricted'));
  end if;
end $$;

insert into public.settings (key, value, is_public) values
  ('automation_enabled', 'false'::jsonb, false),
  ('suspension_appeal_info', '"If you believe this action was taken by mistake, contact support and we will review it."'::jsonb, false)
on conflict (key) do nothing;

create or replace function public.restore_expired_suspensions()
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.profiles
     set status = 'active',
         is_suspended = false,
         suspension_kind = null,
         suspension_reason = null,
         suspension_expires_at = null,
         withdrawals_blocked = false,
         updated_at = now()
   where status = 'suspended'
     and suspension_kind = 'temporary'
     and suspension_expires_at is not null
     and suspension_expires_at < now();
  get diagnostics n = row_count;

  if n > 0 then
    insert into public.audit_logs (actor_role, action, entity_type, details)
    values ('system', 'suspension.auto_restore', 'profile',
            jsonb_build_object('restored', n, 'at', now()));
  end if;
  return n;
end $$;

/* Backend enforcement. Called by triggers below; safe to call directly too. */
create or replace function public.assert_account_active(p_user uuid, p_scope text default 'all')
returns void language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  if p_user is null then return; end if;
  select * into p from public.profiles where id = p_user;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;

  if p.status = 'suspended' and p.suspension_kind = 'temporary'
     and p.suspension_expires_at is not null and p.suspension_expires_at < now() then
    perform public.restore_expired_suspensions();
    return;
  end if;

  if p.status in ('suspended','banned') then
    raise exception 'ACCOUNT_SUSPENDED';
  end if;

  if coalesce(p.withdrawals_blocked, false)
     and (p_scope in ('money','withdrawal') or p_scope = 'all') then
    raise exception 'WITHDRAWALS_BLOCKED';
  end if;
end $$;

create or replace function public.tg_block_suspended_activity()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid;
  v_scope text := coalesce(tg_argv[0], 'all');
  p public.profiles;
begin
  if tg_table_name = 'tasks' then
    if tg_op <> 'UPDATE' or not (new.status = 'claimed' and old.status = 'available') then
      return new;
    end if;
    v_uid := new.worker_id;
  elsif tg_table_name = 'submissions' then
    v_uid := new.worker_id;
  elsif tg_table_name = 'campaigns' then
    v_uid := new.buyer_id;
  elsif tg_table_name = 'withdrawals' then
    v_uid := new.user_id;
  elsif tg_table_name = 'deposits' then
    v_uid := new.user_id;
  end if;

  if v_uid is null or v_uid is distinct from auth.uid() then
    return new;  -- admin / service-role writes are never blocked here
  end if;

  select * into p from public.profiles where id = v_uid;
  if p.id is null then return new; end if;

  if p.status = 'suspended' and p.suspension_kind = 'temporary'
     and p.suspension_expires_at is not null and p.suspension_expires_at < now() then
    perform public.restore_expired_suspensions();
    return new;
  end if;

  if p.status in ('suspended','banned') then
    raise exception 'ACCOUNT_SUSPENDED';
  end if;

  if coalesce(p.withdrawals_blocked, false) and v_scope in ('money','withdrawal') then
    raise exception 'WITHDRAWALS_BLOCKED';
  end if;

  return new;
end $$;

drop trigger if exists tg_block_suspended_tasks on public.tasks;
create trigger tg_block_suspended_tasks before update on public.tasks
  for each row execute function public.tg_block_suspended_activity('work');

drop trigger if exists tg_block_suspended_submissions on public.submissions;
create trigger tg_block_suspended_submissions before insert on public.submissions
  for each row execute function public.tg_block_suspended_activity('work');

drop trigger if exists tg_block_suspended_campaigns on public.campaigns;
create trigger tg_block_suspended_campaigns before insert on public.campaigns
  for each row execute function public.tg_block_suspended_activity('money');

drop trigger if exists tg_block_suspended_deposits on public.deposits;
create trigger tg_block_suspended_deposits before insert on public.deposits
  for each row execute function public.tg_block_suspended_activity('money');

drop trigger if exists tg_block_suspended_withdrawals on public.withdrawals;
create trigger tg_block_suspended_withdrawals before insert on public.withdrawals
  for each row execute function public.tg_block_suspended_activity('withdrawal');

-- The suspended user's own view of their status (works while suspended).
create or replace function public.my_suspension()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v uuid := auth.uid();
  p public.profiles;
begin
  if v is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into p from public.profiles where id = v;
  if p.id is null then return jsonb_build_object('active', true); end if;

  return jsonb_build_object(
    'active', (p.status = 'active'),
    'status', p.status,
    'kind', p.suspension_kind,
    'reason', p.suspension_reason,
    'note', p.suspension_note,
    'suspended_at', p.suspended_at,
    'expires_at', p.suspension_expires_at,
    'appeal_allowed', coalesce(p.suspension_appeal_allowed, true),
    'withdrawals_blocked', coalesce(p.withdrawals_blocked, false),
    'appeal_info', public.setting_text('suspension_appeal_info', null)
  );
end $$;

create or replace function public.admin_suspend_user(
  p_user_id uuid, p_kind text, p_reason text,
  p_expires_at timestamptz default null,
  p_note text default null,
  p_appeal_allowed boolean default true,
  p_reason_key text default null,
  p_evidence jsonb default '[]'::jsonb
) returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_user_id = auth.uid() then raise exception 'CANNOT_MODERATE_SELF'; end if;
  if p_kind not in ('temporary','permanent','under_review','restricted') then
    raise exception 'INVALID_STATUS';
  end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'REASON_REQUIRED'; end if;
  if p_kind = 'temporary' and (p_expires_at is null or p_expires_at <= now()) then
    raise exception 'INVALID_EXPIRY';
  end if;

  select * into p from public.profiles where id = p_user_id for update;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;
  if p.admin_role = 'OWNER' then raise exception 'FORBIDDEN'; end if;

  update public.profiles
     set status = case when p_kind = 'restricted' then 'active' else 'suspended' end,
         is_suspended = (p_kind <> 'restricted'),
         suspension_kind = p_kind,
         suspension_reason_key = nullif(trim(coalesce(p_reason_key, '')), ''),
         suspension_reason = trim(p_reason),
         suspension_note = nullif(trim(coalesce(p_note, '')), ''),
         suspension_evidence = case
           when p_evidence is null or jsonb_typeof(p_evidence) <> 'array' then coalesce(suspension_evidence, '[]'::jsonb)
           else p_evidence
         end,
         suspended_at = case when p_kind = 'restricted' then null else now() end,
         suspension_expires_at = case when p_kind = 'temporary' then p_expires_at else null end,
         suspension_appeal_allowed = coalesce(p_appeal_allowed, true),
         suspended_by = auth.uid(),
         withdrawals_blocked = (p_kind = 'restricted'),
         updated_at = now()
   where id = p_user_id;

  -- open claims go back to the marketplace; nothing is charged to the user
  update public.tasks
     set status = 'available', worker_id = null, claimed_at = null, expires_at = null
   where worker_id = p_user_id and status = 'claimed';

  perform public.notify_user(p_user_id,
    case when p_kind = 'restricted' then 'Account restricted' else 'Account suspended' end,
    trim(p_reason), 'error', '#/dashboard');

  perform public.audit('user.suspend', 'profile', p_user_id,
    jsonb_build_object('kind', p_kind, 'reason', p_reason,
                       'expires_at', p_expires_at, 'note', p_note));
  return jsonb_build_object('ok', true, 'kind', p_kind, 'status',
    case when p_kind = 'restricted' then 'active' else 'suspended' end);
end $$;

create or replace function public.admin_restore_user(p_user_id uuid, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then
    raise exception 'FORBIDDEN';
  end if;
  if not exists (select 1 from public.profiles where id = p_user_id) then
    raise exception 'USER_NOT_FOUND';
  end if;

  update public.profiles
     set status = 'active',
         is_suspended = false,
         suspension_kind = null,
         suspension_reason = null,
         suspension_expires_at = null,
         withdrawals_blocked = false,
         updated_at = now()
   where id = p_user_id;

  perform public.notify_user(p_user_id, 'Account restored',
    coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Your account is active again.'),
    'success', '#/dashboard');
  perform public.audit('user.restore', 'profile', p_user_id,
    jsonb_build_object('note', p_note));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_suspended_users(
  p_mode text default 'suspended', p_query text default null,
  p_limit int default 50, p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare items jsonb; total int;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  select count(*) into total from public.profiles p
   where ((p_mode = 'suspended' and p.status = 'suspended')
       or (p_mode = 'banned' and p.status = 'banned')
       or (p_mode = 'restricted' and coalesce(p.withdrawals_blocked, false))
       or (p_mode = 'all' and (p.status <> 'active' or coalesce(p.withdrawals_blocked, false))))
     and (p_query is null or p_query = ''
          or p.email ilike '%' || p_query || '%'
          or p.full_name ilike '%' || p_query || '%');

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', p.id, 'email', p.email, 'full_name', p.full_name,
      'avatar_url', p.avatar_url, 'status', p.status,
      'admin_role', p.admin_role,
      'suspension_kind', p.suspension_kind,
      'suspension_reason', p.suspension_reason,
      'suspension_note', p.suspension_note,
      'suspension_expires_at', p.suspension_expires_at,
      'suspended_at', p.suspended_at,
      'appeal_allowed', p.suspension_appeal_allowed,
      'withdrawals_blocked', p.withdrawals_blocked,
      'available', coalesce(w.available, 0),
      'pending', coalesce(w.pending, 0)
    ) x
      from public.profiles p
      left join public.wallets w on w.user_id = p.id
     where ((p_mode = 'suspended' and p.status = 'suspended')
         or (p_mode = 'banned' and p.status = 'banned')
         or (p_mode = 'restricted' and coalesce(p.withdrawals_blocked, false))
         or (p_mode = 'all' and (p.status <> 'active' or coalesce(p.withdrawals_blocked, false))))
       and (p_query is null or p_query = ''
            or p.email ilike '%' || p_query || '%'
            or p.full_name ilike '%' || p_query || '%')
     order by p.updated_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

-- keep the older status RPC consistent with the rich suspension fields
create or replace function public.admin_set_user_status(
  p_user_id uuid, p_status text, p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR']) then raise exception 'FORBIDDEN'; end if;
  if p_user_id = auth.uid() then raise exception 'CANNOT_MODERATE_SELF'; end if;
  if p_status not in ('active','suspended','banned') then raise exception 'INVALID_STATUS'; end if;
  if not exists (select 1 from public.profiles where id = p_user_id) then raise exception 'USER_NOT_FOUND'; end if;

  update public.profiles
     set status = p_status,
         is_suspended = (p_status <> 'active'),
         suspension_kind = case when p_status = 'active' then null else coalesce(suspension_kind, 'permanent') end,
         suspension_reason = case when p_status = 'active' then null else coalesce(suspension_reason, nullif(trim(coalesce(p_reason, '')), ''), 'Account ' || p_status) end,
         suspended_at = case when p_status = 'active' then null else coalesce(suspended_at, now()) end,
         suspension_expires_at = case when p_status = 'active' then null else suspension_expires_at end,
         withdrawals_blocked = case when p_status = 'active' then false else withdrawals_blocked end,
         updated_at = now()
   where id = p_user_id;

  if p_status <> 'active' then
    update public.tasks
       set status = 'available', worker_id = null, claimed_at = null, expires_at = null
     where worker_id = p_user_id and status = 'claimed';
    perform public.notify_user(p_user_id, 'Account ' || p_status,
      coalesce(nullif(trim(coalesce(p_reason, '')), ''), 'Contact support for details.'),
      'error', '#/support');
  else
    perform public.notify_user(p_user_id, 'Account restored',
      'Your account is active again.', 'success', '#/dashboard');
  end if;

  perform public.audit('user.status', 'profile', p_user_id,
    jsonb_build_object('status', p_status, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

-- ---------------------------------------------------------------------------
-- Automation engine: jobs, runs, safe execution. No wallet mutations here.
-- ---------------------------------------------------------------------------
create table if not exists public.automation_jobs (
  key text primary key,
  name text not null,
  description text,
  schedule_minutes int not null default 60,
  enabled boolean not null default true,
  last_run_at timestamptz,
  last_status text,
  last_error text,
  runs int not null default 0,
  failures int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.automation_runs (
  id uuid primary key default gen_random_uuid(),
  job_key text not null,
  status text not null check (status in ('success','failed','skipped')),
  trigger text not null default 'manual',
  summary jsonb,
  error text,
  started_at timestamptz not null default now(),
  finished_at timestamptz
);

create index if not exists automation_runs_job_idx on public.automation_runs (job_key, started_at desc);

alter table public.automation_jobs enable row level security;
alter table public.automation_runs enable row level security;
grant all on public.automation_jobs to service_role;
grant all on public.automation_runs to service_role;

insert into public.automation_jobs (key, name, description, schedule_minutes) values
  ('expire_tasks', 'Expire abandoned claims', 'Moves claims past their window to expired.', 10),
  ('restore_suspensions', 'Restore expired suspensions', 'Reactivates temporary suspensions whose expiry has passed.', 15),
  ('duplicate_proofs', 'Detect duplicate proofs', 'Flags identical proof screenshots for review.', 30),
  ('pending_proofs_alert', 'Remind admins about pending proofs', 'One digest per day for proofs older than 6 hours.', 240),
  ('campaign_limits', 'Check campaign limits', 'Flags campaigns that reached their target while still active.', 60),
  ('telegram_failures', 'Retry failed notifications', 'Requeues safe Telegram failures and alerts admins.', 15),
  ('suspicious_users', 'Detect repeated rejections', 'Flags workers with 5+ rejected proofs in 7 days.', 180),
  ('daily_report', 'Daily platform report', 'Sends owners a summary of the platform.', 1440)
on conflict (key) do update
  set name = excluded.name, description = excluded.description, schedule_minutes = excluded.schedule_minutes;

create or replace function public.automation_execute(
  p_job text default null, p_trigger text default 'manual'
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  j record;
  v_status text;
  v_error text;
  v_sum jsonb;
  v_results jsonb := '[]'::jsonb;
  v_count int;
  v_start timestamptz;
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if coalesce(p_job, '') = '' and not public.setting_bool('automation_enabled', false) then
    return jsonb_build_object('ok', false, 'reason', 'AUTOMATION_DISABLED');
  end if;

  for j in
    select * from public.automation_jobs
     where (coalesce(p_job, '') = '' and enabled) or key = p_job
     order by key
  loop
    v_status := 'success';
    v_error := null;
    v_sum := '{}'::jsonb;
    v_start := now();

    begin
      if j.key = 'expire_tasks' then
        v_sum := jsonb_build_object('expired', public.expire_stale_tasks());

      elsif j.key = 'restore_suspensions' then
        v_sum := jsonb_build_object('restored', public.restore_expired_suspensions());

      elsif j.key = 'duplicate_proofs' then
        with dup as (
          select proof_hash from public.submissions
           where proof_hash is not null
           group by proof_hash having count(*) > 1
        )
        insert into public.fraud_flags (user_id, kind, severity, details, ref_id)
        select s.worker_id, 'duplicate_proof', 2,
               jsonb_build_object('proof_hash', s.proof_hash), s.id
          from public.submissions s
          join dup d on d.proof_hash = s.proof_hash
         where not exists (
           select 1 from public.fraud_flags f
            where f.kind = 'duplicate_proof'
              and f.details ->> 'proof_hash' = s.proof_hash
         )
         limit 50;
        get diagnostics v_count = row_count;
        v_sum := jsonb_build_object('flagged', v_count);

      elsif j.key = 'pending_proofs_alert' then
        select count(*) into v_count from public.submissions
         where status = 'pending' and created_at < now() - interval '6 hours';
        if v_count > 0 then
          insert into public.notifications (user_id, title, body, kind, link)
          select p.id, 'Proofs waiting for review',
                 v_count || ' proof(s) have been waiting more than 6 hours.',
                 'info', '#/admin/proofs'
            from public.profiles p
           where p.admin_role in ('OWNER','SUPER_ADMIN','ADMIN','VERIFIER')
             and p.status = 'active'
             and not exists (
               select 1 from public.notifications n
                where n.user_id = p.id
                  and n.title = 'Proofs waiting for review'
                  and n.created_at::date = current_date
             );
        end if;
        v_sum := jsonb_build_object('old_pending', v_count);

      elsif j.key = 'campaign_limits' then
        select count(*) into v_count from public.campaigns c
         where c.status = 'active' and c.approved_count >= c.quantity;
        v_sum := jsonb_build_object('over_limit', v_count);

      elsif j.key = 'telegram_failures' then
        update public.telegram_outbox
           set status = 'queued', last_error = null, attempted_at = null
         where status = 'failed' and attempts < 3;
        get diagnostics v_count = row_count;
        v_sum := jsonb_build_object('requeued', v_count);

      elsif j.key = 'suspicious_users' then
        insert into public.fraud_flags (user_id, kind, severity, details)
        select s.worker_id, 'high_rejection_rate', 2,
               jsonb_build_object('rejected_last_7_days', count(*))
          from public.submissions s
         where s.status = 'rejected'
           and s.created_at >= now() - interval '7 days'
         group by s.worker_id
        having count(*) >= 5
           and not exists (
             select 1 from public.fraud_flags f
              where f.user_id = s.worker_id
                and f.kind = 'high_rejection_rate'
                and f.status in ('open','reviewing')
           );
        get diagnostics v_count = row_count;
        v_sum := jsonb_build_object('flagged', v_count);

      elsif j.key = 'daily_report' then
        v_sum := jsonb_build_object(
          'users', (select count(*) from public.profiles),
          'new_users', (select count(*) from public.profiles where created_at::date = current_date),
          'proofs_pending', (select count(*) from public.submissions where status = 'pending'),
          'approved_today', (select count(*) from public.tasks where status = 'approved' and reviewed_at::date = current_date),
          'withdrawals_open', (select count(*) from public.withdrawals where status in ('pending','approved','processing')),
          'deposits_pending', (select count(*) from public.deposits where status = 'pending'),
          'suspended', (select count(*) from public.profiles where status = 'suspended')
        );
        insert into public.notifications (user_id, title, body, kind, link)
        select p.id, 'Daily platform report',
               'Users ' || (v_sum ->> 'users') ||
               ' · new today ' || (v_sum ->> 'new_users') ||
               ' · proofs pending ' || (v_sum ->> 'proofs_pending') ||
               ' · withdrawals open ' || (v_sum ->> 'withdrawals_open'),
               'info', '#/admin/system'
          from public.profiles p
         where p.admin_role in ('OWNER','SUPER_ADMIN') and p.status = 'active';
      end if;
    exception when others then
      v_status := 'failed';
      v_error := sqlerrm;
    end;

    insert into public.automation_runs (job_key, status, trigger, summary, error, started_at, finished_at)
    values (j.key, v_status, coalesce(p_trigger, 'manual'), v_sum, v_error, v_start, now());

    update public.automation_jobs
       set last_run_at = now(),
           last_status = v_status,
           last_error = v_error,
           runs = runs + 1,
           failures = failures + case when v_status = 'failed' then 1 else 0 end,
           updated_at = now()
     where key = j.key;

    v_results := v_results || jsonb_build_array(jsonb_build_object(
      'job', j.key, 'status', v_status, 'summary', v_sum, 'error', v_error));
  end loop;

  return jsonb_build_object('ok', true, 'job', p_job, 'results', v_results);
end $$;

create or replace function public.automation_overview()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  return jsonb_build_object(
    'enabled', public.setting_bool('automation_enabled', false),
    'jobs', (
      select coalesce(jsonb_agg(to_jsonb(j) order by j.key), '[]'::jsonb)
        from public.automation_jobs j
    ),
    'counts', jsonb_build_object(
      'jobs', (select count(*) from public.automation_jobs),
      'enabled', (select count(*) from public.automation_jobs where enabled),
      'success', (select count(*) from public.automation_runs where status = 'success'),
      'failed', (select count(*) from public.automation_runs where status = 'failed'),
      'runs_today', (select count(*) from public.automation_runs where started_at::date = current_date)
    ),
    'runs', (
      select coalesce(jsonb_agg(to_jsonb(r) order by r.started_at desc), '[]'::jsonb)
        from (select * from public.automation_runs order by started_at desc limit 40) r
    ),
    'next_run', (
      select min(coalesce(last_run_at, now() - interval '1 hour')
                 + make_interval(mins => schedule_minutes))
        from public.automation_jobs where enabled
    )
  );
end $$;

create or replace function public.automation_set_job(p_key text, p_enabled boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  update public.automation_jobs
     set enabled = coalesce(p_enabled, true), updated_at = now()
   where key = p_key;
  if not found then raise exception 'JOB_NOT_FOUND'; end if;
  perform public.audit('automation.job', 'automation_job', null,
    jsonb_build_object('key', p_key, 'enabled', p_enabled));
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.restore_expired_suspensions() from public, anon, authenticated;
revoke all on function public.assert_account_active(uuid, text) from public, anon, authenticated;
revoke all on function public.tg_block_suspended_activity() from public, anon, authenticated;
revoke all on function public.automation_execute(text, text) from public, anon, authenticated;
grant execute on function public.automation_execute(text, text) to service_role, authenticated;

-- ----------------------------------------------------------------------------
-- 18. SEED: services, countries, settings
-- ----------------------------------------------------------------------------
insert into public.services (platform, name, description, default_reward, min_reward, min_quantity, max_quantity, sort_order)
values
  ('youtube',   'YouTube Subscribe', 'Subscribe to the channel and keep the subscription for at least 30 days.', 0.050, 0.020, 10, 20000, 10),
  ('youtube',   'YouTube Watch + Like', 'Watch the video for at least 60 seconds, then like it.', 0.040, 0.015, 10, 20000, 20),
  ('instagram', 'Instagram Follow', 'Follow the profile and stay followed for at least 30 days.', 0.040, 0.015, 10, 20000, 30),
  ('instagram', 'Instagram Like', 'Like the specified post from your own account.', 0.025, 0.010, 10, 20000, 40),
  ('tiktok',    'TikTok Follow', 'Follow the account and keep it for at least 30 days.', 0.040, 0.015, 10, 20000, 50),
  ('tiktok',    'TikTok Watch + Like', 'Watch the video and like it from your own account.', 0.030, 0.010, 10, 20000, 60),
  ('facebook',  'Facebook Page Like', 'Like the page and keep the like for at least 30 days.', 0.030, 0.010, 10, 20000, 70),
  ('x',         'X Follow', 'Follow the account from your own X profile.', 0.030, 0.010, 10, 20000, 80),
  ('x',         'X Repost', 'Repost the specified post from your own account.', 0.035, 0.015, 10, 20000, 90),
  ('telegram',  'Telegram Channel Join', 'Join the channel and stay for at least 14 days.', 0.020, 0.008, 10, 20000, 100),
  ('reddit',    'Reddit Upvote + Comment', 'Upvote the post and leave a genuine, relevant comment.', 0.120, 0.050, 10, 10000, 110),
  ('spotify',   'Spotify Follow + Save', 'Follow the artist and save the track to your library.', 0.030, 0.010, 10, 10000, 120),
  ('discord',   'Discord Server Join', 'Join the server and remain a member for at least 14 days.', 0.020, 0.008, 10, 20000, 130),
  ('website',   'Website Visit', 'Open the link, stay for 30 seconds and complete the requested action.', 0.010, 0.005, 10, 20000, 140)
on conflict (platform, name) do nothing;

insert into public.countries (code, name) values
  ('BD','Bangladesh'), ('IN','India'), ('PK','Pakistan'), ('ID','Indonesia'),
  ('NG','Nigeria'), ('PH','Philippines'), ('VN','Vietnam'), ('BR','Brazil'),
  ('EG','Egypt'), ('TR','Turkey'), ('AE','United Arab Emirates'), ('SA','Saudi Arabia'),
  ('GB','United Kingdom'), ('US','United States'), ('DE','Germany'), ('FR','France'),
  ('ES','Spain'), ('IT','Italy'), ('RU','Russia'), ('MY','Malaysia')
on conflict (code) do nothing;

insert into public.settings (key, value, is_public) values
  ('withdrawal_min', '2'::jsonb, true),
  ('withdrawal_network', '"BEP20"'::jsonb, true),
  ('network_name', '"BNB Smart Chain (BEP-20)"'::jsonb, true),
  ('withdrawal_fee_pct', '5'::jsonb, true),
  ('withdrawal_fee_free_min', '5'::jsonb, true),
  ('campaign_fee_pct', '10'::jsonb, true),
  ('referral_commission_pct', '10'::jsonb, false),
  ('auto_approve_campaigns', 'true'::jsonb, false),
  ('claim_window_minutes', '30'::jsonb, false),
  ('min_deposit', '5'::jsonb, true),
  ('max_open_withdrawals', '3'::jsonb, false),
  ('deposit_address', '"0xaa23b4c36b00a1edefb4b12449a472de56cb843f"'::jsonb, true),
  ('support_email', '""'::jsonb, true),
  ('announcement', '""'::jsonb, true),
  ('owner_email', '"mdn29930@gmail.com"'::jsonb, false),
  ('maintenance', 'false'::jsonb, true),
  ('coin_name', '"TG Coin"'::jsonb, true),
  ('coin_symbol', '"TG"'::jsonb, true),
  ('tg_per_task', '1'::jsonb, true),
  ('daily_checkin_tg', '0.5'::jsonb, true),
  ('tg_per_checkin', '0.5'::jsonb, false),
  ('high_value_min', '0.05'::jsonb, true)
on conflict (key) do nothing;

-- keep the deposit address present on databases seeded before this update
update public.settings
   set value = '"0xaa23b4c36b00a1edefb4b12449a472de56cb843f"'::jsonb, updated_at = now()
 where key = 'deposit_address'
   and coalesce(value #>> '{}', '') = '';

-- Backfill wallets for existing profiles and legacy users
insert into public.wallets (user_id)
select p.id from public.profiles p
 left join public.wallets w on w.user_id = p.id
 where w.user_id is null
on conflict (user_id) do nothing;

insert into public.profiles (id, email, full_name, avatar_url, role, is_suspended, referral_code)
select u.id, u.email,
       coalesce(u.raw_user_meta_data ->> 'full_name', u.raw_user_meta_data ->> 'name',
                split_part(coalesce(u.email, 'worker'), '@', 1)),
       coalesce(u.raw_user_meta_data ->> 'avatar_url', u.raw_user_meta_data ->> 'picture'),
       'worker', false,
       'TM' || upper(substr(replace(u.id::text, '-', ''), 1, 8))
  from auth.users u
  left join public.profiles p on p.id = u.id
 where p.id is null
on conflict (id) do nothing;

insert into public.wallets (user_id)
select p.id from public.profiles p
 left join public.wallets w on w.user_id = p.id
 where w.user_id is null
on conflict (user_id) do nothing;

-- ----------------------------------------------------------------------------
-- 19. EXECUTE GRANTS (authenticated RPC surface only)
-- ----------------------------------------------------------------------------
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname in (
         'my_context','get_public_settings','public_stats','update_my_profile',
         'enable_buyer_mode','enable_buyer_mode','apply_referral',
         'list_available_tasks','get_task','claim_task','release_task','submit_proof','my_tasks',
         'request_withdrawal','leaderboard_weekly','mark_notifications_read',
         'create_support_ticket','list_my_tickets','get_ticket','reply_support_ticket',
         'create_campaign','list_my_campaigns','get_my_campaign','set_campaign_status',
         'request_deposit','submit_verified_deposit','my_identities','refresh_my_identity',
         'checkin_status','claim_daily_checkin','daily_checkin','recent_payouts','recent_activity',
         'my_social_accounts','link_social_account','unlink_social_account','refresh_social_account',
         'start_social_verification','submit_social_verification',
         'admin_list_social_accounts','admin_verify_social_account',
         'review_submission','admin_review_deposit','admin_review_withdrawal',
         'admin_list_withdrawals','admin_list_deposits','admin_overview',
         'admin_list_users','admin_user_detail','admin_set_user_status',
         'admin_set_admin_role','admin_list_tasks','admin_list_campaigns',
         'admin_review_campaign','admin_list_submissions','admin_list_ledger',
         'admin_adjust_balance','admin_upsert_service','admin_list_services',
         'admin_upsert_country','admin_list_countries','admin_get_settings',
         'admin_update_setting','admin_list_admins','admin_list_audit',
         'admin_list_referrals','admin_broadcast','admin_list_tickets',
         'admin_ticket_reply','admin_list_flags','admin_resolve_flag',
         'admin_ai_snapshot',
         'my_telegram_status','set_my_telegram_notifications',
         'admin_telegram_overview','admin_telegram_list','admin_telegram_retry',
         'admin_create_task_slots','admin_set_task_status',
         'claim_owner','admin_wallet_overview','admin_system_status',
         'my_suspension','admin_suspend_user','admin_restore_user',
         'admin_suspended_users','automation_overview','automation_set_job'
       )
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated', f.sig);
  end loop;
end $$;

-- public landing stats / public settings are readable by anonymous visitors
grant execute on function public.public_stats() to anon, authenticated;
grant execute on function public.get_public_settings() to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 20. FIRST OWNER
-- Sign in once through TM GROW, then run this with your own email:
--
--   update public.profiles
--      set admin_role = 'OWNER', status = 'active'
--    where lower(email) = lower('mdn29930@gmail.com');
--
-- Verify with:
--   select id, email, admin_role, status from public.profiles;
-- ----------------------------------------------------------------------------
