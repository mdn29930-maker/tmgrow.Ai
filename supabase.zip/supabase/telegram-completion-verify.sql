-- ============================================================================
-- TM GROW — TELEGRAM TASK-COMPLETION VERIFICATION (read-only)
--
-- Run after supabase/telegram-completion-fix.sql.
-- Every statement is a SELECT. Nothing is sent, queued or changed.
-- ============================================================================

-- 1. Trigger layout ---------------------------------------------------------
--    Expect: submit_trigger_present = false,
--            completion_trigger_present = true,
--            completion_trigger_deferred = true.
select
  exists (select 1 from pg_trigger
           where tgname = 'tg_notify_task_submitted'
             and tgrelid = 'public.submissions'::regclass)  as submit_trigger_present,
  exists (select 1 from pg_trigger
           where tgname = 'submissions_task_completed_tg'
             and tgrelid = 'public.submissions'::regclass)  as completion_trigger_present,
  exists (select 1 from pg_trigger
           where tgname = 'submissions_task_completed_tg'
             and tgrelid = 'public.submissions'::regclass
             and tgdeferrable)                              as completion_trigger_deferred;

-- 2. Settings ---------------------------------------------------------------
select key, value
  from public.settings
 where key in ('telegram_bot_enabled',
               'telegram_notify_task_submitted',
               'telegram_notify_task_approved',
               'telegram_notify_task_completed',
               'telegram_http_timeout_ms',
               'telegram_max_attempts',
               'telegram_api_base')
 order by key;

-- 3. Delivery states in use -------------------------------------------------
select status, count(*) as rows, max(attempts) as max_attempts
  from public.telegram_outbox
 group by status
 order by status;

-- 4. Exactly one task_completed row per submission --------------------------
--    duplicates should be 0 for every row.
select dedupe_key, count(*) as rows
  from public.telegram_outbox
 where kind = 'task_completed'
 group by dedupe_key
 having count(*) > 1;

-- 5. Recent deliveries with real HTTP result -------------------------------
select created_at, kind, status, attempts, http_status,
       error_class, message_id, sent_at, next_attempt_at,
       left(coalesce(last_error, ''), 160) as last_error
  from public.telegram_outbox
 order by created_at desc
 limit 25;

-- 6. Did any message get queued by a submission insert? --------------------
--    Expect 0: submission events must not exist any more.
select count(*) as task_submitted_rows
  from public.telegram_outbox
 where kind = 'task_submitted';

-- 7. Ledger / outbox agreement for recent approvals ------------------------
--    Every task_completed row should have a matching reward credit.
select o.dedupe_key, o.status, o.http_status,
       (o.dedupe_key like 'task_completed:%') as is_completion,
       exists (
         select 1 from public.ledger_entries l
          where l.ref_type = 'submission'
            and l.ref_id = replace(o.dedupe_key, 'task_completed:', '')::uuid
            and coalesce(l.available_delta, 0) > 0
       ) as credit_exists
  from public.telegram_outbox o
 where o.kind = 'task_completed'
 order by o.created_at desc
 limit 20;

-- ============================================================================
-- SAFE MANUAL TEST (do this in order, then rerun the queries above)
--
-- A. Submit proof on a test task, then:
--       select count(*) from public.telegram_outbox where kind = 'task_submitted';
--    Expected: 0.
--
-- B. Reject that proof in Admin → Proof verification, then:
--       select count(*) from public.telegram_outbox
--        where kind = 'task_completed' and created_at > now() - interval '5 min';
--    Expected: 0 (the rejection is not a completion).
--
-- C. Approve another pending proof (reward credited), then:
--       select kind, status, attempts, http_status, last_error
--         from public.telegram_outbox order by created_at desc limit 3;
--    Expected: exactly ONE task_completed row for that submission. It moves
--    queued → sending → sent (http_status 200) or retrying with a backoff.
--
-- D. Admin → Telegram → Send queued now, twice. Expected: no extra row, no
--    duplicate message (dedupe_key unique, status becomes sent once).
--
-- E. Simulate a transient failure by pointing the sender at an unreachable
--    host for one attempt:
--       update public.settings set value = to_jsonb('https://10.255.255.1'::text)
--        where key = 'telegram_api_base';
--       select public.admin_telegram_drain(5);
--    Expected: row status = 'retrying', error_class = 'transient', next_attempt_at set.
--    Restore immediately:
--       update public.settings set value = to_jsonb('https://api.telegram.org'::text)
--        where key = 'telegram_api_base';
--       select public.admin_telegram_retry('<outbox id>');
--
-- F. Real delivery: Admin → Telegram → Send test message, then check the row
--    is sent with http_status 200 and a message_id.
-- ============================================================================
