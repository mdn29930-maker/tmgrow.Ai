-- The SQL editor has no JWT, so my_context() (which calls auth.uid()) must not
-- be invoked unauthenticated: it would raise UNAUTHENTICATED and roll back the
-- batch. Test it from the app, or set request.jwt.claims first.
select case
         when auth.uid() is null
           then jsonb_build_object('authenticated', false,
                                   'note', 'No JWT in SQL editor — my_context is exercised by the app after sign-in.')
         else public.my_context()
       end as my_context_result;

select to_regclass('public.profiles') as profiles,
       to_regclass('public.wallets') as wallets,
       to_regclass('public.settings') as settings,
       to_regclass('public.tasks') as tasks,
       to_regclass('public.campaigns') as campaigns,
       to_regclass('public.submissions') as submissions,
       to_regclass('public.ledger_entries') as ledger_entries,
       to_regclass('public.telegram_outbox') as telegram_outbox;

select count(*) as settings_rows from public.settings;
select key, value, is_public from public.settings
 where key in ('owner_email', 'maintenance', 'deposit_address', 'coin_name')
 order by key;

select proname
  from pg_proc
 where pronamespace = 'public'::regnamespace
   and proname in (
     'my_context','ensure_profile','get_public_settings','public_stats',
     'claim_owner','my_suspension','record_login_event',
     'admin_user_detail','admin_suspend_user','admin_restore_user',
     'admin_suspended_users','admin_freeze_wallet','admin_add_note',
     'admin_scan_fraud','admin_fraud_overview','admin_system_status',
     'admin_wallet_overview','automation_overview'
   )
 order by proname;

select column_name
  from information_schema.columns
 where table_schema = 'public'
   and table_name = 'profiles'
   and column_name like 'suspension%'
 order by column_name;

notify pgrst, 'reload schema';
