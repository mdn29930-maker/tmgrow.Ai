-- ============================================================================
-- TM GROW — ADMIN RBAC, TASK DEDUPE, BULK CONTROL (additive, idempotent)
--
-- READ BEFORE RUNNING. The agent has executed nothing.
--
-- Part 1 root cause
--   is_admin() is true for ANY non-null admin_role, and the panel/route guard
--   and many RPCs use is_admin() as "full admin". A MODERATOR therefore opens
--   every /admin page whose view lists all roles, and passes any RPC that only
--   checks is_admin(). This migration adds a real permission matrix, a guarded
--   role-change path, and a defence-in-depth trigger on profiles.admin_role.
--
-- Part 2 root cause
--   list_available_tasks() excludes only tasks that already have a submission
--   by this worker (sub.task_id = t.id). review_submission() refills a NEW
--   available task row for the same campaign, so the worker sees the same
--   campaign/target again. claim_task() has no per-campaign guard either.
--   Fix: one attempt per campaign per worker, enforced in both functions.
--
-- Part 3: bulk campaign/task actions with audit, no deletes, no refunds.
-- ============================================================================

begin;

-- ============================================================================
-- 1. PERMISSION MATRIX
-- ============================================================================
create table if not exists public.admin_permissions (
  role text not null,
  permission text not null,
  primary key (role, permission)
);

alter table public.admin_permissions enable row level security;

insert into public.admin_permissions (role, permission) values
  -- OWNER: everything
  ('OWNER','dashboard.view'),('OWNER','users.view'),('OWNER','users.edit'),
  ('OWNER','workers.view'),('OWNER','buyers.view'),('OWNER','tasks.view'),
  ('OWNER','tasks.manage'),('OWNER','campaigns.view'),('OWNER','campaigns.manage'),
  ('OWNER','smm.view'),('OWNER','smm.manage'),('OWNER','drip.manage'),
  ('OWNER','verification.view'),('OWNER','verification.decide'),
  ('OWNER','wallets.view'),('OWNER','wallets.edit'),('OWNER','ledger.view'),
  ('OWNER','deposits.view'),('OWNER','deposits.approve'),
  ('OWNER','withdrawals.view'),('OWNER','withdrawals.approve'),
  ('OWNER','referrals.view'),('OWNER','support.view'),('OWNER','support.reply'),
  ('OWNER','notifications.send'),('OWNER','countries.manage'),
  ('OWNER','fraud.view'),('OWNER','fraud.manage'),('OWNER','analytics.view'),
  ('OWNER','settings.manage'),('OWNER','admins.view'),('OWNER','admins.manage'),
  ('OWNER','rbac.manage'),('OWNER','audit.view'),('OWNER','bulk.manage'),
  -- SUPER_ADMIN: broad operations, no OWNER/SECURITY
  ('SUPER_ADMIN','dashboard.view'),('SUPER_ADMIN','users.view'),('SUPER_ADMIN','users.edit'),
  ('SUPER_ADMIN','workers.view'),('SUPER_ADMIN','buyers.view'),('SUPER_ADMIN','tasks.view'),
  ('SUPER_ADMIN','tasks.manage'),('SUPER_ADMIN','campaigns.view'),('SUPER_ADMIN','campaigns.manage'),
  ('SUPER_ADMIN','smm.view'),('SUPER_ADMIN','smm.manage'),('SUPER_ADMIN','drip.manage'),
  ('SUPER_ADMIN','verification.view'),('SUPER_ADMIN','verification.decide'),
  ('SUPER_ADMIN','wallets.view'),('SUPER_ADMIN','ledger.view'),
  ('SUPER_ADMIN','deposits.view'),('SUPER_ADMIN','deposits.approve'),
  ('SUPER_ADMIN','withdrawals.view'),('SUPER_ADMIN','withdrawals.approve'),
  ('SUPER_ADMIN','referrals.view'),('SUPER_ADMIN','support.view'),('SUPER_ADMIN','support.reply'),
  ('SUPER_ADMIN','notifications.send'),('SUPER_ADMIN','countries.manage'),
  ('SUPER_ADMIN','fraud.view'),('SUPER_ADMIN','fraud.manage'),('SUPER_ADMIN','analytics.view'),
  ('SUPER_ADMIN','admins.view'),('SUPER_ADMIN','admins.manage'),('SUPER_ADMIN','audit.view'),
  ('SUPER_ADMIN','bulk.manage'),
  -- ADMIN: operations, no RBAC, no admin role management, no wallets.edit
  ('ADMIN','dashboard.view'),('ADMIN','users.view'),('ADMIN','users.edit'),
  ('ADMIN','workers.view'),('ADMIN','buyers.view'),('ADMIN','tasks.view'),
  ('ADMIN','tasks.manage'),('ADMIN','campaigns.view'),('ADMIN','campaigns.manage'),
  ('ADMIN','smm.view'),('ADMIN','smm.manage'),('ADMIN','drip.manage'),
  ('ADMIN','verification.view'),('ADMIN','verification.decide'),
  ('ADMIN','wallets.view'),('ADMIN','ledger.view'),
  ('ADMIN','deposits.view'),('ADMIN','deposits.approve'),
  ('ADMIN','withdrawals.view'),('ADMIN','referrals.view'),
  ('ADMIN','support.view'),('ADMIN','support.reply'),('ADMIN','notifications.send'),
  ('ADMIN','countries.manage'),('ADMIN','fraud.view'),('ADMIN','analytics.view'),
  ('ADMIN','admins.view'),('ADMIN','audit.view'),('ADMIN','bulk.manage'),
  -- MODERATOR: moderation only
  ('MODERATOR','dashboard.view'),('MODERATOR','users.view'),('MODERATOR','workers.view'),
  ('MODERATOR','tasks.view'),('MODERATOR','campaigns.view'),('MODERATOR','verification.view'),
  ('MODERATOR','verification.decide'),('MODERATOR','fraud.view'),('MODERATOR','fraud.manage'),
  ('MODERATOR','support.view'),('MODERATOR','analytics.view'),
  -- VERIFIER: proofs only
  ('VERIFIER','dashboard.view'),('VERIFIER','verification.view'),
  ('VERIFIER','verification.decide'),('VERIFIER','tasks.view'),
  -- SUPPORT: tickets + read-only users
  ('SUPPORT','dashboard.view'),('SUPPORT','users.view'),('SUPPORT','support.view'),
  ('SUPPORT','support.reply'),('SUPPORT','notifications.send'),('SUPPORT','analytics.view'),
  -- FINANCE: money only
  ('FINANCE','dashboard.view'),('FINANCE','wallets.view'),('FINANCE','ledger.view'),
  ('FINANCE','deposits.view'),('FINANCE','deposits.approve'),
  ('FINANCE','withdrawals.view'),('FINANCE','withdrawals.approve'),
  ('FINANCE','referrals.view'),('FINANCE','analytics.view'),('FINANCE','audit.view')
on conflict (role, permission) do nothing;

create or replace function public.has_permission(p_permission text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
      from public.profiles p
      join public.admin_permissions m on m.role = p.admin_role
     where p.id = auth.uid()
       and p.status = 'active'
       and m.permission = p_permission
  );
$$;

revoke all on function public.has_permission(text) from public, anon;
grant execute on function public.has_permission(text) to authenticated;

create or replace function public.my_permissions()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  v_role text;
  v_perms jsonb := '[]'::jsonb;
begin
  if u is null then return jsonb_build_object('role', null, 'permissions', '[]'::jsonb); end if;

  select admin_role into v_role from public.profiles where id = u and status = 'active';

  if v_role is not null then
    select coalesce(jsonb_agg(permission order by permission), '[]'::jsonb)
      into v_perms
      from public.admin_permissions where role = v_role;
  end if;

  return jsonb_build_object('role', v_role, 'permissions', v_perms);
end $$;

revoke all on function public.my_permissions() from public, anon;
grant execute on function public.my_permissions() to authenticated;

-- ============================================================================
-- 2. ROLE CHANGE: guarded + audited + no self-escalation
-- ============================================================================
create or replace function public.tg_guard_admin_role()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_actor uuid := auth.uid();
  v_actor_role text;
begin
  if new.admin_role is not distinct from old.admin_role then return new; end if;

  /* Schedulers / service role / SQL editor have no JWT: allowed (bootstrap,
     claim_owner, migrations). API callers are checked below. */
  if v_actor is null or auth.role() = 'service_role' then
    insert into public.audit_logs (actor_id, actor_role, action, entity_type, entity_id, details)
    values (v_actor, 'system', 'admin.role.system', 'profile', new.id,
            jsonb_build_object('old_role', old.admin_role, 'new_role', new.admin_role));
    return new;
  end if;

  select admin_role into v_actor_role from public.profiles where id = v_actor and status = 'active';

  /* Bootstrap: a user with no admin role claiming OWNER for themselves is only
     allowed when claim_owner() passed its own email/uid check. */
  if old.admin_role is null and new.admin_role = 'OWNER' and v_actor = new.id then
    return new;
  end if;

  if v_actor = new.id then
    raise exception 'CANNOT_CHANGE_OWN_ROLE';
  end if;

  if v_actor_role is distinct from 'OWNER'
     and (new.admin_role in ('OWNER','SUPER_ADMIN') or old.admin_role in ('OWNER','SUPER_ADMIN')) then
    raise exception 'FORBIDDEN_OWNER_CHANGE';
  end if;

  if v_actor_role not in ('OWNER','SUPER_ADMIN') then
    raise exception 'FORBIDDEN_ROLE_CHANGE';
  end if;

  insert into public.audit_logs (actor_id, actor_role, action, entity_type, entity_id, details)
  values (v_actor, v_actor_role, 'admin.role', 'profile', new.id,
          jsonb_build_object('old_role', old.admin_role, 'new_role', new.admin_role));
  return new;
end $$;

revoke all on function public.tg_guard_admin_role() from public, anon, authenticated;

drop trigger if exists profiles_guard_admin_role on public.profiles;
create trigger profiles_guard_admin_role
  before update of admin_role on public.profiles
  for each row execute function public.tg_guard_admin_role();

create or replace function public.admin_set_admin_role(
  p_user_id uuid, p_admin_role text, p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_old text;
  v_reason text := nullif(btrim(coalesce(p_reason, '')), '');
begin
  if not public.has_permission('admins.manage') then raise exception 'FORBIDDEN'; end if;
  if p_admin_role is not null and p_admin_role not in
     ('OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER','SUPPORT','FINANCE') then
    raise exception 'INVALID_ROLE';
  end if;
  if v_reason is null then raise exception 'REASON_REQUIRED'; end if;

  select admin_role into v_old from public.profiles where id = p_user_id for update;
  if not found then raise exception 'USER_NOT_FOUND'; end if;

  update public.profiles set admin_role = p_admin_role where id = p_user_id;

  perform public.audit('admin.role', 'profile', p_user_id,
    jsonb_build_object('old_role', v_old, 'new_role', p_admin_role, 'reason', v_reason,
                       'actor', auth.uid(), 'at', now()));
  perform public.notify_user(p_user_id, 'Admin role updated',
    'Your admin role is now: ' || coalesce(p_admin_role, 'none') || '.', 'info', '#/admin');
  return jsonb_build_object('ok', true, 'old_role', v_old, 'new_role', p_admin_role);
end $$;

revoke all on function public.admin_set_admin_role(uuid, text, text) from public, anon;
grant execute on function public.admin_set_admin_role(uuid, text, text) to authenticated;

-- Keep the old two-argument signature working for the current UI.
create or replace function public.admin_set_admin_role(p_user_id uuid, p_admin_role text)
returns jsonb language sql security definer set search_path = public as $$
  select public.admin_set_admin_role(p_user_id, p_admin_role, 'role changed from admin panel');
$$;

revoke all on function public.admin_set_admin_role(uuid, text) from public, anon;
grant execute on function public.admin_set_admin_role(uuid, text) to authenticated;

-- ============================================================================
-- 3. WORKER TASK DEDUPE (campaign level, one attempt per worker)
-- ============================================================================
create or replace function public.list_available_tasks(
  p_platform text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0,
  p_min_reward numeric default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  total int;
  items jsonb;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  perform public.expire_stale_tasks();

  select count(*) into total
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
    join public.services s on s.id = c.service_id
   where t.status = 'available'
     and t.worker_id is null
     and c.status = 'active'
     and t.reward >= coalesce(p_min_reward, 0)
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
     and (c.countries = '{}' or p.country_code = any (c.countries))
     and c.min_trust_score <= p.trust_score
     /* One attempt per campaign per worker: completed, claimed, submitted,
        rejected or expired — none of them come back. */
     and not exists (
       select 1 from public.tasks mine
        where mine.campaign_id = c.id
          and t.campaign_id is not null
          and (mine.worker_id = u or exists (
                select 1 from public.submissions sub
                 where sub.task_id = mine.id and sub.worker_id = u))
          and (mine.worker_id = u
               and mine.status in ('claimed','submitted','approved','rejected','expired'))
     );

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id,
      'reward', t.reward,
      'created_at', t.created_at,
      'campaign_id', c.id,
      'title', c.title,
      'instructions_preview', left(c.instructions, 140),
      'platform', s.platform,
      'service_name', s.name,
      'quantity_left', (select count(*) from public.tasks t2 where t2.campaign_id = c.id and t2.status = 'available'),
      'target_url', c.target_url,
      'requires_account', c.require_linked_account,
      'account_linked', exists (
        select 1 from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
      ),
      'account_cooldown_until', (
        select a.linked_at + interval '7 days' from public.social_accounts a
         where a.user_id = u and a.status = 'linked' and a.platform = s.platform
           and s.platform = 'x' and a.linked_at > now() - interval '7 days'
         limit 1
      ),
      'already_done', true
    ) as x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
     where t.status = 'available'
       and t.worker_id is null
       and c.status = 'active'
       and t.reward >= coalesce(p_min_reward, 0)
       and (p_platform is null or p_platform = '' or s.platform = p_platform)
       and (p_search is null or p_search = '' or c.title ilike '%' || p_search || '%' or s.name ilike '%' || p_search || '%')
       and (c.countries = '{}' or p.country_code = any (c.countries))
       and c.min_trust_score <= p.trust_score
       and not exists (
         select 1 from public.tasks mine
          where mine.campaign_id = c.id
            and mine.worker_id = u
            and mine.status in ('claimed','submitted','approved','rejected','expired')
       )
     order by t.reward desc, t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 20), 50))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;

revoke all on function public.list_available_tasks(text, text, int, int, numeric) from public, anon;
grant execute on function public.list_available_tasks(text, text, int, int, numeric) to authenticated;

-- Server-side guard: a worker cannot claim a second unit of a campaign.
create or replace function public.claim_task(p_task_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  c public.campaigns;
  p public.profiles;
  mins int;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_worker then raise exception 'WORKER_MODE_DISABLED'; end if;
  perform public.expire_stale_tasks();

  if (select count(*) from public.tasks where worker_id = u and status in ('claimed','submitted')) >= 25 then
    raise exception 'TOO_MANY_ACTIVE_TASKS';
  end if;

  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.status <> 'available' or t.worker_id is not null then raise exception 'TASK_UNAVAILABLE'; end if;

  select * into c from public.campaigns where id = t.campaign_id;
  if c.status <> 'active' then raise exception 'CAMPAIGN_NOT_ACTIVE'; end if;

  if exists (
    select 1 from public.tasks prev
     where prev.campaign_id = c.id
       and prev.worker_id = u
       and prev.status in ('claimed','submitted','approved','rejected','expired')
  ) then
    raise exception 'ALREADY_TAKEN_THIS_CAMPAIGN';
  end if;

  if p.trust_score < c.min_trust_score then raise exception 'TRUST_TOO_LOW'; end if;
  if c.countries <> '{}' and not (p.country_code = any (c.countries)) then
    raise exception 'NOT_ELIGIBLE_COUNTRY';
  end if;
  if c.approved_count >= c.quantity then raise exception 'CAMPAIGN_FULL'; end if;
  if c.require_linked_account and not exists (
    select 1 from public.social_accounts a
      join public.services sv on sv.platform = a.platform
     where a.user_id = u and a.status = 'linked' and sv.id = c.service_id
  ) then
    raise exception 'LINK_ACCOUNT_REQUIRED';
  end if;

  mins := greatest(5, least(coalesce(public.setting_num('claim_window_minutes', 30), 30), 240));
  update public.tasks
     set worker_id = u, status = 'claimed', claimed_at = now(),
         expires_at = now() + make_interval(mins => mins)
   where id = t.id and status = 'available' and worker_id is null;
  if not found then raise exception 'TASK_UNAVAILABLE'; end if;

  return jsonb_build_object('ok', true, 'task_id', t.id, 'expires_at', now() + make_interval(mins => mins));
end $$;

revoke all on function public.claim_task(uuid) from public, anon;
grant execute on function public.claim_task(uuid) to authenticated;

-- ============================================================================
-- 4. ADMIN BULK CAMPAIGN / TASK CONTROL (no deletes, no refunds)
-- ============================================================================
create or replace function public.admin_bulk_campaigns(p_action text, p_ids uuid[] default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ids uuid[];
  v_count int := 0;
  v_tasks int := 0;
  v_id uuid;
begin
  if not public.has_permission('bulk.manage') then raise exception 'FORBIDDEN'; end if;
  if p_action not in ('pause','resume','cancel') then raise exception 'INVALID_ACTION'; end if;

  select coalesce(array_agg(id), '{}'::uuid[]) into v_ids
    from public.campaigns
   where (p_ids is null or id = any (p_ids));

  if array_length(v_ids, 1) is null then
    return jsonb_build_object('ok', true, 'campaigns', 0, 'tasks', 0);
  end if;

  if p_action = 'cancel' then
    update public.tasks
       set status = 'cancelled'
     where campaign_id = any (v_ids) and status = 'available'
     returning 1 into v_tasks;
  end if;

  foreach v_id in array v_ids loop
    begin
      update public.campaigns
         set status = case p_action
                        when 'pause' then 'paused'
                        when 'resume' then 'active'
                        else 'cancelled' end,
             completed_at = case when p_action = 'cancel' then now() else completed_at end
       where id = v_id
         and status in ('active','paused','pending');
      if found then v_count := v_count + 1; end if;
    exception when others then
      null;
    end;
  end loop;

  select count(*) into v_tasks from public.tasks
   where campaign_id = any (v_ids) and status = 'cancelled';

  perform public.audit('admin.campaigns.bulk', 'campaign', null,
    jsonb_build_object('action', p_action, 'ids', v_ids, 'campaigns', v_count, 'cancelled_tasks', v_tasks));

  return jsonb_build_object('ok', true, 'action', p_action, 'campaigns', v_count, 'tasks', v_tasks);
end $$;

revoke all on function public.admin_bulk_campaigns(text, uuid[]) from public, anon;
grant execute on function public.admin_bulk_campaigns(text, uuid[]) to authenticated;

create or replace function public.admin_bulk_tasks(p_action text, p_ids uuid[] default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count int := 0;
begin
  if not public.has_permission('bulk.manage') then raise exception 'FORBIDDEN'; end if;
  if p_action not in ('cancel') then raise exception 'INVALID_ACTION'; end if;

  update public.tasks
     set status = 'cancelled'
   where status = 'available'
     and (p_ids is null or id = any (p_ids));
  get diagnostics v_count = row_count;

  perform public.audit('admin.tasks.bulk', 'task', null,
    jsonb_build_object('action', p_action, 'count', v_count, 'ids', p_ids));
  return jsonb_build_object('ok', true, 'tasks', v_count);
end $$;

revoke all on function public.admin_bulk_tasks(text, uuid[]) from public, anon;
grant execute on function public.admin_bulk_tasks(text, uuid[]) to authenticated;

-- Counts for the confirmation dialog (no side effects).
create or replace function public.admin_bulk_preview()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

  return jsonb_build_object(
    'active_campaigns', (select count(*) from public.campaigns where status = 'active'),
    'paused_campaigns', (select count(*) from public.campaigns where status = 'paused'),
    'available_tasks', (select count(*) from public.tasks where status = 'available'),
    'submitted_tasks', (select count(*) from public.tasks where status = 'submitted'),
    'smm_orders_active', (select count(*) from public.smm_orders where status in ('pending','processing')),
    'note', 'Cancelling campaigns closes available task slots only. Submitted work stays in review, escrow and ledger rows are untouched, and SMM buyer orders are never touched by campaign actions.'
  );
end $$;

revoke all on function public.admin_bulk_preview() from public, anon;
grant execute on function public.admin_bulk_preview() to authenticated;

notify pgrst, 'reload schema';

commit;
