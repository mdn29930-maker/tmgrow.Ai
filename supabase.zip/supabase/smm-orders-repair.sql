-- ============================================================================
-- TM GROW — SMM BUYER FLOW REPAIR (additive, idempotent, non-destructive)
--
-- WHY THIS FILE EXISTS
-- The buyer reports, on order creation: "Database is not initialised yet…
-- reload the API schema cache…". In src/lib/sb.js that exact wording is
-- produced ONLY for PGRST202 / "function … does not exist" — i.e. the
-- create_smm_order RPC is missing, or exists but is invisible to the PostgREST
-- schema cache. It is NOT a missing table (42P01) and NOT an empty database.
--
-- WHAT THIS FILE DOES
-- Re-deploys exactly the objects the buyer flow needs: the two SMM tables
-- (if not exists), the SMM columns on the shared services table (if not
-- exists), the buyer RPCs (create or replace), and the grants. Then it reloads
-- the PostgREST schema cache itself.
--
-- SAFETY
--   * create table IF NOT EXISTS, add column IF NOT EXISTS,
--     create or replace function, on conflict do nothing.
--   * Nothing is dropped, deleted, renamed or reset. Existing services,
--     orders, wallets, balances and ledger rows are untouched.
--   * No begin/commit wrapper: each statement stands alone, so a partial
--     failure still keeps what succeeded, and the whole file can be re-run.
--   * It does NOT touch worker tasks, campaigns, auth or any other module.
--   * Admin-only order RPCs (admin_smm_orders, refunds, drip) are NOT here;
--     if the admin order page also errors, run supabase/smm-orders.sql
--     (also additive + idempotent) after this file.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. CATEGORIES + ORDERS TABLES (unchanged definitions from smm-orders.sql)
-- ----------------------------------------------------------------------------
create table if not exists public.smm_categories (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  name text not null,
  icon text,
  sort_order int not null default 100,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint smm_categories_platform_name_key unique (platform, name)
);

create index if not exists smm_categories_platform_idx
  on public.smm_categories (platform, is_active, sort_order);

alter table public.smm_categories enable row level security;

drop trigger if exists smm_categories_set_updated_at on public.smm_categories;
create trigger smm_categories_set_updated_at
  before update on public.smm_categories
  for each row execute function public.tg_set_updated_at();

create table if not exists public.smm_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  service_id uuid not null references public.services (id),
  target_link text not null,
  quantity int not null check (quantity > 0),
  rate_snapshot numeric(18, 6) not null check (rate_snapshot > 0),
  total_cost numeric(18, 6) not null check (total_cost > 0),
  refunded_total numeric(18, 6) not null default 0
    check (refunded_total >= 0 and refunded_total <= total_cost),
  status text not null default 'pending'
    check (status in ('pending','processing','completed','partial','cancelled','failed','refunded')),
  admin_note text,
  idempotency_key text,
  source text not null default 'single' check (source in ('single','bulk')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  processed_at timestamptz,
  completed_at timestamptz
);

create index if not exists smm_orders_user_idx
  on public.smm_orders (user_id, created_at desc);
create index if not exists smm_orders_status_idx
  on public.smm_orders (status, created_at desc);
create index if not exists smm_orders_service_idx
  on public.smm_orders (service_id, created_at desc);

create unique index if not exists smm_orders_idempotency_key
  on public.smm_orders (user_id, idempotency_key)
  where idempotency_key is not null;

alter table public.smm_orders enable row level security;

drop trigger if exists smm_orders_set_updated_at on public.smm_orders;
create trigger smm_orders_set_updated_at
  before update on public.smm_orders
  for each row execute function public.tg_set_updated_at();

-- ----------------------------------------------------------------------------
-- 2. SMM COLUMNS ON THE EXISTING services TABLE (all "if not exists")
-- ----------------------------------------------------------------------------
alter table public.services add column if not exists is_smm boolean not null default false;
alter table public.services add column if not exists smm_active boolean not null default true;
alter table public.services add column if not exists category_id uuid references public.smm_categories (id) on delete set null;
alter table public.services add column if not exists rate_per_1000 numeric(18, 6);
alter table public.services add column if not exists cost_price_per_1000 numeric(18, 6);
alter table public.services add column if not exists language text;
alter table public.services add column if not exists estimated_time text;
alter table public.services add column if not exists features jsonb not null default '[]'::jsonb;
alter table public.services add column if not exists archived_at timestamptz;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'services_rate_per_1000_chk') then
    alter table public.services add constraint services_rate_per_1000_chk
      check (rate_per_1000 is null or rate_per_1000 > 0);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'services_cost_price_chk') then
    alter table public.services add constraint services_cost_price_chk
      check (cost_price_per_1000 is null or cost_price_per_1000 >= 0);
  end if;
end $$;

create index if not exists services_smm_idx
  on public.services (platform, smm_active, archived_at, sort_order)
  where is_smm;

-- ----------------------------------------------------------------------------
-- 3. NOTIFICATION TEMPLATES (in-app wording; on conflict do nothing)
-- ----------------------------------------------------------------------------
insert into public.settings (key, value, is_public) values
  ('telegram_tpl_smm_order_placed', to_jsonb('🧾 New SMM order
{{service}}
Link: {{target}}
Quantity: {{quantity}}
Charged: {{total}} USDT

Status: pending — queued for processing.'::text), false),
  ('telegram_tpl_smm_order_processing', to_jsonb('⚙️ Order processing
{{service}}
Quantity: {{quantity}}
Your order is being processed.'::text), false),
  ('telegram_tpl_smm_order_completed', to_jsonb('✅ Order delivered
{{service}}
Quantity: {{quantity}}
Thank you for choosing TM GROW.'::text), false),
  ('telegram_tpl_smm_order_partial', to_jsonb('➗ Order partially delivered
{{service}}
Quantity: {{quantity}}
Contact support if anything looks wrong.'::text), false),
  ('telegram_tpl_smm_order_cancelled', to_jsonb('⚠️ Order cancelled
{{service}}
Quantity: {{quantity}}
A refund is handled through the wallet ledger.'::text), false),
  ('telegram_tpl_smm_order_refunded', to_jsonb('💸 Refund processed
{{service}}
Amount: {{amount}} USDT
The refund was credited to your wallet.'::text), false)
on conflict (key) do nothing;

-- ----------------------------------------------------------------------------
-- 4. BUYER RPCs (create or replace — the live definitions from smm-orders.sql)
-- ----------------------------------------------------------------------------
create or replace function public.smm_categories_list()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', c.id, 'platform', c.platform, 'name', c.name,
           'icon', c.icon, 'sort_order', c.sort_order
         ) order by c.platform, c.sort_order, c.name), '[]'::jsonb)
    from public.smm_categories c
   where c.is_active;
$$;

revoke all on function public.smm_categories_list() from public, anon;
grant execute on function public.smm_categories_list() to authenticated;


create or replace function public.smm_platform_counts()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_object_agg(platform, n), '{}'::jsonb)
    from (
      select s.platform, count(*)::int as n
        from public.services s
       where s.is_smm and s.smm_active and s.archived_at is null
         and s.rate_per_1000 is not null
       group by s.platform
    ) q;
$$;

revoke all on function public.smm_platform_counts() from public, anon;
grant execute on function public.smm_platform_counts() to authenticated;


create or replace function public.smm_list_services(
  p_platform text default null,
  p_category_id uuid default null,
  p_search text default null,
  p_sort text default 'default',
  p_limit int default 25,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.services s
   where s.is_smm and s.smm_active and s.archived_at is null
     and s.rate_per_1000 is not null
     and (p_platform is null or p_platform = '' or s.platform = p_platform)
     and (p_category_id is null or s.category_id = p_category_id)
     and (p_search is null or p_search = ''
          or s.name ilike '%' || p_search || '%'
          or s.platform ilike '%' || p_search || '%'
          or s.id::text = replace(lower(trim(p_search)), '#', ''));

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', x.id, 'platform', x.platform, 'name', x.name,
           'description', x.description,
           'category_id', x.category_id,
           'category_name', x.category_name,
           'language', x.language,
           'rate_per_1000', x.rate_per_1000,
           'min_quantity', x.min_quantity,
           'max_quantity', x.max_quantity,
           'estimated_time', x.estimated_time,
           'features', x.features,
           'short_id', upper(substr(replace(x.id::text, '-', ''), 1, 6)),
           'orders_count', x.orders_count
         ) order by x.sort_position), '[]'::jsonb)
    into v_items
    from (
      select s.*, c.name as category_name, coalesce(o.n, 0) as orders_count,
             row_number() over (order by
               case when p_sort = 'price_asc' then s.rate_per_1000 end asc nulls last,
               case when p_sort = 'price_desc' then s.rate_per_1000 end desc nulls last,
               coalesce(o.n, 0) desc,
               s.sort_order, s.name) as sort_position
        from public.services s
        left join public.smm_categories c on c.id = s.category_id
        left join (
          select service_id, count(*)::int n
            from public.smm_orders
           group by service_id
        ) o on o.service_id = s.id
       where s.is_smm and s.smm_active and s.archived_at is null
         and s.rate_per_1000 is not null
         and (p_platform is null or p_platform = '' or s.platform = p_platform)
         and (p_category_id is null or s.category_id = p_category_id)
         and (p_search is null or p_search = ''
              or s.name ilike '%' || p_search || '%'
              or s.platform ilike '%' || p_search || '%'
              or s.id::text = replace(lower(trim(p_search)), '#', '')
              or upper(substr(replace(s.id::text, '-', ''), 1, 6)) = upper(replace(trim(p_search), '#', '')))
       order by
         case when p_sort = 'price_asc' then s.rate_per_1000 end asc nulls last,
         case when p_sort = 'price_desc' then s.rate_per_1000 end desc nulls last,
         coalesce(o.n, 0) desc,
         s.sort_order, s.name
       limit greatest(1, least(coalesce(p_limit, 25), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) x;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.smm_list_services(text, uuid, text, text, int, int) from public, anon;
grant execute on function public.smm_list_services(text, uuid, text, text, int, int) to authenticated;


create or replace function public.my_smm_orders(
  p_status text default null,
  p_search text default null,
  p_limit int default 20,
  p_offset int default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_items jsonb;
  v_total integer;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;

  select count(*) into v_total
    from public.smm_orders o
   where o.user_id = v_uid
     and (p_status is null or p_status = '' or o.status = p_status)
     and (p_search is null or p_search = ''
          or o.id::text ilike '%' || p_search || '%'
          or o.target_link ilike '%' || p_search || '%');

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', o.id,
           'service_id', o.service_id,
           'service_name', s.name,
           'platform', s.platform,
           'target_link', o.target_link,
           'quantity', o.quantity,
           'rate_snapshot', o.rate_snapshot,
           'total_cost', o.total_cost,
           'refunded_total', o.refunded_total,
           'status', o.status,
           'admin_note', o.admin_note,
           'created_at', o.created_at,
           'updated_at', o.updated_at,
           'processed_at', o.processed_at,
           'completed_at', o.completed_at,
           'short_id', upper(substr(replace(o.id::text, '-', ''), 1, 8))
         ) order by o.created_at desc), '[]'::jsonb)
    into v_items
    from (
      select * from public.smm_orders
       where user_id = v_uid
         and (p_status is null or p_status = '' or status = p_status)
         and (p_search is null or p_search = ''
              or id::text ilike '%' || p_search || '%'
              or target_link ilike '%' || p_search || '%')
       order by created_at desc
       limit greatest(1, least(coalesce(p_limit, 20), 100))
      offset greatest(0, coalesce(p_offset, 0))
    ) o
    join public.services s on s.id = o.service_id;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.my_smm_orders(text, text, int, int) from public, anon;
grant execute on function public.my_smm_orders(text, text, int, int) to authenticated;


create or replace function public.create_smm_order(
  p_service_id uuid,
  p_target_link text,
  p_quantity int,
  p_idempotency_key text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid    uuid := auth.uid();
  v_p      public.profiles;
  v_s      public.services;
  v_w      public.wallets;
  v_total  numeric;
  v_link   text := btrim(coalesce(p_target_link, ''));
  v_key    text := nullif(btrim(coalesce(p_idempotency_key, '')), '');
  v_order  public.smm_orders;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;
  if v_key is null then
    return jsonb_build_object('ok', false, 'code', 'IDEMPOTENCY_KEY_REQUIRED',
      'message', 'Reload the page and try again.');
  end if;

  perform public.ensure_profile();
  select * into v_p from public.profiles where id = v_uid;
  if v_p.status <> 'active' then
    return jsonb_build_object('ok', false, 'code', 'ACCOUNT_RESTRICTED',
      'message', 'This account cannot place orders.');
  end if;
  if not v_p.is_buyer then
    return jsonb_build_object('ok', false, 'code', 'BUYER_MODE_DISABLED',
      'message', 'Open a buyer account first.');
  end if;

  /* Duplicate tap / retry: return the existing order, never charge twice. */
  select * into v_order
    from public.smm_orders
   where user_id = v_uid and idempotency_key = v_key;
  if v_order.id is not null then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
  end if;

  select * into v_s from public.services where id = p_service_id;
  if v_s.id is null or not v_s.is_smm or not v_s.smm_active or v_s.archived_at is not null then
    return jsonb_build_object('ok', false, 'code', 'SERVICE_UNAVAILABLE',
      'message', 'This service is not available.');
  end if;
  if v_s.rate_per_1000 is null or v_s.rate_per_1000 <= 0 then
    return jsonb_build_object('ok', false, 'code', 'SERVICE_NOT_PRICED',
      'message', 'This service has no price yet.');
  end if;

  if v_link = '' or v_link !~* '^https?://' or char_length(v_link) > 500 then
    return jsonb_build_object('ok', false, 'code', 'INVALID_TARGET_URL',
      'message', 'Enter a valid http(s) link.');
  end if;
  if p_quantity is null or p_quantity < v_s.min_quantity or p_quantity > v_s.max_quantity then
    return jsonb_build_object('ok', false, 'code', 'INVALID_QUANTITY',
      'message', 'Quantity must be between ' || v_s.min_quantity || ' and ' || v_s.max_quantity || '.');
  end if;

  v_total := round(p_quantity::numeric * v_s.rate_per_1000 / 1000.0, 6);
  if v_total <= 0 then
    return jsonb_build_object('ok', false, 'code', 'INVALID_TOTAL',
      'message', 'The order total is not valid.');
  end if;

  select * into v_w from public.wallets where user_id = v_uid for update;
  if v_w.user_id is null then
    return jsonb_build_object('ok', false, 'code', 'WALLET_NOT_FOUND',
      'message', 'Wallet not found.');
  end if;
  if v_w.available < v_total then
    return jsonb_build_object('ok', false, 'code', 'INSUFFICIENT_FUNDS',
      'message', 'Not enough available balance for this order.',
      'required', v_total, 'available', v_w.available);
  end if;

  begin
    insert into public.smm_orders (
      user_id, service_id, target_link, quantity,
      rate_snapshot, total_cost, status, idempotency_key, source
    ) values (
      v_uid, v_s.id, v_link, p_quantity,
      v_s.rate_per_1000, v_total, 'pending', v_key, 'single'
    ) returning * into v_order;
  exception when unique_violation then
    select * into v_order from public.smm_orders
     where user_id = v_uid and idempotency_key = v_key;
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
  end;

  perform public.wallet_move(
    v_uid, -v_total, 0, 0, 0,
    'smm_order_charge', 'smm_order', v_order.id,
    'SMM order ' || upper(substr(replace(v_order.id::text, '-', ''), 1, 8)) || ' — ' || v_s.name
  );

  perform public.audit('smm_order.create', 'smm_order', v_order.id,
    jsonb_build_object('service', v_s.name, 'quantity', p_quantity, 'total', v_total));

  perform public.notify_user(v_uid, 'Order placed',
    v_s.name || ' · ' || p_quantity || ' · ' || v_total || ' USDT charged.',
    'success', '#/smm/orders');

  perform public.telegram_enqueue(v_uid, 'smm_order_placed',
    jsonb_build_object(
      'service', v_s.name,
      'target', v_link,
      'quantity', p_quantity,
      'total', public.telegram_money(v_total)
    ), 'smm_placed:' || v_order.id);

  select * into v_w from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'duplicate', false,
    'order', to_jsonb(v_order), 'balance', coalesce(v_w.available, 0));
end $$;

revoke all on function public.create_smm_order(uuid, text, int, text) from public, anon;
grant execute on function public.create_smm_order(uuid, text, int, text) to authenticated;


create or replace function public.create_smm_orders_bulk(
  p_items jsonb,
  p_idempotency_key text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid    uuid := auth.uid();
  v_p      public.profiles;
  v_w      public.wallets;
  v_key    text := nullif(btrim(coalesce(p_idempotency_key, '')), '');
  v_items  jsonb := coalesce(p_items, '[]'::jsonb);
  v_item   jsonb;
  v_s      public.services;
  v_sid    uuid;
  v_link   text;
  v_qty    int;
  v_total  numeric;
  v_sum    numeric := 0;
  v_clean  jsonb := '[]'::jsonb;
  v_errors jsonb := '[]'::jsonb;
  v_order  public.smm_orders;
  v_created jsonb := '[]'::jsonb;
  v_idx    int := 0;
  v_existing jsonb;
begin
  if v_uid is null then raise exception 'UNAUTHENTICATED'; end if;
  if v_key is null then
    return jsonb_build_object('ok', false, 'code', 'IDEMPOTENCY_KEY_REQUIRED',
      'message', 'Reload the page and try again.');
  end if;
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    return jsonb_build_object('ok', false, 'code', 'EMPTY_BATCH',
      'message', 'Add at least one order line.');
  end if;
  if jsonb_array_length(v_items) > 50 then
    return jsonb_build_object('ok', false, 'code', 'BATCH_TOO_LARGE',
      'message', 'A mass order can contain at most 50 lines.');
  end if;

  perform public.ensure_profile();
  select * into v_p from public.profiles where id = v_uid;
  if v_p.status <> 'active' then
    return jsonb_build_object('ok', false, 'code', 'ACCOUNT_RESTRICTED',
      'message', 'This account cannot place orders.');
  end if;
  if not v_p.is_buyer then
    return jsonb_build_object('ok', false, 'code', 'BUYER_MODE_DISABLED',
      'message', 'Open a buyer account first.');
  end if;

  /* Already submitted with this key: return the same batch, no new charge. */
  select coalesce(jsonb_agg(to_jsonb(o) order by o.created_at), '[]'::jsonb)
    into v_existing
    from public.smm_orders o
   where o.user_id = v_uid
     and o.idempotency_key like v_key || ':%';
  if jsonb_array_length(v_existing) > 0 then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', true, 'duplicate', true,
      'orders', v_existing, 'balance', coalesce(v_w.available, 0));
  end if;

  /* Validate every row before any write. */
  for v_item in select * from jsonb_array_elements(v_items) loop
    v_idx := v_idx + 1;
    begin
      v_sid := (v_item ->> 'service_id')::uuid;
    exception when others then
      v_sid := null;
    end;
    v_link := btrim(coalesce(v_item ->> 'target_link', ''));
    begin
      v_qty := (v_item ->> 'quantity')::int;
    exception when others then
      v_qty := null;
    end;

    select * into v_s from public.services where id = v_sid;

    if v_s.id is null or not v_s.is_smm or not v_s.smm_active or v_s.archived_at is not null then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'SERVICE_UNAVAILABLE', 'message', 'Service ID not found or inactive.');
      continue;
    end if;
    if v_s.rate_per_1000 is null or v_s.rate_per_1000 <= 0 then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'SERVICE_NOT_PRICED', 'message', 'Service has no price.');
      continue;
    end if;
    if v_link = '' or v_link !~* '^https?://' or char_length(v_link) > 500 then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'INVALID_TARGET_URL', 'message', 'Target link is not a valid http(s) URL.');
      continue;
    end if;
    if v_qty is null or v_qty < v_s.min_quantity or v_qty > v_s.max_quantity then
      v_errors := v_errors || jsonb_build_object('line', v_idx,
        'code', 'INVALID_QUANTITY',
        'message', 'Quantity must be between ' || v_s.min_quantity || ' and ' || v_s.max_quantity || '.');
      continue;
    end if;

    v_total := round(v_qty::numeric * v_s.rate_per_1000 / 1000.0, 6);
    v_sum := v_sum + v_total;
    v_clean := v_clean || jsonb_build_object(
      'line', v_idx, 'service_id', v_s.id, 'service_name', v_s.name,
      'target_link', v_link, 'quantity', v_qty,
      'rate', v_s.rate_per_1000, 'total', v_total
    );
  end loop;

  if jsonb_array_length(v_errors) > 0 then
    select * into v_w from public.wallets where user_id = v_uid;
    return jsonb_build_object('ok', false, 'code', 'VALIDATION_FAILED',
      'message', 'Nothing was charged. Fix the listed lines and submit again.',
      'errors', v_errors, 'balance', coalesce(v_w.available, 0));
  end if;

  select * into v_w from public.wallets where user_id = v_uid for update;
  if v_w.available < v_sum then
    return jsonb_build_object('ok', false, 'code', 'INSUFFICIENT_FUNDS',
      'message', 'Not enough balance for the whole batch. Nothing was charged.',
      'required', v_sum, 'available', v_w.available);
  end if;

  /* From here every statement is in one transaction: all orders or none. */
  for v_item in select * from jsonb_array_elements(v_clean) loop
    insert into public.smm_orders (
      user_id, service_id, target_link, quantity,
      rate_snapshot, total_cost, status, idempotency_key, source
    ) values (
      v_uid, (v_item ->> 'service_id')::uuid, v_item ->> 'target_link',
      (v_item ->> 'quantity')::int, (v_item ->> 'rate')::numeric,
      (v_item ->> 'total')::numeric, 'pending',
      v_key || ':' || (v_item ->> 'line'), 'bulk'
    ) returning * into v_order;

    perform public.wallet_move(
      v_uid, -(v_item ->> 'total')::numeric, 0, 0, 0,
      'smm_order_charge', 'smm_order', v_order.id,
      'Mass order line ' || (v_item ->> 'line') || ' — ' || v_item ->> 'service_name'
    );

    v_created := v_created || to_jsonb(v_order);
  end loop;

  perform public.audit('smm_order.bulk', 'smm_order', null,
    jsonb_build_object('lines', jsonb_array_length(v_created), 'total', v_sum));

  perform public.notify_user(v_uid, 'Mass order placed',
    jsonb_array_length(v_created) || ' orders · ' || v_sum || ' USDT charged.',
    'success', '#/smm/orders');

  select * into v_w from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'duplicate', false,
    'orders', v_created, 'total', v_sum, 'balance', coalesce(v_w.available, 0));
end $$;

revoke all on function public.create_smm_orders_bulk(jsonb, text) from public, anon;
grant execute on function public.create_smm_orders_bulk(jsonb, text) to authenticated;

-- ----------------------------------------------------------------------------
-- 5. RELOAD THE POSTGREST SCHEMA CACHE — the exact remedy for PGRST202 when the
--    functions already exist. Safe: it only signals PostgREST to re-read the
--    schema; no data is touched.
-- ----------------------------------------------------------------------------
notify pgrst, 'reload schema';

-- ----------------------------------------------------------------------------
-- 6. VERIFICATION (read-only — check the results after running the file)
-- ----------------------------------------------------------------------------
-- 6a. All six buyer RPCs must be listed with the exact expected signatures.
select p.proname,
       pg_get_function_identity_arguments(p.oid) as args,
       has_function_privilege('authenticated', p.oid, 'execute') as buyer_can_execute
  from pg_proc p
  join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public'
   and p.proname in ('create_smm_order','create_smm_orders_bulk',
                     'smm_list_services','my_smm_orders',
                     'smm_platform_counts','smm_categories_list')
 order by p.proname;

-- 6b. What buyers will actually see on the Services page right now:
--     visible = active + not archived + priced. If this is 0 but smm_services
--     > 0, set the services Live in Admin -> SMM panel -> SMM services.
select
  count(*)                                          as smm_services,
  count(*) filter (where smm_active
                     and archived_at is null
                     and rate_per_1000 is not null) as visible_to_buyers,
  (select count(*) from public.smm_categories)      as categories,
  (select count(*) from public.smm_orders)          as existing_orders
  from public.services
 where is_smm;
