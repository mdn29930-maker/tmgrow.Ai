-- ============================================================================
-- TM GROW — MINIMUM DEPOSIT FIX (single source of truth)
--
-- Root cause (verified in the code):
--   * submit_verified_deposit() and request_deposit() read
--     setting_num('min_deposit', 5) from public.settings — the authoritative
--     value.
--   * The deposit page reads settingNumber('min_deposit', 5) from
--     state.settings, which is populated by get_public_settings() —
--     "select ... from public.settings where is_public".
--   * The admin setting editor lets an operator save any setting with
--     "Publicly readable" unchecked. Once min_deposit is is_public = false the
--     app silently falls back to 5 while the server keeps the real value, so a
--     $10 deposit can be rejected with BELOW_MIN_DEPOSIT while the screen says
--     the minimum is $5.
--   * The raised error did not contain the actual minimum, so the message could
--     not explain the mismatch.
--
-- This migration:
--   1. makes the limit settings public again (they are limits, not secrets),
--   2. adds deposit_limits() so the page reads the same value the server uses,
--   3. re-creates both money RPCs with an error that contains the real minimum.
--
-- No wallet balance, ledger row, deposit row or auth object is modified.
-- Idempotent: safe to run more than once.
-- ============================================================================

begin;

-- 1. Limits are public and never a secret. ----------------------------------
update public.settings
   set is_public = true,
       updated_at = now()
 where key in ('min_deposit', 'withdrawal_min')
   and is_public is distinct from true;

-- 2. One authoritative read for the client. --------------------------------
create or replace function public.deposit_limits()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_min numeric := greatest(0, coalesce(public.setting_num('min_deposit', 5), 5));
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;

  return jsonb_build_object(
    'min_amount', v_min,
    'deposit_address', coalesce(nullif(public.setting_text('deposit_address', ''), ''), ''),
    'network', coalesce(nullif(public.setting_text('network_name', ''), ''), 'BNB Smart Chain (BEP-20)'),
    'usdt_contract', coalesce(nullif(public.setting_text('usdt_contract', ''), ''), '0x55d398326f99059fF775485246999027B3197955'),
    'confirmations', coalesce(public.setting_num('deposit_confirmations', 12), 12)
  );
end $$;

revoke all on function public.deposit_limits() from public, anon;
grant execute on function public.deposit_limits() to authenticated;

-- 3. Same RPC, same rules, error carries the real minimum. ------------------
create or replace function public.submit_verified_deposit(
  p_tx_hash text,
  p_amount numeric,
  p_from_address text default null,
  p_block bigint default null,
  p_confirmations int default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  v_hash text;
  v_min numeric;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;

  v_hash := lower(trim(coalesce(p_tx_hash, '')));
  if v_hash !~ '^0x[0-9a-f]{64}$' then raise exception 'INVALID_TX_HASH'; end if;

  v_min := greatest(0, coalesce(public.setting_num('min_deposit', 5), 5));
  if p_amount is null or p_amount < v_min then
    raise exception 'BELOW_MIN_DEPOSIT: %', public.telegram_money(v_min);
  end if;

  if exists (select 1 from public.deposits where lower(tx_hash) = v_hash) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (
    user_id, amount, method, tx_hash, status,
    verified_at, confirmations, from_address, block_number, reviewed_at
  ) values (
    u, round(p_amount, 6), 'USDT_BEP20', v_hash, 'approved',
    now(), p_confirmations, lower(nullif(trim(coalesce(p_from_address, '')), '')),
    p_block, now()
  ) returning * into d;

  perform public.wallet_move(u, d.amount, 0, 0, 0, 'deposit', 'deposit', d.id,
                             'Deposit verified on BNB Smart Chain');
  update public.wallets
     set lifetime_deposited = lifetime_deposited + d.amount
   where user_id = u;

  perform public.notify_user(u, 'Deposit credited',
    d.amount || ' USDT was verified on BNB Smart Chain (BEP-20) and added to your balance.',
    'success', '#/history');
  perform public.audit('deposit.verified', 'deposit', d.id,
    jsonb_build_object('tx_hash', d.tx_hash, 'amount', d.amount,
                       'confirmations', p_confirmations,
                       'from', d.from_address, 'block', p_block));

  return jsonb_build_object('deposit', to_jsonb(d));
end $$;

create or replace function public.request_deposit(
  p_amount numeric,
  p_method text default 'USDT_BEP20',
  p_tx_hash text default null,
  p_proof_path text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  d public.deposits;
  min_amount numeric;
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if p_method not in ('USDT_BEP20','BINANCE_PAY') then raise exception 'INVALID_METHOD'; end if;

  min_amount := greatest(0, coalesce(public.setting_num('min_deposit', 5), 5));
  if p_amount is null or p_amount < min_amount then
    raise exception 'BELOW_MIN_DEPOSIT: %', public.telegram_money(min_amount);
  end if;
  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0 and trim(p_tx_hash) !~* '^0x[a-fA-F0-9]{64}$' then
    raise exception 'INVALID_TX_HASH';
  end if;

  if p_proof_path is not null then
    if split_part(p_proof_path, '/', 1) <> u::text then
      raise exception 'INVALID_PROOF_PATH';
    end if;
  elsif p_tx_hash is null or length(trim(p_tx_hash)) = 0 then
    raise exception 'INVALID_PROOF_PATH';
  end if;

  if p_tx_hash is not null and length(trim(p_tx_hash)) > 0
     and exists (
       select 1 from public.deposits
        where lower(tx_hash) = lower(trim(p_tx_hash))
          and status in ('pending','approved')
     ) then
    raise exception 'DUPLICATE_TX_HASH';
  end if;

  insert into public.deposits (user_id, amount, method, tx_hash, proof_path)
  values (u, round(p_amount, 6), p_method, nullif(trim(coalesce(p_tx_hash, '')), ''), p_proof_path)
  returning * into d;

  insert into public.notifications (user_id, title, body, kind, link)
  select id, 'New deposit request',
         'A buyer submitted a ' || round(p_amount, 6) || ' USDT deposit for review.', 'info', '/admin/deposits'
    from public.profiles where admin_role in ('OWNER','SUPER_ADMIN','ADMIN','FINANCE');

  return jsonb_build_object('deposit', d);
end $$;

notify pgrst, 'reload schema';

commit;
