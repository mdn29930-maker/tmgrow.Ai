-- ============================================================================
-- TM GROW — PREMIUM PLATFORM FEATURES (additive migration)
-- Adds achievements & badges, buyer campaign drafts, usernames and an
-- extended public-stats feed. Nothing existing is replaced: every object is
-- created with "if not exists" and no existing table, RPC or policy is
-- altered. Run once in Supabase → SQL Editor.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. USERNAMES
-- ----------------------------------------------------------------------------
alter table public.profiles add column if not exists username text;

create unique index if not exists profiles_username_key
  on public.profiles (username) where username is not null;

create or replace function public.set_my_username(p_username text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  v text;
  p public.profiles;
begin
  perform public.ensure_profile();
  v := lower(btrim(coalesce(p_username, '')));
  if v is null or v not similar to '[a-z0-9_]{3,24}' then
    raise exception 'INVALID_USERNAME';
  end if;
  if v in ('admin', 'administrator', 'support', 'tmgrow', 'tm_grow', 'root') then
    raise exception 'USERNAME_RESERVED';
  end if;
  if exists (select 1 from public.profiles where username = v and id <> u) then
    raise exception 'USERNAME_TAKEN';
  end if;
  update public.profiles
     set username = v, updated_at = now()
   where id = u
   returning * into p;
  return to_jsonb(p);
end $$;

revoke all on function public.set_my_username(text) from public, anon;
grant execute on function public.set_my_username(text) to authenticated;

-- ----------------------------------------------------------------------------
-- 2. ACHIEVEMENTS & BADGES
-- ----------------------------------------------------------------------------
create table if not exists public.achievements (
  key text primary key,
  name text not null,
  description text not null,
  icon text not null default 'star',
  condition_type text not null
    check (condition_type in ('approved_tasks','lifetime_earned','streak','withdrawals')),
  threshold numeric(18, 2) not null check (threshold > 0),
  reward_tg numeric(18, 4) not null default 0,
  sort_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.user_achievements (
  user_id uuid not null references public.profiles (id) on delete cascade,
  achievement_key text not null references public.achievements (key) on delete cascade,
  unlocked_at timestamptz not null default now(),
  reward_granted boolean not null default false,
  rewarded_at timestamptz,
  primary key (user_id, achievement_key)
);

create index if not exists user_achievements_user_idx
  on public.user_achievements (user_id, reward_granted);

alter table public.achievements enable row level security;
drop policy if exists achievements_read_all on public.achievements;
create policy achievements_read_all on public.achievements
  for select to authenticated using (true);

alter table public.user_achievements enable row level security;
drop policy if exists user_achievements_select_own on public.user_achievements;
create policy user_achievements_select_own on public.user_achievements
  for select to authenticated using (user_id = auth.uid());
drop policy if exists user_achievements_insert_own on public.user_achievements;
create policy user_achievements_insert_own on public.user_achievements
  for insert to authenticated with check (user_id = auth.uid());

-- Seed (edit freely as admin: rewards, thresholds and names are data, not code;
-- progress is always recomputed live by the RPC below).
insert into public.achievements (key, name, description, icon, condition_type, threshold, reward_tg, sort_order)
values
  ('first_task', 'First Task Completed', 'Complete your first verified task.', 'checkCircle', 'approved_tasks', 1, 1, 1),
  ('tasks_10', '10 Tasks Completed', 'Reach 10 approved tasks.', 'tasks', 'approved_tasks', 10, 5, 2),
  ('tasks_50', '50 Tasks Completed', 'Reach 50 approved tasks.', 'star', 'approved_tasks', 50, 20, 3),
  ('tasks_100', '100 Tasks Completed', 'Reach 100 approved tasks.', 'trophy', 'approved_tasks', 100, 50, 4),
  ('streak_7', '7-Day Streak', 'Check in 7 days in a row.', 'flame', 'streak', 7, 10, 5),
  ('streak_30', '30-Day Streak', 'Check in 30 days in a row.', 'flame', 'streak', 30, 50, 6),
  ('first_withdrawal', 'First Withdrawal', 'Receive your first paid withdrawal.', 'wallet', 'withdrawals', 1, 5, 7),
  ('premium_worker', 'Premium Worker', 'Earn 50 USDT lifetime.', 'shield', 'lifetime_earned', 50, 25, 8),
  ('top_contributor', 'Top Contributor', 'Earn 250 USDT lifetime.', 'trending', 'lifetime_earned', 250, 100, 9)
on conflict (key) do nothing;

-- Evaluates every active achievement against real data, auto-unlocks reached
-- milestones and returns the list with live progress.
create or replace function public.my_achievements()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  rec record;
  v_value numeric;
  v_items jsonb := '[]'::jsonb;
  v_unlocked boolean;
  v_granted boolean;
  v_at timestamptz;
begin
  perform public.ensure_profile();

  for rec in
    select * from public.achievements where active order by sort_order, key
  loop
    v_value :=
      case rec.condition_type
        when 'approved_tasks' then
          (select count(*) from public.tasks
            where worker_id = uid and status = 'approved')
        when 'lifetime_earned' then
          (select lifetime_earned from public.wallets where user_id = uid)
        when 'streak' then
          (select coalesce(max(streak), 0) from public.daily_checkins where user_id = uid)
        when 'withdrawals' then
          (select count(*) from public.withdrawals
            where user_id = uid and status = 'paid')
        else 0
      end;
    if v_value is null then v_value := 0; end if;

    if v_value >= rec.threshold
       and not exists (select 1 from public.user_achievements
                        where user_id = uid and achievement_key = rec.key) then
      insert into public.user_achievements (user_id, achievement_key)
      values (uid, rec.key);
      insert into public.notifications (user_id, title, body, kind, link)
      values (uid, 'Achievement unlocked',
              rec.name || ' — open Achievements to claim your reward.',
              'success', '#/achievements');
    end if;

    v_unlocked := null; v_granted := null; v_at := null;
    select true, reward_granted, unlocked_at
      into v_unlocked, v_granted, v_at
      from public.user_achievements
     where user_id = uid and achievement_key = rec.key;

    v_items := v_items || jsonb_build_object(
      'key', rec.key,
      'name', rec.name,
      'description', rec.description,
      'icon', rec.icon,
      'condition_type', rec.condition_type,
      'threshold', rec.threshold,
      'reward_tg', rec.reward_tg,
      'progress', least(v_value, rec.threshold),
      'unlocked', coalesce(v_unlocked, false),
      'reward_granted', coalesce(v_granted, false),
      'unlocked_at', v_at
    );
  end loop;

  return v_items;
end $$;

-- Pays the TM Coin reward exactly like the daily check-in does, only after a
-- server-side re-check that the achievement is unlocked and not yet claimed.
create or replace function public.claim_achievement(p_key text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  a public.achievements;
  ua public.user_achievements;
  w public.wallets;
begin
  perform public.ensure_profile();
  select * into a from public.achievements where key = p_key and active;
  if not found then
    raise exception 'ACHIEVEMENT_NOT_FOUND';
  end if;

  select * into ua from public.user_achievements
   where user_id = uid and achievement_key = p_key;
  if not found then
    raise exception 'NOT_UNLOCKED';
  end if;
  if ua.reward_granted then
    raise exception 'ALREADY_CLAIMED';
  end if;

  if a.reward_tg > 0 then
    update public.wallets
       set tg_balance = tg_balance + a.reward_tg,
           lifetime_tg = lifetime_tg + a.reward_tg,
           updated_at = now()
     where user_id = uid
     returning * into w;
  end if;

  update public.user_achievements
     set reward_granted = true, rewarded_at = now()
   where user_id = uid and achievement_key = p_key;

  insert into public.notifications (user_id, title, body, kind, link)
  values (uid, 'Reward claimed',
          a.name || ' — +' || a.reward_tg::text || ' TM Coins credited.',
          'success', '#/achievements');

  return jsonb_build_object('ok', true, 'reward_tg', a.reward_tg,
                            'tg_balance', coalesce(w.tg_balance, 0));
end $$;

revoke all on function public.my_achievements() from public, anon;
revoke all on function public.claim_achievement(text) from public, anon;
grant execute on function public.my_achievements() to authenticated;
grant execute on function public.claim_achievement(text) to authenticated;

-- ----------------------------------------------------------------------------
-- 3. BUYER CAMPAIGN DRAFTS
--    Drafts are separate from campaigns: funding only happens when a draft is
--    submitted through the existing campaign builder, so escrow behaviour and
--    the create_campaign RPC stay exactly as they are.
-- ----------------------------------------------------------------------------
create table if not exists public.campaign_drafts (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles (id) on delete cascade,
  title text not null default 'Campaign draft',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.campaign_drafts enable row level security;
drop policy if exists campaign_drafts_own on public.campaign_drafts;
create policy campaign_drafts_own on public.campaign_drafts
  for all to authenticated
  using (buyer_id = auth.uid())
  with check (buyer_id = auth.uid());

create or replace function public.save_campaign_draft(
  p_id uuid default null,
  p_title text default 'Campaign draft',
  p_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  d public.campaign_drafts;
begin
  if not coalesce((select is_buyer from public.profiles where id = uid), false) then
    raise exception 'BUYER_MODE_DISABLED';
  end if;

  if p_id is not null then
    update public.campaign_drafts
       set title = coalesce(nullif(btrim(p_title), ''), title),
           payload = p_payload,
           updated_at = now()
     where id = p_id and buyer_id = uid
     returning * into d;
    if not found then
      raise exception 'NOT_ALLOWED';
    end if;
  else
    insert into public.campaign_drafts (buyer_id, title, payload)
    values (uid, coalesce(nullif(btrim(p_title), ''), 'Campaign draft'), p_payload)
    returning * into d;
  end if;

  return to_jsonb(d);
end $$;

create or replace function public.list_my_campaign_drafts()
returns setof public.campaign_drafts
language sql
security definer
set search_path = public
as $$
  select * from public.campaign_drafts
   where buyer_id = auth.uid()
   order by updated_at desc
   limit 50;
$$;

create or replace function public.delete_campaign_draft(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.campaign_drafts where id = p_id and buyer_id = auth.uid();
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.save_campaign_draft(uuid, text, jsonb) from public, anon;
revoke all on function public.list_my_campaign_drafts() from public, anon;
revoke all on function public.delete_campaign_draft(uuid) from public, anon;
grant execute on function public.save_campaign_draft(uuid, text, jsonb) to authenticated;
grant execute on function public.list_my_campaign_drafts() to authenticated;
grant execute on function public.delete_campaign_draft(uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- 4. EXTENDED PUBLIC STATS (read-only; the original public_stats() is untouched)
-- ----------------------------------------------------------------------------
create or replace function public.public_stats_v2()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select public.public_stats()
       || jsonb_build_object(
            'users', (select count(*) from public.profiles),
            'active_users', (select count(*) from public.profiles where status = 'active')
          );
$$;

grant execute on function public.public_stats_v2() to anon, authenticated;
