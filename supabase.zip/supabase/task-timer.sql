-- TM GROW — task timer start marker
-- Records when the worker actually opened the task window. The claim window
-- (claim_task -> expires_at) stays the hard server-side limit.

alter table public.tasks add column if not exists started_at timestamptz;

create or replace function public.start_task(p_task_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  t public.tasks;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;
  if t.expires_at is not null and t.expires_at < now() then raise exception 'TASK_EXPIRED'; end if;

  update public.tasks
     set started_at = coalesce(started_at, now())
   where id = t.id
   returning * into t;

  return jsonb_build_object(
    'ok', true,
    'started_at', t.started_at,
    'expires_at', t.expires_at,
    'seconds_left', greatest(0, floor(extract(epoch from (t.expires_at - now())))::int)
  );
end $$;

revoke all on function public.start_task(uuid) from public, anon;
grant execute on function public.start_task(uuid) to authenticated;

notify pgrst, 'reload schema';
