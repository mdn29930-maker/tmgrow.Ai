-- TM GROW — user-facing announcement feed
-- The admin announcement centre (notifications-announcements.sql) can create,
-- schedule and publish real announcements. This exposes the sent in-app ones to
-- the audience that matches the signed-in user. No rows are fabricated.

create or replace function public.my_announcements(p_limit int default 30)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into p from public.profiles where id = u;

  return (
    select coalesce(jsonb_agg(x order by x_sent desc), '[]'::jsonb)
      from (
        select jsonb_build_object(
          'id', a.id,
          'title', a.title,
          'body', a.body,
          'image_url', a.image_url,
          'link_url', a.link_url,
          'audience', a.audience,
          'sent_at', coalesce(a.sent_at, a.updated_at, a.created_at)
        ) x,
        coalesce(a.sent_at, a.updated_at, a.created_at) as x_sent
          from public.announcements a
         where a.status = 'sent'
           and a.channel in ('in_app', 'both')
           and (
             a.audience = 'all'
             or (a.audience = 'workers' and coalesce(p.is_worker, false))
             or (a.audience = 'buyers' and coalesce(p.is_buyer, false))
           )
         order by coalesce(a.sent_at, a.updated_at, a.created_at) desc
         limit greatest(1, least(coalesce(p_limit, 30), 100))
      ) q
  );
end $$;

revoke all on function public.my_announcements(int) from public, anon;
grant execute on function public.my_announcements(int) to authenticated;

notify pgrst, 'reload schema';


-- Eligible announcements (draft / scheduled / cancelled / failed) can be deleted.
-- Sent history is kept for delivery reporting.
create or replace function public.admin_announcement_delete(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.announcements;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into a from public.announcements where id = p_id for update;
  if a.id is null then raise exception 'ANNOUNCEMENT_NOT_FOUND'; end if;
  if a.status in ('sent', 'sending') then
    raise exception 'ANNOUNCEMENT_ALREADY_SENT';
  end if;

  delete from public.announcements where id = a.id;
  perform public.audit('announcement.delete', 'announcement', p_id,
    jsonb_build_object('title', a.title, 'status', a.status));
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_announcement_delete(uuid) from public, anon;
grant execute on function public.admin_announcement_delete(uuid) to authenticated;

notify pgrst, 'reload schema';
