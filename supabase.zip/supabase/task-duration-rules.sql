-- ============================================================================
-- TM GROW — AUTOMATIC TASK DURATION RULES (no admin timer configuration)
--
-- Additive. No table is dropped or reset. Admin never sets a duration.
--
-- How it works:
--   * task_duration_rules holds the built-in defaults per platform + action.
--     They are seeded here and can be improved later with a small SQL change;
--     there is no admin screen and no per-service duration field.
--   * The platform comes from services.platform, the action is detected from
--     the service name, campaign title and instructions.
--   * start_task() assigns the duration once and stores started_at + ends_at on
--     the exact task, so the countdown cannot change midway.
--   * A trigger on submissions refuses proof before timer_ends_at. The check is
--     server-side and cannot be bypassed by the browser.
--   * Finishing the timer never approves anything: proof review stays separate.
--   * Unknown platform/action falls back to a safe default (30 s).
-- ============================================================================

begin;

-- ============================================================================
-- 1. RULES (database defaults, not admin-editable through the app)
-- ============================================================================
create table if not exists public.task_duration_rules (
  platform text not null,
  action text not null,
  seconds int not null check (seconds between 5 and 300),
  note text,
  updated_at timestamptz not null default now(),
  primary key (platform, action)
);

alter table public.task_duration_rules enable row level security;
-- Read only through the engine function; no table grants to API roles.

insert into public.task_duration_rules (platform, action, seconds, note) values
  -- YouTube
  ('youtube', 'default',   30, 'Generic YouTube action'),
  ('youtube', 'watch',     45, 'Watch time before proof'),
  ('youtube', 'view',      30, 'View a video or Short'),
  ('youtube', 'subscribe', 20, 'Subscribe to the channel'),
  ('youtube', 'like',      15, 'Like the video'),
  ('youtube', 'comment',   60, 'Read the video and write a comment'),
  -- Instagram
  ('instagram', 'default',   25, 'Generic Instagram action'),
  ('instagram', 'follow',    20, 'Follow the profile'),
  ('instagram', 'like',      15, 'Like the post'),
  ('instagram', 'view',      30, 'View a reel or story'),
  ('instagram', 'watch',     30, 'Watch a reel'),
  ('instagram', 'comment',   45, 'Read the post and comment'),
  ('instagram', 'save',      15, 'Save the post'),
  -- TikTok
  ('tiktok', 'default',  25, 'Generic TikTok action'),
  ('tiktok', 'follow',   20, 'Follow the account'),
  ('tiktok', 'like',     15, 'Like the video'),
  ('tiktok', 'view',     30, 'View the video'),
  ('tiktok', 'watch',    30, 'Watch the video'),
  ('tiktok', 'comment',  45, 'Read the video and comment'),
  ('tiktok', 'share',    20, 'Share the video'),
  -- Telegram
  ('telegram', 'default', 20, 'Generic Telegram action'),
  ('telegram', 'join',    20, 'Join the channel or group'),
  ('telegram', 'view',    15, 'Open the channel post'),
  -- Facebook
  ('facebook', 'default', 20, 'Generic Facebook action'),
  ('facebook', 'follow',  20, 'Follow the page'),
  ('facebook', 'like',    15, 'Like the page or post'),
  ('facebook', 'join',    20, 'Join the group'),
  ('facebook', 'share',   30, 'Share the post'),
  -- X / Twitter
  ('x', 'default', 20, 'Generic X action'),
  ('x', 'follow',  20, 'Follow the account'),
  ('x', 'like',    15, 'Like the post'),
  ('x', 'repost',  20, 'Repost the post'),
  ('x', 'comment', 45, 'Reply to the post'),
  -- Threads
  ('threads', 'default', 20, 'Generic Threads action'),
  ('threads', 'follow',  20, 'Follow the profile'),
  ('threads', 'like',    15, 'Like the post'),
  -- Safe fallback for any other platform
  ('*', 'default', 30, 'Fallback duration')
on conflict (platform, action) do update
  set seconds = excluded.seconds, note = excluded.note, updated_at = now();


-- ============================================================================
-- 2. ACTION DETECTION (keyword based, never invented)
-- ============================================================================
create or replace function public.task_action_of(p_platform text, p_text text)
returns text
language plpgsql
immutable
as $$
declare
  v text := lower(coalesce(p_text, ''));
begin
  if v = '' then return 'default'; end if;

  if v ~ '\m(subscribe|subscription|sub)\m' then return 'subscribe'; end if;
  if v ~ '(repost|retweet|retweet|repost)' then return 'repost'; end if;
  if v ~ 'repost' or v ~ 'retweet' then return 'repost'; end if;
  if v ~ '\mfollow(ers|ing)?\m' then return 'follow'; end if;
  if v ~ '\mlike(s)?\m' then return 'like'; end if;
  if v ~ '\mcomment(s|ing)?\m' then return 'comment'; end if;
  if v ~ '\mjoin\m' then return 'join'; end if;
  if v ~ '\m(share|shares|sharing)\m' then return 'share'; end if;
  if v ~ '\m(save|saves|saved)\m' then return 'save'; end if;
  if v ~ '\m(watch|watchtime|minutes watched|watch time)\m' then return 'watch'; end if;
  if v ~ '\m(view|views|play)\m' then return 'view'; end if;
  if v ~ '\m(visit|click|open)\m' then return 'view'; end if;

  return 'default';
end $$;

revoke all on function public.task_action_of(text, text) from public, anon, authenticated;


-- Returns the rule that applies, with a safe fallback. Never raises.
create or replace function public.task_duration(p_platform text, p_text text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_platform text := lower(btrim(coalesce(p_platform, '')));
  v_action   text := public.task_action_of(p_platform, p_text);
  v_seconds  int;
begin
  select r.seconds into v_seconds
    from public.task_duration_rules r
   where r.platform = v_platform and r.action = v_action;

  if v_seconds is null then
    -- platform default, then the global fallback
    select r.seconds into v_seconds
      from public.task_duration_rules r
     where r.platform = v_platform and r.action = 'default';
  end if;
  if v_seconds is null then
    select r.seconds into v_seconds
      from public.task_duration_rules r
     where r.platform = '*' and r.action = 'default';
  end if;

  return jsonb_build_object(
    'seconds', coalesce(v_seconds, 30),
    'action', v_action,
    'platform', v_platform,
    'rule', case when v_seconds is null then 'fallback' else v_platform || ':' || v_action end
  );
end $$;

revoke all on function public.task_duration(text, text) from public, anon;
grant execute on function public.task_duration(text, text) to authenticated;


-- ============================================================================
-- 3. COLUMNS ON tasks (assigned once per claim)
-- ============================================================================
alter table public.tasks add column if not exists required_seconds int;
alter table public.tasks add column if not exists timer_started_at timestamptz;
alter table public.tasks add column if not exists timer_ends_at timestamptz;
alter table public.tasks add column if not exists duration_rule text;

-- A new claim always starts with a clean timer.
create or replace function public.tg_task_timer_reset()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'claimed' and coalesce(old.status, '') <> 'claimed' then
    new.required_seconds := null;
    new.timer_started_at := null;
    new.timer_ends_at := null;
    new.duration_rule := null;
  elsif new.status in ('available', 'approved', 'rejected', 'cancelled', 'expired') then
    new.required_seconds := null;
    new.timer_started_at := null;
    new.timer_ends_at := null;
    new.duration_rule := null;
  end if;
  return new;
end $$;

drop trigger if exists tasks_timer_reset on public.tasks;
create trigger tasks_timer_reset
  before update on public.tasks
  for each row execute function public.tg_task_timer_reset();

revoke all on function public.tg_task_timer_reset() from public, anon, authenticated;


-- ============================================================================
-- 4. start_task assigns the duration once and returns the server deadline
-- ============================================================================
create or replace function public.start_task(p_task_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  t public.tasks;
  c public.campaigns;
  s public.services;
  v_rule jsonb;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into t from public.tasks where id = p_task_id for update;
  if t.id is null then raise exception 'TASK_NOT_FOUND'; end if;
  if t.worker_id is distinct from u then raise exception 'TASK_NOT_CLAIMED'; end if;
  if t.status <> 'claimed' then raise exception 'TASK_NOT_SUBMITTABLE'; end if;
  if t.expires_at is not null and t.expires_at < now() then raise exception 'TASK_EXPIRED'; end if;

  if t.required_seconds is null then
    select * into c from public.campaigns where id = t.campaign_id;
    select * into s from public.services where id = c.service_id;
    v_rule := public.task_duration(
      s.platform,
      coalesce(s.name, '') || ' ' || coalesce(c.title, '') || ' ' || coalesce(c.instructions, '')
    );

    update public.tasks
       set started_at = coalesce(started_at, now()),
           required_seconds = (v_rule ->> 'seconds')::int,
           timer_started_at = now(),
           timer_ends_at = now() + make_interval(secs => (v_rule ->> 'seconds')::int),
           duration_rule = v_rule ->> 'rule'
     where id = t.id
     returning * into t;
  end if;

  return jsonb_build_object(
    'ok', true,
    'started_at', t.timer_started_at,
    'required_seconds', t.required_seconds,
    'timer_ends_at', t.timer_ends_at,
    'seconds_left', greatest(0, ceil(extract(epoch from (t.timer_ends_at - now())))::int),
    'rule', t.duration_rule,
    'claim_expires_at', t.expires_at
  );
end $$;

revoke all on function public.start_task(uuid) from public, anon;
grant execute on function public.start_task(uuid) to authenticated;


-- ============================================================================
-- 5. SERVER-SIDE ENFORCEMENT on proof submission
--    The trigger runs before insert, so a forged browser countdown or a direct
--    RPC call cannot submit early. It never approves; review stays separate.
-- ============================================================================
create or replace function public.tg_submission_timer_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  t public.tasks;
begin
  select * into t from public.tasks where id = new.task_id;
  if t.id is null then
    raise exception 'TASK_NOT_FOUND';
  end if;

  /* Timer exists: it must have started and finished. */
  if t.required_seconds is not null and t.timer_ends_at is not null then
    if t.timer_started_at is null then
      raise exception 'TIMER_NOT_STARTED';
    end if;
    if now() < t.timer_ends_at then
      raise exception 'TIMER_NOT_FINISHED';
    end if;
  end if;

  /* Legacy tasks with no timer keep working (backward compatible). */
  return new;
end $$;

drop trigger if exists submissions_timer_guard on public.submissions;
create trigger submissions_timer_guard
  before insert on public.submissions
  for each row execute function public.tg_submission_timer_guard();

revoke all on function public.tg_submission_timer_guard() from public, anon, authenticated;


notify pgrst, 'reload schema';

commit;
