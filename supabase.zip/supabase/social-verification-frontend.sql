-- ============================================================================
-- TM GROW — SOCIAL VERIFICATION UI BACKEND
--
-- Additive only. Wires the existing Socify RPCs into the existing account
-- verification and task submission flows, and nothing else.
--
-- Adds:
--   * social_accounts: public profile fields + public_status (NOT_SUBMITTED,
--     CHECKING, VERIFIED_PUBLIC_PROFILE, NEEDS_MANUAL_REVIEW, REJECTED,
--     API_ERROR). Ownership stays the existing code-based manual flow.
--   * campaigns: verification_method + verification_rules (default manual).
--   * submissions: verification_method/status/reason/evidence/verified_at,
--     kept in sync with the real review status by a trigger.
--   * social_profile_check() / social_profile_finish(): worker actions that use
--     socify_lookup() and socify_result(), asynchronous via pg_net.
--   * admin_social_profiles() / admin_social_profile_detail() /
--     admin_social_profile_decide(): the admin queue with an audit reason.
--   * admin_socify_retry(): re-dispatch a failed Socify request for its owner.
--   * admin_campaign_verification() / admin_set_campaign_verification().
--   * my_social_accounts() and my_tasks() re-created with the new fields.
--
-- No wallet, ledger, review_submission, auth or Telegram logic is changed.
-- ============================================================================

begin;

-- ============================================================================
-- 1. COLUMNS
-- ============================================================================
alter table public.social_accounts add column if not exists public_status text not null default 'NOT_SUBMITTED';
alter table public.social_accounts add column if not exists profile_name text;
alter table public.social_accounts add column if not exists profile_username text;
alter table public.social_accounts add column if not exists profile_avatar text;
alter table public.social_accounts add column if not exists profile_followers bigint;
alter table public.social_accounts add column if not exists profile_posts bigint;
alter table public.social_accounts add column if not exists profile_verified boolean;
alter table public.social_accounts add column if not exists profile_private boolean;
alter table public.social_accounts add column if not exists profile_raw jsonb;
alter table public.social_accounts add column if not exists profile_checked_at timestamptz;
alter table public.social_accounts add column if not exists profile_socify_request_id uuid;
alter table public.social_accounts add column if not exists profile_error text;

alter table public.social_accounts drop constraint if exists social_accounts_public_status_check;
alter table public.social_accounts add constraint social_accounts_public_status_check
  check (public_status in ('NOT_SUBMITTED','CHECKING','VERIFIED_PUBLIC_PROFILE',
                           'NEEDS_MANUAL_REVIEW','REJECTED','API_ERROR'));

alter table public.campaigns add column if not exists verification_method text not null default 'manual';
alter table public.campaigns add column if not exists verification_rules jsonb not null default '{}'::jsonb;

alter table public.campaigns drop constraint if exists campaigns_verification_method_check;
alter table public.campaigns add constraint campaigns_verification_method_check
  check (verification_method in ('manual','public_profile','followers_min','public_media_exists'));

alter table public.submissions add column if not exists verification_method text;
alter table public.submissions add column if not exists verification_status text;
alter table public.submissions add column if not exists verification_reason text;
alter table public.submissions add column if not exists verification_evidence jsonb;
alter table public.submissions add column if not exists verified_at timestamptz;

create index if not exists social_accounts_public_status_idx
  on public.social_accounts (public_status, profile_checked_at desc);

-- Keep the verification display in step with the real review result.
create or replace function public.tg_submission_verification_sync()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_method text;
begin
  if tg_op = 'INSERT' then
    select verification_method into v_method
      from public.campaigns where id = (select campaign_id from public.tasks where id = new.task_id);
    new.verification_method := coalesce(new.verification_method, v_method, 'manual');
    new.verification_status := coalesce(new.verification_status,
      case when new.verification_method = 'manual' then 'manual_review' else 'pending' end);
    return new;
  end if;

  if new.status is distinct from old.status then
    if new.status = 'approved' then
      new.verification_status := 'approved';
      new.verified_at := coalesce(new.reviewed_at, now());
    elsif new.status = 'rejected' then
      new.verification_status := 'rejected';
      new.verified_at := coalesce(new.reviewed_at, now());
    end if;
  end if;
  return new;
end $$;

drop trigger if exists submissions_verification_sync on public.submissions;
create trigger submissions_verification_sync
  before insert or update of status on public.submissions
  for each row execute function public.tg_submission_verification_sync();

revoke all on function public.tg_submission_verification_sync() from public, anon, authenticated;


-- ============================================================================
-- 2. WORKER: PUBLIC PROFILE CHECK
-- ============================================================================
create or replace function public.social_profile_check(p_account_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  a public.social_accounts;
  v_params jsonb;
  v_res jsonb;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into a from public.social_accounts where id = p_account_id and user_id = u;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;

  if a.platform not in ('instagram','tiktok','youtube') then
    return jsonb_build_object('ok', false, 'code', 'UNSUPPORTED_PLATFORM',
      'message', 'Public profile checks are available for Instagram, TikTok and YouTube.');
  end if;

  v_params := case a.platform
    when 'tiktok' then jsonb_build_object('username', a.handle)
    else jsonb_build_object('user', a.handle)
  end;
  if a.platform = 'youtube' then
    v_params := jsonb_build_object('username', a.handle);
  end if;

  v_res := public.socify_lookup(a.platform, 'profile/info', v_params);

  if not coalesce((v_res ->> 'ok')::boolean, false) then
    update public.social_accounts
       set public_status = 'API_ERROR',
           profile_error = coalesce(v_res ->> 'message', 'The lookup could not start.'),
           updated_at = now()
     where id = a.id;
    return v_res;
  end if;

  update public.social_accounts
     set public_status = 'CHECKING',
         profile_socify_request_id = (v_res ->> 'request_id')::uuid,
         profile_error = null,
         updated_at = now()
   where id = a.id;

  perform public.audit('social.public_check', 'social_account', a.id,
    jsonb_build_object('platform', a.platform, 'request', v_res ->> 'request_id'));

  return jsonb_build_object(
    'ok', true,
    'request_id', v_res ->> 'request_id',
    'cached', coalesce((v_res ->> 'cached')::boolean, false),
    'status', coalesce(v_res ->> 'status', 'pending'),
    'data', v_res -> 'data'
  );
end $$;

revoke all on function public.social_profile_check(uuid) from public, anon;
grant execute on function public.social_profile_check(uuid) to authenticated;


create or replace function public.social_profile_finish(p_account_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  u uuid := auth.uid();
  a public.social_accounts;
  r jsonb;
  d jsonb;
  v_name text;
  v_username text;
  v_avatar text;
  v_followers bigint;
  v_posts bigint;
  v_verified boolean;
  v_private boolean;
  v_status text;
  v_err text;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into a from public.social_accounts where id = p_account_id and user_id = u;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;
  if a.profile_socify_request_id is null then
    return jsonb_build_object('ok', false, 'code', 'NO_CHECK', 'status', a.public_status,
      'message', 'Start a public profile check first.');
  end if;

  r := public.socify_result(a.profile_socify_request_id);
  if coalesce(r ->> 'status', '') = 'pending' then
    return jsonb_build_object('ok', true, 'status', 'CHECKING');
  end if;

  d := coalesce(r -> 'data', '{}'::jsonb);

  if not coalesce((r ->> 'ok')::boolean, false) then
    v_err := coalesce(r ->> 'message', 'The lookup failed.');
    v_status := case
      when r ->> 'code' = 'HTTP_404' then 'REJECTED'
      else 'API_ERROR'
    end;
    update public.social_accounts
       set public_status = v_status, profile_error = v_err,
           profile_checked_at = now(), updated_at = now()
     where id = a.id;
    return jsonb_build_object('ok', false, 'status', v_status,
      'code', r ->> 'code', 'message', v_err);
  end if;

  v_name := coalesce(d ->> 'name', d ->> 'nickname', d #>> '{user,nickname}', d ->> 'full_name');
  v_username := coalesce(d ->> 'username', d ->> 'unique_id',
                         d #>> '{user,unique_id}', d #>> '{user,username}', a.handle);
  v_avatar := coalesce(d ->> 'avatar', d ->> 'avatar_hd', d ->> 'avatar_url',
                       d ->> 'profile_pic_url', d #>> '{user,avatar}', d #>> '{user,avatar_thumb}');
  begin
    v_verified := coalesce((d ->> 'verified')::boolean, (d #>> '{user,verified}')::boolean, false);
  exception when others then v_verified := false;
  end;

  begin
    v_private := coalesce((d ->> 'private')::boolean, (d #>> '{user,private}')::boolean, false);
  exception when others then v_private := false;
  end;

  begin
    v_followers := coalesce(
      nullif(d ->> 'followers', '')::bigint,
      nullif(d ->> 'follower_count', '')::bigint,
      nullif(d #>> '{stats,followerCount}', '')::bigint,
      nullif(d #>> '{stats,followers}', '')::bigint,
      nullif(d #>> '{user,follower_count}', '')::bigint
    );
  exception when others then v_followers := null;
  end;

  begin
    v_posts := coalesce(
      nullif(d ->> 'posts', '')::bigint,
      nullif(d ->> 'video_count', '')::bigint,
      nullif(d #>> '{stats,videoCount}', '')::bigint,
      nullif(d #>> '{stats,postCount}', '')::bigint
    );
  exception when others then v_posts := null;
  end;

  v_status := case
    when v_private then 'NEEDS_MANUAL_REVIEW'
    when v_name is null and v_username is null then 'NEEDS_MANUAL_REVIEW'
    else 'VERIFIED_PUBLIC_PROFILE'
  end;

  update public.social_accounts
     set public_status = v_status,
         profile_name = v_name,
         profile_username = v_username,
         profile_avatar = v_avatar,
         profile_followers = v_followers,
         profile_posts = v_posts,
         profile_verified = v_verified,
         profile_private = v_private,
         profile_raw = d,
         profile_checked_at = now(),
         profile_error = null,
         last_synced_at = now(),
         updated_at = now()
   where id = a.id;

  perform public.audit('social.public_verified', 'social_account', a.id,
    jsonb_build_object('status', v_status, 'followers', v_followers, 'posts', v_posts));

  return jsonb_build_object('ok', true, 'status', v_status,
    'profile', jsonb_build_object(
      'name', v_name, 'username', v_username, 'avatar', v_avatar,
      'followers', v_followers, 'posts', v_posts,
      'verified', v_verified, 'private', v_private
    ));
end $$;

revoke all on function public.social_profile_finish(uuid) from public, anon;
grant execute on function public.social_profile_finish(uuid) to authenticated;


-- ============================================================================
-- 3. EXISTING WORKER RPCs WITH THE NEW FIELDS
-- ============================================================================
create or replace function public.my_social_accounts()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', a.id, 'platform', a.platform, 'handle', a.handle,
           'profile_url', a.profile_url, 'trust_label', a.trust_label,
           'status', a.status, 'last_synced_at', a.last_synced_at,
           'created_at', a.created_at,
           'public_status', a.public_status,
           'profile_name', a.profile_name,
           'profile_username', a.profile_username,
           'profile_avatar', a.profile_avatar,
           'profile_followers', a.profile_followers,
           'profile_posts', a.profile_posts,
           'profile_verified', a.profile_verified,
           'profile_private', a.profile_private,
           'profile_checked_at', a.profile_checked_at,
           'profile_error', a.profile_error
         ) order by a.platform), '[]'::jsonb)
    from public.social_accounts a
   where a.user_id = auth.uid();
$$;


create or replace function public.my_tasks(
  p_status text default null,
  p_limit int default 50,
  p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  items jsonb;
  total int;
begin
  perform public.ensure_profile();
  perform public.expire_stale_tasks();

  select count(*) into total from public.tasks t
   where t.worker_id = u
     and (p_status is null or p_status = '' or p_status = 'all' or t.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into items from (
    select jsonb_build_object(
      'id', t.id,
      'status', t.status,
      'reward', t.reward,
      'claimed_at', t.claimed_at,
      'expires_at', t.expires_at,
      'submitted_at', t.submitted_at,
      'reviewed_at', t.reviewed_at,
      'created_at', t.created_at,
      'campaign_id', c.id,
      'title', c.title,
      'platform', s.platform,
      'service_name', s.name,
      'target_url', c.target_url,
      'submission_id', sub.id,
      'submission_status', sub.status,
      'review_note', sub.review_note,
      'verification_method', coalesce(sub.verification_method, c.verification_method, 'manual'),
      'verification_status', sub.verification_status,
      'verification_reason', sub.verification_reason,
      'verified_at', sub.verified_at
    ) as x
      from public.tasks t
      join public.campaigns c on c.id = t.campaign_id
      join public.services s on s.id = c.service_id
      left join public.submissions sub on sub.task_id = t.id
     where t.worker_id = u
       and (p_status is null or p_status = '' or p_status = 'all' or t.status = p_status)
     order by t.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 100))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', items, 'total', total);
end $$;


-- ============================================================================
-- 4. ADMIN: SOCIAL VERIFICATION QUEUE
-- ============================================================================
create or replace function public.admin_social_profiles(
  p_status text default null, p_limit int default 50
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare items jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
           'id', a.id,
           'user_id', a.user_id,
           'user_name', coalesce(nullif(p.full_name, ''), p.email),
           'platform', a.platform,
           'handle', a.handle,
           'profile_url', a.profile_url,
           'ownership_status', a.status,
           'public_status', a.public_status,
           'profile_name', a.profile_name,
           'profile_username', a.profile_username,
           'profile_avatar', a.profile_avatar,
           'profile_followers', a.profile_followers,
           'profile_posts', a.profile_posts,
           'profile_verified', a.profile_verified,
           'profile_private', a.profile_private,
           'profile_checked_at', a.profile_checked_at,
           'profile_error', a.profile_error,
           'created_at', a.created_at
         ) order by a.profile_checked_at desc nulls last, a.created_at desc), '[]'::jsonb)
    into items
    from public.social_accounts a
    join public.profiles p on p.id = a.user_id
   where (p_status is null or p_status = '' or a.public_status = p_status)
   limit greatest(1, least(coalesce(p_limit, 50), 200));

  return jsonb_build_object(
    'items', items,
    'counts', jsonb_build_object(
      'total', (select count(*) from public.social_accounts),
      'verified', (select count(*) from public.social_accounts where public_status = 'VERIFIED_PUBLIC_PROFILE'),
      'manual', (select count(*) from public.social_accounts where public_status = 'NEEDS_MANUAL_REVIEW'),
      'rejected', (select count(*) from public.social_accounts where public_status = 'REJECTED'),
      'errors', (select count(*) from public.social_accounts where public_status = 'API_ERROR'),
      'checking', (select count(*) from public.social_accounts where public_status = 'CHECKING')
    )
  );
end $$;

revoke all on function public.admin_social_profiles(text, int) from public, anon;
grant execute on function public.admin_social_profiles(text, int) to authenticated;


create or replace function public.admin_social_profile_detail(p_account_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare a public.social_accounts;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into a from public.social_accounts where id = p_account_id;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;

  return jsonb_build_object(
    'account', to_jsonb(a),
    'user_name', (select coalesce(nullif(full_name, ''), email) from public.profiles where id = a.user_id),
    'history', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', r.id, 'platform', r.platform, 'resource', r.resource,
               'status', r.status, 'http_status', r.http_status,
               'credits', r.credits, 'latency_ms', r.latency_ms,
               'error_code', r.error_code, 'error_message', r.error_message,
               'created_at', r.created_at
             ) order by r.created_at desc), '[]'::jsonb)
        from (select * from public.socify_requests
               where user_id = a.user_id and platform = a.platform
               order by created_at desc limit 10) r
    )
  );
end $$;

revoke all on function public.admin_social_profile_detail(uuid) from public, anon;
grant execute on function public.admin_social_profile_detail(uuid) to authenticated;


create or replace function public.admin_social_profile_decide(
  p_account_id uuid, p_decision text, p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare a public.social_accounts; v_status text;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_decision not in ('verify','manual','reject') then raise exception 'INVALID_DECISION'; end if;
  if coalesce(btrim(p_reason), '') = '' then raise exception 'REASON_REQUIRED'; end if;

  select * into a from public.social_accounts where id = p_account_id for update;
  if a.id is null then raise exception 'SOCIAL_NOT_FOUND'; end if;

  v_status := case p_decision
    when 'verify' then 'VERIFIED_PUBLIC_PROFILE'
    when 'reject' then 'REJECTED'
    else 'NEEDS_MANUAL_REVIEW'
  end;

  update public.social_accounts
     set public_status = v_status, profile_error = left(p_reason, 500),
         profile_checked_at = coalesce(profile_checked_at, now()), updated_at = now()
   where id = a.id;

  perform public.audit('social.public_decision', 'social_account', a.id,
    jsonb_build_object('decision', p_decision, 'reason', left(p_reason, 300)));

  perform public.notify_user(a.user_id,
    case when p_decision = 'verify' then 'Public profile confirmed'
         when p_decision = 'reject' then 'Public profile could not be confirmed'
         else 'Public profile needs a manual review' end,
    left(p_reason, 300),
    case when p_decision = 'verify' then 'success' when p_decision = 'reject' then 'error' else 'info' end,
    '#/accounts');

  return jsonb_build_object('ok', true, 'status', v_status);
end $$;

revoke all on function public.admin_social_profile_decide(uuid, text, text) from public, anon;
grant execute on function public.admin_social_profile_decide(uuid, text, text) to authenticated;


-- ============================================================================
-- 5. ADMIN: RETRY A FAILED SOCIFY REQUEST (for its original owner)
-- ============================================================================
create or replace function public.admin_socify_retry(p_request_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r public.socify_requests;
  v_key text;
  v_url text;
  v_headers jsonb;
  v_net bigint;
  v_new uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  select * into r from public.socify_requests where id = p_request_id;
  if r.id is null then raise exception 'REQUEST_NOT_FOUND'; end if;
  if r.status = 'done' then
    return jsonb_build_object('ok', true, 'already', true);
  end if;
  if not exists (select 1 from public.socify_endpoints
                  where platform = r.platform and resource = r.resource and enabled) then
    raise exception 'ENDPOINT_UNAVAILABLE';
  end if;

  v_key := public.socify_api_key();
  if coalesce(btrim(v_key), '') = '' then
    return jsonb_build_object('ok', false, 'code', 'NOT_CONFIGURED',
      'message', 'No API key in Vault.');
  end if;
  if to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is null then
    return jsonb_build_object('ok', false, 'code', 'PG_NET_MISSING',
      'message', 'pg_net is not enabled.');
  end if;

  insert into public.socify_requests (user_id, platform, resource, params, request_key, status)
  values (r.user_id, r.platform, r.resource, r.params, r.request_key, 'pending')
  returning id into v_new;

  v_url := 'https://trysocify.com/api/v1/' || r.platform || '/' || r.resource;
  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key);

  begin
    v_net := net.http_get(v_url, r.params, v_headers, 10000);
  exception when others then
    update public.socify_requests
       set status = 'failed', error_code = 'DISPATCH_FAILED',
           error_message = 'Could not start the upstream request.',
           updated_at = now(), completed_at = now()
     where id = v_new;
    return jsonb_build_object('ok', false, 'code', 'DISPATCH_FAILED');
  end;

  update public.socify_requests
     set net_request_id = v_net, updated_at = now()
   where id = v_new;

  perform public.audit('socify.retry', 'socify_request', p_request_id,
    jsonb_build_object('new_request', v_new));

  return jsonb_build_object('ok', true, 'request_id', v_new);
end $$;

revoke all on function public.admin_socify_retry(uuid) from public, anon;
grant execute on function public.admin_socify_retry(uuid) to authenticated;


-- ============================================================================
-- 6. ADMIN: TASK VERIFICATION SETTINGS
-- ============================================================================
create or replace function public.admin_campaign_verification(p_campaign_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare c public.campaigns;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  select * into c from public.campaigns where id = p_campaign_id;
  if c.id is null then raise exception 'CAMPAIGN_NOT_FOUND'; end if;
  return jsonb_build_object(
    'id', c.id, 'title', c.title, 'platform', (select platform from public.services where id = c.service_id),
    'verification_method', c.verification_method,
    'verification_rules', c.verification_rules
  );
end $$;

revoke all on function public.admin_campaign_verification(uuid) from public, anon;
grant execute on function public.admin_campaign_verification(uuid) to authenticated;


create or replace function public.admin_set_campaign_verification(
  p_campaign_id uuid, p_method text, p_rules jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_rules jsonb := coalesce(p_rules, '{}'::jsonb);
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_method not in ('manual','public_profile','followers_min','public_media_exists') then
    raise exception 'INVALID_METHOD';
  end if;

  -- Only known rule keys are stored; auto approval is always written as false.
  v_rules := jsonb_build_object(
    'min_followers', greatest(0, coalesce((v_rules ->> 'min_followers')::numeric, 0)),
    'require_public_profile', coalesce((v_rules ->> 'require_public_profile')::boolean, false),
    'media_url', left(coalesce(v_rules ->> 'media_url', ''), 500),
    'allow_auto_approve', false
  );

  update public.campaigns
     set verification_method = p_method, verification_rules = v_rules, updated_at = now()
   where id = p_campaign_id;
  if not found then raise exception 'CAMPAIGN_NOT_FOUND'; end if;

  perform public.audit('campaign.verification', 'campaign', p_campaign_id,
    jsonb_build_object('method', p_method, 'rules', v_rules));

  return jsonb_build_object('ok', true, 'method', p_method, 'rules', v_rules);
end $$;

revoke all on function public.admin_set_campaign_verification(uuid, text, jsonb) from public, anon;
grant execute on function public.admin_set_campaign_verification(uuid, text, jsonb) to authenticated;


notify pgrst, 'reload schema';

commit;
