-- ============================================================================
-- TM GROW — SAFE SOCIFY KEY + VERIFICATION SCRIPT
--
-- Use this INSTEAD of the pasted "full fix" script. That script had three
-- problems:
--   1. CREATE EXTENSION pg_net WITH SCHEMA extensions — pg_net always installs
--      into its own `net` schema and does not accept another one.
--   2. DELETE FROM vault.secrets — unnecessary and destructive.
--   3. It printed the first 8 and last 4 characters of the key.
--
-- This file:
--   * never deletes a secret,
--   * stores the key with the exact routine and keeps only one row,
--   * reports extension state honestly,
--   * provides one synchronous read-only test that shows the real HTTP result.
 * Nothing here touches the app's lookup functions.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1. pg_net: let the extension choose its own schema (always `net`)
-- ---------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_extension where extname = 'pg_net') then
    begin
      execute 'create extension if not exists pg_net';
      raise notice 'pg_net installed.';
    exception when others then
      raise notice 'pg_net could not be installed automatically (%). Enable it in Supabase → Database → Extensions.', sqlerrm;
    end;
  else
    raise notice 'pg_net already installed.';
  end if;

  raise notice 'net.http_get 4-arg: %, net._http_response: %',
    to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null,
    to_regclass('net._http_response') is not null;
end $$;


-- ---------------------------------------------------------------------------
-- 2. Set / rotate the key safely (OWNER / SUPER_ADMIN only)
--    Call:  select public.socify_set_key('<NEW_KEY>');
--    The key is never returned; only its length is.
-- ---------------------------------------------------------------------------
create or replace function public.socify_set_key(p_key text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key text := btrim(coalesce(p_key, ''));
  v_id  uuid;
begin
  if current_user not in ('postgres', 'supabase_admin', 'service_role')
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if v_key = '' then
    return jsonb_build_object('ok', false, 'error', 'empty key');
  end if;
  if v_key !~ '^sk_live_[A-Za-z0-9]+$' then
    return jsonb_build_object('ok', false, 'error', 'key does not start with sk_live_ or contains unexpected characters');
  end if;

  select id into v_id
    from vault.secrets
   where name = 'socify_api_key'
   order by updated_at desc
   limit 1;

  if v_id is null then
    perform vault.create_secret(v_key, 'socify_api_key', 'Socify API key read by pg_net');
  else
    -- Positional order matches the Vault documentation:
    -- update_secret(id, new_secret, new_name, new_description)
    perform vault.update_secret(v_id, v_key, 'socify_api_key', 'Socify API key read by pg_net');
  end if;

  perform public.audit('socify.key_set', 'settings', null,
    jsonb_build_object('length', length(v_key)));

  return jsonb_build_object('ok', true, 'key_length', length(v_key));
end $$;

revoke all on function public.socify_set_key(text) from public, anon, authenticated;


-- ---------------------------------------------------------------------------
-- 3. Key status without leaking any part of the secret
-- ---------------------------------------------------------------------------
create or replace function public.socify_key_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_secret text;
  v_count  int;
begin
  if current_user not in ('postgres', 'supabase_admin', 'service_role')
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_count from vault.secrets where name = 'socify_api_key';
  select decrypted_secret into v_secret
    from vault.decrypted_secrets
   where name = 'socify_api_key'
   order by updated_at desc
   limit 1;

  return jsonb_build_object(
    'secret_rows', v_count,
    'present', v_secret is not null,
    'length', coalesce(length(v_secret), 0),
    'trimmed', v_secret = btrim(coalesce(v_secret, '')),
    'format_ok', coalesce(v_secret, '') ~ '^sk_live_[A-Za-z0-9]+$',
    'has_whitespace', coalesce(v_secret, '') ~ '\s',
    'pg_net_installed', exists (select 1 from pg_extension where extname = 'pg_net'),
    'http_get_ready', to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null
  );
end $$;

revoke all on function public.socify_key_status() from public, anon;
grant execute on function public.socify_key_status() to authenticated;


-- ---------------------------------------------------------------------------
-- 4. One synchronous read-only test (admin only)
--    Returns the real HTTP code and body. The key never leaves the function.
-- ---------------------------------------------------------------------------
create or replace function public.admin_socify_probe(p_user text default 'natgeo')
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key   text;
  v_req   bigint;
  v_state int;
  v_body  text;
  v_seen  boolean := false;
  i       integer;
begin
  if current_user not in ('postgres', 'supabase_admin', 'service_role')
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  select btrim(decrypted_secrets.secret) into v_key
    from (select decrypted_secret as secret from vault.decrypted_secrets
           where name = 'socify_api_key'
           order by updated_at desc limit 1) decrypted_secrets;

  if v_key is null or length(v_key) = 0 then
    return jsonb_build_object('ok', false, 'error', 'vault_secret_missing');
  end if;
  if to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is null then
    return jsonb_build_object('ok', false, 'error', 'pg_net_missing');
  end if;

  v_req := net.http_get(
    'https://trysocify.com/api/v1/instagram/profile/info',
    jsonb_build_object('user', coalesce(nullif(btrim(p_user), ''), 'natgeo')),
    jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Accept', 'application/json'),
    15000
  );

  for i in 1..20 loop
    perform pg_sleep(0.5);
    select true, status_code, content
      into v_seen, v_state, v_body
      from net._http_response
     where id = v_req;
    exit when coalesce(v_seen, false);
  end loop;

  if not coalesce(v_seen, false) then
    return jsonb_build_object('ok', false, 'error', 'timeout', 'request_id', v_req);
  end if;

  return jsonb_build_object(
    'ok', (v_state = 200 and coalesce(public.socify_json(v_body) ->> 'ok', 'false') = 'true'),
    'status', v_state,
    'request_id', v_req,
    'body', public.socify_json(v_body),
    'raw', case when public.socify_json(v_body) is null then left(v_body, 400) else null end
  );
end $$;

revoke all on function public.admin_socify_probe(text) from public, anon;
grant execute on function public.admin_socify_probe(text) to authenticated;


notify pgrst, 'reload schema';

commit;
