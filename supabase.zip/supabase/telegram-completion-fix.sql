-- ============================================================================
-- TM GROW — TELEGRAM TASK-COMPLETION FIX (delivery + timeout + retries)
--
-- Idempotent. Additive. Run AFTER supabase/telegram-db-sender.sql.
-- No wallet balance, ledger row, auth flow or Vault secret is touched.
--
-- Root causes fixed here (verified in the existing code):
--
--   1. NO MESSAGE ON SUBMIT.
--      supabase/telegram-events.sql created trigger tg_notify_task_submitted
--      (AFTER INSERT ON submissions) and enabled telegram_notify_task_submitted
--      = true. Every proof upload queued a "Task Submitted" Telegram message.
--      Requirement: submissions must never notify. Trigger is dropped and the
--      setting forced off.
--
--   2. APPROVAL MESSAGE ORDERED BEFORE THE CREDIT.
--      review_submission() sets submissions.status = 'approved' BEFORE it calls
--      wallet_move(). With a plain AFTER trigger the enqueue happened before the
--      reward existed. The completion trigger is now a DEFERRABLE INITIALLY
--      DEFERRED constraint trigger (fires at COMMIT, after every wallet write),
--      and it additionally requires the matching ledger credit row to exist.
--      If the credit is missing, nothing is queued.
--
--   3. 10 SECOND TIMEOUT.
--      telegram_send_pending() called net.http_post(..., 10000). The reported
--      "Timeout of 10000 ms reached ... TCP/SSL handshake time: 9992" is
--      pg_net's own timeout, not a bad bot token. Timeout is now configurable
--      (default 30 000 ms) and the API base host is configurable.
--
--   4. NO BACKOFF, NO RETRYING STATE.
--      A failed row burned 5 attempts in 5 minutes then stopped forever.
--      telegram_outbox now has: retrying state, next_attempt_at,
--      error_class, http_status, request_id. Transient failures (timeout,
--      429, 5xx, no response) back off exponentially and stay retryable.
--      Permanent failures (400/401/403/404) stop retrying but are never
--      marked sent. Nothing is ever marked sent without a 2xx response.
--
--   5. TOKEN SAFETY.
--      Errors are passed through telegram_redact() so a token-shaped string
--      can never be stored in last_error. The token is still never returned
--      by any function and never reaches the browser.
-- ============================================================================

begin;

-- ============================================================================
-- 1. SETTINGS
-- ============================================================================
-- Delivery behaviour is forced (this is the intended product rule).
insert into public.settings (key, value, is_public) values
  ('telegram_notify_task_submitted', 'false'::jsonb, false),
  ('telegram_notify_task_approved', 'false'::jsonb, false),
  ('telegram_notify_task_completed', 'true'::jsonb, false)
on conflict (key) do update set value = excluded.value, updated_at = now();

-- Tunables: keep whatever the admin already set.
insert into public.settings (key, value, is_public) values
  ('telegram_http_timeout_ms', '30000'::jsonb, false),
  ('telegram_max_attempts', '6'::jsonb, false),
  ('telegram_retry_base_seconds', '60'::jsonb, false),
  ('telegram_api_base', to_jsonb('https://api.telegram.org'::text), false)
on conflict (key) do nothing;


-- ============================================================================
-- 2. OUTBOX: columns, delivery states, retry index
-- ============================================================================
alter table public.telegram_outbox add column if not exists request_id bigint;
alter table public.telegram_outbox add column if not exists http_status integer;
alter table public.telegram_outbox add column if not exists next_attempt_at timestamptz;
alter table public.telegram_outbox add column if not exists error_class text;

alter table public.telegram_outbox drop constraint if exists telegram_outbox_status_check;
alter table public.telegram_outbox
  add constraint telegram_outbox_status_check
  check (status in ('queued', 'sending', 'sent', 'failed', 'retrying'));

create index if not exists telegram_outbox_request_idx
  on public.telegram_outbox (request_id)
  where request_id is not null;

create index if not exists telegram_outbox_retry_idx
  on public.telegram_outbox (status, next_attempt_at);


-- ============================================================================
-- 3. SAFE HELPERS
-- ============================================================================

-- Removes token-shaped strings from anything we store. Never returns a secret.
create or replace function public.telegram_redact(p_text text)
returns text
language sql
immutable
as $$
  select case
    when p_text is null then null
    else left(regexp_replace(p_text, '[0-9]{6,}:[A-Za-z0-9_-]{25,}', '[redacted]', 'g'), 500)
  end;
$$;

revoke all on function public.telegram_redact(text) from public, anon, authenticated;

-- 60s, 120s, 240s, ... capped at 1 hour.
create or replace function public.telegram_backoff_seconds(p_attempts int)
returns int
language sql
stable
as $$
  select least(
    3600,
    greatest(
      30,
      (coalesce(public.setting_num('telegram_retry_base_seconds', 60), 60))::int
        * (power(2, greatest(0, coalesce(p_attempts, 1) - 1)))::int
    )
  );
$$;

revoke all on function public.telegram_backoff_seconds(int) from public, anon, authenticated;

create or replace function public.telegram_json_message_id(p_content text)
returns bigint
language plpgsql
immutable
as $$
declare
  v bigint;
begin
  if p_content is null or btrim(p_content) = '' then
    return null;
  end if;
  begin
    v := nullif(p_content::jsonb #>> '{result,message_id}', '')::bigint;
  exception when others then
    v := null;
  end;
  return v;
end $$;

revoke all on function public.telegram_json_message_id(text) from public, anon, authenticated;


-- ============================================================================
-- 4. TOKEN READER (Vault stays the only place the token lives)
-- ============================================================================
create or replace function public.telegram_bot_token()
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v text;
begin
  if to_regclass('vault.decrypted_secrets') is null then
    return null;
  end if;

  execute 'select decrypted_secret from vault.decrypted_secrets where name = $1 limit 1'
    into v using 'telegram_bot_token';

  return v;
end $$;

revoke all on function public.telegram_bot_token() from public, anon, authenticated;


-- ============================================================================
-- 5. CLAIM: queued + due retrying + stale sending
-- ============================================================================
create or replace function public.telegram_claim_internal(p_limit int default 25)
returns setof public.telegram_outbox
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  update public.telegram_outbox o
     set status = 'sending',
         attempts = o.attempts + 1,
         attempted_at = now(),
         request_id = null,
         http_status = null
   where o.id in (
     select id
       from public.telegram_outbox
      where (status = 'queued'
             and (next_attempt_at is null or next_attempt_at <= now()))
         or (status = 'retrying'
             and (next_attempt_at is null or next_attempt_at <= now()))
         or (status = 'sending'
             and coalesce(attempted_at, created_at) < now() - interval '5 minutes')
      order by coalesce(next_attempt_at, created_at), created_at
      limit greatest(1, least(coalesce(p_limit, 25), 50))
      for update skip locked
   )
  returning o.*;
end $$;

revoke all on function public.telegram_claim_internal(int) from public, anon, authenticated;


-- ============================================================================
-- 6. DISPATCH: configurable timeout + base host, safe failure handling
-- ============================================================================
create or replace function public.telegram_send_pending(p_limit int default 25)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_token      text := public.telegram_bot_token();
  v_has_net    boolean;
  v_timeout    int;
  v_base       text;
  v_max        int;
  v_row        public.telegram_outbox;
  v_request    bigint;
  v_url        text;
  v_payload    jsonb;
  v_headers    jsonb := '{"Content-Type": "application/json"}'::jsonb;
  v_dispatched int := 0;
  v_failed     int := 0;
begin
  if coalesce(btrim(v_token), '') = '' then
    return jsonb_build_object('ok', false, 'error', 'TELEGRAM_BOT_TOKEN_MISSING',
                              'dispatched', 0, 'failed', 0);
  end if;

  v_has_net := to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
            or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;

  if not v_has_net then
    return jsonb_build_object('ok', false, 'error', 'PG_NET_NOT_INSTALLED',
                              'dispatched', 0, 'failed', 0);
  end if;

  v_timeout := greatest(5000, least(coalesce(public.setting_num('telegram_http_timeout_ms', 30000), 30000)::int, 120000));
  v_base := rtrim(coalesce(nullif(public.setting_text('telegram_api_base', ''), ''), 'https://api.telegram.org'), '/');
  v_max := greatest(1, least(coalesce(public.setting_num('telegram_max_attempts', 6), 6)::int, 20));

  for v_row in select * from public.telegram_claim_internal(p_limit) loop
    begin
      v_url := v_base || '/bot' || v_token || '/sendMessage';
      v_payload := jsonb_build_object(
        'chat_id', v_row.telegram_id::text,
        'text', v_row.message,
        'disable_web_page_preview', true
      );

      if to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null then
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers, v_timeout);
      else
        v_request := net.http_post(v_url, v_payload, '{}'::jsonb, v_headers);
      end if;

      update public.telegram_outbox
         set request_id = v_request
       where id = v_row.id;

      v_dispatched := v_dispatched + 1;
    exception when others then
      v_failed := v_failed + 1;
      update public.telegram_outbox
         set status = case when v_row.attempts >= v_max then 'failed' else 'retrying' end,
             error_class = 'transient',
             last_error = public.telegram_redact('PG_NET_ERROR: ' || sqlerrm),
             request_id = null,
             next_attempt_at = case
               when v_row.attempts >= v_max then null
               else now() + make_interval(secs => public.telegram_backoff_seconds(v_row.attempts))
             end
       where id = v_row.id;
    end;
  end loop;

  return jsonb_build_object('ok', v_failed = 0,
                            'dispatched', v_dispatched,
                            'failed', v_failed,
                            'timeout_ms', v_timeout);
end $$;

revoke all on function public.telegram_send_pending(int) from public, anon, authenticated;


-- ============================================================================
-- 7. RECONCILE: real HTTP result per attempt, no false "sent"
-- ============================================================================
create or replace function public.telegram_reconcile()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sent    int := 0;
  v_retry   int := 0;
  v_failed  int := 0;
  v_stale   int := 0;
  v_max     int;
begin
  if to_regclass('net._http_response') is null then
    return jsonb_build_object('ok', false, 'error', 'PG_NET_NOT_INSTALLED',
                              'sent', 0, 'retrying', 0, 'failed', 0);
  end if;

  v_max := greatest(1, least(coalesce(public.setting_num('telegram_max_attempts', 6), 6)::int, 20));

  -- 2xx is the only thing that counts as delivered.
  with done as (
    update public.telegram_outbox o
       set status = 'sent',
           sent_at = now(),
           message_id = public.telegram_json_message_id(r.content),
           http_status = r.status_code,
           last_error = null,
           error_class = null,
           next_attempt_at = null,
           request_id = null
      from net._http_response r
     where o.request_id = r.id
       and o.status = 'sending'
       and coalesce(r.status_code, 0) between 200 and 299
    returning 1
  )
  select count(*) into v_sent from done;

  -- Everything else: transient retries, permanent failures.
  with bad as (
    update public.telegram_outbox o
       set status = case
             when coalesce(r.status_code, 0) in (400, 401, 403, 404) then 'failed'
             when o.attempts >= v_max then 'failed'
             else 'retrying'
           end,
           http_status = r.status_code,
           error_class = case
             when coalesce(r.status_code, 0) in (400, 401, 403, 404) then 'permanent'
             else 'transient'
           end,
           last_error = public.telegram_redact(coalesce(
             nullif(r.error_msg, ''),
             case when r.timed_out then 'Timed out: Telegram TLS/HTTP handshake did not complete' end,
             r.content,
             'HTTP ' || coalesce(r.status_code::text, 'unknown')
           )),
           next_attempt_at = case
             when coalesce(r.status_code, 0) in (400, 401, 403, 404) then null
             when o.attempts >= v_max then null
             else now() + make_interval(secs => public.telegram_backoff_seconds(o.attempts))
           end,
           request_id = null
      from net._http_response r
     where o.request_id = r.id
       and o.status = 'sending'
       and not (coalesce(r.status_code, 0) between 200 and 299)
    returning o.status
  )
  select count(*) filter (where status = 'retrying'),
         count(*) filter (where status = 'failed')
    into v_retry, v_failed
    from bad;

  -- A request that never produced a response row (worker crash / lost row).
  with stale as (
    update public.telegram_outbox o
       set status = case when o.attempts >= v_max then 'failed' else 'retrying' end,
           error_class = 'transient',
           last_error = coalesce(o.last_error, 'No HTTP response from pg_net within 5 minutes'),
           next_attempt_at = case
             when o.attempts >= v_max then null
             else now() + make_interval(secs => public.telegram_backoff_seconds(o.attempts))
           end,
           request_id = null
     where o.status = 'sending'
       and coalesce(o.attempted_at, o.created_at) < now() - interval '5 minutes'
    returning 1
  )
  select count(*) into v_stale from stale;

  return jsonb_build_object(
    'ok', true,
    'sent', v_sent,
    'retrying', v_retry + v_stale,
    'failed', v_failed
  );
end $$;

revoke all on function public.telegram_reconcile() from public, anon, authenticated;


-- ============================================================================
-- 8. TICK (cron entry point)
-- ============================================================================
create or replace function public.telegram_tick()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recon jsonb;
  v_disp  jsonb;
begin
  v_recon := public.telegram_reconcile();
  v_disp  := public.telegram_send_pending(25);
  return jsonb_build_object('reconcile', v_recon, 'dispatch', v_disp);
end $$;

revoke all on function public.telegram_tick() from public, anon, authenticated;


-- ============================================================================
-- 9. DISPATCH IMMEDIATELY AFTER ENQUEUE (same transaction, after commit)
-- ============================================================================
create or replace function public.tg_telegram_outbox_dispatch()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  begin
    perform public.telegram_send_pending(5);
  exception when others then
    null;  -- a delivery problem must never roll back a payment
  end;
  return new;
end $$;

revoke all on function public.tg_telegram_outbox_dispatch() from public, anon, authenticated;

drop trigger if exists telegram_outbox_dispatch on public.telegram_outbox;
create trigger telegram_outbox_dispatch
  after insert on public.telegram_outbox
  for each row execute function public.tg_telegram_outbox_dispatch();


-- ============================================================================
-- 10. TASK COMPLETION: only after the reward credit, exactly once
-- ============================================================================

-- 10a. No Telegram message on submit. The setting alone is not enough, because
--      the admin panel can toggle it; the trigger is removed as well.
drop trigger if exists tg_notify_task_submitted on public.submissions;

-- 10b. Completion trigger: deferred (fires at COMMIT, after wallet_move) and
--      guarded by the real ledger credit row for this submission.
create or replace function public.tg_task_completed_notify()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_task     text;
  v_reward   numeric;
  v_coin     numeric;
  v_progress jsonb;
begin
  if new.status <> 'approved' or coalesce(old.status, '') = 'approved' then
    return new;
  end if;

  select c.title, t.reward
    into v_task, v_reward
    from public.tasks t
    join public.campaigns c on c.id = t.campaign_id
   where t.id = new.task_id;

  if v_task is null then
    return new;  -- SMM / non-campaign task: no task_completed message here
  end if;

  /* The reward must already be on the worker's ledger in this transaction.
     review_submission() credits the worker with wallet_move() using this
     submission id as ref_id; without that positive available credit we do
     not notify. Compared by ref_id + user + delta only, so it still matches
     if an older function version used another ref_type or kind. */
  if not exists (
    select 1
      from public.ledger_entries l
     where l.ref_id = new.id
       and l.user_id = new.worker_id
       and coalesce(l.available_delta, 0) > 0
  ) then
    raise warning 'task_completed skipped for submission %: reward credit not found', new.id;
    return new;
  end if;

  v_coin := coalesce(public.setting_num('tg_per_task', 1), 0);

  /* A broken progress helper must never suppress the delivery message. */
  begin
    v_progress := public.telegram_reward_progress(new.worker_id);
  exception when others then
    v_progress := '{}'::jsonb;
  end;

  perform public.telegram_enqueue(
    new.worker_id,
    'task_completed',
    jsonb_build_object(
      'task', v_task,
      'reward', public.telegram_money(v_reward),
      'coin', public.telegram_money(v_coin),
      'progress_line', v_progress ->> 'line',
      'next_rank', v_progress ->> 'next_rank',
      'remaining', v_progress ->> 'remaining'
    ),
    'task_completed:' || new.id          -- one row per submission, unique index
  );

  return new;
exception when others then
  raise warning 'task_completed notification skipped for submission %: %', new.id, sqlerrm;
  return new;
end $$;

revoke all on function public.tg_task_completed_notify() from public, anon, authenticated;

drop trigger if exists submissions_task_completed_tg on public.submissions;
create constraint trigger submissions_task_completed_tg
  after update on public.submissions
  deferrable initially deferred
  for each row execute function public.tg_task_completed_notify();


-- ============================================================================
-- 11. ADMIN RPCs (same signatures the panel already calls)
-- ============================================================================
create or replace function public.admin_telegram_drain(p_limit int default 50)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recon jsonb;
  v_disp  jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  v_recon := public.telegram_reconcile();
  v_disp  := public.telegram_send_pending(greatest(1, least(coalesce(p_limit, 50), 50)));

  perform public.audit('telegram.drain', 'telegram_outbox', null,
    jsonb_build_object('reconcile', v_recon, 'dispatch', v_disp));

  return v_disp || jsonb_build_object(
    'reconcile', v_recon,
    'pending', (select count(*) from public.telegram_outbox where status in ('queued','sending','retrying')),
    'retrying', (select count(*) from public.telegram_outbox where status = 'retrying'),
    'failed_total', (select count(*) from public.telegram_outbox where status = 'failed')
  );
end $$;

revoke all on function public.admin_telegram_drain(int) from public, anon;
grant execute on function public.admin_telegram_drain(int) to authenticated;


create or replace function public.admin_telegram_retry(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  update public.telegram_outbox
     set status = 'queued',
         last_error = null,
         error_class = null,
         attempted_at = null,
         next_attempt_at = null,
         request_id = null,
         http_status = null
   where id = p_id and status <> 'sent';
  if not found then raise exception 'TELEGRAM_ALREADY_SENT'; end if;

  perform public.audit('telegram.retry', 'telegram_outbox', p_id, null);
  perform public.telegram_send_pending(1);
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.admin_telegram_retry(uuid) from public, anon;
grant execute on function public.admin_telegram_retry(uuid) to authenticated;


create or replace function public.admin_telegram_sender_status()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_vault_table    boolean := to_regclass('vault.secrets') is not null;
  v_secret_set     boolean := false;
  v_cron_installed boolean := to_regclass('cron.job') is not null;
  v_cron_schedule  text;
  v_net_ok         boolean :=
    to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is not null
    or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb)') is not null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  if v_vault_table then
    execute 'select exists (select 1 from vault.secrets where name = $1)'
      into v_secret_set using 'telegram_bot_token';
  end if;

  if v_cron_installed then
    execute 'select schedule from cron.job where jobname = $1'
      into v_cron_schedule using 'tmgrow-telegram-tick';
  end if;

  return jsonb_build_object(
    'pg_net', v_net_ok,
    'pg_cron', v_cron_installed,
    'vault', v_vault_table,
    'secret_set', v_secret_set,
    'dispatch_trigger', exists (
      select 1 from pg_trigger
       where tgname = 'telegram_outbox_dispatch'
         and tgrelid = 'public.telegram_outbox'::regclass
    ),
    'completion_trigger_deferred', exists (
      select 1 from pg_trigger
       where tgname = 'submissions_task_completed_tg'
         and tgrelid = 'public.submissions'::regclass
         and tgdeferrable
    ),
    'submit_trigger_removed', not exists (
      select 1 from pg_trigger
       where tgname = 'tg_notify_task_submitted'
         and tgrelid = 'public.submissions'::regclass
    ),
    'cron_schedule', v_cron_schedule,
    'bot_enabled', public.setting_bool('telegram_bot_enabled', false),
    'task_completed_enabled', public.setting_bool('telegram_notify_task_completed', true),
    'task_submitted_enabled', public.setting_bool('telegram_notify_task_submitted', false),
    'timeout_ms', coalesce(public.setting_num('telegram_http_timeout_ms', 30000), 30000)::int,
    'max_attempts', coalesce(public.setting_num('telegram_max_attempts', 6), 6)::int,
    'api_base', coalesce(nullif(public.setting_text('telegram_api_base', ''), ''), 'https://api.telegram.org'),
    'queued', (select count(*) from public.telegram_outbox where status = 'queued'),
    'sending', (select count(*) from public.telegram_outbox where status = 'sending'),
    'retrying', (select count(*) from public.telegram_outbox where status = 'retrying'),
    'failed', (select count(*) from public.telegram_outbox where status = 'failed'),
    'sent_24h', (select count(*) from public.telegram_outbox
                  where status = 'sent' and sent_at >= now() - interval '24 hours'),
    'last_sent_at', (select max(sent_at) from public.telegram_outbox where status = 'sent'),
    'last_error', (select last_error from public.telegram_outbox
                    where last_error is not null
                    order by created_at desc limit 1),
    'last_error_class', (select error_class from public.telegram_outbox
                          where last_error is not null
                          order by created_at desc limit 1)
  );
end $$;

revoke all on function public.admin_telegram_sender_status() from public, anon;
grant execute on function public.admin_telegram_sender_status() to authenticated;


create or replace function public.admin_telegram_list(
  p_status text default null,
  p_limit int default 30,
  p_offset int default 0
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_items jsonb;
  v_total integer;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select count(*) into v_total
    from public.telegram_outbox o
   where (p_status is null or p_status = '' or o.status = p_status);

  select coalesce(jsonb_agg(x), '[]'::jsonb) into v_items from (
    select jsonb_build_object(
      'id', o.id, 'kind', o.kind, 'status', o.status, 'message', o.message,
      'attempts', o.attempts, 'last_error', o.last_error, 'message_id', o.message_id,
      'telegram_id', o.telegram_id, 'created_at', o.created_at, 'sent_at', o.sent_at,
      'request_id', o.request_id, 'http_status', o.http_status,
      'next_attempt_at', o.next_attempt_at, 'error_class', o.error_class,
      'user_id', o.user_id,
      'user_name', coalesce(nullif(p.full_name, ''), p.email, 'User')
    ) x
      from public.telegram_outbox o
      left join public.profiles p on p.id = o.user_id
     where (p_status is null or p_status = '' or o.status = p_status)
     order by o.created_at desc
     limit greatest(1, least(coalesce(p_limit, 30), 100))
    offset greatest(0, coalesce(p_offset, 0))
  ) q;

  return jsonb_build_object('items', v_items, 'total', v_total);
end $$;

revoke all on function public.admin_telegram_list(text, int, int) from public, anon;
grant execute on function public.admin_telegram_list(text, int, int) to authenticated;


create or replace function public.admin_telegram_test()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_tg  bigint;
  v_tpl text;
  v_id  uuid;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  select telegram_id into v_tg from public.profiles where id = v_uid;
  if v_tg is null then
    raise exception 'NO_TELEGRAM_LINK';
  end if;

  v_tpl := coalesce(
    nullif(public.setting_text('telegram_tpl_test', ''), ''),
    '✅ TM GROW notifications are working'
  );

  insert into public.telegram_outbox (user_id, telegram_id, kind, message, dedupe_key)
  values (v_uid, v_tg, 'test', v_tpl, 'test:' || v_uid::text || ':' || gen_random_uuid()::text)
  returning id into v_id;

  perform public.telegram_send_pending(1);
  perform public.audit('telegram.test', 'telegram_outbox', v_id, null);

  return jsonb_build_object('ok', true, 'id', v_id);
end $$;

revoke all on function public.admin_telegram_test() from public, anon;
grant execute on function public.admin_telegram_test() to authenticated;


-- ============================================================================
-- 12. DIAGNOSTIC (read-only, admin)
-- ============================================================================
create or replace function public.admin_telegram_diag()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_cron jsonb;
  v_last jsonb;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  begin
    select to_jsonb(j) into v_cron from cron.job j
     where j.jobname = 'tmgrow-telegram-tick' limit 1;
  exception when others then
    v_cron := null;
  end;

  select jsonb_build_object(
           'at', o.created_at, 'kind', o.kind, 'status', o.status,
           'attempts', o.attempts, 'http_status', o.http_status,
           'error_class', o.error_class, 'last_error', o.last_error,
           'next_attempt_at', o.next_attempt_at, 'message_id', o.message_id)
    into v_last
    from public.telegram_outbox o
   order by o.created_at desc limit 1;

  return jsonb_build_object(
    'server_time', now(),
    'cron_job', v_cron,
    'vault_secret_set', coalesce(public.telegram_bot_token(), '') <> '',
    'bot_enabled', public.setting_bool('telegram_bot_enabled', false),
    'timeout_ms', coalesce(public.setting_num('telegram_http_timeout_ms', 30000), 30000)::int,
    'max_attempts', coalesce(public.setting_num('telegram_max_attempts', 6), 6)::int,
    'api_base', coalesce(nullif(public.setting_text('telegram_api_base', ''), ''), 'https://api.telegram.org'),
    'submit_trigger_present', exists (
      select 1 from pg_trigger
       where tgname = 'tg_notify_task_submitted'
         and tgrelid = 'public.submissions'::regclass),
    'completion_trigger_deferred', exists (
      select 1 from pg_trigger
       where tgname = 'submissions_task_completed_tg'
         and tgrelid = 'public.submissions'::regclass
         and tgdeferrable),
    'outbox', jsonb_build_object(
      'queued', (select count(*) from public.telegram_outbox where status = 'queued'),
      'sending', (select count(*) from public.telegram_outbox where status = 'sending'),
      'retrying', (select count(*) from public.telegram_outbox where status = 'retrying'),
      'failed', (select count(*) from public.telegram_outbox where status = 'failed'),
      'sent', (select count(*) from public.telegram_outbox where status = 'sent')
    ),
    'task_completed_rows', jsonb_build_object(
      'today', (select count(*) from public.telegram_outbox
                 where kind = 'task_completed' and created_at >= date_trunc('day', now())),
      'sent_today', (select count(*) from public.telegram_outbox
                      where kind = 'task_completed' and status = 'sent'
                        and sent_at >= date_trunc('day', now())),
      'last_sent_at', (select max(sent_at) from public.telegram_outbox
                        where kind = 'task_completed' and status = 'sent')
    ),
    'last_row', v_last
  );
end $$;

revoke all on function public.admin_telegram_diag() from public, anon;
grant execute on function public.admin_telegram_diag() to authenticated;


-- ============================================================================
-- 13. GRANTS + CRON
-- ============================================================================
revoke all on function public.telegram_bot_token() from public, anon, authenticated;
revoke all on function public.telegram_json_message_id(text) from public, anon, authenticated;
revoke all on function public.telegram_redact(text) from public, anon, authenticated;
revoke all on function public.telegram_backoff_seconds(int) from public, anon, authenticated;
revoke all on function public.telegram_claim_internal(int) from public, anon, authenticated;
revoke all on function public.telegram_send_pending(int) from public, anon, authenticated;
revoke all on function public.telegram_reconcile() from public, anon, authenticated;
revoke all on function public.telegram_tick() from public, anon, authenticated;
revoke all on function public.tg_telegram_outbox_dispatch() from public, anon, authenticated;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule('tmgrow-telegram-tick', '* * * * *',
      $cron$select public.telegram_tick();$cron$);
    raise notice 'pg_cron: tmgrow-telegram-tick every minute (retries + reconcile).';
  else
    raise notice 'pg_cron missing: delivery works after enqueue, retries need Admin → Telegram → Send queued now.';
  end if;
end $$;


notify pgrst, 'reload schema';

commit;
