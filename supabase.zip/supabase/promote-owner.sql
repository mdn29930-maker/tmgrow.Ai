-- ============================================================================
-- TM GROW — grant OWNER (admin panel access) to an account
--
-- Password not known ("Invalid login credentials")? Use
-- supabase/reset-admin-password.sql instead: it sets the password, confirms
-- the email and grants OWNER in one run.
--
-- How to use:
--   1. Open TM GROW and sign in ONCE with the account you want to be owner.
--      Signing in creates the row in public.profiles (my_context ->
--      ensure_profile). Without that row there is nothing to update.
--   2. Supabase Dashboard -> SQL Editor -> New query.
--   3. Paste this whole file, change the email on the next line if needed,
--      and press Run. It is safe to run again.
--   4. Reload the app (or sign out and in). An "Admin" group appears in the
--      sidebar and the mobile menu, and #/admin opens the Master Admin Panel.
--
-- Every admin RPC re-checks profiles.admin_role and status on the server, so
-- this row is the real permission — nothing is granted by the browser.
-- ============================================================================

do $$
declare
  v_email text := 'mdn29930@gmail.com';   -- <-- your admin email
  v_hit int;
begin
  update public.profiles
     set admin_role = 'OWNER',
         status = 'active',
         is_suspended = false
   where lower(email) = lower(v_email);
  get diagnostics v_hit = row_count;

  if v_hit = 0 then
    raise notice 'TM GROW: no profile for %. Sign in to the app once with that account, then run this again.', v_email;
  else
    raise notice 'TM GROW: OWNER granted to % (% row updated). Reload the app.', v_email, v_hit;
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Check it. admin_role must be OWNER and status must be active.
-- ---------------------------------------------------------------------------
select id, email, full_name, admin_role, status, created_at
  from public.profiles
 where lower(email) = lower('mdn29930@gmail.com');

-- ---------------------------------------------------------------------------
-- Telegram-only account? Telegram sign-in creates a synthetic email
-- (tg<telegram_id>@telegram.tmgrow.app), so update by telegram_id instead:
--
--   update public.profiles
--      set admin_role = 'OWNER', status = 'active', is_suspended = false
--    where telegram_id = 123456789;
--
-- Not sure which account exists? List the newest profiles:
--
--   select id, email, telegram_id, admin_role, status, created_at
--     from public.profiles
--    order by created_at desc
--    limit 50;
-- ---------------------------------------------------------------------------

-- Optional: promote a second person to SUPER_ADMIN (everything except admin
-- roles) or to a narrower queue role. Valid roles:
--   OWNER, SUPER_ADMIN, ADMIN, MODERATOR, VERIFIER, SUPPORT, FINANCE
--
--   update public.profiles
--      set admin_role = 'VERIFIER'
--    where lower(email) = lower('verifier@example.com');
--
-- Remove admin access again (the account keeps working as a worker/buyer):
--
--   update public.profiles
--      set admin_role = null
--    where lower(email) = lower('mdn29930@gmail.com');
