-- ============================================================================
-- TM GROW — DATABASE-NATIVE TASK VERIFICATION (no Edge Function)
--
-- Answers one question honestly: can submitted proofs be checked automatically
-- without the verification-worker Edge Function? Yes for the deterministic
-- checks that can be done from data the database already holds; no for
-- screenshot content and Telegram channel membership, which need an external
-- call or an AI provider.
--
-- Additive. Nothing is dropped, no wallet or review logic is changed: every
-- decision still goes through verification_decide() -> automation_review_submission()
-- -> review_submission(), the same path the admin panel uses.
--
-- What runs per sweep:
--   1. duplicate proof hash (same screenshot used by another submission) -> reject
--   2. worker account not active                                        -> manual
--   3. no screenshot and no proof link                                  -> manual
--   4. Telegram channel task                                            -> manual
--   5. anything else                                                    -> manual
--
-- Auto-approval is NOT part of this sweep. Approving money automatically needs
-- a reliable check (Telegram membership via the bot, or a configured AI
-- provider). Until one is armed, clean proofs wait for a human — which is the
-- honest state.
-- ============================================================================

begin;

-- ============================================================================
-- 0. Safety
-- ============================================================================
do $$
begin
  if to_regclass('public.verification_queue') is null then
    raise exception 'verification_queue is missing. Run supabase/automation-engine.sql first, then re-run this file.';
  end if;
  if to_regprocedure('public.verification_claim_batch(int)') is null
     or to_regprocedure('public.verification_decide(uuid, text, text, jsonb)') is null
     or to_regprocedure('public.verification_context(uuid)') is null then
    raise exception 'Verification functions are missing. Run supabase/automation-engine.sql first.';
  end if;
end $$;


-- ============================================================================
-- 1. DETERMINISTIC SWEEP
-- ============================================================================
create or replace function public.automation_verification_tick(p_limit int default 10)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row    public.verification_queue;
  v_ctx    jsonb;
  v_dup    boolean;
  v_status text;
  v_platform text;
  v_has_evidence boolean;
  v_claim  int;
  v_out    jsonb := jsonb_build_object(
               'claimed', 0, 'rejected', 0, 'manual', 0, 'approved', 0, 'failed', 0
             );
begin
  if auth.role() is distinct from 'service_role'
     and not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;

  if not public.setting_bool('automation_enabled', false) then
    return v_out || jsonb_build_object('ok', false, 'reason', 'AUTOMATION_DISABLED');
  end if;

  if not exists (select 1 from public.automation_modules
                  where key = 'task_verification' and enabled) then
    return v_out || jsonb_build_object('ok', false, 'reason', 'TASK_VERIFICATION_DISABLED');
  end if;

  for v_row in
    select * from public.verification_claim_batch(greatest(1, least(coalesce(p_limit, 10), 20)))
  loop
    v_claim := v_claim + 1;
    begin
      v_ctx := public.verification_context(v_row.id);
      if v_ctx is null then
        raise exception 'NO_CONTEXT';
      end if;

      v_dup := coalesce((v_ctx ->> 'duplicate_hash')::boolean, false)
               or coalesce((v_ctx ->> 'duplicate_for_worker')::boolean, false);
      v_status := coalesce(v_ctx #>> '{worker,status}', '');
      v_platform := lower(coalesce(v_ctx #>> '{campaign,platform}', ''));
      v_has_evidence := (
        coalesce(jsonb_array_length(coalesce(v_ctx #> '{submission,proof_paths}', '[]'::jsonb)), 0) > 0
        or coalesce((v_ctx #> '{submission,proof_path}') #>> '{}', '') <> ''
        or coalesce((v_ctx #> '{submission,proof_link}') #>> '{}', '') <> ''
      );

      /* 1. Duplicate screenshot: a hard, recorded signal. */
      if v_dup then
        perform public.verification_decide(
          v_row.id, 'reject',
          'This exact screenshot was already submitted for another proof.',
          jsonb_build_object('rule', 'duplicate_hash', 'confidence', 1, 'by', 'database'));
        v_out := jsonb_set(v_out, '{rejected}', to_jsonb((v_out ->> 'rejected')::int + 1));
        continue;
      end if;

      /* 2. Worker cannot earn while not active. */
      if v_status <> 'active' then
        perform public.verification_decide(
          v_row.id, 'manual', 'Worker account is not active',
          jsonb_build_object('rule', 'worker_state', 'status', v_status, 'by', 'database'));
        v_out := jsonb_set(v_out, '{manual}', to_jsonb((v_out ->> 'manual')::int + 1));
        continue;
      end if;

      /* 3. Nothing to check. */
      if not v_has_evidence then
        perform public.verification_decide(
          v_row.id, 'manual', 'No screenshot or proof link was submitted.',
          jsonb_build_object('rule', 'missing_evidence', 'by', 'database'));
        v_out := jsonb_set(v_out, '{manual}', to_jsonb((v_out ->> 'manual')::int + 1));
        continue;
      end if;

      /* 4. Telegram membership needs a bot call that this database sweep does
            not make (pg_net is asynchronous and a decision must wait for it). */
      if v_platform = 'telegram' then
        perform public.verification_decide(
          v_row.id, 'manual', 'Telegram membership must be checked through the bot.',
          jsonb_build_object('rule', 'telegram_member', 'by', 'database'));
        v_out := jsonb_set(v_out, '{manual}', to_jsonb((v_out ->> 'manual')::int + 1));
        continue;
      end if;

      /* 5. No reliable automatic check exists for screenshot content here.
            AI verification is not configured, so a human decides. */
      perform public.verification_decide(
        v_row.id, 'manual', 'No reliable automatic verification for this task.',
        jsonb_build_object('rule', 'fallback', 'platform', v_platform,
                           'ai_configured', false, 'by', 'database'));
      v_out := jsonb_set(v_out, '{manual}', to_jsonb((v_out ->> 'manual')::int + 1));

    exception when others then
      v_out := jsonb_set(v_out, '{failed}', to_jsonb((v_out ->> 'failed')::int + 1));
      begin
        perform public.verification_fail(v_row.id, sqlerrm, true);
      exception when others then
        null;  -- the row stays processing; the next sweep re-claims it
      end;
    end;
  end loop;

  v_out := jsonb_set(v_out, '{claimed}', to_jsonb(v_claim));
  v_out := v_out || jsonb_build_object('ok', true, 'ran_at', now());

  perform public.audit('verification.sweep', 'verification_queue', null, v_out);
  return v_out;
end $$;

revoke all on function public.automation_verification_tick(int) from public, anon, authenticated;


-- ============================================================================
-- 2. pg_cron ENTRY POINT (runs with the OWNER identity, like the automation sweep)
-- ============================================================================
create or replace function public.automation_verification_scheduled()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_owner uuid;
  v_prev text;
  v_res jsonb;
begin
  select id into v_owner
    from public.profiles
   where admin_role in ('OWNER', 'SUPER_ADMIN') and status = 'active'
   order by case when admin_role = 'OWNER' then 0 else 1 end, created_at
   limit 1;

  if v_owner is null then
    return jsonb_build_object('ok', false, 'reason', 'NO_ACTIVE_OWNER');
  end if;

  v_prev := coalesce(current_setting('request.jwt.claims', true), '');
  perform set_config('request.jwt.claims',
    jsonb_build_object('sub', v_owner::text, 'role', 'authenticated')::text, true);

  begin
    v_res := public.automation_verification_tick(10);
  exception when others then
    if v_prev <> '' then perform set_config('request.jwt.claims', v_prev, true); end if;
    raise;
  end;

  if v_prev <> '' then perform set_config('request.jwt.claims', v_prev, true); end if;
  return v_res;
end $$;

revoke all on function public.automation_verification_scheduled() from public, anon, authenticated;


-- ============================================================================
-- 3. ADMIN RPCs
-- ============================================================================

-- Queue + engine + the exact switches that decide whether a sweep can run.
create or replace function public.admin_verification_queue(
  p_status text default null, p_limit int default 40
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_cron text;
  v_bot boolean := false;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','MODERATOR','VERIFIER']) then
    raise exception 'FORBIDDEN';
  end if;

  if to_regclass('cron.job') is not null then
    begin
      execute 'select schedule from cron.job where jobname = $1'
        into v_cron using 'tmgrow-verification-sweep';
    exception when others then
      v_cron := null;
    end;
  end if;

  if to_regclass('vault.secrets') is not null then
    begin
      execute 'select exists (select 1 from vault.secrets where name = $1)'
        into v_bot using 'telegram_bot_token';
    exception when others then
      v_bot := false;
    end;
  end if;

  return coalesce(public.verification_list(p_status, p_limit), '{}'::jsonb)
    || jsonb_build_object(
      'engine', public.automation_engine_status(),
      'scheduler', jsonb_build_object(
        'cron_installed', to_regclass('cron.job') is not null,
        'cron_schedule', v_cron,
        'automation_enabled', public.setting_bool('automation_enabled', false),
        'task_verification', coalesce((select enabled from public.automation_modules where key = 'task_verification'), false),
        'auto_rewards', coalesce((select enabled from public.automation_modules where key = 'auto_rewards'), false),
        'ai_verification', coalesce((select enabled from public.automation_modules where key = 'ai_verification'), false),
        'telegram_bot_token', v_bot
      ),
      'scope', jsonb_build_object(
        'automatic', jsonb_build_array(
          'duplicate screenshot hash',
          'worker account state',
          'missing evidence',
          'Telegram task routing to manual',
          'everything else to manual'
        ),
        'not_automatic', jsonb_build_array(
          'screenshot content (needs an AI provider)',
          'Telegram channel membership (needs the bot call)',
          'automatic approvals (needs a reliable check and auto_rewards on)'
        )
      )
    );
end $$;

revoke all on function public.admin_verification_queue(text, int) from public, anon;
grant execute on function public.admin_verification_queue(text, int) to authenticated;


-- Manual decision from the panel, through the same idempotent path.
create or replace function public.admin_verification_decide(
  p_queue_id uuid, p_decision text, p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if p_decision not in ('approve','reject','manual') then
    raise exception 'INVALID_DECISION';
  end if;

  return public.verification_decide(
    p_queue_id, p_decision, p_reason,
    jsonb_build_object('rule', 'manual_admin', 'by', auth.uid())
  );
end $$;

revoke all on function public.admin_verification_decide(uuid, text, text) from public, anon;
grant execute on function public.admin_verification_decide(uuid, text, text) to authenticated;


-- Manual sweep from the panel (OWNER / SUPER_ADMIN only, matching the sweep).
create or replace function public.admin_verification_tick(p_limit int default 10)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  return public.automation_verification_tick(p_limit);
end $$;

revoke all on function public.admin_verification_tick(int) from public, anon;
grant execute on function public.admin_verification_tick(int) to authenticated;


-- ============================================================================
-- 4. SCHEDULE
-- ============================================================================
do $$
begin
  if to_regclass('cron.job') is null then
    raise notice 'pg_cron is not installed: the verification sweep will not run automatically. Enable pg_cron in Supabase → Database → Extensions, then run this file again. Manual sweep and manual decisions still work.';
  else
    perform cron.schedule(
      'tmgrow-verification-sweep',
      '* * * * *',
      $cron$select public.automation_verification_scheduled();$cron$
    );
    raise notice 'pg_cron: tmgrow-verification-sweep every minute.';
  end if;
end $$;


notify pgrst, 'reload schema';

commit;
