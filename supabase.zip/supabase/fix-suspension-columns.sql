alter table public.profiles add column if not exists suspension_kind text;
alter table public.profiles add column if not exists suspension_reason text;
alter table public.profiles add column if not exists suspension_note text;
alter table public.profiles add column if not exists suspended_at timestamptz;
alter table public.profiles add column if not exists suspension_expires_at timestamptz;
alter table public.profiles add column if not exists suspension_appeal_allowed boolean not null default true;
alter table public.profiles add column if not exists suspended_by uuid references public.profiles (id) on delete set null;
alter table public.profiles add column if not exists withdrawals_blocked boolean not null default false;
alter table public.profiles add column if not exists suspension_reason_key text;
alter table public.profiles add column if not exists suspension_evidence jsonb not null default '[]'::jsonb;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_suspension_kind_chk') then
    alter table public.profiles add constraint profiles_suspension_kind_chk
      check (suspension_kind is null
             or suspension_kind in ('temporary','permanent','under_review','restricted'));
  end if;
end $$;

insert into public.settings (key, value, is_public) values
  ('automation_enabled', 'false'::jsonb, false),
  ('suspension_appeal_info',
   '"If you believe this action was taken by mistake, contact support and we will review it."'::jsonb,
   false)
on conflict (key) do nothing;

create or replace function public.restore_expired_suspensions()
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.profiles
     set status = 'active',
         is_suspended = false,
         suspension_kind = null,
         suspension_reason = null,
         suspension_expires_at = null,
         withdrawals_blocked = false,
         updated_at = now()
   where status = 'suspended'
     and suspension_kind = 'temporary'
     and suspension_expires_at is not null
     and suspension_expires_at < now();
  get diagnostics n = row_count;

  if n > 0 then
    insert into public.audit_logs (actor_role, action, entity_type, details)
    values ('system', 'suspension.auto_restore', 'profile',
            jsonb_build_object('restored', n, 'at', now()));
  end if;
  return n;
end $$;

create or replace function public.assert_account_active(p_user uuid, p_scope text default 'all')
returns void language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  if p_user is null then return; end if;
  select * into p from public.profiles where id = p_user;
  if p.id is null then raise exception 'USER_NOT_FOUND'; end if;

  if p.status = 'suspended' and p.suspension_kind = 'temporary'
     and p.suspension_expires_at is not null and p.suspension_expires_at < now() then
    perform public.restore_expired_suspensions();
    return;
  end if;

  if p.status in ('suspended','banned') then
    raise exception 'ACCOUNT_SUSPENDED';
  end if;

  if coalesce(p.withdrawals_blocked, false)
     and (p_scope in ('money','withdrawal') or p_scope = 'all') then
    raise exception 'WITHDRAWALS_BLOCKED';
  end if;
end $$;

create or replace function public.tg_block_suspended_activity()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid;
  v_scope text := coalesce(tg_argv[0], 'all');
  p public.profiles;
begin
  if tg_table_name = 'tasks' then
    if tg_op <> 'UPDATE' or not (new.status = 'claimed' and old.status = 'available') then
      return new;
    end if;
    v_uid := new.worker_id;
  elsif tg_table_name = 'submissions' then
    v_uid := new.worker_id;
  elsif tg_table_name = 'campaigns' then
    v_uid := new.buyer_id;
  elsif tg_table_name = 'withdrawals' then
    v_uid := new.user_id;
  elsif tg_table_name = 'deposits' then
    v_uid := new.user_id;
  end if;

  if v_uid is null or v_uid is distinct from auth.uid() then
    return new;
  end if;

  select * into p from public.profiles where id = v_uid;
  if p.id is null then return new; end if;

  if p.status = 'suspended' and p.suspension_kind = 'temporary'
     and p.suspension_expires_at is not null and p.suspension_expires_at < now() then
    perform public.restore_expired_suspensions();
    return new;
  end if;

  if p.status in ('suspended','banned') then
    raise exception 'ACCOUNT_SUSPENDED';
  end if;

  if coalesce(p.withdrawals_blocked, false) and v_scope in ('money','withdrawal') then
    raise exception 'WITHDRAWALS_BLOCKED';
  end if;

  return new;
end $$;

drop trigger if exists tg_block_suspended_tasks on public.tasks;
create trigger tg_block_suspended_tasks before update on public.tasks
  for each row execute function public.tg_block_suspended_activity('work');

drop trigger if exists tg_block_suspended_submissions on public.submissions;
create trigger tg_block_suspended_submissions before insert on public.submissions
  for each row execute function public.tg_block_suspended_activity('work');

drop trigger if exists tg_block_suspended_campaigns on public.campaigns;
create trigger tg_block_suspended_campaigns before insert on public.campaigns
  for each row execute function public.tg_block_suspended_activity('money');

drop trigger if exists tg_block_suspended_deposits on public.deposits;
create trigger tg_block_suspended_deposits before insert on public.deposits
  for each row execute function public.tg_block_suspended_activity('money');

drop trigger if exists tg_block_suspended_withdrawals on public.withdrawals;
create trigger tg_block_suspended_withdrawals before insert on public.withdrawals
  for each row execute function public.tg_block_suspended_activity('withdrawal');

create or replace function public.my_suspension()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v uuid := auth.uid();
  p public.profiles;
begin
  if v is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into p from public.profiles where id = v;
  if p.id is null then return jsonb_build_object('active', true); end if;

  return jsonb_build_object(
    'active', (p.status = 'active'),
    'status', p.status,
    'kind', p.suspension_kind,
    'reason', p.suspension_reason,
    'note', p.suspension_note,
    'suspended_at', p.suspended_at,
    'expires_at', p.suspension_expires_at,
    'appeal_allowed', coalesce(p.suspension_appeal_allowed, true),
    'withdrawals_blocked', coalesce(p.withdrawals_blocked, false),
    'appeal_info', public.setting_text('suspension_appeal_info', null)
  );
end $$;

revoke all on function public.my_suspension() from public, anon;
grant execute on function public.my_suspension() to authenticated;

select column_name, data_type
  from information_schema.columns
 where table_schema = 'public'
   and table_name = 'profiles'
   and (column_name like 'suspension%' or column_name in ('suspended_at','suspended_by','withdrawals_blocked'))
 order by column_name;

select trigger_name, event_object_table
  from information_schema.triggers
 where trigger_name like 'tg_block_suspended%'
 order by event_object_table;
