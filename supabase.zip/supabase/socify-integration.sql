-- ============================================================================
-- TM GROW — SOCIFY INTEGRATION (Supabase Vault + pg_net, no Edge Function)
--
-- Additive only. Nothing existing is dropped, renamed or altered.
--
-- How it works:
--   * The API key lives in Supabase Vault as `socify_api_key`. It is read only
--     inside SECURITY DEFINER functions and is never returned to any caller.
--   * The 26 documented Socify endpoints are stored in an allowlist table with
--     their exact parameter names. Unknown platforms, resources or parameters
--     are refused before any request is made.
--   * socify_lookup() validates the caller, enforces limits and cache, then
--     dispatches net.http_get(). pg_net is asynchronous, so the response is
--     read back by socify_result() (polled by the page) or by the reconcile
--     sweep. No Edge Function is involved.
--
-- Prerequisites:
--   * pg_net enabled (Database → Extensions). The Telegram sender uses it too.
--   * The key stored once in Vault (see the bottom of this file).
--
-- Safe to re-run.
-- ============================================================================

begin;

-- ============================================================================
-- 0. Keep the secret server-side
-- ============================================================================
create or replace function public.socify_api_key()
returns text
language sql
security definer
set search_path = public
as $$
  select decrypted_secret
    from vault.decrypted_secrets
   where name = 'socify_api_key'
   limit 1;
$$;

revoke all on function public.socify_api_key() from public, anon, authenticated;


-- ============================================================================
-- 1. ENDPOINT ALLOWLIST (exactly the documented catalog)
-- ============================================================================
create table if not exists public.socify_endpoints (
  platform text not null,
  resource text not null,
  label text not null,
  params jsonb not null default '[]'::jsonb,
  rules jsonb not null default '{}'::jsonb,
  credits int not null default 1,
  cache_minutes int not null default 30,
  enabled boolean not null default true,
  sort_order int not null default 100,
  updated_at timestamptz not null default now(),
  primary key (platform, resource)
);

alter table public.socify_endpoints enable row level security;
-- No policies on purpose: only SECURITY DEFINER functions read or write this.

insert into public.socify_endpoints (platform, resource, label, params, rules, credits, cache_minutes, sort_order) values
  -- Instagram (6)
  ('instagram', 'profile/info', 'Profile info',
   '[{"name":"user","required":true}]'::jsonb, '{}'::jsonb, 1, 30, 10),
  ('instagram', 'profile/media', 'Profile media',
   '[{"name":"user","required":true},{"name":"tab","required":false,"options":["posts","reels"]},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 20),
  ('instagram', 'media/info', 'Media info',
   '[{"name":"media","required":true}]'::jsonb, '{}'::jsonb, 1, 30, 30),
  ('instagram', 'media/comments', 'Media comments',
   '[{"name":"media","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 40),
  ('instagram', 'audio', 'Reels by audio',
   '[{"name":"audio_id","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 50),
  ('instagram', 'search', 'Search',
   '[{"name":"query","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 60),

  -- TikTok (11)
  ('tiktok', 'profile/info', 'Profile info',
   '[{"name":"username","required":true}]'::jsonb, '{}'::jsonb, 1, 30, 10),
  ('tiktok', 'profile/videos', 'Profile videos',
   '[{"name":"username","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 20),
  ('tiktok', 'videos/info', 'Video info',
   '[{"name":"url","required":true}]'::jsonb, '{}'::jsonb, 1, 30, 30),
  ('tiktok', 'videos/comments', 'Video comments',
   '[{"name":"url","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 40),
  ('tiktok', 'music/info', 'Music info',
   '[{"name":"id","required":true}]'::jsonb, '{}'::jsonb, 1, 30, 50),
  ('tiktok', 'music-videos', 'Music videos',
   '[{"name":"id","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 60),
  ('tiktok', 'hashtag-videos', 'Hashtag videos',
   '[{"name":"name","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 70),
  ('tiktok', 'keyword-videos', 'Keyword videos',
   '[{"name":"query","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 80),
  ('tiktok', 'profile/followers', 'Profile followers',
   '[{"name":"username","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 90),
  ('tiktok', 'profile/following', 'Profile following',
   '[{"name":"username","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 100),
  ('tiktok', 'user/search', 'User search',
   '[{"name":"query","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 110),

  -- YouTube (9)
  ('youtube', 'channel/info', 'Channel info',
   '[{"name":"id","required":false},{"name":"username","required":false}]'::jsonb, '{"one_of":["id","username"]}'::jsonb, 1, 30, 10),
  ('youtube', 'channel/videos', 'Channel videos',
   '[{"name":"id","required":false},{"name":"username","required":false},{"name":"sort","required":false,"options":["latest","popular"]},{"name":"cursor","required":false}]'::jsonb, '{"one_of":["id","username"]}'::jsonb, 1, 15, 20),
  ('youtube', 'channel/shorts', 'Channel shorts',
   '[{"name":"id","required":false},{"name":"username","required":false},{"name":"sort","required":false,"options":["latest","popular"]},{"name":"cursor","required":false}]'::jsonb, '{"one_of":["id","username"]}'::jsonb, 1, 15, 30),
  ('youtube', 'channel/streams', 'Channel streams',
   '[{"name":"id","required":false},{"name":"username","required":false},{"name":"cursor","required":false}]'::jsonb, '{"one_of":["id","username"]}'::jsonb, 1, 15, 40),
  ('youtube', 'videos/comments', 'Video comments',
   '[{"name":"url","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 15, 50),
  ('youtube', 'music-search', 'Music search',
   '[{"name":"id","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 60),
  ('youtube', 'keyword-search', 'Keyword search',
   '[{"name":"query","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 70),
  ('youtube', 'hashtag-search', 'Hashtag search',
   '[{"name":"name","required":true},{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 80),
  ('youtube', 'trend-search', 'Trend search',
   '[{"name":"cursor","required":false}]'::jsonb, '{}'::jsonb, 1, 10, 90)
on conflict (platform, resource) do update
  set label = excluded.label,
      params = excluded.params,
      rules = excluded.rules,
      credits = excluded.credits,
      cache_minutes = excluded.cache_minutes,
      sort_order = excluded.sort_order,
      updated_at = now();


-- ============================================================================
-- 2. REQUESTS + CACHE
-- ============================================================================
create table if not exists public.socify_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  platform text not null,
  resource text not null,
  params jsonb not null default '{}'::jsonb,
  request_key text not null,
  status text not null default 'pending'
    check (status in ('pending', 'done', 'failed')),
  http_status int,
  credits numeric(10, 2),
  latency_ms int,
  net_request_id bigint,
  response jsonb,
  error_code text,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  expires_at timestamptz
);

create index if not exists socify_requests_user_idx
  on public.socify_requests (user_id, created_at desc);
create index if not exists socify_requests_status_idx
  on public.socify_requests (status, created_at desc);
create index if not exists socify_requests_cache_idx
  on public.socify_requests (request_key, expires_at);

alter table public.socify_requests enable row level security;
-- No policies on purpose: only the SECURITY DEFINER functions touch rows, and
-- they return a row only to its owner or to an admin.

-- Settings (real values, editable from Admin → API Integration)
insert into public.settings (key, value, is_public) values
  ('socify_enabled', 'true'::jsonb, false),
  ('socify_worker_access', 'true'::jsonb, false),
  ('socify_user_daily_requests', '20'::jsonb, false),
  ('socify_daily_credit_cap', '200'::jsonb, false),
  ('socify_min_seconds_between', '5'::jsonb, false),
  ('socify_cache_minutes', '30'::jsonb, false)
on conflict (key) do nothing;


-- ============================================================================
-- 3. HELPERS
-- ============================================================================

-- Safe JSON parse (never raises on a non-JSON body).
create or replace function public.socify_json(p_text text)
returns jsonb
language plpgsql
immutable
as $$
declare
  v jsonb;
begin
  if p_text is null or btrim(p_text) = '' then
    return null;
  end if;
  begin
    v := p_text::jsonb;
  exception when others then
    v := null;
  end;
  return v;
end $$;

revoke all on function public.socify_json(text) from public, anon, authenticated;


-- Catalog for the lookup page: no secrets, enabled endpoints only.
create or replace function public.socify_catalog()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  return jsonb_build_object(
    'enabled', public.setting_bool('socify_enabled', true),
    'worker_access', public.setting_bool('socify_worker_access', true),
    'configured', public.socify_api_key() is not null,
    'endpoints', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'platform', platform,
               'resource', resource,
               'label', label,
               'params', params,
               'rules', rules,
               'credits', credits,
               'cache_minutes', cache_minutes
             ) order by platform, sort_order), '[]'::jsonb)
        from public.socify_endpoints
       where enabled
    )
  );
end $$;

revoke all on function public.socify_catalog() from public, anon;
grant execute on function public.socify_catalog() to authenticated;


-- The caller's own usage today + the limits that apply to them.
create or replace function public.socify_my_usage()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_cap int := public.setting_num('socify_user_daily_requests', 20)::int;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  return jsonb_build_object(
    'used_today', (select count(*) from public.socify_requests
                    where user_id = v_uid
                      and created_at >= date_trunc('day', now())),
    'limit', v_cap,
    'remaining', greatest(0, v_cap - (select count(*) from public.socify_requests
                                       where user_id = v_uid
                                         and created_at >= date_trunc('day', now())))
  );
end $$;

revoke all on function public.socify_my_usage() from public, anon;
grant execute on function public.socify_my_usage() to authenticated;


-- ============================================================================
-- 4. LOOKUP (worker-facing)
-- ============================================================================
create or replace function public.socify_lookup(
  p_platform text, p_resource text, p_params jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid       uuid := auth.uid();
  v_key       text;
  v_ep        public.socify_endpoints;
  v_params    jsonb := coalesce(p_params, '{}'::jsonb);
  v_allowed   jsonb := '{}'::jsonb;
  v_clean     jsonb := '{}'::jsonb;
  v_item      jsonb;
  v_val       text;
  v_key_name  text;
  v_required  text;
  v_rules     jsonb;
  v_headers   jsonb;
  v_url       text;
  v_hash      text;
  v_cached    public.socify_requests;
  v_id        uuid;
  v_net       bigint;
  v_since     timestamptz;
  v_used      int;
  v_cap_user  int := public.setting_num('socify_user_daily_requests', 20)::int;
  v_cap_global int := public.setting_num('socify_daily_credit_cap', 200)::int;
  v_min_gap   int := public.setting_num('socify_min_seconds_between', 5)::int;
  v_cache_min int := public.setting_num('socify_cache_minutes', 30)::int;
  v_active    boolean;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  select status = 'active' into v_active from public.profiles where id = v_uid;
  if not coalesce(v_active, false) then
    raise exception 'ACCOUNT_NOT_ACTIVE';
  end if;

  if not public.setting_bool('socify_enabled', true) then
    return jsonb_build_object('ok', false, 'code', 'DISABLED',
      'message', 'The social lookup service is disabled by the administrator.');
  end if;

  if not public.is_admin() and not public.setting_bool('socify_worker_access', true) then
    return jsonb_build_object('ok', false, 'code', 'WORKER_ACCESS_OFF',
      'message', 'Social lookup is not open to workers yet.');
  end if;

  v_key := public.socify_api_key();
  if coalesce(btrim(v_key), '') = '' then
    return jsonb_build_object('ok', false, 'code', 'NOT_CONFIGURED',
      'message', 'The service is not configured yet: no API key in Vault.');
  end if;

  if to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is null then
    return jsonb_build_object('ok', false, 'code', 'PG_NET_MISSING',
      'message', 'pg_net is not enabled on this project.');
  end if;

  select * into v_ep
    from public.socify_endpoints
   where platform = lower(btrim(coalesce(p_platform, '')))
     and resource = btrim(coalesce(p_resource, ''))
     and enabled;
  if v_ep.platform is null then
    return jsonb_build_object('ok', false, 'code', 'UNSUPPORTED',
      'message', 'That platform or resource is not in the supported catalog.');
  end if;

  /* Only documented parameters, with the documented types/options. */
  for v_item in select * from jsonb_array_elements(v_ep.params) loop
    v_key_name := v_item ->> 'name';
    v_allowed := v_allowed || jsonb_build_object(v_key_name, true);
  end loop;

  if jsonb_typeof(v_params) <> 'object' then
    return jsonb_build_object('ok', false, 'code', 'INVALID_PARAMS',
      'message', 'Parameters must be an object.');
  end if;

  for v_key_name in select jsonb_object_keys(v_params) loop
    if not (v_allowed ? v_key_name) then
      return jsonb_build_object('ok', false, 'code', 'INVALID_PARAM',
        'message', 'Unsupported parameter: ' || v_key_name);
    end if;
  end loop;

  for v_item in select * from jsonb_array_elements(v_ep.params) loop
    v_key_name := v_item ->> 'name';
    v_val := nullif(btrim(coalesce(v_params ->> v_key_name, '')), '');

    if v_val is null then
      if coalesce((v_item ->> 'required')::boolean, false) then
        return jsonb_build_object('ok', false, 'code', 'MISSING_PARAM',
          'message', 'Missing required parameter: ' || v_key_name);
      end if;
      continue;
    end if;

    if length(v_val) > 2000 then
      return jsonb_build_object('ok', false, 'code', 'INVALID_PARAM',
        'message', 'Parameter too long: ' || v_key_name);
    end if;
    if v_val ~ '[[:cntrl:]]' then
      return jsonb_build_object('ok', false, 'code', 'INVALID_PARAM',
        'message', 'Invalid characters in: ' || v_key_name);
    end if;
    if v_item ? 'options'
       and not (v_item -> 'options') ? v_val then
      return jsonb_build_object('ok', false, 'code', 'INVALID_PARAM',
        'message', 'Allowed values for ' || v_key_name || ': ' ||
                   (select string_agg(x, ', ') from jsonb_array_elements_text(v_item -> 'options') x));
    end if;

    v_clean := v_clean || jsonb_build_object(v_key_name, v_val);
  end loop;

  v_rules := coalesce(v_ep.rules, '{}'::jsonb);
  if v_rules ? 'one_of' then
    if not exists (
      select 1 from jsonb_array_elements_text(v_rules -> 'one_of') r
       where v_clean ? r
    ) then
      return jsonb_build_object('ok', false, 'code', 'MISSING_PARAM',
        'message', 'Provide one of: ' ||
          (select string_agg(x, ' or ') from jsonb_array_elements_text(v_rules -> 'one_of') x));
    end if;
  end if;

  /* Cache: an identical successful lookup within its TTL is free. */
  v_hash := md5(v_ep.platform || '|' || v_ep.resource || '|' || v_clean::text);
  select * into v_cached
    from public.socify_requests
   where request_key = v_hash
     and status = 'done'
     and expires_at is not null
     and expires_at > now()
   order by completed_at desc
   limit 1;

  if v_cached.id is not null then
    return jsonb_build_object(
      'ok', true, 'cached', true, 'request_id', v_cached.id,
      'status', 'done', 'platform', v_cached.platform, 'resource', v_cached.resource,
      'data', v_cached.response, 'credits', v_cached.credits,
      'latency_ms', v_cached.latency_ms, 'expires_at', v_cached.expires_at
    );
  end if;

  /* Limits: daily per user, global credits, minimum gap between calls. */
  select count(*) into v_used
    from public.socify_requests
   where user_id = v_uid and created_at >= date_trunc('day', now());
  if v_used >= v_cap_user then
    return jsonb_build_object('ok', false, 'code', 'USER_DAILY_LIMIT',
      'message', 'Daily lookup limit reached (' || v_cap_user || ').');
  end if;

  select count(*) into v_used
    from public.socify_requests
   where created_at >= date_trunc('day', now());
  if v_used >= v_cap_global then
    return jsonb_build_object('ok', false, 'code', 'GLOBAL_DAILY_CAP',
      'message', 'The platform daily request cap is reached. Try again tomorrow.');
  end if;

  select max(created_at) into v_since
    from public.socify_requests where user_id = v_uid;
  if v_since is not null and v_since > now() - make_interval(secs => v_min_gap) then
    return jsonb_build_object('ok', false, 'code', 'TOO_SOON',
      'message', 'Please wait a few seconds before the next lookup.',
      'retry_after', greatest(1, v_min_gap - extract(epoch from (now() - v_since))::int));
  end if;

  insert into public.socify_requests (user_id, platform, resource, params, request_key, status)
  values (v_uid, v_ep.platform, v_ep.resource, v_clean, v_hash, 'pending')
  returning id into v_id;

  v_url := 'https://trysocify.com/api/v1/' || v_ep.platform || '/' || v_ep.resource;
  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key);

  begin
    v_net := net.http_get(v_url, v_clean, v_headers, 10000);
  exception when others then
    update public.socify_requests
       set status = 'failed', error_code = 'DISPATCH_FAILED',
           error_message = 'Could not start the upstream request.',
           updated_at = now(), completed_at = now()
     where id = v_id;
    return jsonb_build_object('ok', false, 'code', 'DISPATCH_FAILED',
      'message', 'Could not start the upstream request.', 'request_id', v_id);
  end;

  update public.socify_requests
     set net_request_id = v_net, updated_at = now()
   where id = v_id;

  return jsonb_build_object(
    'ok', true, 'cached', false, 'request_id', v_id,
    'status', 'pending', 'platform', v_ep.platform, 'resource', v_ep.resource,
    'credits', v_ep.credits, 'cache_minutes', least(v_cache_min, v_ep.cache_minutes)
  );
end $$;

revoke all on function public.socify_lookup(text, text, jsonb) from public, anon;
grant execute on function public.socify_lookup(text, text, jsonb) to authenticated;


-- ============================================================================
-- 5. RESULT (poll) + RECONCILE
-- ============================================================================
create or replace function public.socify_result_internal(p_request_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r        public.socify_requests;
  v_raw    record;
  v_body   jsonb;
  v_meta   jsonb;
  v_cache  int := public.setting_num('socify_cache_minutes', 30)::int;
  v_ep_cache int;
  v_msg    text;
begin
  select * into r from public.socify_requests where id = p_request_id for update;
  if r.id is null then
    return jsonb_build_object('ok', false, 'code', 'NOT_FOUND');
  end if;

  if r.status <> 'pending' then
    return jsonb_build_object(
      'ok', r.status = 'done', 'cached', false, 'request_id', r.id,
      'status', r.status, 'platform', r.platform, 'resource', r.resource,
      'data', r.response, 'credits', r.credits, 'latency_ms', r.latency_ms,
      'http_status', r.http_status,
      'code', r.error_code, 'message', r.error_message,
      'expires_at', r.expires_at
    );
  end if;

  if r.net_request_id is null then
    if r.created_at < now() - interval '20 seconds' then
      update public.socify_requests
         set status = 'failed', error_code = 'NO_REQUEST',
             error_message = 'The request was not dispatched.',
             updated_at = now(), completed_at = now()
       where id = r.id;
    end if;
    return jsonb_build_object('ok', true, 'status', 'pending', 'request_id', r.id,
      'platform', r.platform, 'resource', r.resource);
  end if;

  select * into v_raw from net._http_response where id = r.net_request_id;

  if v_raw.id is null then
    if r.created_at < now() - interval '90 seconds' then
      update public.socify_requests
         set status = 'failed', error_code = 'NO_RESPONSE',
             error_message = 'No response from the upstream service.',
             updated_at = now(), completed_at = now()
       where id = r.id;
      return jsonb_build_object('ok', false, 'status', 'failed', 'request_id', r.id,
        'code', 'NO_RESPONSE', 'message', 'No response from the upstream service.');
    end if;
    return jsonb_build_object('ok', true, 'status', 'pending', 'request_id', r.id,
      'platform', r.platform, 'resource', r.resource);
  end if;

  if v_raw.timed_out then
    update public.socify_requests
       set status = 'failed', http_status = v_raw.status_code, error_code = 'TIMEOUT',
           error_message = 'The upstream service timed out. Try again.',
           updated_at = now(), completed_at = now()
     where id = r.id;
    return jsonb_build_object('ok', false, 'status', 'failed', 'request_id', r.id,
      'code', 'TIMEOUT', 'message', 'The upstream service timed out. Try again.');
  end if;

  v_body := public.socify_json(v_raw.content);

  if coalesce(v_raw.status_code, 0) between 200 and 299 then
    v_meta := coalesce(v_body -> 'meta', '{}'::jsonb);
    select cache_minutes into v_ep_cache
      from public.socify_endpoints
     where platform = r.platform and resource = r.resource;

    update public.socify_requests
       set status = 'done',
           http_status = v_raw.status_code,
           response = coalesce(v_body -> 'data', v_body),
           credits = coalesce((v_meta ->> 'credits_charged')::numeric, 1),
           latency_ms = coalesce((v_meta ->> 'latency_ms')::int, null),
           expires_at = now() + make_interval(mins => least(coalesce(v_ep_cache, v_cache), v_cache)),
           updated_at = now(), completed_at = now()
     where id = r.id
    returning * into r;

    return jsonb_build_object(
      'ok', true, 'cached', false, 'request_id', r.id, 'status', 'done',
      'platform', r.platform, 'resource', r.resource,
      'data', r.response, 'credits', r.credits, 'latency_ms', r.latency_ms,
      'expires_at', r.expires_at
    );
  end if;

  v_msg := case coalesce(v_raw.status_code, 0)
    when 400 then 'The upstream service rejected the parameters.'
    when 401 then 'The API key is invalid. An administrator must update it.'
    when 402 then 'Socify credits are exhausted. Top up or wait for the monthly reset.'
    when 404 then 'Not found: the public profile, media or resource does not exist.'
    when 429 then 'Rate limited by Socify. Try again shortly.'
    when 502 then 'The upstream lookup failed at Socify.'
    when 503 then 'Socify is temporarily unavailable.'
    when 504 then 'The upstream lookup timed out. Try again.'
    else 'The lookup failed.'
  end;
  if coalesce((v_body ->> 'error'), '') <> '' then
    v_msg := v_msg || ' ' || left(v_body ->> 'error', 200);
  end if;

  update public.socify_requests
     set status = 'failed', http_status = v_raw.status_code,
         error_code = 'HTTP_' || coalesce(v_raw.status_code::text, 'ERROR'),
         error_message = left(v_msg, 500),
         updated_at = now(), completed_at = now()
   where id = r.id;

  return jsonb_build_object('ok', false, 'status', 'failed', 'request_id', r.id,
    'code', 'HTTP_' || coalesce(v_raw.status_code::text, 'ERROR'),
    'message', v_msg, 'http_status', v_raw.status_code);
end $$;

revoke all on function public.socify_result_internal(uuid) from public, anon, authenticated;


create or replace function public.socify_result(p_request_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_owner uuid;
begin
  if auth.uid() is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  select user_id into v_owner from public.socify_requests where id = p_request_id;
  if v_owner is null then
    return jsonb_build_object('ok', false, 'code', 'NOT_FOUND');
  end if;
  if v_owner <> auth.uid() and not public.is_admin() then
    raise exception 'FORBIDDEN';
  end if;

  return public.socify_result_internal(p_request_id);
end $$;

revoke all on function public.socify_result(uuid) from public, anon;
grant execute on function public.socify_result(uuid) to authenticated;


-- Finishes anything a closed tab abandoned. Safe to call repeatedly.
create or replace function public.socify_reconcile(p_limit int default 20)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  v_done int := 0;
  v_failed int := 0;
  v_res jsonb;
begin
  for r in
    select id from public.socify_requests
     where status = 'pending' and created_at < now() - interval '3 seconds'
     order by created_at
     limit greatest(1, least(coalesce(p_limit, 20), 50))
  loop
    v_res := public.socify_result_internal(r.id);
    if v_res ->> 'status' = 'done' then v_done := v_done + 1;
    elsif v_res ->> 'status' = 'failed' then v_failed := v_failed + 1;
    end if;
  end loop;

  return jsonb_build_object('ok', true, 'done', v_done, 'failed', v_failed);
end $$;

revoke all on function public.socify_reconcile(int) from public, anon, authenticated;


-- ============================================================================
-- 6. ADMIN
-- ============================================================================
create or replace function public.admin_socify_overview()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key boolean := public.socify_api_key() is not null;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN','SUPPORT']) then
    raise exception 'FORBIDDEN';
  end if;

  return jsonb_build_object(
    'configured', v_key,
    'pg_net', to_regprocedure('net.http_get(text, jsonb, jsonb, integer)') is not null,
    'enabled', public.setting_bool('socify_enabled', true),
    'worker_access', public.setting_bool('socify_worker_access', true),
    'limits', jsonb_build_object(
      'user_daily_requests', public.setting_num('socify_user_daily_requests', 20),
      'daily_credit_cap', public.setting_num('socify_daily_credit_cap', 200),
      'min_seconds_between', public.setting_num('socify_min_seconds_between', 5),
      'cache_minutes', public.setting_num('socify_cache_minutes', 30)
    ),
    'platforms', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'platform', platform, 'endpoints', n
             ) order by platform), '[]'::jsonb)
        from (select platform, count(*)::int as n
                from public.socify_endpoints where enabled
               group by platform) q
    ),
    'counts', jsonb_build_object(
      'total', (select count(*) from public.socify_requests),
      'today', (select count(*) from public.socify_requests where created_at >= date_trunc('day', now())),
      'done_today', (select count(*) from public.socify_requests
                      where status = 'done' and created_at >= date_trunc('day', now())),
      'failed_today', (select count(*) from public.socify_requests
                        where status = 'failed' and created_at >= date_trunc('day', now())),
      'pending', (select count(*) from public.socify_requests where status = 'pending'),
      'credits_today', (select coalesce(sum(credits), 0) from public.socify_requests
                         where status = 'done' and created_at >= date_trunc('day', now())),
      'credits_month', (select coalesce(sum(credits), 0) from public.socify_requests
                         where status = 'done' and created_at >= date_trunc('month', now()))
    ),
    'last_success', (select max(completed_at) from public.socify_requests where status = 'done'),
    'recent', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', r.id, 'platform', r.platform, 'resource', r.resource,
               'status', r.status, 'http_status', r.http_status,
               'credits', r.credits, 'latency_ms', r.latency_ms,
               'error_code', r.error_code, 'error_message', r.error_message,
               'created_at', r.created_at,
               'user_name', coalesce(nullif(p.full_name, ''), p.email)
             ) order by r.created_at desc), '[]'::jsonb)
        from (select * from public.socify_requests order by created_at desc limit 40) r
        left join public.profiles p on p.id = r.user_id
    )
  );
end $$;

revoke all on function public.admin_socify_overview() from public, anon;
grant execute on function public.admin_socify_overview() to authenticated;


create or replace function public.admin_socify_set(p_key text, p_value jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_allowed text[] := array[
    'socify_enabled', 'socify_worker_access',
    'socify_user_daily_requests', 'socify_daily_credit_cap',
    'socify_min_seconds_between', 'socify_cache_minutes'
  ];
  v_num numeric;
begin
  if not public.has_admin_role(array['OWNER','SUPER_ADMIN','ADMIN']) then
    raise exception 'FORBIDDEN';
  end if;
  if not p_key = any(v_allowed) then
    raise exception 'INVALID_KEY';
  end if;

  if p_key in ('socify_user_daily_requests','socify_daily_credit_cap',
               'socify_min_seconds_between','socify_cache_minutes') then
    v_num := (p_value #>> '{}')::numeric;
    if v_num < 0 or v_num > 100000 then
      raise exception 'INVALID_VALUE';
    end if;
    p_value := to_jsonb(v_num);
  elsif p_key in ('socify_enabled','socify_worker_access') then
    if jsonb_typeof(p_value) <> 'boolean' then
      raise exception 'INVALID_VALUE';
    end if;
  end if;

  insert into public.settings (key, value, is_public)
  values (p_key, p_value, false)
  on conflict (key) do update set value = excluded.value, updated_at = now();

  perform public.audit('socify.setting', 'settings', null,
    jsonb_build_object('key', p_key, 'value', p_value));

  return jsonb_build_object('ok', true, 'key', p_key, 'value', p_value);
end $$;

revoke all on function public.admin_socify_set(text, jsonb) from public, anon;
grant execute on function public.admin_socify_set(text, jsonb) to authenticated;


-- ============================================================================
-- 7. OPTIONAL CRON (reconcile abandoned requests)
-- ============================================================================
do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.schedule(
      'tmgrow-socify-reconcile',
      '* * * * *',
      $cron$select public.socify_reconcile(20);$cron$
    );
    raise notice 'pg_cron: tmgrow-socify-reconcile every minute.';
  else
    raise notice 'pg_cron not installed: the page polling still completes lookups; enabling pg_cron adds a reconcile safety net.';
  end if;
end $$;


-- ============================================================================
-- 8. KEY CONFIGURATION (run once, replace the placeholder)
--
--   select vault.create_secret('<SOCIFY_API_KEY>', 'socify_api_key',
--     'Socify API key read by pg_net from Vault');
--
-- Rotate later:
--   select vault.update_secret(id, new_secret => '<NEW_KEY>')
--     from vault.secrets where name = 'socify_api_key';
--
-- The key is never stored in socify_requests, never returned by any function,
-- and never sent to the browser.
-- ============================================================================

notify pgrst, 'reload schema';

commit;
