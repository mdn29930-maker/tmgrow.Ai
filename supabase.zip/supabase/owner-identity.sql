-- TM GROW — who am I, and owner bootstrap by user id
-- Run after schema.sql, owner-access.sql and advanced-management.sql.
-- Safe to re-run. It never deletes a profile, wallet or balance.

-- The owner can be pinned by auth user id as well as by email. That covers a
-- Telegram Mini App account, whose email is tg<id>@telegram.tmgrow.app and can
-- never equal the Gmail address.
insert into public.settings (key, value, is_public) values
  ('owner_user_id', '""'::jsonb, false)
on conflict (key) do nothing;

-- Every signed-in account can read its own verified identity and role.
create or replace function public.my_identity()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_owner_email text := lower(coalesce(public.setting_text('owner_email', ''), ''));
  v_owner_uid text := lower(trim(coalesce(public.setting_text('owner_user_id', ''), '')));
  p public.profiles;
  v_confirmed boolean := false;
begin
  if v is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into p from public.profiles where id = v;
  select (u.email_confirmed_at is not null) into v_confirmed
    from auth.users u where u.id = v;

  return jsonb_build_object(
    'uid', v,
    'jwt_email', v_email,
    'auth_email_confirmed', coalesce(v_confirmed, false),
    'profile_exists', (p.id is not null),
    'profile_email', p.email,
    'full_name', p.full_name,
    'telegram_id', p.telegram_id,
    'admin_role', p.admin_role,
    'status', p.status,
    'is_admin', (p.admin_role is not null and p.status = 'active'),
    'owner_email_configured', v_owner_email,
    'owner_user_id_configured', v_owner_uid,
    'matches_owner_email', (v_owner_email <> '' and v_email = v_owner_email),
    'matches_owner_uid', (v_owner_uid <> '' and v_owner_uid = v::text)
  );
end $$;

revoke all on function public.my_identity() from public, anon;
grant execute on function public.my_identity() to authenticated;

-- claim_owner(): grants OWNER only to the configured owner, matched by verified
-- JWT email OR by the configured auth user id. No parameter is trusted.
create or replace function public.claim_owner()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_owner_email text := lower(coalesce(public.setting_text('owner_email', ''), ''));
  v_owner_uid text := lower(trim(coalesce(public.setting_text('owner_user_id', ''), '')));
  v_match_email boolean;
  v_match_uid boolean;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED';
  end if;

  v_match_email := (v_owner_email <> '' and v_email = v_owner_email);
  v_match_uid := (v_owner_uid <> '' and v_owner_uid = v_uid::text);

  if not (v_match_email or v_match_uid) then
    return jsonb_build_object(
      'ok', false,
      'reason', case when v_owner_email = '' and v_owner_uid = ''
                     then 'OWNER_NOT_CONFIGURED' else 'NOT_THE_OWNER_ACCOUNT' end,
      'uid', v_uid,
      'email', v_email
    );
  end if;

  if not exists (
    select 1 from auth.users u
     where u.id = v_uid
       and (u.email_confirmed_at is not null or v_match_uid)
  ) then
    return jsonb_build_object('ok', false, 'reason', 'EMAIL_NOT_VERIFIED', 'uid', v_uid);
  end if;

  perform public.ensure_profile();

  update public.profiles
     set admin_role = 'OWNER',
         status = 'active',
         is_suspended = false,
         updated_at = now()
   where id = v_uid;

  insert into public.wallets (user_id) values (v_uid)
  on conflict (user_id) do nothing;

  perform public.audit('owner.claim', 'profile', v_uid,
    jsonb_build_object('email', v_email, 'matched', case when v_match_email then 'email' else 'uid' end));

  return jsonb_build_object('ok', true, 'email', v_email, 'uid', v_uid, 'role', 'OWNER');
end $$;

revoke all on function public.claim_owner() from public, anon;
grant execute on function public.claim_owner() to authenticated;

-- Safe self-check. The SQL editor runs as the postgres role with no JWT, so
-- auth.uid() is null there and my_identity() would (correctly) refuse. Calling
-- it from the app is authenticated; in the editor you only get this note.
select case
         when auth.uid() is null then jsonb_build_object(
           'authenticated', false,
           'note', 'No JWT in the SQL editor. This function is called by the app after sign-in. To test here, set request.jwt.claims first (see comment below).'
         )
         else public.my_identity()
       end as identity;

-- Optional manual test with a real user, inside the same transaction:
--   select set_config('request.jwt.claims',
--     json_build_object('sub','<auth-user-id>','role','authenticated','email','mdn29930@gmail.com')::text,
--     true);
--   select public.my_identity();
--   select public.claim_owner();

