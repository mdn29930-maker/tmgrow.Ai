-- TM GROW — fix "column reference c is ambiguous" in create_campaign
--
-- Cause: create_campaign() declares a record variable named "c"
-- (c public.campaigns) and the country normalisation used
--     from unnest(coalesce(p_countries,'{}')) c
-- where the table alias and its single output column are both named "c".
-- PL/pgSQL then cannot tell whether "c" means the campaigns record or the
-- unnested text value.
--
-- Fix: alias the unnested column as t(cc) and qualify every reference.
-- No p_ parameter needed renaming — they are already prefixed.
--
-- Run this whole file once in Supabase -> SQL Editor. It replaces the
-- function; no table, row, wallet or balance is touched.

create or replace function public.create_campaign(
  p_service_id uuid,
  p_title text,
  p_instructions text,
  p_target_url text,
  p_quantity int,
  p_reward numeric,
  p_countries text[] default '{}',
  p_min_trust int default 0,
  p_require_linked_account boolean default false
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  p public.profiles;
  s public.services;
  w public.wallets;
  c public.campaigns;
  budget numeric;
  fee numeric;
  fee_pct numeric;
  countries_clean text[];
begin
  perform public.ensure_profile();
  select * into p from public.profiles where id = u;
  if p.status <> 'active' then raise exception 'ACCOUNT_RESTRICTED'; end if;
  if not p.is_buyer then raise exception 'BUYER_MODE_DISABLED'; end if;

  select * into s from public.services where id = p_service_id;
  if s.id is null or not s.active then raise exception 'SERVICE_UNAVAILABLE'; end if;

  if p_title is null or char_length(trim(p_title)) < 3 then raise exception 'INVALID_TITLE'; end if;
  if p_instructions is null or char_length(trim(p_instructions)) < 10 then raise exception 'INVALID_INSTRUCTIONS'; end if;
  if p_target_url is null or p_target_url !~* '^https?://' then raise exception 'INVALID_TARGET_URL'; end if;
  if p_quantity is null or p_quantity < s.min_quantity or p_quantity > s.max_quantity then
    raise exception 'INVALID_QUANTITY';
  end if;
  if p_reward is null or p_reward < s.min_reward or p_reward > s.min_reward * 50 then
    raise exception 'INVALID_REWARD';
  end if;

  if (select count(*) from public.campaigns cp
       where cp.buyer_id = u and cp.status in ('pending','active','paused')) >= 10 then
    raise exception 'TOO_MANY_ACTIVE_CAMPAIGNS';
  end if;

  -- Unnested values are named "cc" via the alias t(cc). Never alias this
  -- column "c": create_campaign already has a record variable c.
  select coalesce(array_agg(distinct upper(trim(cc))), '{}')
    into countries_clean
    from unnest(coalesce(p_countries, '{}')) as t(cc)
   where cc is not null and trim(cc) <> '';

  select * into w from public.wallets where user_id = u for update;
  budget := round(p_quantity::numeric * p_reward, 6);
  fee_pct := least(greatest(coalesce(public.setting_num('campaign_fee_pct', 10), 0), 0), 50);
  fee := round(budget * fee_pct / 100.0, 6);

  if w.available < budget + fee then raise exception 'INSUFFICIENT_FUNDS'; end if;

  perform public.wallet_move(u, -(budget + fee), 0, budget, 0, 'campaign_funding', 'campaign', null,
                             'Campaign budget reserved in escrow');

  insert into public.campaigns (
    buyer_id, service_id, title, instructions, target_url,
    quantity, reward_per_task, total_budget, fee_amount, reserved_remaining,
    status, countries, min_trust_score, require_linked_account
  ) values (
    u, s.id, trim(p_title), trim(p_instructions), trim(p_target_url),
    p_quantity, p_reward, budget, fee, budget,
    case when public.setting_bool('auto_approve_campaigns', true) then 'active' else 'pending' end,
    countries_clean, greatest(0, least(coalesce(p_min_trust, 0), 100)),
    coalesce(p_require_linked_account, false)
  ) returning * into c;

  insert into public.platform_ledger (kind, amount, ref_type, ref_id, note, created_by)
  values ('campaign_fee', fee, 'campaign', c.id, 'Campaign fee', u);

  update public.ledger_entries le
     set ref_id = c.id
   where le.user_id = u
     and le.kind = 'campaign_funding'
     and le.ref_id is null
     and le.id = (select max(le2.id) from public.ledger_entries le2
                   where le2.user_id = u and le2.kind = 'campaign_funding');

  if c.status = 'active' then
    insert into public.tasks (campaign_id, status, reward)
    select c.id, 'available', c.reward_per_task
      from generate_series(1, c.quantity);
  end if;

  perform public.audit('campaign.create', 'campaign', c.id,
    jsonb_build_object('title', c.title, 'quantity', c.quantity, 'budget', budget, 'fee', fee));
  perform public.notify_user(u, 'Campaign created',
    '"' || c.title || '" is ' || c.status || '.', 'success', '#/buyer/campaigns/' || c.id);

  return jsonb_build_object('campaign', to_jsonb(c));
end $$;

notify pgrst, 'reload schema';

-- Verify
select proname, pg_get_function_identity_arguments(oid) as args
  from pg_proc
 where pronamespace = 'public'::regnamespace
   and proname = 'create_campaign';
