/* Supabase Edge Function: verification-worker
 *
 * Drains verification_queue safely:
 *   deterministic rules → Telegram Bot API membership → optional AI → manual.
 *
 * Only two outcomes ever touch money, and both go through the existing
 * review_submission() ledger path via verification_decide():
 *   approve  (requires the `auto_rewards` module + automation_enabled)
 *   reject   (only on definitive evidence: reused screenshot hash, or
 *             Telegram reporting left/kicked)
 * Everything uncertain becomes `manual` — never a paid guess.
 *
 * Deploy:
 *   supabase functions deploy verification-worker
 *   supabase secrets set AUTOMATION_CRON_SECRET=<random>
 *   # optional AI (OpenAI-compatible vision endpoint)
 *   supabase secrets set AI_VERIFY_URL=... AI_VERIFY_KEY=... AI_VERIFY_MODEL=...
 *
 * Schedule (Supabase Cron, every 1–2 minutes):
 *   POST https://<ref>.supabase.co/functions/v1/verification-worker
 *   header x-cron-secret: <AUTOMATION_CRON_SECRET>
 *
 * Auth: cron secret, or a signed-in OWNER / SUPER_ADMIN JWT.
 */

import { createClient } from 'npm:@supabase/supabase-js@2.45.4';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' }
  });

type Ctx = {
  queue: { id: string; submission_id: string; worker_id: string; attempts: number; mode: string };
  submission: { id: string; proof_path?: string; proof_paths?: string[]; proof_link?: string; note?: string };
  task: { id: string; reward: number };
  campaign: { id: string; title: string; target_url: string; platform: string; instructions?: string };
  worker: { id: string; status: string; telegram_id?: number | null; is_suspended?: boolean };
  duplicate_hash?: boolean;
  duplicate_for_worker?: boolean;
};

function telegramChannel(url: string): string | null {
  try {
    const u = new URL(String(url));
    if (!/(^|\.)t\.me$/i.test(u.hostname)) return null;
    const part = u.pathname.replace(/^\//, '').split('/')[0];
    if (!part || part === 'joinchat' || part.startsWith('+')) return null;
    return `@${part}`;
  } catch (_) { return null; }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);

  const supabaseUrl = (Deno.env.get('SUPABASE_URL') || '').trim();
  const serviceKey = (Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '').trim();
  if (!supabaseUrl || !serviceKey) return json({ error: 'Missing SUPABASE_URL / SERVICE_ROLE_KEY' }, 500);

  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false }
  });

  /* ---------------------------------------------------------------- auth */
  const cronSecret = (Deno.env.get('AUTOMATION_CRON_SECRET') || '').trim();
  const viaCron = !!cronSecret && (req.headers.get('x-cron-secret') || '') === cronSecret;

  if (!viaCron) {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.toLowerCase().startsWith('bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return json({ error: 'UNAUTHENTICATED' }, 401);
    const { data: userData, error: userError } = await admin.auth.getUser(token);
    if (userError || !userData?.user) return json({ error: 'UNAUTHENTICATED' }, 401);
    const { data: profile } = await admin
      .from('profiles')
      .select('admin_role, status')
      .eq('id', userData.user.id)
      .maybeSingle();
    if (!profile || profile.status !== 'active'
        || !['OWNER', 'SUPER_ADMIN'].includes(String(profile.admin_role))) {
      return json({ error: 'FORBIDDEN' }, 403);
    }
  }

  /* -------------------------------------------------------------- modules */
  const { data: armed } = await admin
    .from('settings').select('value').eq('key', 'automation_enabled').maybeSingle();
  const enabled = armed?.value === true;
  if (!enabled) return json({ ok: false, reason: 'AUTOMATION_DISABLED' }, 409);

  const { data: modules } = await admin
    .from('automation_modules').select('key, enabled, config')
    .in('key', ['task_verification', 'auto_rewards', 'fraud_engine', 'ai_verification']);

  const moduleOn = (key: string) => !!modules?.find((m) => m.key === key)?.enabled;
  const aiConfig = modules?.find((m) => m.key === 'ai_verification')?.config || {};
  if (!moduleOn('task_verification')) {
    return json({ ok: false, reason: 'TASK_VERIFICATION_DISABLED' }, 409);
  }

  /* ---------------------------------------------------------------- claim */
  const { data: batch, error: claimError } = await admin
    .rpc('verification_claim_batch', { p_limit: 10 });
  if (claimError) return json({ error: claimError.message }, 500);
  const jobs = (batch || []) as Array<{ id: string }>;

  const botToken = (Deno.env.get('TELEGRAM_BOT_TOKEN') || '').trim();
  const aiUrl = (Deno.env.get('AI_VERIFY_URL') || '').trim();
  const aiKey = (Deno.env.get('AI_VERIFY_KEY') || '').trim();
  const aiModel = (Deno.env.get('AI_VERIFY_MODEL') || 'gpt-4o-mini').trim();
  const aiMinConfidence = Number(aiConfig?.min_confidence ?? 0.9);
  let aiCalls = 0;
  const aiCap = 10;

  const stats = { claimed: jobs.length, approved: 0, rejected: 0, manual: 0, failed: 0, ai_checks: 0 };

  const decide = async (id: string, decision: string, reason: string | null, evidence: unknown) => {
    const { error } = await admin.rpc('verification_decide', {
      p_queue_id: id, p_decision: decision,
      p_reason: reason, p_evidence: evidence ?? {}
    });
    if (!error) return true;
    if (/AUTO_REWARDS_DISABLED/.test(error.message)) {
      /* Approvals are armed off: keep it for a human instead of guessing. */
      await admin.rpc('verification_decide', {
        p_queue_id: id, p_decision: 'manual',
        p_reason: 'Auto rewards are disabled', p_evidence: evidence ?? {}
      });
      return false;
    }
    throw new Error(error.message);
  };

  for (const job of jobs) {
    try {
      const { data: rawCtx, error: ctxError } = await admin
        .rpc('verification_context', { p_queue_id: job.id });
      if (ctxError || !rawCtx) throw new Error(ctxError?.message || 'NO_CONTEXT');
      const ctx = rawCtx as Ctx;

      /* ---------------------------------------------------- deterministic */
      if (ctx.duplicate_hash || ctx.duplicate_for_worker) {
        const ok = await decide(job.id, 'reject',
          'This exact screenshot was already submitted for another proof.',
          { rule: 'duplicate_hash', confidence: 1 });
        if (ok) stats.rejected += 1;
        continue;
      }

      if (ctx.worker.is_suspended || ctx.worker.status !== 'active') {
        await decide(job.id, 'manual', 'Worker account is not active', { rule: 'worker_state' });
        stats.manual += 1;
        continue;
      }

      /* -------------------------------------------------- Telegram member */
      if (ctx.campaign.platform === 'telegram' && botToken) {
        const channel = telegramChannel(ctx.campaign.target_url);
        const tgId = Number(ctx.worker.telegram_id || 0);
        if (channel && tgId) {
          const api = `https://api.telegram.org/bot${botToken}/getChatMember`
            + `?chat_id=${encodeURIComponent(channel)}&user_id=${tgId}`;
          const res = await fetch(api);
          const data = await res.json().catch(() => ({}));
          if (data?.ok) {
            const status = String(data.result?.status || '');
            const evidence = { rule: 'telegram_member', channel, status };
            if (['member', 'administrator', 'creator'].includes(status)) {
              const ok = await decide(job.id, 'approve', null as unknown as string, evidence);
              if (ok) stats.approved += 1;
              else stats.manual += 1;
              continue;
            }
            if (['left', 'kicked'].includes(status)) {
              const ok = await decide(job.id, 'reject',
                'Your account is not a member of this Telegram channel.', evidence);
              if (ok) stats.rejected += 1;
              continue;
            }
            await decide(job.id, 'manual', 'Telegram membership is restricted/unknown', evidence);
            stats.manual += 1;
            continue;
          }
          await decide(job.id, 'manual', 'Bot could not read channel membership (bot may not be an admin)',
            { rule: 'telegram_member', channel, error: String(data?.description || 'unknown') });
          stats.manual += 1;
          continue;
        }
        await decide(job.id, 'manual', 'Worker has no linked Telegram account for verification',
          { rule: 'telegram_member' });
        stats.manual += 1;
        continue;
      }

      /* -------------------------------------------------- optional AI pass */
      if (moduleOn('ai_verification') && aiUrl && aiKey && aiCalls < aiCap) {
        const path = (ctx.submission.proof_paths && ctx.submission.proof_paths[0]) || ctx.submission.proof_path;
        if (path) {
          const { data: signed } = await admin.storage.from('proofs').createSignedUrl(path, 600);
          if (signed?.signedUrl) {
            aiCalls += 1;
            stats.ai_checks += 1;
            try {
              const res = await fetch(aiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${aiKey}` },
                body: JSON.stringify({
                  model: aiModel,
                  response_format: { type: 'json_object' },
                  messages: [
                    {
                      role: 'system',
                      content: 'You verify social-task screenshots for TM GROW. Answer with JSON only: '
                        + '{"verdict":"approve|reject|uncertain","confidence":0-1,"reason":"short"}. '
                        + 'Only say approve when the screenshot clearly proves the requested action by the '
                        + 'worker; otherwise say uncertain.'
                    },
                    {
                      role: 'user',
                      content: [
                        { type: 'text', text: `Task: ${ctx.campaign.title}\nPlatform: ${ctx.campaign.platform}\nInstructions: ${ctx.campaign.instructions || ''}` },
                        { type: 'image_url', image_url: { url: signed.signedUrl } }
                      ]
                    }
                  ]
                })
              });
              const data = await res.json().catch(() => null);
              const text = data?.choices?.[0]?.message?.content || '{}';
              const verdict = JSON.parse(typeof text === 'string' ? text : '{}');
              const confidence = Number(verdict.confidence || 0);
              const evidence = { rule: 'ai', verdict: verdict.verdict, confidence, reason: verdict.reason };

              if (verdict.verdict === 'approve' && confidence >= aiMinConfidence) {
                const ok = await decide(job.id, 'approve', null as unknown as string, evidence);
                if (ok) stats.approved += 1;
                else stats.manual += 1;
                continue;
              }
              if (verdict.verdict === 'reject' && confidence >= 0.98) {
                const ok = await decide(job.id, 'reject',
                  'The screenshot does not show the required action.', evidence);
                if (ok) stats.rejected += 1;
                continue;
              }
              await decide(job.id, 'manual', 'AI was not confident enough', evidence);
              stats.manual += 1;
              continue;
            } catch (e) {
              await decide(job.id, 'manual', 'AI verification failed', { rule: 'ai', error: String((e as Error).message) });
              stats.manual += 1;
              continue;
            }
          }
        }
      }

      /* ------------------------------------------- nothing reliable enough */
      await decide(job.id, 'manual', 'No reliable automatic verification for this task', {
        rule: 'fallback', platform: ctx.campaign.platform
      });
      stats.manual += 1;
    } catch (e) {
      stats.failed += 1;
      const message = String((e as Error)?.message || e);
      /* Automatic DB/API failures are retryable; retries back off, then dead. */
      try {
        await admin.rpc('verification_fail', {
          p_queue_id: job.id, p_error: message, p_retryable: true
        });
      } catch (_) { /* the queue row stays processing for the next sweep */ }
    }
  }

  return json({ ok: true, ...stats });
});
