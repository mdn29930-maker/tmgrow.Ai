/* Supabase Edge Function: automation-tick
 *
 * Runs the TM GROW AUTO MANAGER jobs in the database.
 *
 * Why an Edge Function: a Supabase Cron / pg_cron schedule (or this function on
 * a timer) keeps jobs running while nobody has the admin panel open. A browser
 * setInterval is only a manual "run now" convenience.
 *
 * Deploy:
 *   supabase functions deploy automation-tick
 *   supabase secrets set AUTOMATION_CRON_SECRET=<long random>
 *
 * Schedule (Supabase Dashboard -> Integrations -> Cron, once a minute):
 *   POST https://<project-ref>.supabase.co/functions/v1/automation-tick
 *   header x-cron-secret: <the same secret>
 *
 * Auth: the cron secret, or a signed-in OWNER / SUPER_ADMIN JWT.
 * No wallet balances are ever changed here: jobs expire claims, restore
 * expired suspensions, flag suspicious proofs and send notifications.
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' }
  });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!supabaseUrl || !serviceKey) {
    return json({ error: 'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY missing.' }, 500);
  }

  let body: Record<string, unknown> = {};
  try { body = await req.json(); } catch (_) { body = {}; }
  const job = body.job ? String(body.job) : null;

  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false }
  });

  const cronSecret = Deno.env.get('AUTOMATION_CRON_SECRET') || '';
  const cronHeader = req.headers.get('x-cron-secret') || '';
  const viaCron = !!cronSecret && cronHeader === cronSecret;

  let trigger = 'manual';
  if (viaCron) {
    trigger = 'schedule';
    if (job) return json({ error: 'CRON_RUNS_ALL_JOBS' }, 400);
  } else {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.toLowerCase().startsWith('bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return json({ error: 'UNAUTHENTICATED' }, 401);

    const { data: userData, error: userError } = await admin.auth.getUser(token);
    if (userError || !userData?.user) return json({ error: 'UNAUTHENTICATED' }, 401);

    const { data: profile } = await admin
      .from('profiles')
      .select('admin_role, status')
      .eq('id', userData.user.id)
      .maybeSingle();

    if (!profile || profile.status !== 'active'
        || !['OWNER', 'SUPER_ADMIN'].includes(String(profile.admin_role))) {
      return json({ error: 'FORBIDDEN' }, 403);
    }
  }

  const { data, error } = await admin.rpc('automation_execute', {
    p_job: job,
    p_trigger: trigger
  });

  if (error) return json({ error: error.message }, 500);
  if (data && data.ok === false) return json(data, 409);

  return json(data || { ok: true });
});
