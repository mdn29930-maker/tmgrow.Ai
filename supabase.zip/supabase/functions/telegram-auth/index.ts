/* Supabase Edge Function: telegram-auth
 *
 * Exchanges a Telegram Mini App `initData` string for a real Supabase session.
 * Every failure returns JSON with the failing `step`, so the client shows the
 * real reason instead of a bare HTTP 500, and the same step is written to the
 * function log (never the token, never the raw initData).
 *
 * Deploy:
 *   supabase functions deploy telegram-auth --no-verify-jwt
 *   supabase secrets set TELEGRAM_BOT_TOKEN=<bot token>
 *
 * GET /functions/v1/telegram-auth returns a config health check (no secrets).
 */

import { createClient } from 'npm:@supabase/supabase-js@2.45.4';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
  });

const fail = (step: string, message: string, status = 500) => {
  console.error(`[telegram-auth] step=${step} ${message}`);
  return json({ error: message, step }, status);
};

const encoder = new TextEncoder();

async function hmac(keyBytes: Uint8Array, message: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(message));
  return new Uint8Array(signature);
}

const toHex = (bytes: Uint8Array) =>
  Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/* Telegram WebApp initData validation, written out explicitly.
   Docs ("Validating data received via the Mini App"):
     secret_key        = HMAC_SHA256(data = bot_token, key = "WebAppData")
     data_check_string = every field except `hash` (and except the newer
                         `signature` field), sorted by field name, joined as
                         key=value with \n, using the URL-decoded values.
     hash              = HMAC_SHA256(data = data_check_string, key = secret_key)
   Two variants are checked so both current and older clients pass: without
   `signature`, and (fallback) without only `hash`. */
type SignatureCheck = {
  ok: boolean;
  matched: string | null;
  providedHash: string;
  hashLength: number;
  fields: string[];
  hasSignatureField: boolean;
  dataCheckLength: number;
  variants: Array<{ label: string; excluded: string[]; computed: string }>;
};

async function verifyInitData(rawInitData: string, botToken: string): Promise<SignatureCheck> {
  const params = new URLSearchParams(rawInitData);
  const providedHash = (params.get('hash') || '').toLowerCase();
  const fields = Array.from(new Set(Array.from(params.keys()))).sort();
  const hasSignatureField = params.has('signature');

  const secret = await hmac(encoder.encode('WebAppData'), botToken);

  const build = (excluded: string[]) => {
    const pairs: string[] = [];
    params.forEach((value, key) => {
      if (excluded.includes(key)) return;
      pairs.push(`${key}=${value}`); /* value is already URL-decoded */
    });
    pairs.sort();
    return pairs.join('\n');
  };

  const variants: SignatureCheck['variants'] = [];
  let matched: string | null = null;

  for (const [label, excluded] of [
    ['without hash+signature', ['hash', 'signature']],
    ['without hash only', ['hash']]
  ] as const) {
    const dataCheck = build([...excluded]);
    const computed = toHex(await hmac(secret, dataCheck));
    variants.push({ label, excluded: [...excluded], computed });
    if (providedHash && timingSafeEqual(computed, providedHash)) matched = label;
  }

  const primary = build(['hash', 'signature']);

  return {
    ok: !!matched,
    matched,
    providedHash,
    hashLength: providedHash.length,
    fields,
    hasSignatureField,
    dataCheckLength: primary.length,
    variants
  };
}

const isMissing = (message: string | undefined) =>
  /does not exist|schema cache|Could not find the table|column .* does not exist/i.test(message || '');

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });

  /* Secrets are sometimes pasted with wrapping quotes; strip those only. */
  const botToken = (Deno.env.get('TELEGRAM_BOT_TOKEN') || '')
    .trim()
    .replace(/^["'`]+|["'`]+$/g, '')
    .trim();
  const supabaseUrl = (Deno.env.get('SUPABASE_URL') || '').trim();
  const serviceKey = (Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '').trim();

  const tokenWellFormed = /^\d{5,}:[A-Za-z0-9_-]{30,}$/.test(botToken);

  /* Which bot is this token actually for? Public info, used to explain
     BAD_SIGNATURE (the Mini App must be opened by the same bot). */
  let botUsername = '';
  async function loadBotIdentity() {
    if (botUsername || !botToken) return botUsername;
    try {
      const res = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
      const data = await res.json().catch(() => null);
      if (data?.ok && data.result?.username) botUsername = String(data.result.username);
    } catch (_) { /* offline: leave blank */ }
    return botUsername;
  }

  /* Health check: says what is configured without revealing any value. */
  if (req.method === 'GET') {
    await loadBotIdentity();
    return json({
      ok: true,
      function: 'telegram-auth',
      bot_token_set: botToken.length > 0,
      bot_token_format_valid: tokenWellFormed,
      bot_username: botUsername || null,
      supabase_url_set: supabaseUrl.length > 0,
      service_role_set: serviceKey.length > 0
    });
  }

  if (req.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);

  let stage = 'config';
  try {
    if (!botToken) {
      return fail('config', 'TELEGRAM_BOT_TOKEN is not set. Run: supabase secrets set TELEGRAM_BOT_TOKEN=...');
    }
    if (!supabaseUrl || !serviceKey) {
      return fail('config', 'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY missing in the function environment.');
    }

    stage = 'body';
    /* Read the raw text once so we can report what actually arrived without
       ever logging the initData value itself. */
    let rawBody = '';
    try {
      rawBody = await req.text();
    } catch {
      return fail('body', 'Could not read the request body.', 400);
    }

    let parsed: Record<string, unknown> = {};
    let parseMode = 'json';
    try {
      parsed = rawBody ? JSON.parse(rawBody) : {};
    } catch {
      /* A text/plain or form-encoded body is still accepted: the key is what
         matters, not the header. */
      try {
        const form = new URLSearchParams(rawBody);
        if (form.has('initData')) {
          parsed = { initData: form.get('initData') };
          parseMode = 'form';
        }
      } catch { /* ignore */ }
    }

    /* Same key names, both spellings, value trimmed. */
    const initData = String((parsed as any)?.initData ?? (parsed as any)?.init_data ?? '').trim();

    /* Safe diagnostics: length and key names only — never the value. */
    const contentType = req.headers.get('content-type') || '(none)';
    const keyNames = Object.keys(parsed || {});
    console.log('[telegram-auth] body', JSON.stringify({
      length: rawBody.length,
      contentType,
      parseMode,
      keys: keyNames,
      hasInitData: keyNames.includes('initData') || keyNames.includes('init_data'),
      initDataLength: initData.length
    }));

    if (!rawBody) {
      return fail('body', 'EMPTY_BODY — the request arrived without a body.', 400);
    }
    if (!keyNames.length) {
      return fail('body',
        `INVALID_JSON_BODY — body of ${rawBody.length} characters could not be parsed as JSON or form data.`, 400);
    }
    if (!initData) {
      return fail('body',
        `MISSING_INIT_DATA — body length ${rawBody.length}, keys received: ${keyNames.join(', ') || 'none'}. ` +
        'The function expects a JSON object {"initData":"..."}.', 400);
    }

    stage = 'signature';
    const params = new URLSearchParams(initData);
    if (!params.get('hash')) return fail('signature', 'MISSING_HASH', 400);

    const check = await verifyInitData(initData, botToken);

    /* Safe diagnostics: field names, presence and lengths — never values or the token. */
    await loadBotIdentity();
    console.log('[telegram-auth] signature check', JSON.stringify({
      ok: check.ok,
      matched: check.matched,
      fields: check.fields,
      hasSignatureField: check.hasSignatureField,
      providedHashLength: check.hashLength,
      dataCheckLength: check.dataCheckLength,
      tokenWellFormed,
      botUsername: botUsername || null
    }));

    /* Optional diagnose mode: proves the algorithm without creating a session.
       Body: { "initData": "...", "diagnose": true } */
    if ((parsed as any).diagnose === true) {
      return json({
        ok: check.ok,
        diagnose: true,
        step: 'signature',
        algorithm: 'HMAC_SHA256(data_check_string, HMAC_SHA256(bot_token, "WebAppData"))',
        matched_variant: check.matched,
        fields: check.fields,
        has_signature_field: check.hasSignatureField,
        hash_length: check.hashLength,
        data_check_length: check.dataCheckLength,
        variants: check.variants.map((v) => ({ label: v.label, excluded: v.excluded })),
        token_format_valid: tokenWellFormed,
        bot_username: botUsername || null
      }, check.ok ? 200 : 401);
    }

    if (!check.ok) {
      return fail('signature',
        'BAD_SIGNATURE — the HMAC of this initData does not match the configured bot token. '
        + `Token format valid: ${tokenWellFormed}. `
        + `Function bot: ${botUsername ? '@' + botUsername : 'unknown (getMe failed)'}. `
        + `Fields received: ${check.fields.join(', ')}. `
        + (check.hasSignatureField ? 'Payload includes a `signature` field (both variants were tried). ' : '')
        + 'Open the Mini App from the same bot that owns this token.', 401);
    }

    const authDate = Number(params.get('auth_date') || 0);
    if (!authDate) return fail('signature', 'MISSING_AUTH_DATE', 401);
    const ageSeconds = Math.floor(Date.now() / 1000) - authDate;
    if (ageSeconds > 86400) return fail('signature', 'EXPIRED — reopen the Mini App from the bot.', 401);
    if (ageSeconds < -120) return fail('signature', 'AUTH_DATE_IN_FUTURE — check the device clock and reopen the Mini App.', 401);

    let tgUser: Record<string, unknown> = {};
    try {
      tgUser = JSON.parse(params.get('user') || '{}');
    } catch {
      return fail('signature', 'INVALID_USER payload.', 400);
    }
    const telegramId = Number(tgUser.id);
    if (!telegramId) return fail('signature', 'NO_TELEGRAM_ID', 400);

    const username = typeof tgUser.username === 'string' ? tgUser.username : null;
    const firstName = typeof tgUser.first_name === 'string' ? tgUser.first_name : '';
    const lastName = typeof tgUser.last_name === 'string' ? tgUser.last_name : '';
    const photo = typeof tgUser.photo_url === 'string' ? tgUser.photo_url : null;
    const language = typeof tgUser.language_code === 'string' ? tgUser.language_code : null;
    const fullName = [firstName, lastName].filter(Boolean).join(' ').trim()
      || (username ? `@${username}` : `Telegram ${telegramId}`);
    const email = `tg${telegramId}@telegram.tmgrow.app`;

    stage = 'client';
    const admin = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false }
    });

    /* ------------------------------------------------------- find the user */
    stage = 'lookup';
    let userId: string | null = null;

    const { data: mapping, error: mappingError } = await admin
      .from('telegram_users')
      .select('user_id')
      .eq('telegram_id', telegramId)
      .maybeSingle();
    if (mappingError && !isMissing(mappingError.message)) {
      console.error('[telegram-auth] telegram_users read:', mappingError.message);
    }
    if (mapping?.user_id) userId = mapping.user_id as string;

    if (!userId) {
      const { data: profile, error: profileLookupError } = await admin
        .from('profiles')
        .select('id')
        .eq('email', email)
        .maybeSingle();
      if (profileLookupError && !isMissing(profileLookupError.message)) {
        console.error('[telegram-auth] profile lookup:', profileLookupError.message);
      }
      if (profile?.id) userId = profile.id as string;
    }

    /* --------------------------------------------- create or recover user */
    stage = 'create_user';
    if (!userId) {
      const { data: created, error: createError } = await admin.auth.admin.createUser({
        email,
        email_confirm: true,
        user_metadata: {
          full_name: fullName,
          name: fullName,
          avatar_url: photo,
          picture: photo,
          telegram_id: telegramId,
          telegram_username: username,
          provider: 'telegram'
        }
      });

      if (created?.user) {
        userId = created.user.id;
      } else {
        console.error('[telegram-auth] createUser:', createError?.message || 'no user returned');

        /* Recovery: the auth user may exist from an earlier attempt whose
           profile/mapping failed. Look it up by email, then by scanning. */
        const { data: recovered, error: recoverError } = await admin
          .rpc('telegram_user_id_by_email', { p_email: email });
        if (!recoverError && recovered) userId = String(recovered);

        if (!userId) {
          const { data: listed, error: listError } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
          if (!listError && listed?.users) {
            const found = listed.users.find((u) => (u.email || '').toLowerCase() === email.toLowerCase());
            if (found) userId = found.id;
          } else if (listError) {
            console.error('[telegram-auth] listUsers:', listError.message);
          }
        }

        if (!userId) {
          return fail('create_user',
            `Could not create or find the Telegram account: ${createError?.message || recoverError?.message || 'unknown error'}`);
        }
      }
    }

    if (!userId) return fail('create_user', 'No user id after create/recover.');

    /* ---------------------------------------------------- profile + wallet */
    stage = 'profile';
    const referralCode = 'TM' + userId.replace(/-/g, '').slice(0, 8).toUpperCase();

    const { error: insertProfileError } = await admin.from('profiles').upsert({
      id: userId,
      email,
      full_name: fullName,
      avatar_url: photo,
      telegram_id: telegramId,
      referral_code: referralCode
    }, { onConflict: 'id', ignoreDuplicates: true });
    if (insertProfileError) {
      console.error('[telegram-auth] profile insert:', insertProfileError.message);
    }

    const { error: updateProfileError } = await admin
      .from('profiles')
      .update({
        telegram_id: telegramId,
        full_name: fullName,
        avatar_url: photo || undefined,
        email
      })
      .eq('id', userId);

    if (updateProfileError) {
      /* A missing telegram_id column must not block sign-in: the session is
         the priority, and supabase/telegram-auth-repair.sql adds the column. */
      if (isMissing(updateProfileError.message)) {
        console.error('[telegram-auth] profile update skipped (run supabase/telegram-auth-repair.sql):',
          updateProfileError.message);
      } else {
        return fail('profile', `Profile update failed: ${updateProfileError.message}`);
      }
    }

    stage = 'wallet';
    const { error: walletError } = await admin
      .from('wallets')
      .upsert({ user_id: userId }, { onConflict: 'user_id', ignoreDuplicates: true });
    if (walletError) {
      /* ensure_profile() creates the wallet on the first RPC; never block the
         login because of it, but keep the reason in the log. */
      console.error('[telegram-auth] wallet upsert:', walletError.message);
    }

    stage = 'identity';
    const { error: mappingUpsertError } = await admin.from('telegram_users').upsert({
      telegram_id: telegramId,
      user_id: userId,
      username,
      first_name: firstName || null,
      last_name: lastName || null,
      photo_url: photo,
      language_code: language,
      last_login_at: new Date().toISOString()
    }, { onConflict: 'telegram_id' });
    if (mappingUpsertError) {
      console.error('[telegram-auth] telegram_users upsert:', mappingUpsertError.message);
    }

    try {
      const { error: userUpdateError } = await admin.auth.admin.updateUserById(userId, {
        user_metadata: {
          full_name: fullName,
          name: fullName,
          avatar_url: photo,
          picture: photo,
          telegram_id: telegramId,
          telegram_username: username
        }
      });
      if (userUpdateError) console.error('[telegram-auth] auth metadata update:', userUpdateError.message);
    } catch (e) {
      console.error('[telegram-auth] auth metadata update threw:', (e as Error).message);
    }

    /* -------------------------------------------------- one-time token hash */
    stage = 'session';
    let tokenHash = '';
    let lastLinkError = '';

    for (let attempt = 0; attempt < 2 && !tokenHash; attempt += 1) {
      const { data: link, error } = await admin.auth.admin.generateLink({ type: 'magiclink', email });
      tokenHash = link?.properties?.hashed_token || '';
      if (error) {
        lastLinkError = error.message;
        console.error(`[telegram-auth] generateLink attempt ${attempt + 1}:`, error.message);
      }
    }

    if (!tokenHash) {
      return fail('session',
        `Could not create the session: ${lastLinkError || 'no token hash'} ` +
        '(check Authentication → Providers → Email is enabled and the auth user exists).');
    }

    console.log(`[telegram-auth] ok telegram_id=${telegramId} user=${userId}`);
    return json({
      ok: true,
      token_hash: tokenHash,
      user: { id: userId, telegram_id: telegramId, name: fullName }
    });
  } catch (e) {
    console.error('[telegram-auth] unhandled', stage, e);
    return fail(stage, (e as Error)?.message || 'Unexpected server error.', 500);
  }
});
