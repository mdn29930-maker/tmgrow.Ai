/* Supabase Edge Function: telegram-notify
 *
 * Delivers the rows that public.telegram_enqueue() put in telegram_outbox.
 * The bot token lives only in this function's secrets — never in the browser,
 * never in a database-readable setting.
 *
 * Why an outbox: the approval RPC commits the wallet movement and the queued
 * message in one transaction. Rewards can never be paid twice, and a Telegram
 * outage can never roll a reward back — it only leaves a retryable row.
 *
 * Deploy:
 *   supabase functions deploy telegram-notify
 *   supabase secrets set TELEGRAM_BOT_TOKEN=123456:AA...
 *   supabase secrets set TELEGRAM_CRON_SECRET=<random string>   # optional
 *
 * Actions (POST JSON):
 *   { "action": "drain" }        send every queued / retryable row
 *   { "action": "retry", "id": "<outbox uuid>" }   requeue one row, then drain
 *   { "action": "test" }         send the test template to the caller
 *
 * Auth: a signed-in admin (OWNER / SUPER_ADMIN / ADMIN / SUPPORT) via the
 * user's JWT, or the cron secret in x-cron-secret (drain only, for pg_cron).
 * SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are provided
 * by the platform.
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' }
  });

const ADMIN_ROLES = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'SUPPORT'];
const MAX_ATTEMPTS = 5;

type OutboxRow = {
  id: string;
  user_id: string;
  telegram_id: number;
  kind: string;
  message: string;
  attempts: number;
};

type SendResult = { ok: boolean; messageId?: number; error?: string };

async function sendMessage(token: string, chatId: number, text: string): Promise<SendResult> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        disable_web_page_preview: true
      })
    });

    let payload: any = {};
    try { payload = await res.json(); } catch (_) { /* non-JSON body */ }

    if (res.ok && payload?.ok) {
      return { ok: true, messageId: Number(payload.result?.message_id) || undefined };
    }

    const description = payload?.description || `HTTP ${res.status}`;
    return { ok: false, error: String(description).slice(0, 500) };
  } catch (e) {
    return { ok: false, error: `NETWORK: ${(e as Error)?.message || 'request failed'}`.slice(0, 500) };
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);

  const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN') || '';
  if (!botToken) return json({ error: 'TELEGRAM_BOT_TOKEN is not set for this project.' }, 500);

  const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!supabaseUrl || !serviceKey) {
    return json({ error: 'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY missing.' }, 500);
  }

  let body: Record<string, unknown> = {};
  try { body = await req.json(); } catch (_) { body = {}; }
  const action = String(body.action || 'drain');

  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false }
  });

  const cronSecret = Deno.env.get('TELEGRAM_CRON_SECRET') || '';
  const cronHeader = req.headers.get('x-cron-secret') || '';
  const viaCron = !!cronSecret && cronHeader === cronSecret;
  if (viaCron && action !== 'drain') return json({ error: 'CRON_ACTION_NOT_ALLOWED' }, 403);

  let caller: { id: string; role: string | null } | null = null;

  if (!viaCron) {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.toLowerCase().startsWith('bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return json({ error: 'UNAUTHENTICATED' }, 401);

    // Validate the user's JWT with the service client, then check the role on
    // their profile. A worker's token can never drain the queue.
    const { data: userData, error: userError } = await admin.auth.getUser(token);
    if (userError || !userData?.user) return json({ error: 'UNAUTHENTICATED' }, 401);

    const { data: profile } = await admin
      .from('profiles')
      .select('id, admin_role, status')
      .eq('id', userData.user.id)
      .maybeSingle();

    if (!profile || profile.status !== 'active' || !ADMIN_ROLES.includes(String(profile.admin_role))) {
      return json({ error: 'FORBIDDEN' }, 403);
    }
    caller = { id: String(profile.id), role: profile.admin_role };
  }

  /* ---------------------------------------------------------------- retry */
  if (action === 'retry') {
    const id = String(body.id || '');
    if (!id) return json({ error: 'MISSING_ID' }, 400);

    const { data: row } = await admin
      .from('telegram_outbox')
      .select('id, status')
      .eq('id', id)
      .maybeSingle();
    if (!row) return json({ error: 'NOT_FOUND' }, 404);
    if (row.status === 'sent') return json({ error: 'TELEGRAM_ALREADY_SENT' }, 409);

    await admin.from('telegram_outbox')
      .update({ status: 'queued', last_error: null, attempted_at: null })
      .eq('id', id);
  }

  /* ----------------------------------------------------------------- test */
  if (action === 'test') {
    if (!caller) return json({ error: 'FORBIDDEN' }, 403);

    const { data: profile } = await admin
      .from('profiles')
      .select('telegram_id')
      .eq('id', caller.id)
      .maybeSingle();
    if (!profile?.telegram_id) {
      return json({ error: 'NO_TELEGRAM_LINK', message: 'Open TM GROW from your Telegram bot once to link this account.' }, 400);
    }

    const { data: tpl } = await admin
      .from('settings')
      .select('value')
      .eq('key', 'telegram_tpl_test')
      .maybeSingle();
    const text = String(tpl?.value ?? '✅ TM GROW notifications are working')
      || '✅ TM GROW notifications are working';

    const sent = await sendMessage(botToken, Number(profile.telegram_id), text);
    return json({
      ok: sent.ok,
      sent: sent.ok ? 1 : 0,
      error: sent.error || null
    }, sent.ok ? 200 : 502);
  }

  /* ------------------------------------------------------------- webhook? */
  if (action !== 'drain') return json({ error: 'INVALID_ACTION' }, 400);

  /* ----------------------------------------------------------------- drain */
  const { data: claimed, error: claimError } = await admin
    .rpc('telegram_claim', { p_limit: 25 });

  if (claimError) {
    return json({ error: `CLAIM_FAILED: ${claimError.message}` }, 500);
  }

  const rows = (claimed || []) as OutboxRow[];
  let sent = 0;
  let failed = 0;
  const results: Array<{ id: string; kind: string; ok: boolean; error?: string }> = [];

  for (const row of rows) {
    const result = await sendMessage(botToken, Number(row.telegram_id), row.message);

    if (result.ok) {
      sent += 1;
      await admin.from('telegram_outbox')
        .update({
          status: 'sent',
          sent_at: new Date().toISOString(),
          message_id: result.messageId ?? null,
          last_error: null
        })
        .eq('id', row.id);
    } else {
      failed += 1;
      // The claim already counted this attempt; the row is retried later until
      // MAX_ATTEMPTS, then it stays failed with the provider's reason.
      const exhausted = Number(row.attempts || 0) >= MAX_ATTEMPTS;
      await admin.from('telegram_outbox')
        .update({
          status: 'failed',
          last_error: exhausted
            ? `Gave up after ${row.attempts} attempts: ${result.error || 'unknown error'}`
            : result.error || 'unknown error'
        })
        .eq('id', row.id);
    }

    results.push({ id: row.id, kind: row.kind, ok: result.ok, error: result.error });
  }

  return json({
    ok: failed === 0,
    processed: rows.length,
    sent,
    failed,
    results
  });
});
