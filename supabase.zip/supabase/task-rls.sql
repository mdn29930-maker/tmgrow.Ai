-- TM GROW — task access check/repair (RLS + grants)
-- The app reads tasks through SECURITY DEFINER RPCs (get_task, claim_task,
-- list_available_tasks), so RLS on the base tables does not have to expose
-- available rows. These policies mirror schema.sql and add a safe read policy
-- for workers, then re-grant the RPC surface.
--
-- Note: this project's table is public.submissions (there is no
-- task_submissions table).

alter table public.tasks enable row level security;
alter table public.submissions enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
     where schemaname = 'public' and tablename = 'tasks'
       and policyname = 'tasks_select_self_or_admin'
  ) then
    execute 'create policy tasks_select_self_or_admin on public.tasks
               for select to authenticated
               using (worker_id = auth.uid() or public.is_admin())';
  end if;

  if not exists (
    select 1 from pg_policies
     where schemaname = 'public' and tablename = 'tasks'
       and policyname = 'tasks_select_available_worker'
  ) then
    execute 'create policy tasks_select_available_worker on public.tasks
               for select to authenticated
               using (
                 status = ''available''
                 and exists (
                   select 1 from public.profiles p
                    where p.id = auth.uid()
                      and p.is_worker
                      and p.status = ''active''
                 )
               )';
  end if;

  if not exists (
    select 1 from pg_policies
     where schemaname = 'public' and tablename = 'submissions'
       and policyname = 'submissions_select_self_or_admin'
  ) then
    execute 'create policy submissions_select_self_or_admin on public.submissions
               for select to authenticated
               using (worker_id = auth.uid() or public.is_admin())';
  end if;
end $$;

grant select on public.tasks to authenticated;
grant select on public.submissions to authenticated;

do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname in ('get_task','claim_task','release_task','start_task','submit_proof','list_available_tasks','my_tasks')
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated', f.sig);
  end loop;
end $$;

notify pgrst, 'reload schema';

-- Verify: policies on tasks + the worker RPCs exist.
select schemaname, tablename, policyname, cmd
  from pg_policies
 where schemaname = 'public' and tablename in ('tasks','submissions')
 order by tablename, policyname;

select proname, pg_get_function_identity_arguments(oid) as args
  from pg_proc
 where pronamespace = 'public'::regnamespace
   and proname in ('get_task','claim_task','release_task','start_task','submit_proof','list_available_tasks','my_tasks')
 order by proname;
