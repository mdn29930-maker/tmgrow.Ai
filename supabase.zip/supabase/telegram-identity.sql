-- TM GROW — Telegram OIDC identity linking
-- The Supabase custom OIDC provider identifies a Telegram user by the stable
-- "sub" claim. This RPC copies it onto the profile (once), so repeated logins
-- map to the same account and the Telegram bot can message the user.
-- Run after schema.sql. No email is required.

create or replace function public.link_telegram_identity()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  u uuid := auth.uid();
  v_sub text;
  v_name text;
  v_pic text;
  v_tg bigint;
  v_other uuid;
begin
  if u is null then raise exception 'UNAUTHENTICATED'; end if;

  select i.identity_data ->> 'sub',
         coalesce(i.identity_data ->> 'name', i.identity_data ->> 'preferred_username'),
         i.identity_data ->> 'picture'
    into v_sub, v_name, v_pic
    from auth.identities i
   where i.user_id = u
     and i.provider in ('custom:telegram', 'telegram')
   order by i.created_at desc
   limit 1;

  if v_sub is null or v_sub !~ '^[0-9]+$' then
    return jsonb_build_object('ok', false, 'reason', 'NO_TELEGRAM_IDENTITY');
  end if;

  v_tg := v_sub::bigint;

  -- Never steal an identity already attached to another TM GROW account.
  select id into v_other
    from public.profiles
   where telegram_id = v_tg and id <> u
   limit 1;
  if v_other is not null then
    return jsonb_build_object('ok', false, 'reason', 'TELEGRAM_ALREADY_LINKED');
  end if;

  select user_id into v_other
    from public.telegram_users
   where telegram_id = v_tg and user_id <> u
   limit 1;
  if v_other is not null then
    return jsonb_build_object('ok', false, 'reason', 'TELEGRAM_ALREADY_LINKED');
  end if;

  update public.profiles
     set telegram_id = v_tg,
         full_name = coalesce(nullif(full_name, ''), nullif(v_name, ''), full_name),
         avatar_url = coalesce(avatar_url, nullif(v_pic, '')),
         updated_at = now()
   where id = u;

  -- Keep the mapping table used by telegram-auth / telegram-notify consistent.
  insert into public.telegram_users (telegram_id, user_id, username, first_name, photo_url)
  values (v_tg, u, null, nullif(v_name, ''), nullif(v_pic, ''))
  on conflict (telegram_id) do update
    set user_id = excluded.user_id,
        last_login_at = now();

  return jsonb_build_object('ok', true, 'telegram_id', v_tg);
end $$;

revoke all on function public.link_telegram_identity() from public, anon;
grant execute on function public.link_telegram_identity() to authenticated;

notify pgrst, 'reload schema';

select column_name
  from information_schema.columns
 where table_schema = 'public' and table_name = 'profiles' and column_name = 'telegram_id';
