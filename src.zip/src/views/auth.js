/* TM GROW authentication — sign-in (Google / Telegram / email), registration
   with username + role choice, and forgot / reset password flows.
   Supabase handles hashing, sessions, verification email and rate limiting
   server-side; this screen only collects inputs and reports server verdicts. */

import { CONFIG } from '../config.js?v=2025-10-12-39';
import { sb, rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import { state, pendingRef, rememberHash, loadSession, loadContext } from '../lib/store.js?v=2025-10-12-39';
import { isTelegramMiniApp, telegramUser, signInWithTelegram, telegramFriendlyError } from '../lib/telegram.js?v=2025-10-12-39';
import { esc, toast, setBusy } from '../lib/ui.js?v=2025-10-12-39';

/* Marks that a browser Telegram OAuth redirect was started, so a callback that
   never produces a session can be reported instead of hanging forever. */
const TG_OAUTH_KEY = 'tmgrow-telegram-oauth-pending';
const TG_OAUTH_MAX_AGE = 20000;
const PENDING_USERNAME_KEY = 'tmgrow-pending-username';
const USERNAME_RE = /^[a-zA-Z0-9_]{3,24}$/;

function callbackError() {
  try {
    const search = new URLSearchParams(window.location.search);
    const hash = new URLSearchParams(String(window.location.hash || '').replace(/^#/, ''));
    const raw = search.get('error_description') || search.get('error')
      || hash.get('error_description') || hash.get('error') || '';
    return raw ? decodeURIComponent(raw.replace(/\+/g, ' ')) : '';
  } catch (_) { return ''; }
}

function pendingOAuthTooOld() {
  try {
    const raw = sessionStorage.getItem(TG_OAUTH_KEY);
    if (!raw) return false;
    if (Date.now() - Number(raw) < TG_OAUTH_MAX_AGE) return false;
    sessionStorage.removeItem(TG_OAUTH_KEY);
    return true;
  } catch (_) { return false; }
}

function clearOAuthPending() {
  try { sessionStorage.removeItem(TG_OAUTH_KEY); } catch (_) { /* ignore */ }
}

function googleLogo() {
  return `<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true">
    <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.5 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.8 6.1C12.3 13.2 17.6 9.5 24 9.5z"/>
    <path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-2.8-.4-4.1H24v8.4h12.5c-.3 2.1-1.6 5.2-4.5 7.3l7.6 5.9c4.5-4.2 6.5-10.2 6.5-17.5z"/>
    <path fill="#FBBC05" d="M10.4 28.7c-.5-1.4-.8-2.9-.8-4.7s.3-3.3.7-4.7l-7.8-6.1C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.8l7.8-6.1z"/>
    <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2 1.5-4.7 2.5-8.3 2.5-6.4 0-11.7-3.7-13.6-8.8l-7.8 6.1C6.5 42.6 14.6 48 24 48z"/>
  </svg>`;
}

function telegramLogo() {
  return `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true">
    <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
  </svg>`;
}

export async function renderAuth(root, opts = {}) {
  let mode = ['signin', 'signup', 'forgot', 'reset'].includes(opts.mode) ? opts.mode : 'signin';
  let role = 'worker';

  /* A provider redirect can come back with error / error_description. Show it
     instead of leaving the sign-in page silent. */
  const cbError = callbackError();
  if (cbError) state.telegramError = cbError;
  else if (pendingOAuthTooOld() && !state.session) {
    state.telegramError = 'Telegram sign-in did not complete. Check that the custom:telegram OIDC provider is enabled and that the redirect URL is allowed in Supabase Auth.';
  }

  const paint = () => {
    const signup = mode === 'signup';
    const tgUser = isTelegramMiniApp() ? telegramUser() : null;
    const tgName = tgUser ? String(tgUser.first_name || tgUser.username || 'Telegram').trim() : '';

    const TITLES = {
      signin: ['Welcome back', 'Sign in to claim tasks and manage your USDT wallet.'],
      signup: ['Create your account', 'Free to join. Claim tasks, submit proof and get paid in USDT.'],
      forgot: ['Reset your password', 'Enter your email and we send a secure reset link.'],
      reset: ['Choose a new password', 'The reset link from your email signs you in here safely.']
    };
    const [t1, t2] = TITLES[mode] || TITLES.signin;

    root.innerHTML = `<div class="auth-screen">
      <div class="auth-shell">
        <header class="auth-top">
          <a class="auth-brand" href="#/" aria-label="TM GROW home">
            <span class="auth-logo-box"><span aria-hidden="true">TM</span></span>
            <span class="auth-brand-text">
              <span class="auth-brand-name">TM GROW</span>
              <span class="auth-brand-sub">Social task network</span>
            </span>
          </a>
        </header>

        <div class="auth-titles">
          <h1>${esc(t1)}</h1>
          <p>${esc(t2)}</p>
        </div>

        ${(mode === 'signin' || mode === 'signup') ? `
        <div class="auth-oauth">
          ${state.telegramError ? `<div class="alert error mb-16">${esc(state.telegramError)}</div>` : ''}
          <button class="auth-oauth-btn auth-google" type="button" data-google>
            <span class="ab-ic">${googleLogo()}</span>
            <span class="ab-label">Continue with Google</span>
          </button>
          <p class="auth-note">Your Google name and profile photo are imported automatically.</p>

          <button class="auth-oauth-btn auth-telegram" type="button" data-telegram>
            <span class="ab-ic">${telegramLogo()}</span>
            <span class="ab-label">${tgUser ? `Continue as ${esc(tgName)}` : 'Continue with Telegram'}</span>
          </button>
          ${tgUser ? `<p class="auth-note">Verified by the TM GROW bot${tgUser.username ? ` · @${esc(tgUser.username)}` : ''}</p>` : ''}
        </div>

        <div class="auth-divider"><span>Or use email</span></div>` : ''}

        <form class="auth-form" data-form>
          ${mode === 'forgot' ? `
          <label class="auth-field" for="auth-email">
            <span class="auth-label">Email</span>
            <input class="auth-input" id="auth-email" name="email" type="email" inputmode="email" required placeholder="you@example.com" />
          </label>` : mode === 'reset' ? `
          <label class="auth-field" for="auth-password">
            <span class="auth-label">New password</span>
            <input class="auth-input" id="auth-password" name="password" type="password" autocomplete="new-password" placeholder="At least 6 characters" required minlength="6" />
          </label>
          <label class="auth-field" for="auth-password2">
            <span class="auth-label">Confirm new password</span>
            <input class="auth-input" id="auth-password2" name="password2" type="password" autocomplete="new-password" required minlength="6" />
          </label>
          ${!state.session ? `<p class="auth-note" style="text-align:left">Open the reset link from your email in this browser — it signs you in securely, then you pick a new password.</p>` : ''}` : `
          ${signup ? `<label class="auth-field" for="auth-name">
            <span class="auth-label">Full name</span>
            <input class="auth-input" id="auth-name" name="name" autocomplete="name" placeholder="Your name" required minlength="2" />
          </label>
          <label class="auth-field" for="auth-username">
            <span class="auth-label">Username</span>
            <input class="auth-input" id="auth-username" name="username" autocomplete="username" placeholder="e.g. taskmaster" required pattern="[A-Za-z0-9_]{3,24}" maxlength="24" />
            <span class="auth-opt" style="display:block;margin-top:6px">3-24 letters, numbers or underscores. Shown on the leaderboard.</span>
          </label>` : ''}
          <label class="auth-field" for="auth-email">
            <span class="auth-label">Email</span>
            <input class="auth-input" id="auth-email" name="email" type="email" inputmode="email" autocomplete="email" placeholder="you@example.com" required />
          </label>
          <label class="auth-field" for="auth-password">
            <span class="auth-label">Password</span>
            <input class="auth-input" id="auth-password" name="password" type="password" autocomplete="${signup ? 'new-password' : 'current-password'}" placeholder="At least 6 characters" required minlength="6" />
          </label>
          ${signup ? `<label class="auth-field" for="auth-password2">
            <span class="auth-label">Confirm password</span>
            <input class="auth-input" id="auth-password2" name="password2" type="password" autocomplete="new-password" required minlength="6" />
          </label>
          <div class="auth-field">
            <span class="auth-label">I want to join as</span>
            <div class="row" style="gap:8px;margin-top:2px">
              <label class="chip ${role === 'worker' ? 'active' : ''}" style="cursor:pointer">
                <input type="radio" name="role" value="worker" ${role === 'worker' ? 'checked' : ''} style="accent-color:var(--brand);width:auto" />
                Worker — earn per task
              </label>
              <label class="chip ${role === 'buyer' ? 'active' : ''}" style="cursor:pointer">
                <input type="radio" name="role" value="buyer" ${role === 'buyer' ? 'checked' : ''} style="accent-color:var(--brand);width:auto" />
                Buyer — promote my brand
              </label>
            </div>
          </div>
          <label class="auth-field" for="auth-ref">
            <span class="auth-label">Referral code <span class="auth-opt">optional</span></span>
            <input class="auth-input" id="auth-ref" name="ref" placeholder="TMXXXXXXXX" value="${esc(pendingRef() || '')}" />
          </label>
          <label class="check" style="color:var(--muted);font-size:12.5px">
            <input type="checkbox" name="terms" required style="accent-color:var(--brand)" />
            I accept the Terms of Service and Privacy Policy
          </label>` : ''}`}
          <button class="auth-submit" type="submit" data-submit>${mode === 'signin' ? 'Sign in' : mode === 'signup' ? 'Create account' : mode === 'forgot' ? 'Send reset link' : 'Update password'}</button>
        </form>

        <div class="auth-foot">
          ${mode === 'signin'
            ? `New to TM GROW? <button type="button" data-mode="signup">Create an account</button>
               <div class="mt-10"><button type="button" class="auth-opt" data-mode="forgot">Forgot password?</button></div>`
            : mode === 'signup'
              ? `Already have an account? <button type="button" data-mode="signin">Sign in</button>`
              : `<button type="button" data-mode="signin">Back to sign in</button>`}
        </div>

        <p class="auth-legal">By continuing you agree to honest task completion, our verification rules and the <a href="/terms.html">Terms of Service</a> and <a href="/privacy.html">Privacy Policy</a>. TM GROW never asks for your social media password.</p>
      </div>
    </div>`;

    root.querySelector('[data-google]')?.addEventListener('click', onGoogle);
    root.querySelector('[data-telegram]')?.addEventListener('click', tgUser ? onTelegramMini : onTelegram);
    root.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => {
      mode = b.dataset.mode;
      paint();
    }));
    root.querySelectorAll('input[name="role"]').forEach((r) => r.addEventListener('change', () => {
      role = r.value;
      paint();
    }));
    root.querySelector('[data-form]').addEventListener('submit', onSubmit);
  };

  async function onGoogle() {
    const btn = root.querySelector('[data-google]');
    setBusy(btn, true, 'Redirecting');
    rememberHash('/dashboard');
    try {
      const { error } = await sb.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
          queryParams: { prompt: 'select_account' }
        }
      });
      if (error) throw error;
    } catch (e) {
      setBusy(btn, false);
      toast(friendlyError(e), 'error', 7000);
    }
  }

  /* Telegram OIDC through Supabase's custom provider. The provider config lives
     in Supabase Auth (issuer https://oauth.telegram.org, scopes openid profile,
     email optional); the client secret never touches this code. */
  async function onTelegram() {
    const btn = root.querySelector('[data-telegram]');
    setBusy(btn, true, 'Opening Telegram');
    rememberHash('/dashboard');
    try {
      try { sessionStorage.setItem(TG_OAUTH_KEY, String(Date.now())); } catch (_) { /* ignore */ }
      const { error } = await sb.auth.signInWithOAuth({
        provider: CONFIG.telegramProvider || 'custom:telegram',
        options: {
          redirectTo: window.location.origin + window.location.pathname,
          scopes: 'openid profile'
        }
      });
      if (error) throw error;
    } catch (e) {
      clearOAuthPending();
      setBusy(btn, false);
      const raw = String(e?.message || e || '');
      const msg = /provider|unsupported|custom:?/i.test(raw)
        ? 'Telegram sign-in is not enabled on this Supabase project. Authentication → Providers → Telegram (custom OIDC) must exist with identifier "telegram".'
        : /redirect|not allowed|uri/i.test(raw)
          ? 'This app URL is not on the allowed redirect list. Add it under Authentication → URL Configuration and register the Supabase callback in BotFather.'
          : friendlyError(e);
      state.telegramError = msg;
      toast(msg, 'error', 12000);
      paint();
    }
  }

  /* Inside a Telegram Mini App the identity comes from initData, verified by
     the telegram-auth Edge Function; no browser redirect is involved. */
  async function onTelegramMini() {
    const btn = root.querySelector('[data-telegram]');
    setBusy(btn, true, 'Signing in');
    try {
      await signInWithTelegram(sb);
      state.telegramError = null;
      /* Only navigate once a real session exists — verifyOtp must have stored it. */
      const session = await loadSession();
      if (!session) {
        const err = new Error('Telegram returned a token, but Supabase did not create a session from it (verifyOtp). Try again from the bot.');
        err.code = 'NO_SESSION';
        throw err;
      }
      await loadContext().catch(() => {});
      navigateDashboard();
    } catch (e) {
      state.telegramError = telegramFriendlyError(e);
      toast(state.telegramError, 'error', 12000);
      paint();
    }
  }

  async function onSubmit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const btn = root.querySelector('[data-submit]');
    const data = new FormData(form);
    const email = String(data.get('email') || '').trim();
    const password = String(data.get('password') || '');
    const password2 = String(data.get('password2') || '');
    const name = String(data.get('name') || '').trim();
    const username = String(data.get('username') || '').trim();
    const role = String(data.get('role') || 'worker');
    const ref = String(data.get('ref') || '').trim();

    setBusy(btn, true, mode === 'signin' ? 'Signing in' : mode === 'signup' ? 'Creating account' : 'Working');
    try {
      if (mode === 'signin') {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigateDashboard();
      } else if (mode === 'forgot') {
        const { error } = await sb.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}${window.location.pathname}#/reset`
        });
        if (error) throw error;
        toast('If that email has an account, a reset link is on its way. Open it in this browser.', 'success', 8000);
        mode = 'signin';
        paint();
      } else if (mode === 'reset') {
        if (!state.session) {
          throw new Error('Open the reset link from your email in this browser first.');
        }
        if (password !== password2) {
          toast('The two passwords do not match.', 'error');
          setBusy(btn, false);
          return;
        }
        const { error } = await sb.auth.updateUser({ password });
        if (error) throw error;
        toast('Password updated. Sign in with your new password.', 'success');
        mode = 'signin';
        paint();
      } else {
        /* registration */
        if (!USERNAME_RE.test(username)) {
          toast('Username must be 3-24 letters, numbers or underscores.', 'error');
          setBusy(btn, false);
          return;
        }
        if (password !== password2) {
          toast('The two passwords do not match.', 'error');
          setBusy(btn, false);
          return;
        }
        if (ref) {
          try { localStorage.setItem('tmgrow-ref', ref); } catch (_) { /* ignore */ }
        }
        const { data: signUpData, error } = await sb.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: name || email.split('@')[0],
              username,
              role
            },
            emailRedirectTo: window.location.origin
          }
        });
        if (error) throw error;
        if (signUpData?.session) {
          await applySignupExtras(username, role);
          toast('Account created. Welcome to TM GROW.', 'success');
          navigateDashboard();
        } else {
          try { localStorage.setItem(PENDING_USERNAME_KEY, username); } catch (_) { /* ignore */ }
          toast('Check your inbox to confirm your email, then sign in.', 'success', 8000);
          mode = 'signin';
          paint();
        }
      }
    } catch (err) {
      toast(friendlyError(err), 'error', 7000);
      setBusy(btn, false);
    }
  }

  /* Best-effort extras after a confirmed signup session: the username and,
     when chosen, the buyer capability. Failures are reported but never block
     the account. */
  async function applySignupExtras(username, chosenRole) {
    try {
      await rpc('set_my_username', { p_username: username });
    } catch (e) {
      toast(friendlyError(e), 'error', 6000);
    }
    if (chosenRole === 'buyer') {
      try { await rpc('enable_buyer_mode'); } catch (_) { /* can be enabled later from Profile */ }
    }
  }

  function navigateDashboard() {
    window.location.hash = '#/dashboard';
  }

  paint();
}
