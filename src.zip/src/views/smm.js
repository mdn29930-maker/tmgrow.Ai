/* Buyer SMM experience (FoxiGrow-inspired).
   Uses only the SMM RPCs from supabase/smm-orders.sql. No fake data, no
   client-side pricing authority: the server recalculates and charges. */

import { rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import { state } from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, usdt, toast, openModal, confirmDialog, loadingBlock, emptyState, errorPanel,
  setBusy, debounce, platformMeta, platformIcon, copyText, ago, dateTime
} from '../lib/ui.js?v=2025-10-12-39';

const FAV_KEY = 'tmgrow-smm-favs';
const RECENT_KEY = 'tmgrow-smm-recent';

const STATUS = {
  pending: ['gold', 'Pending'],
  processing: ['orange', 'Processing'],
  completed: ['green', 'Completed'],
  partial: ['blue', 'Partial'],
  cancelled: ['grey', 'Cancelled'],
  failed: ['red', 'Failed'],
  refunded: ['violet', 'Refunded']
};

const TABS = [
  ['', 'All'], ['pending', 'Pending'], ['processing', 'Processing'],
  ['completed', 'Completed'], ['partial', 'Partial'], ['cancelled', 'Cancelled'],
  ['failed', 'Failed'], ['refunded', 'Refunded']
];

const SMM_PLATFORMS = [
  ['telegram', 'Telegram'], ['x', 'X / Twitter'], ['tiktok', 'TikTok'],
  ['instagram', 'Instagram'], ['facebook', 'Facebook'], ['youtube', 'YouTube'],
  ['threads', 'Threads']
];

function statusChip(status) {
  const [tone, label] = STATUS[status] || ['grey', status || '—'];
  return `<span class="badge ${tone}">${esc(label)}</span>`;
}

function plat(id) {
  try { return platformMeta(id); } catch (_) { return { label: id || '', bg: 'rgba(255,255,255,.06)', color: '#8b93a1' }; }
}

function favs() {
  try { return JSON.parse(localStorage.getItem(FAV_KEY) || '{}') || {}; } catch (_) { return {}; }
}
function setFav(id, on) {
  const f = favs();
  if (on) f[id] = 1; else delete f[id];
  try { localStorage.setItem(FAV_KEY, JSON.stringify(f)); } catch (_) { /* ignore */ }
}
function recents() {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]') || []; } catch (_) { return []; }
}
function pushRecent(service) {
  if (!service || !service.id) return;
  const list = recents().filter((s) => s.id !== service.id);
  list.unshift({ id: service.id, name: service.name, platform: service.platform, rate_per_1000: service.rate_per_1000, short_id: service.short_id });
  try { localStorage.setItem(RECENT_KEY, JSON.stringify(list.slice(0, 6))); } catch (_) { /* ignore */ }
}

function totalFor(service, qty) {
  return Math.round(Number(qty || 0) * Number(service?.rate_per_1000 || 0)) / 1000;
}

function money(n) {
  const v = Number(n || 0);
  return usdt(Number.isFinite(v) ? v : 0);
}

function available() {
  return Number(state.wallet?.available || 0);
}

/* ------------------------------------------------------------------ orders */
async function countsByStatus() {
  const statuses = ['pending', 'processing', 'completed', 'refunded'];
  const res = await Promise.all(TABS.filter(([v]) => v).map(([v]) => rpc('my_smm_orders', {
    p_status: v, p_search: null, p_limit: 1, p_offset: 0
  }).then((r) => Number(r?.total || 0)).catch(() => 0)));
  const out = {};
  TABS.filter(([v]) => v).forEach(([v], i) => { out[v] = res[i] || 0; });
  return out;
}

/* =============================================================== DASHBOARD */
export async function renderSmmDashboard(root) {
  root.innerHTML = loadingBlock('Loading your SMM dashboard');
  let counts = state.smmCounts;
  if (!counts) {
    try { state.smmCounts = await rpc('smm_platform_counts'); } catch (_) { state.smmCounts = {}; }
    counts = state.smmCounts;
  }

  const [recent, popular, totals] = await Promise.all([
    rpc('my_smm_orders', { p_status: null, p_search: null, p_limit: 5, p_offset: 0 }).catch(() => ({ items: [] })),
    rpc('smm_list_services', { p_limit: 8, p_offset: 0 }).catch(() => ({ items: [] })),
    countsByStatus()
  ]);

  const openCount = Number(totals.pending || 0) + Number(totals.processing || 0);
  const rec = recents();
  const serviceCount = Object.values(counts || {}).reduce((sum, value) => sum + Number(value || 0), 0);
  const platformCount = Object.values(counts || {}).filter((value) => Number(value || 0) > 0).length;

  root.innerHTML = `<div class="smm-dashboard">
    <div class="workspace-page-intro">
      <div><span class="eyebrow">BUYER / SMM PANEL</span><h2>Social services</h2><p>Place direct orders and follow fulfilment from your live account data.</p></div>
      <a class="btn btn-ghost" href="#/buyer">${icon('grid', 15)} Campaign workspace</a>
    </div>

    <section class="smm-dashboard-hero">
      <div class="smm-dashboard-copy">
        <span class="smm-dashboard-kicker">DIRECT ORDERING</span>
        <h2>Grow with clarity.</h2>
        <p>Choose a service, set a public target and quantity, then follow the order through its recorded status and delivery progress.</p>
        <div class="row-wrap mt-18">
          <a class="btn btn-primary" href="#/smm/services">${icon('plus', 15)} Create an order</a>
          <a class="btn btn-ghost" href="#/smm/mass">${icon('layers', 15)} Mass order</a>
        </div>
      </div>
      <div class="smm-dashboard-balance">
        <span>AVAILABLE BALANCE</span>
        <strong>${money(available())}<small>USDT</small></strong>
        <p>${serviceCount} active services across ${platformCount} platforms</p>
        <a class="btn btn-soft btn-block" href="#/deposit">${icon('download', 15)} Add funds</a>
      </div>
      <div class="smm-dashboard-glow" aria-hidden="true"></div>
    </section>

    <section class="smm-dashboard-metrics" aria-label="Order summary">
      <div><span>Open orders</span><strong>${openCount}</strong><small>Pending or processing</small></div>
      <div><span>Completed</span><strong>${Number(totals.completed || 0)}</strong><small>Recorded as completed</small></div>
      <div><span>Refunded</span><strong>${Number(totals.refunded || 0)}</strong><small>Order status count</small></div>
      <div><span>Active services</span><strong>${serviceCount}</strong><small>${platformCount} platforms</small></div>
    </section>

    <div class="smm-dashboard-columns">
      <section class="smm-dashboard-panel">
        <div class="smm-dashboard-panel-heading"><div><span class="eyebrow">ORDER ACTIVITY</span><h3>Recent orders</h3></div><a href="#/smm/orders">All orders ${icon('arrowRight', 13)}</a></div>
        ${(recent.items || []).length ? `<div class="list">${recent.items.map((o) => `
          <a class="smm-dashboard-order" href="#/smm/orders" data-order-open="${esc(o.id)}">
            <span class="smm-dashboard-platform">${platformIcon(o.platform, 17)}</span>
            <span class="smm-dashboard-order-copy"><strong class="truncate">${esc(o.service_name)}</strong><small>#${esc(o.short_id)} · ${Number(o.quantity).toLocaleString()} · ${money(o.total_cost)} USDT · ${esc(ago(o.created_at))}</small></span>
            ${statusChip(o.status)}${icon('chevronRight', 15)}
          </a>`).join('')}</div>` : emptyState({ iconName: 'layers', title: 'No orders yet', text: 'Choose a service from the catalogue to place your first order.', action: '<a class="btn btn-primary btn-sm" href="#/smm/services">Browse services</a>' })}
      </section>

      <section class="smm-dashboard-panel">
        <div class="smm-dashboard-panel-heading"><div><span class="eyebrow">LIVE CATALOGUE</span><h3>Available services</h3></div><a href="#/smm/services">Browse all ${icon('arrowRight', 13)}</a></div>
        ${(popular.items || []).length ? `<div class="smm-dashboard-service-list">${popular.items.map((s) => `
          <button type="button" data-order-service="${esc(s.id)}">
            <span class="smm-dashboard-platform">${platformIcon(s.platform, 17)}</span>
            <span><strong class="truncate">${esc(s.name)}</strong><small>${esc(plat(s.platform).label)} · ${money(s.rate_per_1000)} / 1K · ${Number(s.min_quantity)}–${Number(s.max_quantity)}</small></span>
            ${icon('arrowRight', 14)}
          </button>`).join('')}</div>` : '<p class="small muted">No active SMM services are published right now.</p>'}
      </section>
    </div>

    ${rec.length ? `<section class="smm-dashboard-recently">
      <div class="smm-dashboard-panel-heading"><div><span class="eyebrow">ON THIS DEVICE</span><h3>Recently viewed</h3></div><span class="badge grey">${rec.length}</span></div>
      <div class="smm-dashboard-recent-list">${rec.map((s) => `
        <button class="chip" type="button" data-order-service="${esc(s.id)}">${platformIcon(s.platform, 14)} ${esc(s.name)} · ${money(s.rate_per_1000)} / 1K</button>`).join('')}</div>
    </section>` : ''}
  </div>`;

  root.querySelectorAll('[data-order-service]').forEach((b) => b.addEventListener('click', async () => {
    await openOrderById(b.dataset.orderService);
  }));
  root.querySelectorAll('[data-order-open]').forEach((a) => a.addEventListener('click', (e) => {
    e.preventDefault();
    showOrderDetailByList(root, recent.items || [], a.dataset.orderOpen);
  }));
}

/* ================================================================ SERVICES */
export async function renderSmmServices(root, ctx = {}) {
  let platform = (ctx?.params?.platform || '').toLowerCase();
  let search = '';
  let category = '';
  let sort = 'default';
  let offset = 0;
  const limit = 20;
  let items = [];
  let total = 0;
  let categories = [];

  let countsFailed = false;
  let catsFailed = false;
  try { state.smmCounts = state.smmCounts || await rpc('smm_platform_counts'); } catch (_) { countsFailed = !state.smmCounts; }
  try { categories = (await rpc('smm_categories_list')) || []; } catch (_) { catsFailed = true; }
  const counts = state.smmCounts || {};

  const platformChips = [['', 'All platforms'], ...SMM_PLATFORMS.filter(([id]) => Object.prototype.hasOwnProperty.call(counts, id) || id === 'x' || 'telegram instagram tiktok youtube facebook threads'.split(' ').includes(id))];

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">SMM</span><h2>${platform ? esc(plat(platform).label) + ' services' : 'Services'}</h2><p>Prices are set by TM Grow Admin and charged from your USDT balance. Nothing here is fetched from a reseller.</p></div>
      <div class="row-wrap">
        <a class="btn btn-ghost btn-sm" href="#/smm/mass">${icon('layers', 14)} Mass order</a>
        <a class="btn btn-ghost btn-sm" href="#/smm/orders">${icon('book', 14)} My orders</a>
      </div>
    </div>
    <div class="smm-search">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="svc-q" placeholder="Search service or #ID" autocomplete="off" /></div>
      <select class="select input-sm" id="svc-sort" style="max-width:150px">
        <option value="default">Default</option>
        <option value="price_asc">Price ↑</option>
        <option value="price_desc">Price ↓</option>
      </select>
    </div>
    <div class="row-wrap mt-10" id="svc-chips">
      ${platformChips.map(([v, l]) => {
        const n = v ? Number(counts[v] || 0) : Object.values(counts).reduce((a, b) => a + Number(b || 0), 0);
        return `<button class="chip ${platform === v ? 'active' : ''}" type="button" data-platform="${esc(v)}">${esc(l)}${countsFailed ? '' : ` <span class="chip-count">${n}</span>`}</button>`;
      }).join('')}
    </div>
    ${countsFailed ? `<div class="tiny dim mt-6">${icon('alert', 12)} Live platform counts could not be loaded — the numbers are hidden instead of shown as 0. The catalogue below is unaffected.</div>` : ''}
    <div class="row-wrap mt-10">
      <select class="select input-sm" id="svc-cat" style="max-width:200px">
        <option value="">All categories</option>
        ${catsFailed ? '<option value="" disabled>Categories unavailable right now</option>' : ''}
        ${categories.map((c) => `<option value="${esc(c.id)}" ${category === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
      </select>
    </div>
    <div id="svc-list" class="mt-14">${loadingBlock('Loading services')}</div>
    <div class="center mt-18"><button class="btn btn-ghost hide" id="svc-more" type="button">Load more</button></div>`;

  const listEl = root.querySelector('#svc-list');
  const moreBtn = root.querySelector('#svc-more');

  const load = async (reset = true) => {
    if (reset) offset = 0;
    listEl.innerHTML = loadingBlock('Loading services');
    let res;
    try {
      res = await rpc('smm_list_services', {
        p_platform: platform || null,
        p_category_id: category || null,
        p_search: search || null,
        p_sort: sort,
        p_limit: limit,
        p_offset: offset
      });
    } catch (e) {
      listEl.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }
    items = res?.items || [];
    total = Number(res?.total || 0);
    paint();
  };

  const paint = () => {
    if (!items.length) {
      listEl.innerHTML = emptyState({
        iconName: 'sliders',
        title: 'No services match',
        text: platform ? 'The administrator has not published active services for this platform yet.' : 'Try another platform, category or search.'
      });
      moreBtn.classList.add('hide');
      return;
    }
    const f = favs();
    listEl.innerHTML = `<div class="smm-services">${items.map((s) => `
      <div class="smm-service">
        <div class="smm-service-top">
          <span class="smm-service-ic">${platformIcon(s.platform, 18)}</span>
          <div class="smm-service-main">
            <button class="smm-service-name" type="button" data-order-service="${esc(s.id)}">${esc(s.name)}</button>
            <div class="smm-service-meta">
              <button class="smm-copy" type="button" data-copy-id="${esc(s.id)}" title="Copy service ID">#${esc(s.short_id)} ${icon('copy', 11)}</button>
              ${s.language ? `<span class="badge grey">${esc(s.language)}</span>` : ''}
              ${s.category_name ? `<span class="badge grey">${esc(s.category_name)}</span>` : ''}
              ${Number(s.orders_count) > 0 ? `<span class="badge orange">Popular</span>` : ''}
            </div>
          </div>
          <button class="smm-fav ${f[s.id] ? 'on' : ''}" type="button" data-fav="${esc(s.id)}" aria-label="Favourite">${icon('star', 16)}</button>
          <div class="smm-rate"><span>${money(s.rate_per_1000)}</span><small>/1K</small></div>
        </div>
        <div class="smm-limits">Min <strong>${Number(s.min_quantity).toLocaleString()}</strong> · Max <strong>${Number(s.max_quantity).toLocaleString()}</strong>${s.estimated_time ? ` · <span class="tiny dim">${esc(s.estimated_time)}</span>` : ''}</div>
        ${(s.features || []).length ? `<div class="row-wrap mt-6">${s.features.map((x) => `<span class="badge grey">${esc(typeof x === 'string' ? x : x.label || '')}</span>`).join('')}</div>` : ''}
        ${s.description ? `<details class="smm-desc"><summary>Description</summary><div class="small muted">${esc(s.description)}</div></details>` : ''}
        <div class="smm-service-actions">
          <button class="btn btn-primary btn-sm" type="button" data-order-service="${esc(s.id)}">Order now</button>
        </div>
      </div>`).join('')}</div>`;
    moreBtn.classList.toggle('hide', items.length >= total);
  };

  root.querySelector('[data-platform]')?.closest('#svc-chips')?.addEventListener('click', (e) => {
    const b = e.target.closest('[data-platform]');
    if (!b) return;
    platform = b.dataset.platform;
    root.querySelectorAll('#svc-chips .chip').forEach((c) => c.classList.toggle('active', c === b));
    load();
  });

  root.querySelector('#svc-q').addEventListener('input', debounce((e) => {
    search = e.target.value.trim();
    load();
  }, 320));
  root.querySelector('#svc-sort').addEventListener('change', (e) => { sort = e.target.value; load(); });
  root.querySelector('#svc-cat').addEventListener('change', (e) => { category = e.target.value; load(); });
  moreBtn.addEventListener('click', () => {
    offset += limit;
    load(false);
  });

  listEl.addEventListener('click', async (e) => {
    const fav = e.target.closest('[data-fav]');
    if (fav) {
      const on = !fav.classList.contains('on');
      fav.classList.toggle('on', on);
      setFav(fav.dataset.fav, on);
      return;
    }
    const cp = e.target.closest('[data-copy-id]');
    if (cp) {
      const ok = await copyText(cp.dataset.copyId);
      toast(ok ? 'Service ID copied.' : 'Copy failed.', ok ? 'success' : 'error');
      return;
    }
    const ord = e.target.closest('[data-order-service]');
    if (ord) {
      const svc = items.find((s) => s.id === ord.dataset.orderService);
      if (svc) openOrder(svc);
    }
  });

  await load();
}

/* ============================================================= ORDER SHEET */
async function openOrderById(serviceId) {
  if (!serviceId) return;
  try {
    const res = await rpc('smm_list_services', { p_search: serviceId, p_limit: 1, p_offset: 0 });
    const svc = (res?.items || []).find((s) => s.id === serviceId) || (res?.items || [])[0];
    if (svc) openOrder(svc);
    else toast('That service is no longer available.', 'error');
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

function openOrder(service) {
  pushRecent(service);
  const min = Number(service.min_quantity || 1);
  const max = Number(service.max_quantity || 1);
  let qty = min;
  const m = openModal({
    title: 'Order now',
    subtitle: `${plat(service.platform).label} · #${service.short_id}`,
    body: `<div class="smm-sheet">
      <div class="smm-sheet-head">
        <span class="smm-service-ic">${platformIcon(service.platform, 18)}</span>
        <div style="min-width:0;flex:1">
          <div class="strong truncate">${esc(service.name)}</div>
          <div class="tiny dim">Rate ${money(service.rate_per_1000)} / 1K · ${min.toLocaleString()}–${max.toLocaleString()}</div>
        </div>
      </div>
      ${service.description ? `<p class="small muted mt-10">${esc(service.description)}</p>` : ''}
      ${(service.features || []).length ? `<div class="row-wrap mt-8">${service.features.map((x) => `<span class="badge grey">${esc(typeof x === 'string' ? x : x.label || '')}</span>`).join('')}</div>` : ''}

      <div class="field mt-14">
        <label class="label">Target link</label>
        <input class="input mono" id="smm-link" placeholder="https://instagram.com/example" autocomplete="off" />
        <span class="hint" id="smm-link-hint">The public link this order should be delivered to.</span>
      </div>

      <div class="field mt-12">
        <label class="label">Quantity</label>
        <div class="smm-qty">
          <button class="qty-btn" type="button" data-qty="-1" aria-label="Decrease">−</button>
          <input class="input" id="smm-qty" type="number" min="${min}" max="${max}" step="1" value="${qty}" inputmode="numeric" />
          <button class="qty-btn" type="button" data-qty="1" aria-label="Increase">+</button>
        </div>
        <div class="row-between tiny dim mt-6"><span>Min ${min.toLocaleString()} · Max ${max.toLocaleString()}</span><span id="smm-hint"></span></div>
      </div>

      <div class="smm-summary mt-14">
        <div class="row-between small"><span>Rate per 1K</span><span>${money(service.rate_per_1000)} USDT</span></div>
        <div class="row-between small mt-6"><span>Total</span><strong id="smm-total" class="gold-text">${money(totalFor(service, qty))} USDT</strong></div>
        <div class="row-between small mt-6"><span>Available</span><span>${money(available())} USDT</span></div>
        <div class="row-between small mt-6"><span>After payment</span><span id="smm-after">${money(available() - totalFor(service, qty))} USDT</span></div>
      </div>
      <div class="alert warn mt-10 hide" id="smm-bad">${icon('alert', 17)}<div id="smm-bad-text"></div></div>
      <p class="tiny dim mt-10">Orders are queued for fulfilment. Status changes only when TM Grow staff actually processes the order.</p>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
      <button class="btn btn-primary" type="button" data-submit disabled>Order now</button>`
  });

  const linkEl = m.root.querySelector('#smm-link');
  const qtyEl = m.root.querySelector('#smm-qty');
  const totalEl = m.root.querySelector('#smm-total');
  const afterEl = m.root.querySelector('#smm-after');
  const badEl = m.root.querySelector('#smm-bad');
  const badText = m.root.querySelector('#smm-bad-text');
  const submit = m.root.querySelector('[data-submit]');
  let submitted = false;

  const sync = () => {
    const raw = qtyEl.value;
    const q = Math.floor(Number(raw) || 0);
    const clamp = Math.min(max, Math.max(min, q || min));
    const t = totalFor(service, clamp);
    totalEl.textContent = `${money(t)} USDT`;
    afterEl.textContent = `${money(available() - t)} USDT`;
    const linkOk = /^https?:\/\/\S+$/i.test(linkEl.value.trim());
    let msg = '';
    if (!Number.isInteger(q) || q < min || q > max) msg = `Quantity must be ${min}–${max}.`;
    else if (!linkOk) msg = 'Enter a valid http(s) target link.';
    else if (t > available()) msg = 'Not enough balance for this order.';
    badEl.classList.toggle('hide', !msg);
    badText.textContent = msg || '';
    submit.disabled = !!msg || submitted;
  };

  m.root.querySelectorAll('[data-qty]').forEach((b) => b.addEventListener('click', () => {
    const step = Number(b.dataset.qty);
    qtyEl.value = String(Math.min(max, Math.max(min, (Math.floor(Number(qtyEl.value) || min) + step))));
    sync();
  }));
  qtyEl.addEventListener('input', sync);
  linkEl.addEventListener('input', sync);
  m.root.querySelector('[data-cancel]').onclick = () => m.close();

  submit.onclick = async () => {
    if (submitted) return;
    submitted = true;
    submit.disabled = true;
    setBusy(submit, true, 'Placing order');
    try {
      const key = (crypto && crypto.randomUUID) ? crypto.randomUUID() : `k${Date.now()}${Math.random()}`;
      const res = await rpc('create_smm_order', {
        p_service_id: service.id,
        p_target_link: linkEl.value.trim(),
        p_quantity: Math.floor(Number(qtyEl.value)),
        p_idempotency_key: key
      });
      if (!res || res.ok === false) {
        submitted = false;
        toast((res && res.message) || 'The order could not be placed.', 'error', 8000);
        setBusy(submit, false);
        sync();
        return;
      }
      m.close();
      showOrderConfirmation(res.order, res.balance, service);
    } catch (e) {
      submitted = false;
      toast(friendlyError(e), 'error', 8000);
      setBusy(submit, false);
      sync();
    }
  };

  sync();
  setTimeout(() => linkEl.focus(), 120);
}

function showOrderConfirmation(order, balance, service) {
  const m = openModal({
    title: 'Order placed',
    subtitle: 'Queued for fulfilment',
    body: `<div class="smm-confirm">
      <div class="smm-confirm-mark">${icon('checkCircle', 34)}</div>
      <div class="strong" style="font-size:16px">${esc(service?.name || 'Service')}</div>
      <div class="tiny dim mono">#${esc(String(order?.id || '').replace(/-/g, '').slice(0, 8).toUpperCase())}</div>
      <div class="grid grid-2 mt-14">
        <div class="card card-pad"><div class="tiny dim">Quantity</div><div class="strong">${Number(order?.quantity || 0).toLocaleString()}</div></div>
        <div class="card card-pad"><div class="tiny dim">Charged</div><div class="strong">${money(order?.total_cost)} USDT</div></div>
        <div class="card card-pad"><div class="tiny dim">Status</div><div class="strong">Pending</div></div>
        <div class="card card-pad"><div class="tiny dim">New balance</div><div class="strong">${money(balance)} USDT</div></div>
      </div>
      <p class="small muted mt-14">The order is in the fulfilment queue. It will move to Processing and Completed only after TM Grow staff process it — never automatically.</p>
    </div>`,
    footer: `<a class="btn btn-ghost" href="#/smm/orders">My orders</a>
      <button class="btn btn-primary" type="button" data-close>Done</button>`
  });
  m.root.querySelector('[data-close]').onclick = () => { m.close(); refreshBuyerShell(); };
  m.root.querySelector('a[href="#/smm/orders"]').addEventListener('click', refreshBuyerShell);
}

/* Kept small: updates the sidebar balance after a charge. */
function refreshBuyerShell() {
  try {
    const el = document.querySelector('[data-wallet-available]');
    if (el) el.innerHTML = `${money(available()).replace(' USDT', '')} <span>USDT</span>`;
  } catch (_) { /* ignore */ }
}

/* =============================================================== MASS ORDER */
export async function renderSmmMass(root) {
  let services = [];
  try {
    const res = await rpc('smm_list_services', { p_limit: 100, p_offset: 0 });
    services = res?.items || [];
  } catch (e) {
    root.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
    return;
  }
  const byId = new Map(services.map((s) => [s.id, s]));

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">SMM</span><h2>Mass order</h2><p>One line per order. The whole batch is validated first, then charged together — if one line is wrong, nothing is charged.</p></div>
      <a class="btn btn-ghost btn-sm" href="#/smm/services">${icon('search', 14)} Catalogue</a>
    </div>
    <div class="card card-pad">
      <label class="label">Lines</label>
      <textarea class="textarea mono" id="mass-lines" rows="7" placeholder="service_id | target_link | quantity&#10;e.g. 3f2a9c1e-... | https://instagram.com/example | 100"></textarea>
      <div class="row-wrap mt-10">
        <button class="btn btn-soft btn-sm" type="button" data-use-picked>Use catalogue IDs</button>
        <span class="tiny dim">Format: service_id | target link | quantity (max 50 lines).</span>
      </div>
    </div>
    <div id="mass-body" class="mt-14"></div>
    <div class="card card-pad mt-14">
      <div class="row-between"><span class="muted">Grand total</span><strong id="mass-total" class="gold-text">0 USDT</strong></div>
      <div class="row-between small mt-6"><span class="muted">Available</span><span>${money(available())} USDT</span></div>
      <button class="btn btn-primary mt-14" type="button" id="mass-submit" disabled>Submit batch</button>
    </div>`;

  const linesEl = root.querySelector('#mass-lines');
  const body = root.querySelector('#mass-body');
  const totalEl = root.querySelector('#mass-total');
  const submit = root.querySelector('#mass-submit');
  let parsed = [];
  let submitting = false;

  const parse = () => {
    parsed = [];
    let sum = 0;
    const rows = String(linesEl.value || '').split('\n').map((x) => x.trim()).filter(Boolean);
    rows.slice(0, 50).forEach((line, i) => {
      const parts = line.split('|').map((x) => x.trim());
      const row = { line: i + 1, raw: line, ok: false, error: '', service: null, qty: 0, total: 0, target: '' };
      if (parts.length < 3) { row.error = 'Use service_id | target_link | quantity'; parsed.push(row); return; }
      const [sid, target, qtyRaw] = parts;
      const svc = byId.get(sid);
      row.service = svc;
      row.target = target;
      row.qty = Math.floor(Number(qtyRaw) || 0);
      if (!svc) row.error = 'Unknown or inactive service ID.';
      else if (!/^https?:\/\/\S+$/i.test(target)) row.error = 'Invalid target link.';
      else if (!Number.isInteger(row.qty) || row.qty < Number(svc.min_quantity) || row.qty > Number(svc.max_quantity)) row.error = `Quantity must be ${Number(svc.min_quantity)}–${Number(svc.max_quantity)}.`;
      else {
        row.total = totalFor(svc, row.qty);
        row.ok = true;
        sum += row.total;
      }
      parsed.push(row);
    });
    body.innerHTML = parsed.length ? `<div class="card"><div class="card-body"><div class="list">${parsed.map((r) => `
      <div class="list-row">
        ${r.ok ? '<span class="badge green">OK</span>' : '<span class="badge red">Fix</span>'}
        <div class="list-main" style="min-width:0">
          <div class="list-title truncate">${esc(r.service ? r.service.name : r.raw)}</div>
          <div class="list-sub truncate">${esc(r.target || '')} · ${Number(r.qty || 0).toLocaleString()}${r.ok ? ` · ${money(r.total)} USDT` : ''}</div>
          ${r.error ? `<div class="tiny red">${esc(r.error)}</div>` : ''}
        </div>
      </div>`).join('')}</div></div></div>` : '<p class="small muted">No lines yet.</p>';
    totalEl.textContent = `${money(sum)} USDT`;
    submit.disabled = submitting || sum <= 0 || sum > available() || parsed.some((r) => !r.ok) || parsed.length === 0;
    return sum;
  };

  linesEl.addEventListener('input', debounce(parse, 250));

  submit.addEventListener('click', async () => {
    if (submitting) return;
    const sum = parse();
    if (sum <= 0 || parsed.some((r) => !r.ok)) return;
    const ok = await confirmDialog({
      title: 'Submit mass order?',
      message: `${parsed.length} order(s) · ${money(sum)} USDT will be charged in one atomic batch. If any line fails validation, nothing is charged.`,
      confirmLabel: 'Submit batch'
    });
    if (!ok) return;
    submitting = true;
    submit.disabled = true;
    setBusy(submit, true, 'Submitting');
    try {
      const key = (crypto && crypto.randomUUID) ? crypto.randomUUID() : `b${Date.now()}`;
      const res = await rpc('create_smm_orders_bulk', {
        p_items: parsed.map((r) => ({ service_id: r.service.id, target_link: r.target, quantity: r.qty })),
        p_idempotency_key: key
      });
      if (!res || res.ok === false) {
        toast((res && res.message) || 'The batch was rejected. Nothing was charged.', 'error', 9000);
        submitting = false;
        setBusy(submit, false);
        parse();
        return;
      }
      const n = (res.orders || []).length;
      toast(`${n} order(s) placed · ${money(res.total || sum)} USDT charged.`, 'success', 8000);
      root.innerHTML = '';
      renderSmmMass(root);
    } catch (e) {
      toast(friendlyError(e), 'error', 9000);
      submitting = false;
      setBusy(submit, false);
      parse();
    }
  });

  parse();
}

/* ================================================================== ORDERS */
export async function renderSmmOrders(root) {
  let status = '';
  let search = '';
  let offset = 0;
  const limit = 20;
  let total = 0;
  let items = [];

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">SMM</span><h2>My orders</h2><p>Every status below comes from the database. Nothing is completed automatically.</p></div>
      <a class="btn btn-ghost btn-sm" href="#/smm/services">${icon('plus', 14)} New order</a>
    </div>
    <div class="smm-search">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="ord-q" placeholder="Order ID or target link" autocomplete="off" /></div>
    </div>
    <div class="tabs mt-10" id="ord-tabs">
      ${TABS.map(([v, l]) => `<button class="tab ${v === status ? 'active' : ''}" type="button" data-status="${v}">${l}</button>`).join('')}
    </div>
    <div id="ord-list" class="mt-14">${loadingBlock('Loading orders')}</div>
    <div class="center mt-18"><button class="btn btn-ghost hide" id="ord-more" type="button">Load more</button></div>`;

  const listEl = root.querySelector('#ord-list');
  const moreBtn = root.querySelector('#ord-more');

  const load = async (reset = true) => {
    if (reset) offset = 0;
    listEl.innerHTML = loadingBlock('Loading orders');
    let res;
    try {
      res = await rpc('my_smm_orders', { p_status: status || null, p_search: search || null, p_limit: limit, p_offset: offset });
    } catch (e) {
      listEl.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }
    items = reset ? (res?.items || []) : [...items, ...(res?.items || [])];
    total = Number(res?.total || 0);
    paint();
  };

  const paint = () => {
    if (!items.length) {
      listEl.innerHTML = emptyState({ iconName: 'layers', title: 'No orders in this view', text: 'Place an order or choose another filter.' });
      moreBtn.classList.add('hide');
      return;
    }
    listEl.innerHTML = `<div class="smm-orders">${items.map((o) => {
      const qty = Number(o.quantity || 0);
      const done = Number(o.completed_quantity || 0);
      const tracked = o.completed_quantity !== undefined && o.completed_quantity !== null;
      const pc = qty > 0 ? Math.min(100, Math.round(done / qty * 100)) : 0;
      return `<button class="card card-pad smm-order-row" type="button" data-order="${esc(o.id)}" style="width:100%;text-align:left;background:var(--surface)">
        <div class="row-between" style="gap:10px;flex-wrap:wrap">
          <div class="row" style="gap:8px;min-width:0">
            <span class="smm-service-ic">${platformIcon(o.platform, 16)}</span>
            <div style="min-width:0">
              <div class="strong truncate">${esc(o.service_name)}</div>
              <div class="tiny dim mono">#${esc(o.short_id)} · ${esc(ago(o.created_at))}</div>
            </div>
          </div>
          ${statusChip(o.status)}
        </div>
        <div class="row-between small mt-10">
          <span class="truncate" style="max-width:60%">${esc(o.target_link)}</span>
          <span>${Number(o.quantity).toLocaleString()} · <strong>${money(o.total_cost)} USDT</strong></span>
        </div>
        ${tracked ? `<div class="row-between tiny dim mt-6">
          <span>${done.toLocaleString()} / ${qty.toLocaleString()} delivered${Number(o.rejected_quantity || 0) > 0 ? ` · ${Number(o.rejected_quantity)} rejected` : ''}</span>
          ${o.drip_paused ? '<span class="badge red">Release paused</span>' : ''}
        </div>
        <div class="progress mt-6"><i style="width:${pc}%"></i></div>` : ''}
        ${Number(o.refunded_total || 0) > 0 ? `<div class="tiny dim mt-6">Refunded ${money(o.refunded_total)} USDT</div>` : ''}
      </button>`;
    }).join('')}</div>`;
    moreBtn.classList.toggle('hide', items.length >= total);
  };

  listEl.addEventListener('click', (e) => {
    const a = e.target.closest('[data-order-open]');
    if (a) { e.preventDefault(); showOrderById(root, items, a.dataset.orderOpen); return; }
    const b = e.target.closest('[data-order]');
    if (b) showOrderById(root, items, b.dataset.order);
  });

  root.querySelector('#ord-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-status]');
    if (!b) return;
    status = b.dataset.status;
    root.querySelectorAll('#ord-tabs .tab').forEach((t) => t.classList.toggle('active', t === b));
    load();
  });
  root.querySelector('#ord-q').addEventListener('input', debounce((e) => {
    search = e.target.value.trim();
    load();
  }, 320));
  moreBtn.addEventListener('click', () => { offset += limit; load(false); });

  await load();
}

async function showOrderById(root, list, id) {
  const local = (list || []).find((o) => o.id === id);
  if (local) { await showOrderDetail(local); return; }
  try {
    const res = await rpc('my_smm_orders', { p_status: null, p_search: id, p_limit: 1, p_offset: 0 });
    const o = (res?.items || [])[0];
    if (o) await showOrderDetail(o);
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

async function showOrderDetail(o) {
  /* Real per-unit counts, computed from this order's task rows on the server. */
  let prog = null;
  try {
    prog = await rpc('smm_order_progress', { p_order_id: o.id });
  } catch (_) {
    prog = null;
  }

  const timeline = [
    ['Placed', o.created_at],
    ['Processing', o.processed_at],
    ['Completed', o.completed_at]
  ].filter(([, t]) => !!t);

  const q = Number(prog?.quantity ?? o.quantity ?? 0);
  const done = Number(prog?.completed ?? 0);
  const openQty = Number(prog?.pending ?? 0) + Number(prog?.claimed ?? 0) + Number(prog?.verification ?? 0);
  const notReleased = Math.max(0, q - done - openQty);
  const pctDone = q > 0 ? Math.min(100, Math.round((done / q) * 100)) : 0;
  const cell = (label, value) => `<div class="card card-pad"><div class="tiny dim">${esc(label)}</div><div class="strong">${Number(value || 0).toLocaleString()}</div></div>`;

  const progressBlock = prog ? `<div class="card mt-12">
      <div class="card-head"><h3>Delivery progress</h3><span class="badge ${q > 0 && done >= q ? 'green' : 'grey'}">${done.toLocaleString()} / ${q.toLocaleString()}</span></div>
      <div class="card-body">
        <div class="progress"><i style="width:${pctDone}%"></i></div>
        <div class="grid grid-2 mt-12">
          ${cell('Completed', done)}
          ${cell('In review', prog.verification)}
          ${cell('In progress', prog.claimed)}
          ${cell('Waiting to be claimed', prog.pending)}
          ${cell('Not released yet', notReleased)}
          ${cell('Rejected or expired', prog.rejected)}
        </div>
        ${prog.next_release_at && notReleased > 0 ? `<div class="tiny dim mt-10">Next automatic batch: ${esc(dateTime(prog.next_release_at))}.</div>` : ''}
        <p class="tiny dim mt-10">These counts come from the real task rows of this order. A unit counts as completed only after its proof is approved.</p>
      </div>
    </div>` : '';

  const m = openModal({
    title: `Order #${o.short_id}`,
    subtitle: o.service_name,
    wide: true,
    body: `<div class="row-wrap mb-10">${statusChip(o.status)}${Number(o.refunded_total || 0) > 0 ? `<span class="badge violet">Refunded ${money(o.refunded_total)} USDT</span>` : ''}</div>
      <div class="grid grid-2">
        <div class="card card-pad"><div class="tiny dim">Platform</div><div class="strong">${esc(plat(o.platform).label)}</div></div>
        <div class="card card-pad"><div class="tiny dim">Quantity</div><div class="strong">${Number(o.quantity).toLocaleString()}</div></div>
        <div class="card card-pad"><div class="tiny dim">Rate snapshot</div><div class="strong">${money(o.rate_snapshot)} / 1K</div></div>
        <div class="card card-pad"><div class="tiny dim">Charged</div><div class="strong">${money(o.total_cost)} USDT</div></div>
      </div>
      <div class="card card-pad mt-12">
        <div class="tiny dim">Target link</div>
        <div class="mono small" style="word-break:break-all">${esc(o.target_link)}</div>
      </div>
      ${progressBlock}
      <div class="card mt-12">
        <div class="card-head"><h3>Timeline</h3></div>
        <div class="card-body"><div class="list">${timeline.map(([label, t]) => `
          <div class="list-row"><span class="badge green">${esc(label)}</span><div class="list-main"><div class="list-sub">${esc(dateTime(t))}</div></div></div>`).join('')}
          ${timeline.length === 1 ? '<p class="tiny dim mt-6">Waiting for staff processing.</p>' : ''}
        </div></div>
      </div>
      ${o.admin_note ? `<div class="alert info mt-12">${icon('info', 17)}<div>${esc(o.admin_note)}</div></div>` : ''}
      <p class="tiny dim mt-10">Only real recorded events are shown. Nothing advances automatically except batch release and the per-unit counters.</p>`,
    footer: '<button class="btn btn-ghost" type="button" data-close>Close</button>'
  });
  m.root.querySelector('[data-close]').onclick = () => m.close();
}

/* Old signature kept for the dashboard click path. */
function showOrderDetailByList(root, list, id) { showOrderById(root, list, id); }
