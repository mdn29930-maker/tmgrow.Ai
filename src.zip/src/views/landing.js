import { CONFIG } from '../config.js?v=2025-10-12-39';
import { state, loadPublicData, settingText, withdrawalMin } from '../lib/store.js?v=2025-10-12-39';
import { icon, esc, usdt, platformMeta, openModal } from '../lib/ui.js?v=2025-10-12-39';

const PLATFORMS = ['x', 'youtube', 'instagram', 'tiktok', 'facebook', 'telegram', 'reddit', 'spotify'];

function statBlock(stats) {
  if (!stats) return '';
  const items = [
    { key: 'users', label: 'Registered users', value: Number(stats.users || 0) },
    { key: 'workers', label: 'Active workers', value: Number(stats.workers || 0) },
    { key: 'tasks_completed', label: 'Completed tasks', value: Number(stats.tasks_completed || 0) },
    { key: 'rewards_paid', label: 'USDT paid out', value: Number(stats.rewards_paid || 0), money: true },
    { key: 'active_campaigns', label: 'Active campaigns', value: Number(stats.active_campaigns || 0) }
  ].filter((i) => i.value > 0);

  if (!items.length) return '';
  return `<section class="land-section" style="padding-top:10px">
    <div class="land-wrap">
      <div class="land-stats">
        ${items.map((i) => `
          <div class="land-stat">
            <b>${i.money ? usdt(i.value) : Math.round(i.value).toLocaleString('en-US')}</b>
            <span>${esc(i.label)}</span>
          </div>`).join('')}
      </div>
      <p class="tiny dim center" style="margin-top:10px">Live totals from verified platform records.</p>
    </div>
  </section>`;
}

export async function renderLanding(root) {
  try { await loadPublicData(); } catch (_) { /* optional */ }

  const minWithdraw = withdrawalMin();
  const announcement = settingText('announcement', '');

  const languageModal = () => {
    const m = openModal({
      title: 'Language',
      subtitle: 'Interface language',
      body: `<div class="list">
          <div class="list-row">
            <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px;color:var(--brand)">${icon('globe', 16)}</span>
            <div class="list-main"><div class="list-title">English</div><div class="list-sub">Active — the full interface</div></div>
            <span class="badge green">Active</span>
          </div>
        </div>
        <p class="tiny dim mt-14">Other languages appear here when translations are published. The platform currently runs in English everywhere.</p>`,
      footer: '<button class="btn btn-primary" type="button" data-lang-ok>Got it</button>'
    });
    m.root.querySelector('[data-lang-ok]').onclick = () => m.close();
  };

  root.innerHTML = `<div class="landing">
    <header class="land-nav"><div class="land-wrap"><div class="land-nav-in">
      <a class="brand" href="#/" style="padding:0">
        <span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span>
        <span><span class="brand-name">TM GROW</span><span class="brand-sub">Social task network</span></span>
      </a>
      <nav class="land-links">
        <a href="#/">Home</a>
        <a href="#how">How It Works</a>
        <a href="#/login">Explore Tasks</a>
        <a href="#buyers">For Buyers</a>
        <a href="#about">About</a>
        <a href="#faq">FAQ</a>
      </nav>
      <div class="land-nav-actions">
        <button class="btn btn-ghost btn-sm" type="button" data-language aria-label="Language selector" title="Language">${icon('globe', 16)} <span class="tiny">EN</span></button>
        <a class="btn btn-ghost btn-sm" href="#/login">Login</a>
        <a class="land-earn-pill" href="#/login">${icon('zap', 14)} Register</a>
      </div>
    </div></div></header>

    ${announcement ? `<div class="land-wrap"><div class="alert info" style="margin:16px 0 0">${icon('info', 17)}<div>${esc(announcement)}</div></div></div>` : ''}

    <main class="land-main" style="flex:1">
      <section class="land-wrap land-hero">
        <div>
          <span class="land-eyebrow">${icon('zap', 13)} Global social task platform</span>
          <h1>Grow Your Social Presence.<br /><span class="grad">Earn Real Rewards.</span></h1>
          <p class="land-lead">
            TM Grow connects businesses with a global community of workers. Promote your brand, complete social tasks,
            and earn <strong>USDT</strong> and <strong>TM Coins</strong> — withdrawn to your own wallet from a low
            <strong>${esc(usdt(minWithdraw))} USDT</strong> minimum.
          </p>
          <div class="land-cta">
            <a class="btn btn-primary btn-lg" href="#/login">Start Earning ${icon('arrowRight', 17)}</a>
            <a class="btn btn-ghost btn-lg" href="#buyers">Promote Your Business</a>
          </div>
          ${Number(state.publicStats?.users || 0) > 0 ? `<div class="land-social">
            <div class="land-avs">
              <span style="background:#f97316">${icon('user', 14)}</span>
              <span style="background:#8b5cf6">${icon('user', 14)}</span>
              <span style="background:#22c55e">${icon('user', 14)}</span>
              <span style="background:#ec4899">${icon('user', 14)}</span>
            </div>
            <div class="small muted">Joined by <strong style="color:#fff">${Number(state.publicStats.users).toLocaleString('en-US')}</strong> registered accounts<br />worldwide</div>
          </div>` : ''}
          <div class="land-proof">
            <span class="tick">${icon('check', 14)} Free to join</span>
            <span class="tick">${icon('check', 14)} ${esc(usdt(minWithdraw))} USDT minimum withdrawal</span>
            <span class="tick">${icon('check', 14)} ${esc(CONFIG.networkName)}</span>
          </div>
        </div>

        <div class="phone-stage">
          <span class="land-particle" style="left:12%;top:14%;animation-delay:0s"></span>
          <span class="land-particle" style="left:78%;top:8%;animation-delay:.8s"></span>
          <span class="land-particle" style="left:66%;top:82%;animation-delay:1.4s"></span>
          <span class="land-particle" style="left:22%;top:74%;animation-delay:2s"></span>
          <span class="land-particle" style="left:88%;top:52%;animation-delay:2.6s"></span>
          <div class="float-chip a">${icon('checkCircle', 14)} Proof approved</div>
          <div class="float-chip b">${icon('coin', 14)} TM Coin bonus</div>
          <div class="phone">
            <div class="phone-screen">
              <div class="phone-notch"></div>
              <div class="phone-ui">
                <div class="phone-top">
                  <span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span>
                  <div><div class="pt-name">TM GROW</div><div class="pt-sub">Worker wallet</div></div>
                </div>
                <div class="phone-balance">
                  <div class="pb-label">Available balance</div>
                  <div class="pb-value">0.00 <small>USDT</small></div>
                  <div class="pb-foot"><span>Pending review</span><span>0.00</span></div>
                </div>
                <div class="phone-task">
                  <span class="pt-ic" style="background:${platformMeta('x').bg};color:${platformMeta('x').color}">${icon('x', 14)}</span>
                  <div><div class="pt-title">Follow on X</div><div class="pt-meta">+0.030 USDT</div></div>
                  <span class="pt-btn">START</span>
                </div>
                <div class="phone-task">
                  <span class="pt-ic" style="background:${platformMeta('youtube').bg};color:${platformMeta('youtube').color}">${icon('youtube', 14)}</span>
                  <div><div class="pt-title">YouTube subscribe</div><div class="pt-meta">+0.050 USDT</div></div>
                  <span class="pt-btn">START</span>
                </div>
                <div class="phone-task">
                  <span class="pt-ic" style="background:${platformMeta('instagram').bg};color:${platformMeta('instagram').color}">${icon('instagram', 14)}</span>
                  <div><div class="pt-title">Instagram follow</div><div class="pt-meta">+0.040 USDT</div></div>
                  <span class="pt-btn">START</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      ${statBlock(state.publicStats)}

      <section class="land-section" id="how">
        <div class="land-wrap">
          <div class="land-sec-head">
            <span class="land-eyebrow">How it works</span>
            <h2>From sign-up to payout in five steps</h2>
            <p>No forms, no fees to join, and no social media passwords — ever.</p>
          </div>
          <div class="land-cards">
            <div class="land-card">
              <div class="lc-step">STEP 01</div>
              <div class="lc-ic">${icon('user', 20)}</div>
              <h3>Create your account</h3>
              <p>Sign in with Google, Telegram or email in one tap. Your wallet is created automatically.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">STEP 02</div>
              <div class="lc-ic">${icon('layers', 20)}</div>
              <h3>Choose your role</h3>
              <p>Join as a worker to earn per task, or as a buyer to promote your brand. You can hold both.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">STEP 03</div>
              <div class="lc-ic">${icon('tasks', 20)}</div>
              <h3>Publish or complete tasks</h3>
              <p>Buyers fund campaigns into escrow. Workers claim tasks, follow the instructions and submit proof.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">STEP 04</div>
              <div class="lc-ic">${icon('checkCircle', 20)}</div>
              <h3>Earn rewards</h3>
              <p>A human verifier approves each proof. Rewards plus TM Coin bonuses land in your balance.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">STEP 05</div>
              <div class="lc-ic">${icon('wallet', 20)}</div>
              <h3>Manage your wallet</h3>
              <p>Track every transaction, claim daily rewards and withdraw USDT to your BEP-20 address.</p>
            </div>
          </div>
        </div>
      </section>

      <section class="land-section" id="workers">
        <div class="land-wrap">
          <div class="land-sec-head">
            <span class="land-eyebrow">Feature highlights</span>
            <h2>Everything you need to earn and grow</h2>
            <p>Built for daily use: a fast marketplace, transparent rewards and real payouts.</p>
          </div>
          <div class="land-cards">
            <div class="land-card">
              <div class="lc-ic">${icon('tasks', 20)}</div>
              <h3>Easy task marketplace</h3>
              <p>Browse quick tasks and high-value campaigns across eight social platforms with live slot counts.</p>
            </div>
            <div class="land-card">
              <div class="lc-ic">${icon('zap', 20)}</div>
              <h3>Fast task submission</h3>
              <p>Open the target, complete the action, upload your screenshot — all in one guided task window.</p>
            </div>
            <div class="land-card">
              <div class="lc-ic">${icon('shield', 20)}</div>
              <h3>Secure reward tracking</h3>
              <p>Escrow-funded budgets, an immutable ledger and server-side checks on every balance change.</p>
            </div>
            <div class="land-card">
              <div class="lc-ic">${icon('globe', 20)}</div>
              <h3>Multiple social platforms</h3>
              <p>YouTube, Instagram, TikTok, X, Facebook, Telegram, Reddit, Spotify and Discord tasks.</p>
            </div>
            <div class="land-card">
              <div class="lc-ic">${icon('book', 20)}</div>
              <h3>Transparent task history</h3>
              <p>Every claim, submission and decision is recorded — you always see exactly where you stand.</p>
            </div>
            <div class="land-card">
              <div class="lc-ic">${icon('star', 20)}</div>
              <h3>User-friendly dashboard</h3>
              <p>Live balances, daily streaks, achievements, analytics and leaderboards in one clean workspace.</p>
            </div>
          </div>
          <div class="land-platforms mt-24">
            ${PLATFORMS.map((p) => {
              const m = platformMeta(p);
              return `<span class="land-platform" style="color:${m.color}">${icon(m.icon, 16)}<span style="color:var(--muted)">${esc(m.label)}</span></span>`;
            }).join('')}
          </div>
        </div>
      </section>

      <section class="land-section" id="buyers">
        <div class="land-wrap">
          <div class="land-sec-head">
            <span class="land-eyebrow">For buyers</span>
            <h2>Buy real social engagement, task by task</h2>
            <p>Launch a campaign or place a direct SMM order, set the reward, and only pay for verified work.</p>
          </div>
          <div class="land-cards">
            <div class="land-card">
              <div class="lc-step">LAUNCH</div>
              <div class="lc-ic">${icon('megaphone', 20)}</div>
              <h3>Create a campaign</h3>
              <p>Pick a service, set quantity and reward per task, and add the exact instructions plus target link.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">FUND</div>
              <div class="lc-ic">${icon('card', 20)}</div>
              <h3>Fund into escrow</h3>
              <p>The budget and platform fee are reserved from your buyer wallet. Unused escrow is refunded when the campaign closes.</p>
            </div>
            <div class="land-card">
              <div class="lc-step">VERIFY</div>
              <div class="lc-ic">${icon('checkCircle', 20)}</div>
              <h3>Approve delivery</h3>
              <p>Every submission is verified before a worker is paid. Rejected proofs release the reward back to the campaign.</p>
            </div>
          </div>
          <div class="center mt-24">
            <a class="btn btn-ghost btn-lg" href="#/login">Open a buyer account ${icon('arrowRight', 17)}</a>
          </div>
        </div>
      </section>

      <section class="land-section" id="about">
        <div class="land-wrap">
          <div class="land-sec-head">
            <span class="land-eyebrow">About</span>
            <h2>What TM GROW is</h2>
          </div>
          <div class="land-faq" style="max-width:760px">
            <details open>
              <summary>A marketplace, not a social network</summary>
              <p>TM GROW connects brands with people who complete real social actions. Brands fund campaigns into escrow; workers complete the action on their own accounts and submit proof. Verifiers review every submission before money moves.</p>
            </details>
            <details>
              <summary>Honest rewards</summary>
              <p>Rewards are paid in USDT, a stablecoin, plus TM Coins — a platform bonus token for streaks and milestones. TM Coins reward activity; they are not withdrawable cash, and the platform says so everywhere.</p>
            </details>
            <details>
              <summary>Real records, no invented numbers</summary>
              <p>Every figure shown on this page comes from the platform's own verified records: registered accounts, approved tasks and the actual USDT released. Balances and payouts are enforced server-side.</p>
            </details>
          </div>
        </div>
      </section>

      <section class="land-section" id="faq">
        <div class="land-wrap">
          <div class="land-sec-head"><span class="land-eyebrow">FAQ</span><h2>Straight answers</h2></div>
          <div class="land-faq">
            <details open>
              <summary>How do I get paid on TM GROW?</summary>
              <p>Complete a task, submit the proof requested by the campaign, and wait for verification. When a verifier approves it, the reward moves from pending to your available USDT balance. You can then request a withdrawal to your own BEP-20 wallet.</p>
            </details>
            <details>
              <summary>Is verification automatic?</summary>
              <p>No. Unless a campaign explicitly states an API integration, proofs are reviewed manually by a verifier. We do not claim automatic detection that is not configured.</p>
            </details>
            <details>
              <summary>When are withdrawals processed?</summary>
              <p>Withdrawal requests enter a finance queue. Each payout is made on BNB Smart Chain (BEP-20) and the transaction hash is recorded on the request. Timing depends on the finance team, and TM GROW never invents a fake transaction hash.</p>
            </details>
            <details>
              <summary>Do you need my social media password?</summary>
              <p>Never. TM GROW only asks you to complete a public action on your own account and submit a screenshot as proof. We never ask for passwords, 2FA codes, or session cookies.</p>
            </details>
            <details>
              <summary>What are TM Coins?</summary>
              <p>TM Coins are TM GROW's platform reward token, credited as a bonus alongside USDT for approved work, daily check-ins and achievements. They reward activity and have no guaranteed cash value.</p>
            </details>
            <details>
              <summary>Is it free to join?</summary>
              <p>Yes. Creating a worker account is free. Buying a campaign is funded from your buyer wallet with a platform fee shown before you confirm.</p>
            </details>
          </div>
        </div>
      </section>

      <section class="land-section" id="community">
        <div class="land-wrap">
          <div class="land-sec-head">
            <span class="land-eyebrow">Community</span>
            <h2>Talk to real people</h2>
            <p>Join the official channels — real members, real support, no paid testimonials.</p>
          </div>
          <div class="center">
            <a class="btn btn-ghost" href="https://t.me/Tmgrowglobal" target="_blank" rel="noopener noreferrer">${icon('telegram', 16)} Global community</a>
            <a class="btn btn-ghost" style="margin-left:8px" href="https://t.me/BTCsignal777" target="_blank" rel="noopener noreferrer">${icon('telegram', 16)} Contact support</a>
          </div>
        </div>
      </section>

      <section class="land-wrap">
        <div class="land-final">
          <span class="land-eyebrow">Start today</span>
          <h2>Your next task is a tap away</h2>
          <p>Join TM GROW, earn per verified task, and withdraw from ${esc(usdt(minWithdraw))} USDT.</p>
          <a class="btn btn-primary btn-lg" href="#/login">Create free account ${icon('arrowRight', 17)}</a>
        </div>
      </section>
    </main>

    <footer class="land-wrap">
      <div class="land-foot">
        <span>© ${new Date().getFullYear()} TM GROW. All rights reserved.</span>
        <span class="row" style="gap:16px">
          <a href="#/login">Sign in</a>
          <a href="/terms.html">Terms</a>
          <a href="/privacy.html">Privacy</a>
          <a href="#faq">FAQ</a>
          <a href="#about">About</a>
          <a href="#buyers">For Buyers</a>
        </span>
      </div>
    </footer>
  </div>`;

  /* In-page anchors must not touch the hash router, which owns window.location.hash. */
  root.querySelectorAll('a[href^="#"]').forEach((a) => {
    const id = a.getAttribute('href').slice(1);
    if (!['how', 'workers', 'buyers', 'faq', 'about'].includes(id)) return;
    a.addEventListener('click', (e) => {
      const section = document.getElementById(id);
      if (!section) return;
      e.preventDefault();
      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  root.querySelectorAll('[data-language]').forEach((b) => b.addEventListener('click', languageModal));
}
