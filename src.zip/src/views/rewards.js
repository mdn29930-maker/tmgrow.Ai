/* Reward celebration overlay. Pure presentation: it only appears after a
   server-side reward has actually been credited. */

export function showRewardBurst(amount, label) {
  const el = document.createElement('div');
  el.className = 'reward-burst';
  const clean = (v) => String(v === null || v === undefined ? '' : v).replace(/[&<>"]/g, '');

  const parts = Array.from({ length: 12 }, (_, i) => {
    const ang = (Math.PI * 2 * i) / 12;
    const dx = Math.round(Math.cos(ang) * (120 + (i % 4) * 38));
    const dy = Math.round(Math.sin(ang) * (90 + (i % 3) * 30));
    const c = ['#FFD54F', '#FFB020', '#FF6B35', '#FFF3C4'][i % 4];
    return `<span class="rb-p" style="--dx:${dx}px;--dy:${dy}px;background:${c};left:calc(50% - 5px);top:calc(50% - 5px)"></span>`;
  }).join('');

  el.innerHTML = `<div class="reward-burst-card">
      <div class="reward-burst-coin"><svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 8h5M12 8v8M9.8 16h4.7"/></svg></div>
      <div class="reward-burst-amount">${clean(amount)}</div>
      <div class="reward-burst-label">${clean(label)}</div>
    </div>${parts}`;

  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 350);
  }, 2000);
}
