/* Achievements & badges. Unlock conditions are evaluated server-side by
   public.my_achievements(); the TM Coin reward is credited by
   public.claim_achievement() only after a fresh server-side re-check.
   If the migration has not been run, the page says so instead of faking
   progress. */

import { rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import { state, currentMode } from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, tg, toast, loadingBlock, errorPanel, emptyState, setBusy
} from '../lib/ui.js?v=2025-10-12-39';
import { showRewardBurst } from './rewards.js?v=2025-10-12-39';
import { navigate } from '../lib/router.js?v=2025-10-12-39';

const MISSING_SQL = 'The achievements system is not installed on this database yet. Run supabase/premium-platform.sql in the Supabase SQL editor, then reload this page.';

function missingRpc(e) {
  const raw = String((e && (e.raw?.message || e.message)) || '');
  return /PGRST202|Could not find the function|schema cache|does not exist/i.test(raw);
}

function progressLabel(a) {
  const p = Number(a.progress || 0);
  const t = Number(a.threshold || 1);
  switch (a.condition_type) {
    case 'lifetime_earned': return `${tg(p)} / ${tg(t)} USDT`;
    case 'streak': return `${p} / ${t} days`;
    case 'withdrawals': return `${p} / ${t} payouts`;
    default: return `${p} / ${t} tasks`;
  }
}

export async function renderAchievements(root) {
  if (currentMode() === 'buyer') {
    navigate('/dashboard', { replace: true });
    return;
  }
  root.innerHTML = loadingBlock('Loading achievements');

  let items = [];
  let errText = '';
  try {
    items = (await rpc('my_achievements')) || [];
  } catch (e) {
    errText = missingRpc(e) ? MISSING_SQL : friendlyError(e);
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Rewards</span><h2>Achievements &amp; badges</h2><p>Unlock milestones by earning and claim TM Coin rewards.</p></div>
      <span class="badge gold">${icon('coin', 13)} ${esc(tg(state.wallet?.tg_balance))} TM</span>
    </div>

    ${errText ? errorPanel(errText) : ''}
    ${!errText && !items.length
      ? emptyState({
        iconName: 'trophy',
        title: 'No achievements configured',
        text: 'An administrator can add achievements to the achievements table; progress is then tracked automatically.'
      })
      : ''}

    <div class="ach-grid">
      ${items.map((a) => {
        const pctDone = Math.min(100, Math.round((Number(a.progress || 0) / Math.max(1, Number(a.threshold || 1))) * 100));
        const unlocked = !!a.unlocked;
        const granted = !!a.reward_granted;
        return `<div class="ach-card ${unlocked ? 'unlocked' : 'locked'}">
          <div class="ach-top">
            <span class="ach-icon">${icon(a.icon || 'star', 20)}</span>
            <div style="min-width:0;flex:1">
              <div class="ach-name">${esc(a.name)}</div>
              <div class="ach-desc">${esc(a.description)}</div>
            </div>
            ${unlocked ? `<span class="badge gold">${icon('trophy', 12)} Unlocked</span>` : ''}
          </div>
          <div class="ach-progress"><i style="width:${pctDone}%"></i></div>
          <div class="ach-meta"><span>${esc(progressLabel(a))}</span><span class="gold-text">+${esc(tg(a.reward_tg))} TM</span></div>
          ${unlocked && !granted
            ? `<button class="btn btn-gold btn-block" type="button" data-claim="${esc(a.key)}">${icon('gift', 15)} Claim reward</button>`
            : unlocked
              ? `<span class="badge green" style="justify-content:center">${icon('checkCircle', 13)} Reward claimed</span>`
              : `<button class="btn btn-ghost btn-block" type="button" disabled>Locked</button>`}
        </div>`;
      }).join('')}
    </div>

    ${!errText ? `<p class="tiny dim center mt-18">Conditions are verified server-side. TM Coins are a reward token, not withdrawable cash.</p>` : ''}`;

  root.querySelectorAll('[data-claim]').forEach((b) => b.addEventListener('click', async () => {
    const key = b.dataset.claim;
    setBusy(b, true, 'Claiming');
    try {
      const res = await rpc('claim_achievement', { p_key: key });
      showRewardBurst(`+${tg(res?.reward_tg)} TM Coins`, 'Achievement reward claimed!');
      toast('Reward credited to your TM Coin balance.', 'success');
      await renderAchievements(root);
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(b, false);
    }
  }));
}
