import { sb, rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import {
  state, loadContext, displayName, firstName, withdrawalMin,
  settingText, settingNumber, currentMode, switchMode
} from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, usdt, tg, ago, shortDate, dateTime, statusBadge, platformMeta, platformIcon,
  toast, openModal, confirmDialog, loadingBlock, skeletonCards, emptyState, errorPanel,
  uploadProofFile, signedProofUrl, safeHttpUrl, setBusy, pct, timeLeft, copyText,
  debounce, qs, qsa, initials, avatarHTML, openTelegramUrl
} from '../lib/ui.js?v=2025-10-12-39';
import { navigate, refreshRoute } from '../lib/router.js?v=2025-10-12-39';
import { showRewardBurst } from './rewards.js?v=2025-10-12-39';

const KIND_LABEL = {
  task_pending: 'Reward pending review',
  task_reward: 'Task reward released',
  task_refund: 'Pending reward reversed',
  escrow_release: 'Campaign escrow released',
  escrow_return: 'Campaign escrow returned',
  campaign_funding: 'Campaign funded',
  campaign_refund: 'Campaign escrow refunded',
  deposit: 'Deposit credited',
  withdrawal_hold: 'Withdrawal requested',
  withdrawal_paid: 'Withdrawal paid',
  withdrawal_refund: 'Withdrawal rejected — refunded',
  referral_bonus: 'Referral commission',
  admin_adjustment: 'Balance adjustment',
  smm_task_reward: 'SMM task reward',
  smm_order_charge: 'SMM order payment',
  smm_order_refund: 'SMM order refund'
};

const PLATFORM_FILTERS = [
  ['', 'All'], ['youtube', 'YouTube'], ['instagram', 'Instagram'], ['tiktok', 'TikTok'],
  ['x', 'X'], ['facebook', 'Facebook'], ['telegram', 'Telegram'], ['reddit', 'Reddit'], ['spotify', 'Spotify']
];

export function paintWallet() {
  document.querySelectorAll('[data-wallet-available]').forEach((el) => {
    el.innerHTML = `${usdt(state.wallet?.available)} <span>USDT</span>`;
  });
}

async function freshContext() {
  try {
    await loadContext();
    paintWallet();
  } catch (_) { /* page still shows cached values */ }
}

function kpi({ label, value, suffix = '', foot = '', iconName = 'chart', tone = '' }) {
  return `<div class="kpi ${tone}">
    <div class="kpi-top">
      <div class="kpi-label">${esc(label)}</div>
      <span class="kpi-ic">${icon(iconName, 16)}</span>
    </div>
    <div class="kpi-num">${value}${suffix ? `<small>${esc(suffix)}</small>` : ''}</div>
    ${foot ? `<div class="kpi-foot">${foot}</div>` : ''}
  </div>`;
}

function taskCard(t) {
  const m = platformMeta(t.platform);
  /* A real button, not an anchor: nothing can submit a form or reload the page.
     data-task-link drives the single delegated handler below. */
  return `<button type="button" class="task" data-task-link="${esc(t.id)}">
    <span class="task-ic" style="background:${m.bg};color:${m.color}">${platformIcon(t.platform, 20)}</span>
    <span class="task-main">
      <span class="task-title">${esc(t.title)}</span>
      <span class="task-meta">
        <span class="reward">${esc(usdt(t.reward))}<small>USDT</small></span>
        <span>${esc(m.label)}</span>
        <span>${Number(t.quantity_left || 0)} slots left</span>
      </span>
    </span>
    <span class="task-cta">
      ${t.account_cooldown_until && cooldownLabel(t.account_cooldown_until)
        ? `<span class="badge red">${icon('clock', 12)} ${esc(cooldownLabel(t.account_cooldown_until))}</span>`
        : t.requires_account && !t.account_linked
          ? `<span class="badge blue">${icon('link', 12)} Link ${esc(m.label)}</span>`
          : t.already_done
            ? statusBadge('approved', 'Taken')
            : `<span class="badge orange">Start ${icon('chevronRight', 12)}</span>`}
    </span>
  </button>`;
}

/* Debug switch: alert() steps are shown only when you opt in, so normal users
   never see them. Enable once in the console with:
       localStorage.setItem('tmgrowDebug', 'on')
   Disable with localStorage.removeItem('tmgrowDebug'). */
function debugStep(label) {
  /* Diagnostics go to the console only: never interrupt a worker with alerts. */
  try { console.debug('[tmgrow:start]', label); } catch (_) { /* ignore */ }
}

function openTaskById(id) {
  const clean = String(id || '').trim();
  if (!clean) {
    toast('This task has no id. Reload the page.', 'error');
    return;
  }
  toast('Opening task…', 'info', 1500);
  window.location.hash = '#/tasks/' + encodeURIComponent(clean);
  /* If the hash is still on the list shortly after, say so instead of failing
     silently, and force the router to re-evaluate once. */
  setTimeout(() => {
    const hash = String(window.location.hash || '');
    if (!hash.startsWith('#/tasks/')) {
      alert('Task navigation failed. Hash stayed at: ' + (hash || '(empty)') + '\nTask id: ' + clean);
      window.location.hash = '#/tasks/' + encodeURIComponent(id);
      refreshRoute();
    }
  }, 700);
}

function bindTaskLinks(scope) {
  if (!scope) return;
  scope.querySelectorAll('[data-task-link]').forEach((el) => {
    if (el.dataset.bound === '1') return;
    el.dataset.bound = '1';
    const start = (e) => {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      handleStartTask(el.dataset.taskLink);
    };
    el.addEventListener('click', start);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') start(e);
    });
  });
}

function handleStartTask(taskId) {
  debugStep('1. START clicked. Task id: ' + taskId);
  openTaskById(taskId);
  debugStep('2. Hash set to ' + window.location.hash);
}

function txAmount(entry) {
  const a = Number(entry.available_delta || 0);
  const p = Number(entry.pending_delta || 0);
  const r = Number(entry.reserved_delta || 0);
  const pick = a !== 0 ? a : p !== 0 ? p : r;
  const bucket = a !== 0 ? 'available' : p !== 0 ? 'pending' : 'reserved';
  const positive = pick >= 0;
  return `<span class="list-amount ${positive ? 'green' : 'red'}">${positive ? '+' : ''}${esc(usdt(pick))}<span class="tiny dim"> ${bucket}</span></span>`;
}

function cooldownLabel(until) {
  const ms = new Date(until).getTime() - Date.now();
  if (!Number.isFinite(ms) || ms <= 0) return '';
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  return d > 0 ? `${d}d ${h}h` : `${h}h`;
}

/* `accounts` is the raw result of my_social_accounts(): null means the check
   failed, so the banner stays hidden instead of nagging about unknown state. */
function needsLinkBanner(accounts) {
  if (!Array.isArray(accounts)) return false;
  return !accounts.some((a) => a && a.status === 'linked');
}

function linkBanner() {
  return `<a class="link-warning" href="#/accounts">
    <span class="lw-ic">${icon('link', 18)}</span>
    <span class="lw-text">
      <strong>Link your accounts to start earning</strong>
      <span>Some campaigns only accept workers with a verified social account. Link it, copy the code into your profile, and a verifier activates it.</span>
    </span>
    ${icon('chevronRight', 16)}
  </a>`;
}

function levelInfo(p, c, w) {
  const done = Number(c?.my_approved_tasks || 0);
  const earned = Number(w?.lifetime_earned || 0);
  const level = Math.max(1, Math.min(99, 1 + Math.floor(done / 25)));
  const tier = earned >= 50 ? 'Elite' : earned >= 10 ? 'Pro' : earned >= 2 ? 'Rising' : 'Newbie';
  const trust = Math.max(0, Math.min(1000, Number(p?.trust_score ?? 549)));
  const trustLabel = trust >= 850 ? 'Whitelist' : trust >= 550 ? 'Trusted' : trust >= 250 ? 'Established' : 'Newbie';
  const nextAt = trust >= 850 ? 1000 : trust >= 550 ? 850 : trust >= 250 ? 550 : 250;
  return { done, earned, level, tier, trust, trustLabel, nextAt, toNext: Math.max(0, nextAt - trust) };
}

/* ============================================================ DASHBOARD === */
export async function renderDashboard(root) {
  if (currentMode() === 'buyer') {
    navigate('/buyer', { replace: true });
    return;
  }
  root.innerHTML = `<div class="page-head"><div><span class="eyebrow">Earn</span><h2>Welcome back, ${esc(firstName())}</h2><p>Your balance, daily bonus and live tasks in one place.</p></div>
    <a class="btn btn-primary" href="#/tasks">${icon('tasks', 16)} Browse tasks</a></div>
    ${skeletonCards(3)}`;

  await freshContext();

  const [feed, claimed, ledger, checkin, payouts, accounts, submittedRes] = await Promise.all([
    rpc('list_available_tasks', { p_limit: 5, p_offset: 0 }).catch(() => ({ items: [] })),
    rpc('my_tasks', { p_status: 'claimed', p_limit: 5, p_offset: 0 }).catch(() => ({ items: [] })),
    sb.from('ledger_entries')
      .select('id,kind,available_delta,pending_delta,reserved_delta,note,created_at')
      .order('created_at', { ascending: false }).limit(6),
    rpc('checkin_status').catch(() => ({})),
    rpc('recent_payouts', { p_limit: 6 }).catch(() => []),
    rpc('my_social_accounts').catch(() => null),
    rpc('my_tasks', { p_status: 'submitted', p_limit: 1, p_offset: 0 }).catch(() => ({ total: 0 }))
  ]);

  const tasks = feed?.items || [];
  const active = (claimed?.items || [])[0];
  const entries = ledger.error ? [] : (ledger.data || []);
  const w = state.wallet || {};
  const c = state.counts || {};
  const p = state.profile || {};
  const info = levelInfo(p, c, w);
  const chk = checkin || {};
  const checked = !!chk.checked_in_today;
  const reward = Number(chk.reward_tg ?? settingNumber('daily_checkin_tg', 0.5));
  const list = Array.isArray(payouts) ? payouts : [];
  const submittedCount = Number(submittedRes?.total || 0);

  const levelPct = Math.min(100, Math.round((info.done % 25) / 25 * 100));
  root.innerHTML = `<div class="worker-dashboard">
    <header class="card card-pad worker-identity-card">
      <div class="row" style="gap:14px;min-width:0">
        ${avatarHTML(p, 'avatar-hero')}
        <div style="min-width:0;flex:1">
          <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
            <h2 class="truncate" style="font-size:21px;letter-spacing:-.4px">${esc(firstName())}</h2>
            ${p.username ? `<span class="badge grey" title="Username">@${esc(p.username)}</span>` : ''}
            <span class="badge orange">LV.${info.level}</span>
            <span class="badge outline">${esc(String(info.tier).toUpperCase())}</span>
            ${p.is_buyer ? '<span class="badge blue">Worker + Buyer</span>' : ''}
          </div>
          <div class="tiny dim mt-6">${esc(p.country_code || 'Country not set')} · ${lifetimeTierBadge(w.lifetime_earned, 'Rank tier — based on lifetime approved earnings')}</div>
        </div>
        <a class="icon-square" href="#/accounts" aria-label="Account settings" title="Account settings">${icon('settings', 18)}</a>
      </div>
      <div class="row-between tiny dim mt-14"><span class="row" style="gap:5px">${icon('shield', 13)} Trust score</span><span class="strong blue">${info.trust} / 1000 · ${esc(info.trustLabel)}</span></div>
    </header>

    <section class="stat-grid" aria-label="Your balances and progress">
      <div class="stat-box stat-actionable">
        <h3 class="c-green" data-count-to="${Number(w.available || 0)}" data-count-decimals="2">0.00</h3>
        <p>${icon('wallet', 12)} Available USDT</p>
        <div class="stat-actions">
          <a href="#/withdraw">${icon('arrowUpRight', 11)} Withdraw</a>
          <a href="#/history">${icon('book', 11)} History</a>
        </div>
      </div>
      <div class="stat-box stat-actionable">
        <h3 class="c-gold" data-count-to="${Number(w.tg_balance || 0)}" data-count-decimals="2">0</h3>
        <p>${icon('coin', 12)} TM Coin</p>
        <div class="stat-actions">
          <a href="#/achievements">Rewards</a>
          <a href="#/history">Activity</a>
        </div>
      </div>
      <div class="stat-box">
        <h3 class="c-green" data-count-to="${Number(w.lifetime_earned || 0)}" data-count-decimals="2">0.00</h3>
        <p>${icon('trending', 12)} Total Earned</p>
      </div>
      <div class="stat-box">
        <h3 class="c-orange" data-count-to="${info.done}" data-count-decimals="0">0</h3>
        <p>${icon('checkCircle', 12)} Completed Tasks</p>
      </div>
      <div class="stat-box">
        <h3 class="c-blue" data-count-to="${submittedCount}" data-count-decimals="0">0</h3>
        <p>${icon('clock', 12)} Pending Review</p>
      </div>
      <div class="stat-box">
        <h3 class="c-gold" data-count-to="${Number(chk.streak || 0)}" data-count-decimals="0">0</h3>
        <p>${icon('flame', 12)} Day Streak</p>
      </div>
    </section>

    ${list.length ? `<div class="payout-ticker" aria-label="Recent withdrawals"><div class="payout-track">${list.concat(list).map((x) => `<span>${icon('arrowUpRight', 12)}<b>${esc(x.name)}</b>&nbsp;withdrew&nbsp;<b>${esc(usdt(x.amount))} USDT</b></span>`).join('')}</div></div>` : ''}

    <div class="worker-work-grid">
      <div class="worker-main-column">
        ${active ? `<section class="worker-active-task">
          <div class="worker-section-heading"><div><span class="eyebrow">PICK UP WHERE YOU LEFT OFF</span><h3>Active task</h3></div><span class="badge orange">${icon('clock', 12)} In progress</span></div>
          <div class="worker-active-task-body">
            <span class="task-ic" style="background:${platformMeta(active.platform).bg};color:${platformMeta(active.platform).color}">${platformIcon(active.platform, 20)}</span>
            <div class="worker-active-task-copy"><strong class="truncate">${esc(active.title)}</strong><span>${esc(platformMeta(active.platform).label)} · ${esc(usdt(active.reward))} USDT · expires ${esc(active.expires_at ? dateTime(active.expires_at) : '—')}</span></div>
            <a class="btn btn-primary btn-sm" href="#/tasks/${encodeURIComponent(active.id)}">Continue</a>
          </div>
        </section>` : ''}

        <section class="worker-task-section">
          <div class="worker-section-heading"><div><span class="eyebrow">LIVE MARKETPLACE</span><h3>Latest opportunities</h3></div><a href="#/tasks">All tasks ${icon('arrowRight', 13)}</a></div>
          ${tasks.length ? `<div class="worker-task-list">${tasks.map(taskCard).join('')}</div>` : emptyState({
            iconName: 'tasks',
            title: 'No tasks available yet',
            text: 'New campaigns appear here as soon as a brand funds them. Check back shortly.',
            action: '<a class="btn btn-ghost" href="#/my-tasks">Review my tasks</a>'
          })}
        </section>

        <section class="worker-activity-panel">
          <div class="worker-section-heading"><div><span class="eyebrow">WALLET LEDGER</span><h3>Recent activity</h3></div><a href="#/history">Full history ${icon('arrowRight', 13)}</a></div>
          ${entries.length ? `<div class="list">${entries.map((e) => `
            <div class="list-row">
              <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${icon('coin', 15)}</span>
              <div class="list-main"><div class="list-title">${esc(KIND_LABEL[e.kind] || e.kind)}</div><div class="list-sub">${esc(ago(e.created_at))}</div></div>
              ${txAmount(e)}
            </div>`).join('')}</div>` : '<p class="small muted">No wallet activity yet. Approved rewards and other balance movements will appear here.</p>'}
        </section>
      </div>

      <aside class="worker-side-column">
        <section class="worker-checkin-card">
          <div class="worker-side-title"><span class="worker-side-icon">${icon('calendar', 17)}</span><div><span>DAILY REWARD</span><strong>Check in</strong></div></div>
          <div class="checkin-days" aria-label="7-day check-in progress">
            ${Array.from({ length: 7 }, (_, i) => {
              const streak = Math.max(0, Number(chk.streak || 0));
              const cyclePos = checked ? ((Math.max(1, streak) - 1) % 7) + 1 : (streak % 7) + 1;
              const claimedDay = i + 1 < cyclePos || (checked && i + 1 === cyclePos);
              const availableDay = !checked && i + 1 === cyclePos;
              return `<div class="checkin-day ${claimedDay ? 'claimed' : availableDay ? 'available' : 'locked'}"><span>D${i + 1}</span><i>${icon(claimedDay ? 'checkCircle' : availableDay ? 'gift' : 'lock', 13)}</i></div>`;
            }).join('')}
          </div>
          <div class="worker-checkin-reward">+${esc(tg(reward))}<small> TM</small></div>
          <p>${checked ? 'Claimed today. Come back tomorrow to continue your streak.' : 'Check in every day and collect TM Coins.'}</p>
          <div class="worker-checkin-meta"><span>${Number(chk.total_days || 0)} total days</span><span>${Number(chk.streak || 0)} day streak</span></div>
          <button class="btn ${checked ? 'btn-ghost' : 'btn-primary'} btn-block" type="button" data-claim-checkin ${checked ? 'disabled' : ''}>${icon(checked ? 'checkCircle' : 'gift', 15)} ${checked ? 'Claimed today' : 'Claim daily reward'}</button>
        </section>

        ${needsLinkBanner(accounts) ? linkBanner() : `<section class="worker-side-card">
          <div class="worker-side-title"><span class="worker-side-icon">${icon('link', 17)}</span><div><span>READY TO EARN</span><strong>Social accounts</strong></div></div>
          <p>Manage the public profiles you use for tasks. Some campaigns require a verified account.</p>
          <a class="btn btn-ghost btn-block" href="#/accounts">Manage linked accounts ${icon('arrowRight', 14)}</a>
        </section>`}

        <section class="worker-side-card worker-referral-card">
          <div class="worker-side-title"><span class="worker-side-icon">${icon('users', 17)}</span><div><span>INVITE & EARN</span><strong>Share TM GROW</strong></div></div>
          <p>${esc(String(state.referral?.rate || 10))}% commission on your invited workers’ approved tasks.</p>
          <div class="worker-referral-code"><span>${esc(state.referral?.code || '—')}</span><button type="button" data-copy-ref aria-label="Copy referral code">${icon('copy', 14)}</button></div>
          <a class="btn btn-invite btn-block" href="#/referrals">${icon('users', 14)} Invite friends</a>
        </section>

        <section class="worker-side-card">
          <div class="worker-side-title"><span class="worker-side-icon">${icon('book', 17)}</span><div><span>OFFICIAL GUIDE</span><strong>How earning works</strong></div></div>
          <p>Claim a task, complete the action, upload proof — and a human verifier releases your reward.</p>
          <button class="btn btn-ghost btn-block" type="button" data-open-guide>${icon('book', 14)} Open the official guide</button>
        </section>

        <section class="worker-side-card">
          <div class="worker-section-heading"><div><span class="eyebrow">COMMUNITY</span><h3>Recent payouts</h3></div></div>
          ${list.length ? `<div class="worker-payout-list">${list.slice(0, 4).map((x) => `<div><span class="worker-payout-avatar">${esc(initials(x.name))}</span><span class="worker-payout-name truncate">${esc(x.name)}</span><strong>${esc(usdt(x.amount))}<small> USDT</small></strong></div>`).join('')}</div>` : '<p class="small muted">No recent payouts to display.</p>'}
        </section>
      </aside>
    </div>
  </div>`;

  bindTaskLinks(root);
  animateCounters(root);

  const guideBtn = root.querySelector('[data-open-guide]');
  if (guideBtn) guideBtn.addEventListener('click', () => {
    const gm = openModal({
      title: 'Official guide',
      subtitle: 'How earning works on TM GROW',
      body: `<div class="step-list">
          <div class="step"><span class="sn">1</span><span>Link a social account and paste the verification code in your profile.</span></div>
          <div class="step"><span class="sn">2</span><span>Claim a task, complete it on your own account and upload a clear screenshot.</span></div>
          <div class="step"><span class="sn">3</span><span>Wait for the verifier. Approved rewards move to your available balance.</span></div>
          <div class="step"><span class="sn">4</span><span>Withdraw from ${esc(usdt(withdrawalMin()))} USDT on BEP-20. Approved tasks also earn TG Coin.</span></div>
        </div>
        <div class="alert info mt-14">${icon('shield', 17)}<div>Verification is manual and human. Never share a password or 2FA code with anyone.</div></div>`,
      footer: '<button class="btn btn-primary" type="button" data-guide-ok>Got it</button>'
    });
    gm.root.querySelector('[data-guide-ok]').onclick = () => gm.close();
  });

  const copy = root.querySelector('[data-copy-ref]');
  if (copy) copy.addEventListener('click', async () => {
    const ok = await copyText(state.referral?.code || '');
    toast(ok ? 'Referral code copied.' : 'Copy failed.', ok ? 'success' : 'error');
  });

  const claim = root.querySelector('[data-claim-checkin]');  if (claim) claim.addEventListener('click', async () => {
    setBusy(claim, true, 'Claiming');
    try {
      const res = await rpc('claim_daily_checkin');
      showRewardBurst(`+${tg(res?.reward_tg || reward)} TM Coins`, 'Daily Reward Claimed!');
      await freshContext();
      toast(`+${tg(res?.reward_tg || reward)} TG claimed. Streak ${Number(res?.streak || 0)}.`, 'success');
      await renderDashboard(root);
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(claim, false);
    }
  });
}

/* ================================================================ TASKS === */
export async function renderTasks(root) {
  let platform = '';
  let search = '';
  let highValue = false;
  let offset = 0;
  let total = 0;
  let loading = false;
  const highMin = settingNumber('high_value_min', 0.05);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Marketplace</span><h2>Available tasks</h2><p>Each task is funded by a campaign and paid after verification.</p></div>
      <div class="row-wrap" style="gap:8px">
        <a class="btn btn-ghost" href="#/my-tasks">${icon('checkCircle', 16)} My tasks</a>
        <a class="btn btn-ghost" href="#/withdraw">${icon('arrowUpRight', 16)} Withdraw</a>
      </div>
    </div>

    <div class="tabs" id="task-tier-tabs" style="margin-bottom:12px;max-width:420px">
      <button class="tab active" type="button" data-high="0">Quick tasks</button>
      <button class="tab" type="button" data-high="1">High value · ${esc(usdt(highMin))}+ USDT</button>
    </div>

    <div class="filter-bar">
      <div class="input-group">
        ${icon('search', 17)}
        <input class="input input-icon" id="task-search" placeholder="Search campaigns or platforms" autocomplete="off" />
      </div>
      <div class="chips" id="platform-chips">
        ${PLATFORM_FILTERS.map(([v, label]) => `<button class="chip ${v === '' ? 'active' : ''}" type="button" data-platform="${v}">${label}</button>`).join('')}
      </div>
    </div>

    <div id="link-warning-slot"></div>
    <div id="smm-slot"></div>
    <div id="task-feed">${skeletonCards(4)}</div>
    <div class="center mt-18"><button class="btn btn-ghost hide" id="load-more" type="button">Load more</button></div>`;

  const feedEl = root.querySelector('#task-feed');
  const moreBtn = root.querySelector('#load-more');

  const load = async (append = false) => {
    if (loading) return;
    loading = true;
    if (!append) feedEl.innerHTML = skeletonCards(4);
    else setBusy(moreBtn, true, 'Loading');
    try {
      const res = await rpc('list_available_tasks', {
        p_platform: platform || null,
        p_search: search || null,
        p_limit: 20,
        p_offset: offset,
        p_min_reward: highValue ? highMin : 0
      });
      const items = res?.items || [];
      total = Number(res?.total || 0);
      if (append) {
        feedEl.insertAdjacentHTML('beforeend', items.map(taskCard).join(''));
      } else {
        feedEl.innerHTML = items.length ? `<div class="task-list">${items.map(taskCard).join('')}</div>` : emptyState({
          iconName: 'search',
          title: 'No tasks match this filter',
          text: 'Try another platform, clear the search, or check back when new campaigns are funded.'
        });
      }
      offset += items.length;
      moreBtn.classList.toggle('hide', offset >= total || items.length === 0);
      bindTaskLinks(feedEl);
      if (total > 0) {
        root.querySelector('.page-head p').textContent =
          `${total} available task${total === 1 ? '' : 's'} · rewards paid after verification`;
      }
    } catch (e) {
      feedEl.innerHTML = errorPanel(friendlyError(e));
    } finally {
      loading = false;
      setBusy(moreBtn, false);
    }
  };

  /* SMM units are separate task rows with campaign_id NULL, so
     list_available_tasks() (an inner join on campaigns) can never return
     them. The Task Bag reads them from smm_worker_feed() and shows them above
     campaign tasks, with the same claim/start/submit runner. */
  const smmSlot = root.querySelector('#smm-slot');
  let smmItems = [];

  const paintSmm = () => {
    if (!smmSlot) return;
    const list = smmItems.filter((t) => !platform || t.platform === platform);
    if (!list.length) {
      smmSlot.innerHTML = '';
      return;
    }
    smmSlot.innerHTML = `<div class="sec-title" style="margin:0 0 10px">
        <h3 class="row" style="gap:6px">${icon('zap', 15)} SMM units <span class="badge orange">${list.length}</span></h3>
        <a href="#/smm-tasks">SMM task bag ${icon('chevronRight', 13)}</a>
      </div>
      <div class="col" style="gap:10px">${list.map(smmAvailableCard).join('')}</div>`;
    smmSlot.querySelectorAll('[data-smm-open]').forEach((b) => b.addEventListener('click', () => {
      openSmmTask(root, b.dataset.smmOpen, async () => {
        await loadSmm();
        await load(false);
      });
    }));
  };

  const loadSmm = async () => {
    try {
      const res = await rpc('smm_worker_feed', { p_limit: 20 });
      smmItems = res?.items || [];
    } catch (_) {
      smmItems = [];
    }
    paintSmm();
  };

  root.querySelector('#task-search').addEventListener('input', debounce((e) => {
    search = e.target.value.trim();
    offset = 0;
    load(false);
  }, 320));

  root.querySelector('#task-tier-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-high]');
    if (!b) return;
    highValue = b.dataset.high === '1';
    qsa(root, '#task-tier-tabs .tab').forEach((t) => t.classList.toggle('active', t === b));
    offset = 0;
    load(false);
  });

  root.querySelector('#platform-chips').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-platform]');
    if (!btn) return;
    qsa(root, '#platform-chips .chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    platform = btn.dataset.platform;
    offset = 0;
    paintSmm();
    load(false);
  });

  rpc('my_social_accounts').then((accounts) => {
    const slot = root.querySelector('#link-warning-slot');
    if (slot && slot.isConnected && needsLinkBanner(accounts)) slot.innerHTML = linkBanner();
  }).catch(() => { /* banner is optional */ });

  moreBtn.addEventListener('click', () => load(true));
  await loadSmm();
  await load(false);
}

/* ========================================================== TASK DETAIL === */
export async function renderTaskDetail(root, { params }) {
  root.innerHTML = loadingBlock('Loading task');

  const id = params.id;
  let data;
  try {
    data = await rpc('get_task', { p_task_id: id });
  } catch (err) {
    const raw = err?.raw?.message || err?.message || 'Unknown error';
    toast(`Could not open this task: ${raw}`, 'error', 9000);
    root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/tasks">${icon('arrowLeft', 15)} All tasks</a>
      <div class="mt-14">${errorPanel(`Could not open task ${esc(String(id || ''))}. ${raw}`)}</div>
      <div class="row mt-14"><button class="btn btn-ghost" type="button" data-retry-task>${icon('refresh', 14)} Retry</button></div>`;
    const retry = root.querySelector('[data-retry-task]');
    if (retry) retry.addEventListener('click', () => renderTaskDetail(root, { params }));
    return;
  }

  if (!data || !data.task) {
    toast('This task could not be read from the database. It may have been removed.', 'error', 8000);
    root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/tasks">${icon('arrowLeft', 15)} All tasks</a>
      <div class="mt-14">${errorPanel('The task response was empty. Reload the task list and try another task.')}</div>`;
    return;
  }

  const t = data.task;
  const c = data.campaign;
  const s = data.service;
  const mine = t.worker_id && state.profile && t.worker_id === state.profile.id;
  const m = platformMeta(s.platform);
  const target = safeHttpUrl(c.target_url);
  const sub = data.submission;

  /* SMM drip tasks have no campaign. Open their own runner instead of a
     campaign page with empty fields. */
  if (t.smm_order_id) {
    root.innerHTML = loadingBlock('Opening SMM task');
    await openSmmTask(root, t.id);
    return;
  }

  let actionHtml = '';
  if (t.status === 'available') {
    if (data.account_cooldown_until && cooldownLabel(data.account_cooldown_until)) {
      actionHtml = `<div class="alert warn">${icon('clock', 17)}<div><strong>X account warm-up.</strong> This account linked recently, so X tasks unlock in <strong>${esc(cooldownLabel(data.account_cooldown_until))}</strong>.</div></div>`;
    } else if (data.requires_account && !data.account_linked) {
      actionHtml = `<div class="alert warn">${icon('link', 17)}<div>This campaign only accepts workers with a <strong>verified ${esc(m.label)}</strong> account.</div></div>
        <a class="btn btn-primary btn-lg btn-block mt-10" href="#/accounts">${icon('link', 17)} Link your account</a>
        <p class="hint center mt-6">Verification is done by a human after you paste the code in your profile.</p>`;
    } else {
      actionHtml = `<button class="btn btn-primary btn-lg btn-block" type="button" data-claim>${icon('check', 17)} Start this task</button>
      <p class="hint center mt-6">You will have ${esc(settingNumber('claim_window_minutes', 30))} minutes to complete and submit proof.</p>`;
    }
  } else if (t.status === 'claimed' && mine) {
    actionHtml = `<div class="alert warn">${icon('clock', 17)}<div>Claim active — submit before <strong data-countdown>${esc(t.expires_at ? timeLeft(t.expires_at).text : '—')}</strong>.</div></div>`;
  } else if (t.status === 'submitted') {
    actionHtml = `<div class="alert info">${icon('clock', 17)}<div>Proof submitted. A verifier is reviewing it now.</div></div>`;
  } else if (t.status === 'approved') {
    actionHtml = `<div class="alert success">${icon('checkCircle', 17)}<div>Approved. ${esc(usdt(t.reward))} USDT was released to your available balance.</div></div>`;
  } else if (t.status === 'rejected') {
    actionHtml = `<div class="alert error">${icon('xCircle', 17)}<div><strong>Proof rejected.</strong><br>${esc(sub?.review_note || 'The proof did not meet the requirements.')}</div></div>`;
  } else if (t.status === 'expired') {
    actionHtml = `<div class="alert warn">${icon('clock', 17)}<div>This claim expired. Claim an available task again.</div></div>`;
  }

  root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/tasks">${icon('arrowLeft', 15)} All tasks</a>
    <div class="detail-grid mt-14">
      <div class="col" style="gap:14px">
        <div class="card card-pad">
          <div class="row" style="gap:12px;align-items:flex-start">
            <span class="task-ic" style="background:${m.bg};color:${m.color};width:46px;height:46px">${platformIcon(s.platform, 22)}</span>
            <div style="flex:1;min-width:0">
              <div class="row" style="gap:8px;flex-wrap:wrap">
                <span class="badge" style="color:${m.color};background:${m.bg}">${esc(m.label)}</span>
                ${statusBadge(t.status)}
              </div>
              <h2 style="font-size:20px;margin-top:9px">${esc(c.title)}</h2>
              <p class="small muted mt-6">${esc(s.name)} · Campaign ${esc(String(c.id).slice(0, 8))}</p>
            </div>
          </div>

          <hr class="divider" />
          <h3 style="font-size:13px" class="mb-10">Task instructions</h3>
          <div class="panel panel-pad" style="white-space:pre-wrap;font-size:13.5px;line-height:1.7;color:var(--muted)">${esc(c.instructions)}</div>

          <h3 style="font-size:13px" class="mb-10 mt-18">Target</h3>
          ${target
            ? `<div class="row-wrap">
                 <a class="btn btn-soft" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 16)} Open target link</a>
                 <button class="btn btn-ghost btn-sm" type="button" data-copy-target>${icon('copy', 14)} Copy link</button>
               </div>
               <div class="mono-box mt-10">${esc(target)}</div>`
            : `<div class="alert error">${icon('alert', 17)}<div>This campaign target link is invalid. Contact support.</div></div>`}

          <div class="alert info mt-18">${icon('shield', 17)}<div><strong>Never share passwords.</strong> TM GROW only needs the public action and a screenshot. We never ask for 2FA codes or account access.</div></div>
        </div>

        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">How this is verified</h3>
          <div class="step-list">
            <div class="step"><span class="sn">1</span><span>Open the link and complete exactly what the instructions ask on your own account.</span></div>
            <div class="step"><span class="sn">2</span><span>Take a screenshot that clearly shows your account and the completed action.</span></div>
            <div class="step"><span class="sn">3</span><span>Upload it here. A human verifier approves or rejects it with a reason.</span></div>
            <div class="step"><span class="sn">4</span><span>Approved rewards move from pending to available USDT. Request a payout from your wallet.</span></div>
          </div>
        </div>
      </div>

      <aside class="col detail-aside" style="gap:14px;position:sticky;top:80px">
        <div class="card card-pad">
          <div class="kpi-label">Reward</div>
          <div class="row" style="gap:8px;align-items:baseline;margin-top:4px">
            <span style="font-size:30px;font-weight:800;letter-spacing:-1px">${esc(usdt(t.reward))}</span>
            <span class="small muted">USDT</span>
          </div>
          <div class="small gold-text mt-6">+ TG Coin bonus on approval</div>
          <div class="divider"></div>
          <div class="row-between small"><span class="muted">Campaign target</span><span>${Number(c.quantity)} tasks</span></div>
          <div class="row-between small mt-6"><span class="muted">Approved so far</span><span>${Number(c.approved_count)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Your trust score</span><span>${Number(data.worker_trust)}/1000</span></div>
          <div class="mt-14">${actionHtml}</div>
        </div>

        ${(t.status === 'claimed' && mine) ? `
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Complete this task</h3>
          <p class="small muted">Open the target link, do exactly what the instructions ask, then submit up to 6 screenshots and an optional proof link.</p>
          <button class="btn btn-primary btn-block mt-14" type="button" data-start-task>${icon('arrowUpRight', 16)} Start task</button>
          <p class="hint mt-8">The timer length is chosen automatically from the platform and action, then enforced by the server. Submit unlocks when it ends and at least one screenshot is attached.</p>
        </div>` : ''}

        ${sub && (sub.status === 'pending' || sub.status === 'approved') ? `
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Your submission</h3>
          ${statusBadge(sub.status)}
          <p class="small muted mt-10">${esc(sub.note || 'No note added.')}</p>
          <p class="tiny dim mt-6">${Number(sub.proof_paths?.length || 1)} screenshot${Number(sub.proof_paths?.length || 1) === 1 ? '' : 's'}${sub.proof_link ? ' · proof link attached' : ''} · submitted ${esc(dateTime(sub.created_at))}</p>
          ${safeHttpUrl(sub.proof_link) ? `<a class="btn btn-ghost btn-sm mt-10" href="${esc(safeHttpUrl(sub.proof_link))}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Open proof link</a>` : ''}
        </div>` : ''}

        ${(t.status === 'approved' || t.status === 'rejected') ? `
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Review result</h3>
          ${statusBadge(t.status)}
          ${sub?.review_note ? `<p class="small muted mt-10">${esc(sub.review_note)}</p>` : ''}
          <p class="tiny dim mt-6">Reviewed ${esc(dateTime(t.reviewed_at || sub?.reviewed_at))}</p>
        </div>` : ''}
      </aside>
    </div>`;

  const claimBtn = root.querySelector('[data-claim]');
  if (claimBtn) {
    claimBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      debugStep('1. Claim button clicked for ' + id);
      setBusy(claimBtn, true, 'Starting…');
      try {
        const claimed = await rpc('claim_task', { p_task_id: id });
        debugStep('2. claim_task succeeded: ' + JSON.stringify(claimed).slice(0, 200));
        toast('Task claimed. Complete it before the timer ends.', 'success');
        window.location.hash = '#/tasks/' + encodeURIComponent(id);
        await freshContext();
        await renderTaskDetail(root, { params });
        const start = root.querySelector('[data-start-task]');
        if (start) start.click();
        else toast('Task claimed, but the task window could not open. Reload this page.', 'error', 7000);
      } catch (err) {
        const raw = err?.raw?.message || err?.message || 'Unknown error';
        console.error('[tmgrow:claim]', err);
        alert('claim_task failed: ' + raw);
        toast(`Could not claim this task: ${raw}`, 'error', 9000);
        setBusy(claimBtn, false, 'Start this task');
      }
    });
  }

  const copyTarget = root.querySelector('[data-copy-target]');
  if (copyTarget) copyTarget.addEventListener('click', async () => {
    const ok = await copyText(target);
    toast(ok ? 'Link copied.' : 'Copy failed — select the link manually.', ok ? 'success' : 'error');
  });

  const countdownEl = root.querySelector('[data-countdown]');
  if (countdownEl && t.expires_at) {
    const timer = setInterval(() => {
      if (!countdownEl.isConnected) { clearInterval(timer); return; }
      const tl = timeLeft(t.expires_at);
      countdownEl.textContent = tl.text;
      if (tl.expired) clearInterval(timer);
    }, 1000);
  }

  const startBtn = root.querySelector('[data-start-task]');
  if (startBtn) startBtn.addEventListener('click', openRunner);

  async function openRunner() {
    if (t.status !== 'claimed' || !mine) {
      toast('Claim this task first to open the task window.', 'error');
      return;
    }
    if (!target) {
      toast('This campaign target link is invalid. Contact support.', 'error');
      return;
    }

    /* The server decides the duration from platform + action and stores it on
       the task. The same deadline is used for the whole window, so it cannot
       change midway. */
    let started = null;
    try {
      started = await rpc('start_task', { p_task_id: id });
    } catch (err) {
      toast(friendlyError(err), 'error', 7000);
      return;
    }

    const seconds = Math.max(5, Number(started?.required_seconds || 30));
    let endsAt = started?.timer_ends_at
      ? new Date(started.timer_ends_at).getTime()
      : Date.now() + seconds * 1000;
    const startedAtMs = started?.timer_started_at
      ? new Date(started.timer_started_at).getTime()
      : Date.now();
    const clock = (s) => `${String(Math.floor(Math.max(0, s) / 60)).padStart(2, '0')}:${String(Math.max(0, s) % 60).padStart(2, '0')}`;
    const ruleLabel = String(started?.rule || 'default').replace(':', ' · ');

    const files = [];
    const urls = [];
    let ticker = null;

    const m = openModal({
      title: c.title,
      subtitle: `Task #${String(t.id).slice(0, 8)} · ${esc(usdt(t.reward))} USDT`,
      body: `<div class="runner-top">
          <div class="runner-timer" data-timer-box>
            <span>Time left</span>
            <b data-timer>${String(seconds).padStart(2, '0')}s</b>
          </div>
          <a class="runner-open" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 15)} Open task</a>
        </div>
        <div class="tiny dim center mt-6">Automatic timer · ${seconds}s · ${esc(ruleLabel)}</div>

        <div class="runner-links">
          ${['Watch', 'Like', 'Subscribe'].map((label) => `<div class="runner-link-row">
            <span class="runner-link-label">${label}</span>
            <button class="runner-copy" type="button" data-copy-runner aria-label="Copy ${label} link">${icon('copy', 15)}</button>
          </div>`).join('')}
        </div>

        <div class="field mt-14">
          <label class="label" for="exec-link">Proof link</label>
          <input class="input" id="exec-link" type="url" placeholder="https://..." />
        </div>

        <label class="dropzone mt-14" id="exec-drop" for="exec-files">
          ${icon('upload', 24)}
          <div class="dz-title" id="exec-dz-title">Click to select screenshot 0/6</div>
          <div class="dz-sub">JPG, PNG or WebP · max 6 images, 5 MB each</div>
        </label>
        <input id="exec-files" type="file" accept="image/png,image/jpeg,image/webp" multiple class="hide" />
        <div class="proof-grid mt-10" id="exec-previews"></div>

        <details class="mt-14">
          <summary class="tiny dim" style="cursor:pointer">Campaign instructions</summary>
          <div class="small muted mt-6" style="white-space:pre-wrap;line-height:1.65">${esc(c.instructions)}</div>
        </details>

        <div class="field mt-14">
          <label class="label" for="exec-note">Note for the verifier <span class="hint">(optional)</span></label>
          <textarea class="textarea" id="exec-note" maxlength="500" placeholder="Your username on the platform, anything the verifier should know…"></textarea>
        </div>`,
      footer: `<div class="runner-footer">
        <button class="btn btn-ghost runner-giveup" type="button" data-give-up>Give up this task</button>
        <button class="btn runner-submit is-waiting" type="button" data-submit-proof disabled>Please wait ${String(seconds).padStart(2, '0')}s</button>
      </div>`,
      onClose: () => {
        if (ticker) clearInterval(ticker);
        urls.forEach((u) => URL.revokeObjectURL(u));
      }
    });

    const timerEl = m.root.querySelector('[data-timer]');
    const timerBox = m.root.querySelector('[data-timer-box]');
    const submitBtn = m.root.querySelector('[data-submit-proof]');
    const previews = m.root.querySelector('#exec-previews');
    const input = m.root.querySelector('#exec-files');
    const drop = m.root.querySelector('#exec-drop');
    const dzTitle = m.root.querySelector('#exec-dz-title');

    const syncSubmit = () => {
      const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
      const ready = left === 0 && files.length > 0;
      submitBtn.disabled = !ready;
      submitBtn.classList.toggle('is-waiting', !ready);
      submitBtn.classList.toggle('is-ready', ready);
      if (left > 0) {
        submitBtn.textContent = `Please wait ${clock(left)}`;
      } else {
        submitBtn.textContent = files.length > 0 ? 'Submit proof' : 'Add a screenshot';
      }
      if (timerEl) timerEl.textContent = clock(left);
      if (dzTitle) dzTitle.textContent = `Click to select screenshot ${files.length}/6`;
    };

    ticker = setInterval(() => {
      const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
      if (timerEl) timerEl.textContent = clock(left);
      if (left === 0) {
        clearInterval(ticker);
        ticker = null;
        timerBox?.classList.add('done');
      }
      syncSubmit();
    }, 250);

    m.root.querySelectorAll('[data-copy-runner]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await copyText(target);
      toast(ok ? 'Copied!' : 'Copy failed — select the link manually.', ok ? 'success' : 'error');
    }));

    const renderPreviews = () => {
      urls.forEach((u) => URL.revokeObjectURL(u));
      urls.length = 0;
      previews.innerHTML = files.map((f, i) => {
        const u = URL.createObjectURL(f);
        urls.push(u);
        return `<div class="proof-preview"><img src="${u}" alt="Screenshot ${i + 1}" /><button class="pp-remove" type="button" data-remove="${i}" aria-label="Remove">${icon('x', 14)}</button></div>`;
      }).join('');
      previews.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', () => {
        files.splice(Number(b.dataset.remove), 1);
        renderPreviews();
        syncSubmit();
      }));
    };

    const addFiles = (list) => {
      Array.from(list || []).forEach((f) => {
        if (files.length >= 6) { toast('Up to 6 screenshots per task.', 'error'); return; }
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { toast('Use JPG, PNG or WebP screenshots.', 'error'); return; }
        if (f.size > 5 * 1024 * 1024) { toast('Each screenshot must be under 5 MB.', 'error'); return; }
        files.push(f);
      });
      renderPreviews();
      syncSubmit();
    };

    input.addEventListener('change', () => { addFiles(input.files); input.value = ''; });
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('drag'); }));
    drop.addEventListener('drop', (e) => addFiles(e.dataTransfer?.files));

    m.root.querySelector('[data-give-up]').addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Give up this task?',
        message: 'The claim is released and the task returns to the marketplace straight away. Nothing is submitted.',
        confirmLabel: 'Give up',
        danger: true
      });
      if (!ok) return;
      setBusy(m.root.querySelector('[data-give-up]'), true, 'Releasing');
      try {
        await rpc('release_task', { p_task_id: id });
        m.close();
        toast('Claim released.', 'success');
        await freshContext();
        await renderTaskDetail(root, { params });
      } catch (e) {
        toast(friendlyError(e), 'error', 6000);
        setBusy(m.root.querySelector('[data-give-up]'), false);
      }
    });

    submitBtn.addEventListener('click', async () => {
      if (submitBtn.disabled) return;
      setBusy(submitBtn, true, 'Uploading');
      try {
        const paths = [];
        let firstHash = null;
        for (const f of files) {
          const { path, hash } = await uploadProofFile(f, state.profile.id);
          paths.push(path);
          if (!firstHash && hash) firstHash = hash;
        }
        await rpc('submit_proof', {
          p_task_id: id,
          p_proof_paths: paths,
          p_proof_link: (m.root.querySelector('#exec-link')?.value || '').trim() || null,
          p_note: (m.root.querySelector('#exec-note')?.value || '').trim() || null,
          p_proof_hash: firstHash,
          p_time_spent: Math.max(0, Math.min(86400, Math.ceil((Date.now() - startedAtMs) / 1000)))
        });
        toast('Proof submitted. The reward is pending verification.', 'success');
        m.close();
        await freshContext();
        await renderTaskDetail(root, { params });
      } catch (e) {
        const raw = String((e && e.message) || '');
        if (/TIMER_NOT_FINISHED/i.test(raw)) {
          try {
            const fresh = await rpc('get_task', { p_task_id: id });
            const end = fresh?.task?.timer_ends_at;
            if (end) endsAt = new Date(end).getTime();
          } catch (_) { /* keep the local deadline */ }
          toast('The server timer has not finished yet. It is now synced to the real deadline.', 'error', 8000);
          syncSubmit();
        } else {
          toast(friendlyError(e), 'error', 7000);
        }
        setBusy(submitBtn, false);
      }
    });

    syncSubmit();
  }

}

/* =============================================================== WALLET === */
export async function renderWallet(root) {
  root.innerHTML = loadingBlock('Loading wallet');
  await freshContext();

  const [ledgerRes, wdRes] = await Promise.all([
    sb.from('ledger_entries')
      .select('id,kind,available_delta,pending_delta,reserved_delta,available_after,note,ref_type,created_at')
      .order('created_at', { ascending: false }).limit(60),
    sb.from('withdrawals')
      .select('id,amount,network,address,status,tx_hash,admin_note,created_at,processed_at')
      .order('created_at', { ascending: false }).limit(20)
  ]);

  const entries = ledgerRes.error ? [] : (ledgerRes.data || []);
  const withdrawals = wdRes.error ? [] : (wdRes.data || []);
  const w = state.wallet || {};
  const min = withdrawalMin();

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Earnings</span><h2>Wallet</h2><p>USDT balances, withdrawal requests and the immutable ledger.</p></div>
      <a class="btn btn-primary" href="#/tasks">${icon('tasks', 16)} Earn more</a>
    </div>

    <div class="kpis">
      ${kpi({ label: 'Available', value: esc(usdt(w.available)), suffix: 'USDT', iconName: 'wallet', tone: 'green', foot: 'Withdrawable now' })}
      ${kpi({ label: 'Pending', value: esc(usdt(w.pending)), suffix: 'USDT', iconName: 'clock', tone: 'gold', foot: 'Awaiting verification' })}
      ${kpi({ label: 'Held', value: esc(usdt(w.reserved)), suffix: 'USDT', iconName: 'lock', tone: 'blue', foot: 'Withdrawals or escrow' })}
      ${kpi({ label: 'Lifetime', value: esc(usdt(w.lifetime_earned)), suffix: 'USDT', iconName: 'trending', tone: 'violet', foot: 'Approved rewards' })}
    </div>

    <div class="grid grid-2 mt-24" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>Request withdrawal</h3><span class="badge gold">BEP-20</span></div>
        <div class="card-body">
          <div class="alert info mb-16">${icon('info', 17)}<div>Minimum ${esc(usdt(min))} USDT. Enter your own BEP-20 address. Payouts are manual and the real transaction hash is recorded when finance sends it.</div></div>
          <form id="wd-form" class="col" style="gap:13px">
            <div class="field">
              <label class="label" for="wd-amount">Amount (USDT)</label>
              <div class="row" style="gap:8px">
                <input class="input" id="wd-amount" name="amount" type="number" min="${esc(min)}" step="0.000001" max="${esc(Number(w.available || 0))}" placeholder="${esc(usdt(min))}" required />
                <button class="btn btn-ghost btn-sm" type="button" data-max>Max</button>
              </div>
            </div>
            <div class="field">
              <label class="label" for="wd-address">BEP-20 address</label>
              <input class="input mono" id="wd-address" name="address" placeholder="0x…" pattern="^0x[a-fA-F0-9]{40}$" required />
              <span class="hint">Double-check the network and address. Blockchain transfers cannot be reversed.</span>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Request withdrawal</button>
          </form>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>Withdrawal requests</h3><span class="badge grey">${withdrawals.length}</span></div>
        <div class="card-body">
          ${withdrawals.length ? `<div class="list">${withdrawals.map((x) => `
            <div class="list-row" style="align-items:flex-start">
              <div class="list-main">
                <div class="list-title">${esc(usdt(x.amount))} USDT ${statusBadge(x.status)}</div>
                <div class="list-sub mono truncate">${esc(x.address)}</div>
                <div class="tiny dim mt-6">Requested ${esc(ago(x.created_at))}${x.processed_at ? ` · processed ${esc(ago(x.processed_at))}` : ''}</div>
                ${x.admin_note ? `<div class="tiny red mt-6">${esc(x.admin_note)}</div>` : ''}
                ${x.tx_hash ? `<a class="tiny blue mono truncate mt-6" style="display:block" href="https://bscscan.com/tx/${esc(x.tx_hash)}" target="_blank" rel="noopener noreferrer">${esc(x.tx_hash)}</a>` : ''}
              </div>
              <span class="small muted">${x.tx_hash ? 'Paid' : '—'}</span>
            </div>`).join('')}</div>` : `<p class="small muted">No withdrawal requests yet.</p>`}
        </div>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Transaction history</h3><span class="badge grey">${entries.length} entries</span></div>
      <div class="card-body">
        ${entries.length ? `<div class="list">${entries.map((e) => `
          <div class="list-row">
            <span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('coin', 15)}</span>
            <div class="list-main">
              <div class="list-title">${esc(KIND_LABEL[e.kind] || e.kind)}</div>
              <div class="list-sub">${e.note ? esc(e.note) + ' · ' : ''}${esc(ago(e.created_at))}</div>
            </div>
            ${txAmount(e)}
          </div>`).join('')}</div>` : emptyState({ iconName: 'coin', title: 'No transactions yet', text: 'Complete a task and approved rewards will appear here.' })}
      </div>
    </div>`;

  const form = root.querySelector('#wd-form');
  const amountEl = root.querySelector('#wd-amount');
  root.querySelector('[data-max]').addEventListener('click', () => {
    amountEl.value = Number(state.wallet?.available || 0).toFixed(6);
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type=submit]');
    const amount = Number(amountEl.value);
    const address = root.querySelector('#wd-address').value.trim();
    if (!Number.isFinite(amount) || amount < min) return toast(`Minimum withdrawal is ${usdt(min)} USDT.`, 'error');
    if (amount > Number(w.available || 0)) return toast('Amount exceeds your available balance.', 'error');
    if (!/^0x[a-fA-F0-9]{40}$/.test(address)) return toast('Enter a valid BEP-20 address.', 'error');

    setBusy(btn, true, 'Requesting');
    try {
      await rpc('request_withdrawal', { p_amount: amount, p_address: address });
      toast('Withdrawal requested. Funds are held until finance processes it.', 'success');
      await freshContext();
      await renderWallet(root);
    } catch (err) {
      toast(friendlyError(err), 'error', 7000);
      setBusy(btn, false);
    }
  });
}

/* ========================================================== LEADERBOARD === */
export async function renderLeaderboard(root) {
  root.innerHTML = loadingBlock('Loading leaderboard');
  let rows = [];
  try { rows = await rpc('leaderboard_weekly', { p_limit: 50 }) || []; } catch (_) { rows = []; }

  const top = rows.slice(0, 3);
  const rest = rows.slice(3);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Weekly</span><h2>Top earners</h2><p>Ranked by approved task rewards since Monday 00:00 UTC. Resets every week.</p></div>
    </div>

    ${rows.length === 0 ? emptyState({ iconName: 'trophy', title: 'No approved rewards this week yet', text: 'The leaderboard fills as soon as proofs are approved. Be the first.' }) : `
      <div class="grid grid-3" style="align-items:end">
        ${top.map((r, i) => `
          <div class="card card-pad" style="${i === 0 ? 'border-color:rgba(245,196,81,.4)' : ''};${r.is_me ? 'box-shadow:0 0 0 1px rgba(255,122,24,.35)' : ''}">
            <div class="row-between mb-10">
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <span class="badge ${i === 0 ? 'gold' : i === 1 ? 'grey' : 'orange'}">#${i + 1}</span>
                ${rankTierBadge(r.earned, 'Weekly tier — based on approved rewards this week')}
              </div>
              ${r.is_me ? '<span class="badge orange">You</span>' : ''}
            </div>
            <div class="row" style="gap:10px">
              <span class="avatar">${r.avatar_url ? `<img src="${esc(r.avatar_url)}" alt="" />` : esc(initials(r.name))}</span>
              <div style="min-width:0">
                <div class="strong truncate">${esc(r.name)}</div>
                <div class="tiny dim">${esc(r.country_code || '—')} · ${Number(r.tasks || 0)} tasks</div>
              </div>
            </div>
            <div class="mt-14"><span style="font-size:22px;font-weight:800;letter-spacing:-.6px">${esc(usdt(r.earned))}</span><span class="small muted"> USDT</span></div>
          </div>`).join('')}
      </div>

      ${rest.length ? `<div class="card mt-18">
        <div class="card-head"><h3>Full ranking</h3><span class="badge grey">${rows.length}</span></div>
        <div class="table-wrap" style="border:0">
          <table class="table">
            <thead><tr><th>#</th><th>Worker</th><th>Country</th><th class="num">Tasks</th><th class="num">Earned</th></tr></thead>
            <tbody>
              ${rest.map((r, i) => `<tr>
                <td class="dim">#${i + 4}</td>
                <td><div class="row" style="gap:8px"><span class="avatar xs">${r.avatar_url ? `<img src="${esc(r.avatar_url)}" alt="" />` : esc(initials(r.name))}</span><span>${esc(r.name)}</span>${r.is_me ? '<span class="badge orange">You</span>' : ''}${rankTierBadge(r.earned, 'Weekly tier')}</div></td>
                <td class="muted">${esc(r.country_code || '—')}</td>
                <td class="num">${Number(r.tasks || 0)}</td>
                <td class="num gold-text">${esc(usdt(r.earned))}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>` : ''}
    `}`;
}

/* ============================================================ REFERRALS === */
export async function renderReferrals(root) {
  await freshContext();
  const ref = state.referral || {};
  let rows = [];
  try {
    const { data } = await sb.from('referrals')
      .select('id,rate,created_at,referred_id')
      .order('created_at', { ascending: false }).limit(50);
    rows = data || [];
  } catch (_) { rows = []; }

  const link = `${window.location.origin}/?ref=${encodeURIComponent(ref.code || '')}#/login`;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Invite</span><h2>Referral programme</h2><p>Share your code. Earn ${esc(String(ref.rate || 10))}% of the task rewards your invitees are approved for.</p></div>
    </div>

    <div class="grid grid-2" style="align-items:start">
      <div class="card card-pad">
        <div class="kpi-label">Your referral code</div>
        <div class="row mt-10" style="gap:8px">
          <div class="mono-box" style="flex:1;font-size:16px;letter-spacing:2px">${esc(ref.code || '—')}</div>
          <button class="btn btn-soft" type="button" data-copy-code>${icon('copy', 15)}</button>
        </div>
        <div class="field mt-14">
          <label class="label">Invite link</label>
          <input class="input mono input-sm" readonly value="${esc(link)}" data-link />
        </div>
        <div class="row mt-14">
          <button class="btn btn-primary" type="button" data-share>${icon('send', 16)} Share invite</button>
          <button class="btn btn-ghost" type="button" data-copy-link>${icon('link', 16)} Copy link</button>
        </div>
        <div class="alert info mt-18">${icon('info', 17)}<div>Commission is credited to your available balance when an invited worker's proof is approved. It is paid by the platform, not deducted from the worker.</div></div>
      </div>

      <div class="kpis" style="grid-template-columns:1fr 1fr">
        ${kpi({ label: 'Invited workers', value: Number(ref.count || 0), iconName: 'users', tone: 'blue' })}
        ${kpi({ label: 'Commission earned', value: esc(usdt(ref.earned)), suffix: 'USDT', iconName: 'coin', tone: 'gold' })}
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Referral activity</h3><span class="badge grey">${rows.length}</span></div>
      <div class="card-body">
        ${rows.length ? `<div class="list">${rows.map((r) => `
          <div class="list-row">
            <span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('user', 15)}</span>
            <div class="list-main">
              <div class="list-title">Worker ${esc(String(r.referred_id).slice(0, 8))}…</div>
              <div class="list-sub">Joined ${esc(shortDate(r.created_at))} · commission ${esc(String(r.rate))}%</div>
            </div>
            <span class="badge green">Linked</span>
          </div>`).join('')}</div>` : `<p class="small muted">No referrals yet. Share your link on a platform where real people can join.</p>`}
      </div>
    </div>`;

  const copy = async (text, ok) => {
    const done = await copyText(text);
    toast(done ? ok : 'Copy failed.', done ? 'success' : 'error');
  };
  root.querySelector('[data-copy-code]').addEventListener('click', () => copy(ref.code || '', 'Referral code copied.'));
  root.querySelector('[data-copy-link]').addEventListener('click', () => copy(link, 'Invite link copied.'));
  root.querySelector('[data-share]').addEventListener('click', async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join TM GROW',
          text: `Use my code ${ref.code} to join TM GROW and earn USDT for social micro tasks.`,
          url: link
        });
        return;
      } catch (_) { /* user cancelled */ }
    }
    copy(link, 'Invite link copied — share it anywhere.');
  });
}

/* ============================================================== PROFILE === */
export async function renderProfile(root) {
  await freshContext();
  let countries = [];
  try {
    const { data } = await sb.from('countries').select('code,name').eq('active', true).order('name');
    countries = data || [];
  } catch (_) { countries = []; }

  const p = state.profile || {};
  const w = state.wallet || {};
  const viaTelegram = /@telegram\.tmgrow\.app$/i.test(p.email || '');
  const trust = Math.max(0, Math.min(1000, Number(p.trust_score ?? 549)));
  const trustLabel = trust >= 850 ? 'Whitelist' : trust >= 550 ? 'Trusted' : trust >= 250 ? 'Established' : 'Newbie';
  const trustNext = trust >= 850 ? 1000 : trust >= 550 ? 850 : trust >= 250 ? 550 : 250;
  const trustToNext = Math.max(0, trustNext - trust);
  const info = levelInfo(p, state.counts || {}, w);
  const levelPct = Math.min(100, Math.round((info.done % 25) / 25 * 100));

  const [ledgerRes, checkin, social, tgStatus] = await Promise.all([
    sb.from('ledger_entries')
      .select('id,kind,available_delta,pending_delta,reserved_delta,created_at')
      .order('created_at', { ascending: false }).limit(8),
    rpc('checkin_status').catch(() => ({})),
    rpc('my_social_accounts').catch(() => []),
    rpc('my_telegram_status').catch(() => null)
  ]);
  const entries = ledgerRes.error ? [] : (ledgerRes.data || []);
  const chk = checkin || {};
  const linkedCount = Array.isArray(social) ? social.length : 0;
  const tgState = tgStatus || {};
  const tgSummary = !tgStatus
    ? 'Checking…'
    : !tgState.linked
      ? 'Open TM GROW from the bot to link'
      : tgState.enabled === false
        ? 'Off — tap to turn on'
        : 'On — rewards and payouts in Telegram';

  root.innerHTML = `<div class="dash-head">
      <div>
        <h2 style="font-size:24px;font-weight:800;letter-spacing:-.5px">Profile</h2>
        <div class="tiny dim mt-6">Manage your account settings</div>
      </div>
      <a class="icon-square" href="#/accounts" aria-label="Account settings">${icon('settings', 18)}</a>
    </div>

    <div class="card card-pad">
      <div class="row-between" style="align-items:flex-start">
        <div class="row" style="gap:14px;min-width:0">
          ${avatarHTML(p, 'avatar-hero')}
          <div style="min-width:0">
            <div class="strong truncate" style="font-size:20px;font-weight:800">${esc(displayName())}</div>
            <div class="row mt-6" style="gap:6px;flex-wrap:wrap">
              <span class="badge gold">LV.${info.level}</span>
              <span class="badge outline">${esc(String(info.tier).toUpperCase())}</span>
              ${p.username ? `<span class="badge grey" title="Username">@${esc(p.username)}</span>` : ''}
              ${lifetimeTierBadge(w.lifetime_earned, 'Rank tier — based on lifetime approved earnings')}
              ${p.is_buyer ? '<span class="badge blue">Worker + Buyer</span>' : ''}
            </div>
            <div class="tiny dim mt-6" style="letter-spacing:.7px;text-transform:uppercase">${esc(p.country_code || 'Country not set')}</div>
          </div>
        </div>
        <button class="trust-pill" type="button" data-trust>TRUST <b>${info.trust}</b> ${icon('chevronRight', 12)}</button>
      </div>
      <div class="row-between tiny dim mt-14"><span>Level progress</span><span>${info.done % 25}/25</span></div>
      <div class="progress mt-6"><i style="width:${levelPct}%"></i></div>
      <div class="row-between tiny dim mt-14"><span>Current Score</span><span class="strong" style="color:var(--text)">${trust} / 1000 · ${esc(trustLabel)}</span></div>
      <div class="progress trust-progress mt-6"><i style="width:${Math.round(trust / 10)}%"></i></div>
      <div class="tiny dim mt-6">${trustToNext > 0 ? `${trustToNext} trust points to the next tier. Approved tasks add +1, high-value ones +2.` : 'Top trust tier reached'}</div>
    </div>

    <div class="card card-pad" style="background:radial-gradient(circle at 10% 0%, rgba(255,122,24,.16), transparent 55%), var(--surface);border-color:rgba(255,122,24,.22)">
      <div class="row" style="gap:8px">
        <span class="icon-square">${icon('wallet', 18)}</span>
        <div class="strong" style="font-size:15px">My wallet</div>
      </div>
      <div class="row" style="align-items:baseline;gap:8px;margin:12px 0 4px">
        <span style="font-size:36px;font-weight:800;letter-spacing:-1.5px">${esc(usdt(w.available))}</span>
        <span class="badge green">USDT</span>
      </div>
      <div class="tiny dim">pending ${esc(usdt(w.pending))} · lifetime earned ${esc(usdt(w.lifetime_earned))} · withdrawn ${esc(usdt(w.lifetime_withdrawn))}</div>
      <a class="btn btn-primary btn-block mt-14" href="#/withdraw">${icon('arrowUpRight', 16)} Withdraw</a>
      <div class="row mt-10" style="gap:8px">
        <a class="btn btn-ghost btn-sm" style="flex:1" href="#/deposit">${icon('download', 14)} Deposit</a>
        <a class="btn btn-ghost btn-sm" style="flex:1" href="#/history">${icon('book', 14)} History</a>
      </div>
    </div>

    <div class="card card-pad mt-14">
      <div class="row-between" style="gap:12px">
        <div style="min-width:0">
          <div class="strong" style="font-size:14px">App mode</div>
          <div class="tiny dim mt-6">${p.is_buyer ? 'Worker and buyer tools are both on your account.' : 'Worker mode earns tasks. Buyer mode orders campaigns.'}</div>
        </div>
        <div class="mode-switch">
          ${p.is_worker ? `<button class="mode-btn ${currentMode() === 'worker' ? 'active' : ''}" type="button" data-mode-go="worker">Worker</button>` : ''}
          <button class="mode-btn ${currentMode() === 'buyer' ? 'active' : ''}" type="button" data-mode-go="buyer">Buyer</button>
        </div>
      </div>
    </div>

    <div class="card settings-list">
      <div class="list-item">
        <div class="row" style="gap:12px;min-width:0">
          <span class="item-icon">${icon('mail', 18)}</span>
          <div class="item-text"><h4>${viaTelegram ? 'Telegram' : 'Google / email'}</h4><p class="truncate">${viaTelegram ? 'Signed in through the Telegram mini app' : `${esc(p.email || '')} · photo synced`}</p></div>
        </div>
        <span class="linked-pill">✓ Linked</span>
      </div>

      <a class="list-item" href="#/accounts">
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('users', 18)}</span>
          <div class="item-text"><h4>Account management</h4><p>Task accounts and sign-in methods</p></div>
        </div>
        <div class="row" style="gap:6px"><span class="tiny" style="color:#4ade80;font-weight:700">${linkedCount}/9</span><span class="arrow">›</span></div>
      </a>

      <button class="list-item" type="button" data-trust>
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('shield', 18)}</span>
          <div class="item-text"><h4>Trust score</h4><p>${esc(trustLabel)} · ${trust}/1000</p></div>
        </div>
        <span class="arrow">›</span>
      </button>

      <button class="list-item" type="button" data-edit-profile>
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('edit', 18)}</span>
          <div class="item-text"><h4>Edit profile</h4><p>Name and country</p></div>
        </div>
        <span class="arrow">›</span>
      </button>

      ${p.is_buyer
        ? `<a class="list-item" href="#/buyer"><div class="row" style="gap:12px"><span class="item-icon">${icon('megaphone', 18)}</span><div class="item-text"><h4>Buyer account</h4><p>Campaigns, deposits and orders</p></div></div><div class="row" style="gap:6px"><span class="tiny" style="color:#4ade80;font-weight:700">Active</span><span class="arrow">›</span></div></a>`
        : `<button class="list-item" type="button" data-enable-buyer><div class="row" style="gap:12px"><span class="item-icon">${icon('megaphone', 18)}</span><div class="item-text"><h4>Open buyer account</h4><p>Fund campaigns from your wallet</p></div></div><span class="arrow">›</span></button>`}

      ${state.profile?.admin_role ? `<a class="list-item" href="#/admin"><div class="row" style="gap:12px"><span class="item-icon">${icon('grid', 18)}</span><div class="item-text"><h4>Admin panel</h4><p>${esc(state.profile.admin_role.replace('_', ' '))}</p></div></div><span class="arrow">›</span></a>` : ''}

      <a class="list-item" href="#/support">
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('ticket', 18)}</span>
          <div class="item-text"><h4>Support</h4><p>Open a ticket with the team</p></div>
        </div>
        <span class="arrow">›</span>
      </a>

      <a class="list-item" href="#/terms">
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('file', 18)}</span>
          <div class="item-text"><h4>Terms &amp; rules</h4><p>Platform terms, payouts and conduct</p></div>
        </div>
        <span class="arrow">›</span>
      </a>

      <a class="list-item" href="#/more">
        <div class="row" style="gap:12px">
          <span class="item-icon">${icon('settings', 18)}</span>
          <div class="item-text"><h4>All settings &amp; tools</h4><p>Theme, mode, guides, leaderboard and referrals</p></div>
        </div>
        <span class="arrow">›</span>
      </a>
    </div>

    <div class="sec-title" style="margin:20px 4px 10px">
      <h3>Reward history</h3>
      <a href="#/history">View more ${icon('chevronRight', 12)}</a>
    </div>
    <div class="card settings-list">
      ${chk.checked_in_today ? `<div class="list-item">
        <div class="row" style="gap:12px">
          <span class="history-ic" style="background:rgba(245,196,81,.12);border-color:rgba(245,196,81,.3);color:var(--gold)">${icon('gift', 16)}</span>
          <div class="item-text"><h4>Daily check-in (streak ${Number(chk.streak || 0)})</h4><p>${esc(ago(new Date().toISOString()))}</p></div>
        </div>
        <span class="history-amt" style="color:var(--gold)">+${esc(tg(chk.reward_tg || 0))} TG</span>
      </div>` : ''}
      ${entries.length ? entries.slice(0, 6).map((e) => {
        const amt = Number(e.available_delta || 0) !== 0 ? Number(e.available_delta) : Number(e.pending_delta || 0);
        return `<div class="list-item">
          <div class="row" style="gap:12px;min-width:0">
            <span class="history-ic">${icon('coin', 16)}</span>
            <div class="item-text" style="min-width:0"><h4 class="truncate">${esc(KIND_LABEL[e.kind] || e.kind)}</h4><p>${esc(ago(e.created_at))}</p></div>
          </div>
          <span class="history-amt" style="color:${amt >= 0 ? '#4ade80' : '#ff8998'}">${amt >= 0 ? '+' : ''}${esc(usdt(amt))} USDT</span>
        </div>`;
      }).join('') : (chk.checked_in_today ? '' : '<div class="list-item"><div class="item-text"><h4>No rewards yet</h4><p>Complete a task or claim your daily check-in.</p></div></div>')}
    </div>

    <div class="sec-title" style="margin:20px 4px 10px"><h3>Messages &amp; community</h3></div>
    <div class="card settings-list">
      <button class="list-item" type="button" data-telegram-notify>
        <div class="row" style="gap:12px;min-width:0">
          <span class="item-icon">${icon('telegram', 18)}</span>
          <div class="item-text" style="min-width:0"><h4>Telegram notifications</h4><p class="truncate">${esc(tgSummary)}</p></div>
        </div>
        <span class="arrow">›</span>
      </button>
      <a class="list-item" href="https://t.me/Tmgrowglobal" target="_blank" rel="noopener noreferrer" data-tg-url="https://t.me/Tmgrowglobal">
        <div class="row" style="gap:12px"><span class="item-icon">${icon('telegram', 18)}</span><div class="item-text"><h4>Global Community</h4><p>@Tmgrowglobal</p></div></div>
        <span class="arrow">›</span>
      </a>
      <a class="list-item" href="https://t.me/BTCsignal777" target="_blank" rel="noopener noreferrer" data-tg-url="https://t.me/BTCsignal777">
        <div class="row" style="gap:12px"><span class="item-icon">${icon('telegram', 18)}</span><div class="item-text"><h4>Contact Admin</h4><p>@BTCsignal777</p></div></div>
        <span class="arrow">›</span>
      </a>
      <a class="list-item" href="#/notifications">
        <div class="row" style="gap:12px"><span class="item-icon">${icon('bell', 18)}</span><div class="item-text"><h4>Notifications</h4><p>${Number(state.counts.unread_notifications || 0)} unread</p></div></div>
        <span class="arrow">›</span>
      </a>
      <button class="list-item" type="button" data-signout>
        <div class="row" style="gap:12px"><span class="item-icon" style="color:#ff8998">${icon('logout', 18)}</span><div class="item-text"><h4 style="color:#ff8998">Log out</h4><p>Sign out of TM GROW</p></div></div>
        <span class="arrow">›</span>
      </button>
    </div>`;

  root.querySelectorAll('[data-tg-url]').forEach((b) => b.addEventListener('click', (e) => {
    e.preventDefault();
    openTelegramUrl(b.dataset.tgUrl);
  }));

  root.querySelectorAll('[data-trust]').forEach((b) => b.addEventListener('click', () => {
    openModal({
      title: 'Trust score',
      subtitle: `${trust}/1000 · ${trustLabel}`,
      body: `<div class="progress"><i style="width:${Math.round(trust / 10)}%"></i></div>
        <div class="row-between small mt-10"><span class="muted">${esc(trustLabel)}</span><span>${trust} / 1000</span></div>
        <div class="alert info mt-14">${icon('info', 17)}<div>${trustToNext > 0 ? `${trustToNext} points to reach the next tier. Trust grows with approved tasks and clean proofs; rejected proofs lower it.` : 'You are in the top trust tier.'}</div></div>
        <div class="alert warn mt-10">${icon('shield', 17)}<div>Trust is checked by a human verifier from your proof. Linking an account does not add points by itself.</div></div>`,
      footer: '<button class="btn btn-primary" type="button" data-close-trust>Got it</button>'
    });
    const closeBtn = document.querySelector('[data-close-trust]');
    if (closeBtn) closeBtn.addEventListener('click', () => {
      const back = document.querySelector('[data-modal-backdrop]');
      if (back) back.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    });
  }));

  const editBtn = root.querySelector('[data-edit-profile]');
  if (editBtn) editBtn.addEventListener('click', () => {
    const m = openModal({
      title: 'Edit profile',
      subtitle: 'Name and country',
      body: `<form id="pf-form" class="col" style="gap:13px">
        <div class="field"><label class="label">Full name</label><input class="input" name="full_name" value="${esc(p.full_name || '')}" maxlength="80" required /></div>
        <div class="field">
          <label class="label">Username</label>
          <input class="input" name="username" value="${esc(p.username || '')}" maxlength="24" pattern="[A-Za-z0-9_]{3,24}" placeholder="e.g. taskmaster" autocomplete="off" />
          <span class="hint">3-24 letters, numbers or underscores. Shown on the leaderboard.</span>
        </div>
        <div class="field">
          <label class="label">Country</label>
          <select class="select" name="country_code">
            <option value="">Not set</option>
            ${countries.map((c) => `<option value="${esc(c.code)}" ${p.country_code === c.code ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
          </select>
          <span class="hint">Some campaigns are restricted by country.</span>
        </div>
        <button class="btn btn-primary" type="submit">Save profile</button>
      </form>
      <div class="divider"></div>
      <p class="tiny dim">Name and photo are imported from your Google account. Use Sync to re-read them after changing your Google photo.</p>
      <button class="btn btn-ghost btn-sm btn-block mt-10" type="button" data-sync-identity>${icon('refresh', 14)} Sync account</button>`
    });
    m.root.querySelector('#pf-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      const btn = e.currentTarget.querySelector('button[type=submit]');
      setBusy(btn, true, 'Saving');
      try {
        await rpc('update_my_profile', {
          p_full_name: String(fd.get('full_name') || ''),
          p_country_code: String(fd.get('country_code') || '') || null
        });
        const uname = String(fd.get('username') || '').trim().toLowerCase();
        if (uname && uname !== (p.username || '').toLowerCase()) {
          try {
            await rpc('set_my_username', { p_username: uname });
          } catch (ue) {
            toast(friendlyError(ue), 'error', 6500);
          }
        }
        await freshContext();
        m.close();
        toast('Profile saved.', 'success');
        await renderProfile(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(btn, false);
      }
    });
    m.root.querySelector('[data-sync-identity]').addEventListener('click', async (e) => {
      setBusy(e.currentTarget, true, 'Syncing');
      try {
        await rpc('refresh_my_identity');
        await freshContext();
        m.close();
        toast('Name and photo synced.', 'success');
        await renderProfile(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(e.currentTarget, false);
      }
    });
  });

  root.querySelectorAll('[data-mode-go]').forEach((b) => b.addEventListener('click', async () => {
    const mode = b.dataset.modeGo;
    if (mode === 'buyer' && !state.profile?.is_buyer) {
      navigate('/buyer');
      return;
    }
    if (mode === currentMode()) return;
    b.disabled = true;
    try {
      await switchMode(mode);
      await loadContext();
      toast(mode === 'buyer' ? 'Buyer mode on.' : 'Worker mode on.', 'success');
      navigate(mode === 'buyer' ? '/buyer' : '/dashboard');
    } catch (err) {
      toast(friendlyError(err), 'error');
      b.disabled = false;
    }
  }));

  const enable = root.querySelector('[data-enable-buyer]');  if (enable) enable.addEventListener('click', async () => {
    setBusy(enable, true, 'Enabling');
    try {
      await rpc('enable_buyer_mode');
      await freshContext();
      toast('Buyer account enabled.', 'success');
      await renderProfile(root);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(enable, false);
    }
  });

  const tgBtn = root.querySelector('[data-telegram-notify]');
  if (tgBtn) tgBtn.addEventListener('click', () => openTelegramNotifyModal(tgStatus, root));

  root.querySelector('[data-signout]').addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Sign out?', message: 'You can sign back in with Google or email.', confirmLabel: 'Sign out' });
    if (!ok) return;
    const { sb: client } = await import('../lib/sb.js');
    await client.auth.signOut();
  });
}

/* Telegram delivery preference. The account is linked by opening the app from
   the bot; this only decides whether events are queued for it. */
function openTelegramNotifyModal(status, host) {
  const tg = status || {};
  const linked = tg.linked === true;
  const botOn = tg.bot_enabled === true;
  const enabled = tg.enabled !== false;

  if (!linked) {
    const m = openModal({
      title: 'Telegram notifications',
      subtitle: 'Not linked yet',
      body: `<div class="alert warn">${icon('telegram', 17)}<div>Your Telegram account is not linked to TM GROW yet. Open the app from the TM GROW bot in Telegram once — that links the account safely, without a password or code.</div></div>
        <p class="small muted mt-12" style="line-height:1.7">After that, task approvals, deposits, withdrawals and referral bonuses are sent to your Telegram chat as soon as they are committed.</p>`,
      footer: '<button class="btn btn-primary" type="button" data-ok>Got it</button>'
    });
    m.root.querySelector('[data-ok]').onclick = () => m.close();
    return;
  }

  const m = openModal({
    title: 'Telegram notifications',
    subtitle: tg.username ? `@${tg.username}` : `Telegram ${tg.telegram_id || ''}`,
    body: `<div class="row-between" style="gap:14px">
        <div style="min-width:0">
          <div class="strong" style="font-size:14px">Send my updates to Telegram</div>
          <div class="tiny dim mt-6">Task approved or rejected, deposit credited, withdrawal approved or paid, referral bonuses.</div>
        </div>
        <button class="btn ${enabled ? 'btn-soft' : 'btn-ghost'} btn-sm" type="button" data-toggle>
          ${enabled ? 'On' : 'Off'}
        </button>
      </div>
      ${botOn ? '' : '<div class="alert info mt-14">' + icon('info', 17) + '<div>Telegram delivery is currently paused platform-wide by the admin. Your preference is saved and works again when it is switched on.</div></div>'}
      <p class="tiny dim mt-14">This is a preference only. Rewards are always credited to your wallet in the app first; a Telegram message is a copy, never the payment itself.</p>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Close</button>`
  });

  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-toggle]').onclick = async (e) => {
    const btn = e.currentTarget;
    setBusy(btn, true, 'Saving');
    try {
      await rpc('set_my_telegram_notifications', { p_enabled: !enabled });
      toast(`Telegram notifications ${!enabled ? 'on' : 'off'}.`, 'success');
      m.close();
      if (host) await renderProfile(host);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  };
}

/* ========================================================== NOTIFICATIONS = */
export async function renderNotifications(root) {
  root.innerHTML = loadingBlock('Loading notifications');
  let rows = [];
  try {
    const { data } = await sb.from('notifications')
      .select('id,title,body,kind,link,read_at,created_at')
      .order('created_at', { ascending: false }).limit(100);
    rows = data || [];
  } catch (_) { rows = []; }

  const unread = rows.filter((r) => !r.read_at).length;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Inbox</span><h2>Notifications</h2><p>${unread} unread of ${rows.length}.</p></div>
      ${unread ? `<button class="btn btn-ghost btn-sm" type="button" data-read-all>${icon('check', 15)} Mark all read</button>` : ''}
    </div>

    <div class="card">
      <div class="card-body">
        ${rows.length ? `<div class="list">${rows.map((n) => `
          <div class="list-row" style="${!n.read_at ? 'background:rgba(255,122,24,.035);margin:0 -20px;padding:12px 20px' : ''}">
            <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px;color:${n.kind === 'success' ? 'var(--green)' : n.kind === 'error' || n.kind === 'warning' ? 'var(--red)' : 'var(--blue)'}">
              ${icon(n.kind === 'success' ? 'checkCircle' : n.kind === 'error' ? 'xCircle' : n.kind === 'warning' ? 'alert' : 'info', 16)}
            </span>
            <div class="list-main">
              <div class="row" style="gap:8px"><span class="list-title">${esc(n.title)}</span>${!n.read_at ? '<span class="badge orange">New</span>' : ''}</div>
              ${n.body ? `<div class="list-sub">${esc(n.body)}</div>` : ''}
              <div class="tiny dim mt-6">${esc(ago(n.created_at))}</div>
              ${n.link ? `<a class="tiny brand-text mt-6" style="display:inline-block" href="${esc(n.link)}">Open</a>` : ''}
            </div>
          </div>`).join('')}</div>` : emptyState({ iconName: 'bell', title: 'No notifications', text: 'Task decisions, withdrawals and announcements will appear here.' })}
      </div>
    </div>`;

  const readAll = root.querySelector('[data-read-all]');
  if (readAll) readAll.addEventListener('click', async () => {
    setBusy(readAll, true, 'Saving');
    try {
      await rpc('mark_notifications_read', { p_ids: null });
      await freshContext();
      document.querySelectorAll('[data-bell-dot]').forEach((d) => d.remove());
      toast('Notifications marked read.', 'success');
      await renderNotifications(root);
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(readAll, false);
    }
  });
}

/* =============================================================== SUPPORT = */
export async function renderSupport(root) {
  let tickets = [];
  try { tickets = await rpc('list_my_tickets') || []; } catch (_) { tickets = []; }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Help</span><h2>Support</h2><p>Ask about a task decision, a withdrawal or your account.</p></div>
      <button class="btn btn-primary" type="button" data-new-ticket>${icon('plus', 16)} New ticket</button>
    </div>

    <div class="card">
      <div class="card-head"><h3>Your tickets</h3><span class="badge grey">${tickets.length}</span></div>
      <div class="card-body">
        ${tickets.length ? `<div class="list">${tickets.map((t) => `
          <a class="list-row" href="#/support/${encodeURIComponent(t.id)}">
            <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${icon('ticket', 16)}</span>
            <div class="list-main">
              <div class="row" style="gap:8px"><span class="list-title">${esc(t.subject)}</span>${statusBadge(t.status)}</div>
              <div class="list-sub truncate">${esc(t.last_message || 'No messages yet')}</div>
              <div class="tiny dim mt-6">${esc(t.category)} · updated ${esc(ago(t.updated_at))}</div>
            </div>
            ${icon('chevronRight', 16)}
          </a>`).join('')}</div>` : emptyState({
            iconName: 'ticket',
            title: 'No tickets yet',
            text: 'Open a ticket and the support team will reply inside TM GROW.',
            action: `<button class="btn btn-primary" type="button" data-new-ticket>New ticket</button>`
          })}
      </div>
    </div>`;

  const openNew = () => {
    const m = openModal({
      title: 'New support ticket',
      subtitle: 'Describe the issue precisely so we can resolve it faster.',
      body: `<form id="ticket-form" class="col" style="gap:13px">
        <div class="field"><label class="label">Subject</label><input class="input" name="subject" maxlength="160" required minlength="3" placeholder="e.g. Proof rejected but task was completed" /></div>
        <div class="field"><label class="label">Category</label><select class="select" name="category">
          <option value="general">General</option>
          <option value="task">Task / proof</option>
          <option value="withdrawal">Withdrawal</option>
          <option value="deposit">Deposit</option>
          <option value="campaign">Campaign</option>
          <option value="account">Account</option>
        </select></div>
        <div class="field"><label class="label">Message</label><textarea class="textarea" name="body" maxlength="4000" required placeholder="Include your task ID, campaign name or transaction hash if relevant."></textarea></div>
        <button class="btn btn-primary" type="submit">Send ticket</button>
      </form>`
    });
    m.root.querySelector('#ticket-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      const btn = e.currentTarget.querySelector('button[type=submit]');
      setBusy(btn, true, 'Sending');
      try {
        const res = await rpc('create_support_ticket', {
          p_subject: String(fd.get('subject') || ''),
          p_category: String(fd.get('category') || 'general'),
          p_body: String(fd.get('body') || '')
        });
        m.close();
        toast('Ticket created.', 'success');
        if (res?.ticket?.id) window.location.hash = `#/support/${res.ticket.id}`;
        else await renderSupport(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(btn, false);
      }
    });
  };

  root.querySelectorAll('[data-new-ticket]').forEach((b) => b.addEventListener('click', openNew));
}

export async function renderSupportTicket(root, { params }) {
  root.innerHTML = loadingBlock('Loading ticket');
  let data;
  try { data = await rpc('get_ticket', { p_ticket_id: params.id }); }
  catch (e) {
    root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/support">${icon('arrowLeft', 15)} Support</a><div class="mt-14">${errorPanel(friendlyError(e))}</div>`;
    return;
  }

  const t = data.ticket;
  const messages = data.messages || [];

  root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/support">${icon('arrowLeft', 15)} Support</a>
    <div class="card mt-14">
      <div class="card-head">
        <div><h3>${esc(t.subject)}</h3><p class="tiny dim mt-6">${esc(t.category)} · opened ${esc(dateTime(t.created_at))}</p></div>
        ${statusBadge(t.status)}
      </div>
      <div class="card-body">
        <div class="chat" id="chat">
          ${messages.map((m) => `
            <div class="chat-msg ${m.is_staff ? '' : 'user'}">
              <span class="avatar">${m.is_staff ? 'TM' : esc(initials(state.profile?.full_name, state.profile?.email))}</span>
              <div>
                <div class="chat-bubble">${esc(m.body)}</div>
                <div class="tiny dim mt-6">${m.is_staff ? 'TM GROW support' : 'You'} · ${esc(ago(m.created_at))}</div>
              </div>
            </div>`).join('') || '<p class="small muted">No messages yet.</p>'}
        </div>
        <div class="chat-input mt-18">
          <textarea id="ticket-reply" placeholder="Write a reply…" maxlength="4000"></textarea>
          <button class="btn btn-primary btn-icon" type="button" id="ticket-send" aria-label="Send">${icon('send', 17)}</button>
        </div>
      </div>
    </div>`;

  const send = root.querySelector('#ticket-send');
  send.addEventListener('click', async () => {
    const body = root.querySelector('#ticket-reply').value.trim();
    if (!body) return toast('Write a message first.', 'error');
    setBusy(send, true, '');
    try {
      await rpc('reply_support_ticket', { p_ticket_id: params.id, p_body: body });
      await renderSupportTicket(root, { params });
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(send, false);
    }
  });
}


/* ============================================================== MY TASKS === */
export async function renderMyTasks(root) {
  await freshContext();
  let filter = 'all';

  const VERIF_LABEL = {
    pending: ['orange', 'Verification pending'],
    manual_review: ['gold', 'Manual review'],
    approved: ['green', 'Approved'],
    rejected: ['red', 'Rejected'],
    api_error: ['red', 'Verification error']
  };
  const METHOD_LABEL = {
    manual: 'Manual proof review',
    public_profile: 'Public profile check',
    followers_min: 'Follower check',
    public_media_exists: 'Public media check'
  };
  const verifBadge = (status) => {
    if (!status) return '';
    const [tone, label] = VERIF_LABEL[status] || ['grey', status];
    return `<span class="badge ${tone}">${esc(label)}</span>`;
  };

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Earn</span><h2>My tasks</h2><p>Everything you claimed, submitted and got paid for.</p></div>
      <a class="btn btn-ghost" href="#/tasks">${icon('plus', 15)} Find tasks</a>
    </div>
    <div class="tabs" id="mt-tabs" style="margin-bottom:14px">
      ${[['all', 'All'], ['claimed', 'In progress'], ['submitted', 'In review'], ['approved', 'Approved'], ['rejected', 'Rejected']]
        .map(([v, l]) => `<button class="tab ${v === 'all' ? 'active' : ''}" type="button" data-tab="${v}">${l}</button>`).join('')}
    </div>
    <div id="mt-list">${loadingBlock('Loading your tasks')}</div>`;

  const listEl = root.querySelector('#mt-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading your tasks');
    let items = [];
    try {
      const res = await rpc('my_tasks', {
        p_status: filter === 'all' ? null : filter,
        p_limit: 100,
        p_offset: 0
      });
      items = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = items.length ? `<div class="card"><div class="card-body"><div class="list">
      ${items.map((t) => {
        const m = platformMeta(t.platform);
        return `<a class="list-row" href="#/tasks/${encodeURIComponent(t.id)}">
          <span class="task-ic" style="background:${m.bg};color:${m.color};width:38px;height:38px">${platformIcon(t.platform, 18)}</span>
          <div class="list-main">
            <div class="row" style="gap:8px;flex-wrap:wrap"><span class="list-title">${esc(t.title)}</span>${statusBadge(t.status)}</div>
            <div class="list-sub">${esc(m.label)} · ${esc(usdt(t.reward))} USDT · ${esc(ago(t.reviewed_at || t.submitted_at || t.claimed_at || t.created_at))}</div>
            ${t.review_note ? `<div class="tiny red mt-6">${esc(t.review_note)}</div>` : ''}
            ${t.verification_status ? `<div class="row-wrap mt-6">
              ${verifBadge(t.verification_status)}
              <span class="tiny dim">${esc(METHOD_LABEL[t.verification_method] || t.verification_method || 'Manual proof review')}</span>
            </div>` : ''}
            ${t.verification_reason && t.verification_status !== 'approved' ? `<div class="tiny dim mt-6">${esc(t.verification_reason)}</div>` : ''}
          </div>
          ${icon('chevronRight', 16)}
        </a>`;
      }).join('')}
    </div></div></div>` : emptyState({
      iconName: 'tasks',
      title: filter === 'all' ? 'No tasks yet' : 'Nothing in this status',
      text: filter === 'all' ? 'Claim your first task from the marketplace.' : 'Try another tab.',
      action: '<a class="btn btn-primary" href="#/tasks">Browse tasks</a>'
    });
  };

  root.querySelector('#mt-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    filter = b.dataset.tab;
    root.querySelectorAll('#mt-tabs .tab').forEach((t) => t.classList.toggle('active', t === b));
    load();
  });

  await load();
}

/* ================================================================= MORE === */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('tmgrow-theme', theme); } catch (_) { /* ignore */ }
}

export async function renderMore(root) {
  await freshContext();
  const p = state.profile || {};
  const theme = document.documentElement.dataset.theme === 'light' ? 'light' : 'dark';

  const gridItem = (iconName, label, action, active = false) =>
    `<button class="grid-item ${active ? 'active-support' : ''}" type="button" data-grid="${action}">
      <span class="grid-icon">${icon(iconName, 22)}</span>
      <span class="grid-text">${esc(label)}</span>
    </button>`;

  root.innerHTML = `<div class="dash-head" style="margin-bottom:16px">
      <div class="row" style="gap:12px;min-width:0">
        ${avatarHTML(p, 'avatar-hero')}
        <div style="min-width:0">
          <div class="strong truncate">${esc(displayName())}</div>
          <div class="tiny dim">${p.admin_role ? esc(p.admin_role.replace('_', ' ')) : p.is_buyer ? 'Worker + Buyer' : 'Worker account'}</div>
        </div>
      </div>
      <button class="btn btn-ghost btn-sm" type="button" data-signout>${
        icon('logout', 14)} Sign out</button>
    </div>

    <div class="support-grid">
      ${gridItem('trophy', 'Leaderboard', 'leaderboard')}
      ${gridItem('users', 'Referrals', 'referrals')}
      ${gridItem('sparkles', 'Premium', 'premium')}
      ${gridItem('user', 'Profile', 'profile')}
      ${gridItem('shield', 'Linked accounts', 'accounts')}
      ${gridItem('ticket', 'Support', 'support', true)}
      ${gridItem('book', 'Guides', 'guides')}
      ${gridItem('info', 'FAQ', 'faq')}
      ${gridItem('file', 'Terms', 'terms')}
    </div>

    <div class="settings-list">
      <div class="setting-row">
        <div class="setting-left"><span class="setting-icon">${icon('globe', 18)}</span> Language</div>
        <div class="tiny dim">English</div>
      </div>
      <div class="setting-row">
        <div class="setting-left"><span class="setting-icon">${icon(theme === 'light' ? 'star' : 'lock', 18)}</span> Dark theme</div>
        <div class="toggle-switch ${theme === 'dark' ? 'on' : ''}" id="themeToggle" role="switch" aria-checked="${theme === 'dark'}">
          <div class="toggle-circle"></div>
        </div>
      </div>
      <div class="setting-row">
        <div class="setting-left"><span class="setting-icon">${icon('layers', 18)}</span> Mode</div>
        <div class="mode-switch">
          <button class="mode-btn active" type="button" data-mode="worker">Worker</button>
          <button class="mode-btn" type="button" data-mode="buyer">Advertiser</button>
        </div>
      </div>
      <a class="setting-row" href="#/accounts">
        <div class="setting-left"><span class="setting-icon">${icon('link', 18)}</span> Linked accounts</div>
        <div class="tiny dim">›</div>
      </a>
      <a class="setting-row" href="#/notifications">
        <div class="setting-left"><span class="setting-icon">${icon('bell', 18)}</span> Notifications</div>
        <div class="tiny dim">${Number(state.counts.unread_notifications || 0)} unread ›</div>
      </a>
      <a class="setting-row" href="#/support">
        <div class="setting-left"><span class="setting-icon">${icon('ticket', 18)}</span> Support tickets</div>
        <div class="tiny dim">›</div>
      </a>
      <a class="setting-row" href="#/terms">
        <div class="setting-left"><span class="setting-icon">${icon('file', 18)}</span> Terms &amp; rules</div>
        <div class="tiny dim">›</div>
      </a>
      ${state.profile?.admin_role ? `<a class="setting-row" href="#/admin">
        <div class="setting-left"><span class="setting-icon">${icon('grid', 18)}</span> Admin panel</div>
        <div class="tiny dim">›</div>
      </a>` : ''}
      <button class="setting-row" type="button" data-signout style="color:#ff8998">
        <div class="setting-left"><span class="setting-icon" style="color:#ff8998">${icon('logout', 18)}</span> Sign out</div>
        <span class="tiny dim">›</span>
      </button>
    </div>`;

  const toggle = root.querySelector('#themeToggle');
  if (toggle) toggle.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    applyTheme(next);
    toggle.classList.toggle('on', next === 'dark');
    toggle.setAttribute('aria-checked', next === 'dark' ? 'true' : 'false');
    toast(next === 'light' ? 'Light theme on.' : 'Dark theme on.', 'success');
  });

  root.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => {
    if (b.dataset.mode === 'buyer') {
      if (state.profile?.is_buyer) navigate('/buyer');
      else navigate('/buyer');
    } else navigate('/dashboard');
  }));

  const infoModal = (title, body) => {
    const m = openModal({
      title,
      body,
      footer: '<button class="btn btn-primary" type="button" data-close-info>Got it</button>'
    });
    m.root.querySelector('[data-close-info]').onclick = () => m.close();
  };

  const go = (path) => navigate(path);
  root.querySelectorAll('[data-grid]').forEach((b) => b.addEventListener('click', () => {
    const a = b.dataset.grid;
    if (a === 'leaderboard') return go('/leaderboard');
    if (a === 'referrals') return go('/referrals');
    if (a === 'premium') return go('/referrals');
    if (a === 'profile') return go('/profile');
    if (a === 'accounts') return go('/accounts');
    if (a === 'support') return go('/support');
    if (a === 'guides') {
      return infoModal('Guides', `<div class="step-list">
        <div class="step"><span class="sn">1</span><span>Link a social account and paste the verification code in your profile.</span></div>
        <div class="step"><span class="sn">2</span><span>Claim a task, complete it and upload a clear screenshot.</span></div>
        <div class="step"><span class="sn">3</span><span>Wait for the verifier. Approved rewards move to your available balance.</span></div>
        <div class="step"><span class="sn">4</span><span>Withdraw from 2 USDT on BEP-20; free from 5 USDT.</span></div>
      </div>`);
    }
    if (a === 'faq') {
      return infoModal('FAQ', `<div class="list">
        <div class="list-row"><div class="list-main"><div class="list-title">Is verification automatic?</div><div class="list-sub">No. A human verifier checks every proof.</div></div></div>
        <div class="list-row"><div class="list-main"><div class="list-title">When do I get paid?</div><div class="list-sub">On approval, the reward moves to your available balance.</div></div></div>
        <div class="list-row"><div class="list-main"><div class="list-title">Minimum withdrawal?</div><div class="list-sub">2 USDT. Free from 5 USDT; 5% below that.</div></div></div>
        <div class="list-row"><div class="list-main"><div class="list-title">Do you need my passwords?</div><div class="list-sub">Never. Only public actions and screenshots.</div></div></div>
      </div>`);
    }
    if (a === 'terms') return go('/terms');
  }));

  root.querySelectorAll('[data-signout]').forEach((b) => b.addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Sign out?', message: 'You can sign back in with Google or email.', confirmLabel: 'Sign out' });
    if (!ok) return;
    try { await sb.auth.signOut(); } catch (_) { /* ignore */ }
  }));
}


/* ================================================================= TERMS === */
/* Published date of the text below. Bump it whenever the terms change. */
const TERMS_UPDATED = '12 October 2025';

export async function renderTerms(root) {
  const minWithdraw = withdrawalMin();
  const feePct = settingNumber('withdrawal_fee_pct', 5);
  const feeFree = settingNumber('withdrawal_fee_free_min', 5);
  const supportEmail = settingText('support_email', '');
  const back = state.session ? '#/dashboard' : '#/';

  const contactLine = supportEmail
    ? `Email <a href="mailto:${esc(supportEmail)}">${esc(supportEmail)}</a> or open a support ticket from your account.`
    : 'Open a support ticket from your account and the team will answer inside TM GROW.';

  const sec = (n, title, body) => `<section class="legal-sec">
    <h2>${n}. ${esc(title)}</h2>
    ${body}
  </section>`;

  root.innerHTML = `<div class="legal-page">
    <header class="legal-head">
      <a class="brand" href="${esc(back)}">
        <span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span>
        <span><span class="brand-name">TM GROW</span><span class="brand-sub">Social task network</span></span>
      </a>
      <a class="btn btn-ghost btn-sm" href="${esc(back)}">${icon('arrowLeft', 15)} Back</a>
    </header>

    <main class="legal-wrap">
      <span class="eyebrow">Legal</span>
      <h1>Terms of Service</h1>
      <p class="legal-updated">Last updated ${esc(TERMS_UPDATED)}. These terms apply to every worker, buyer and administrator account.</p>

      <div class="legal-card">
        ${sec(1, 'About TM GROW', `<p>TM GROW is a marketplace for social media micro tasks. Brands (buyers) fund campaigns and set the action they want; workers complete that action on their own social accounts and submit proof. TM GROW holds the campaign budget and pays approved work in USDT.</p>
          <p>TM GROW is not a social network and is not affiliated with X, YouTube, Instagram, TikTok, Facebook, Telegram, Reddit, Spotify or Discord. Using the platform does not create an employment, agency or partnership relationship with TM GROW or with any campaign owner.</p>`)}

        ${sec(2, 'Eligibility and your account', `<ul>
            <li>You must be at least 18 years old and legally able to enter this agreement.</li>
            <li>One account per person. Duplicate, shared or automated accounts are closed and their balances frozen.</li>
            <li>You must give accurate details and keep access to the email address used to sign in.</li>
            <li>You are responsible for everything done through your account. Never share your password, one-time codes or session cookies.</li>
            <li>We may ask for identity or ownership verification before paying a withdrawal, reversing a deposit or restoring a suspended account.</li>
          </ul>`)}

        ${sec(3, 'How tasks work', `<ul>
            <li>Claiming a task reserves it for you for ${esc(String(settingNumber('claim_window_minutes', 30)))} minutes. Unused claims expire and return to the marketplace.</li>
            <li>You must complete exactly the action described in the campaign instructions and submit a screenshot that shows your own account and the completed action.</li>
            <li>Proofs are reviewed by a human verifier unless a campaign page explicitly says an API integration checks it. Reviews are not instant.</li>
            <li>Some campaigns only accept workers with a verified linked account, or a minimum trust score, or specific countries. Those limits are shown before you claim.</li>
            <li>Rejected proofs state a reason. Repeatedly rejected work lowers your trust score and can close task access.</li>
          </ul>`)}

        ${sec(4, 'Rewards and TG Coin', `<ul>
            <li>An approved task releases its USDT reward to your available balance. Until then the reward is pending and cannot be withdrawn.</li>
            <li>TG Coin is a platform bonus token credited alongside approved work and daily check-ins. It is not money, is not an investment, has no guaranteed cash value and cannot be withdrawn as USDT unless a published promotion says so.</li>
            <li>Campaign owners can pause or end a campaign. Stated quantities and delivery are published per campaign and are not a promise of continuous work.</li>
            <li>Rewards are only paid for work completed and approved before a campaign ends.</li>
          </ul>`)}

        ${sec(5, 'Deposits and withdrawals', `<ul>
            <li>Buyer accounts are funded with USDT on BNB Smart Chain (BEP-20) to the address shown in the deposit screen. Deposits on another network, or to another address, cannot be recovered.</li>
            <li>Each deposit is checked on-chain and needs the required network confirmations. The credited amount is the USDT actually received by the platform address.</li>
            <li>The minimum withdrawal is ${esc(usdt(minWithdraw))} USDT. A ${esc(String(feePct))}% network and processing fee applies to withdrawals below ${esc(usdt(feeFree))} USDT; withdrawals at or above that amount are fee free.</li>
            <li>Only USDT on BEP-20 is supported. You are responsible for entering a correct, compatible address. Crypto transfers are final.</li>
            <li>Withdrawals are paid manually from the finance queue. When a payout is sent, its real transaction hash is recorded on the request. TM GROW never invents a transaction hash or a payout.</li>
            <li>Balances obtained through fraud, duplicate accounts or manipulated proofs are removed, including from already processed requests.</li>
          </ul>`)}

        ${sec(6, 'Anti-fraud and verification', `<ul>
            <li>Every proof is tied to your account, the task and a hash of the uploaded image. Reusing the same screenshot is detected and rejected.</li>
            <li>Bots, scripts, emulators, click farms, bought engagement, VPN masking to bypass a country rule and coordinated rings are prohibited.</li>
            <li>We may delay, hold or reverse a payout while a risk review is open, and we may ask for a screen recording of the completed action.</li>
            <li>Suspected fraud may be reported to campaign owners and, where the law requires it, to the authorities.</li>
          </ul>`)}

        ${sec(7, 'Social accounts and verification codes', `<ul>
            <li>Only link accounts you own and control. Never link an account that is rented, bought or shared.</li>
            <li>To prove ownership you paste a verification code generated by TM GROW into the linked account's public profile. You may remove it afterwards.</li>
            <li>TM GROW never asks for passwords, two-factor codes, backup codes or session cookies, and never logs into your social accounts.</li>
            <li>Actions that break a platform's own rules are your responsibility. If a campaign asks for something that violates a social network's terms, do not do it and report the campaign.</li>
            <li>A linked X account has a 7-day warm-up before X tasks unlock, and unlinking an account removes access to campaigns that require it.</li>
          </ul>`)}

        ${sec(8, 'Prohibited conduct', `<ul>
            <li>Submitting fake, edited, borrowed or generated screenshots, or proof of an action you did not perform.</li>
            <li>Creating multiple accounts, referring yourself, or trading referral rewards between your own accounts.</li>
            <li>Abusing refunds, chargebacks, duplicate deposit submissions or withdrawal requests to obtain funds twice.</li>
            <li>Harassment, threats, hate speech, doxxing, spam or any illegal content in campaign instructions, proofs, notes or tickets.</li>
            <li>Attempting to access another account, an administrator area, or to reverse engineer, scrape or overload the platform.</li>
            <li>Offering tasks that require a worker to break a law or a social platform's terms, or that pay for fake engagement.</li>
          </ul>`)}

        ${sec(9, 'Taxes', '<p>You are responsible for the taxes that apply to rewards you receive, in your own country. TM GROW does not withhold tax and does not give tax advice. Keep your own record of approved tasks, deposits and withdrawals; your transaction history is available in the app.</p>')}

        ${sec(10, 'Intellectual property', '<p>The TM GROW name, logo, interface and code belong to TM GROW. You receive a limited, non-transferable right to use the platform for its intended purpose. Campaign instructions, briefs and creative material belong to the campaign owner; you may use them only to complete that campaign. Do not copy, resell or republish the platform or another user\'s content.</p>')}

        ${sec(11, 'Availability and disclaimers', `<ul>
            <li>The platform is provided as it is. We work to keep it available but do not guarantee uninterrupted service, and maintenance or outages can delay claims and reviews.</li>
            <li>The number of available tasks depends on buyers funding campaigns. TM GROW does not promise a minimum income, a daily task count or an approval.</li>
            <li>Crypto values move. The USDT amount credited is the amount received on-chain at the time of verification.</li>
            <li>To the extent the law allows, TM GROW is not liable for indirect losses, lost profit, or losses caused by a wrong wallet address, a wrong network or a compromised social account.</li>
          </ul>`)}

        ${sec(12, 'Violations and account closure', `<ul>
            <li>Depending on severity we may reject a proof, lower your trust score, hold a payout, restrict task access, suspend or close an account, or cancel a buyer campaign.</li>
            <li>Balances proven to come from fraud are removed. Legitimate earnings in an otherwise closed account are handled case by case through support.</li>
            <li>You may appeal a decision through a support ticket within 30 days. Appeals are reviewed by a person, not automatically.</li>
            <li>You can close your account at any time from support; open claims, pending reviews and withdrawals are settled first.</li>
          </ul>`)}

        ${sec(13, 'Changes and contact', `<p>We may update these terms when the platform, its fees or the law change. The date at the top of this page shows the current version, and continuing to use TM GROW after an update means you accept it. Material changes are announced in your notifications.</p>
          <p>${contactLine}</p>`)}
      </div>

      <div class="legal-foot">
        <a href="#/support">Support</a>
        <a href="/privacy.html">Privacy</a>
        <a href="#/login">Sign in</a>
        <span>© ${new Date().getFullYear()} TM GROW</span>
      </div>
    </main>
  </div>`;
}


/* ============================================================ SMM TASKS ===
   Tasks released by the SMM drip scheduler (supabase/smm-drip.sql). They are
   separate from campaign tasks: different claim/start/submit RPCs, one unit
   per task, and the same server-enforced automatic timer. */

const SMM_TABS = [
  ['available', 'Available'],
  ['claimed', 'In progress'],
  ['submitted', 'In review'],
  ['approved', 'Approved'],
  ['rejected', 'Rejected']
];

const SMM_MISSING_SQL = 'SMM fulfilment is not installed on this database yet. Run supabase/smm-drip.sql in the Supabase SQL editor, then reload this page.';

function smmRpcMissing(e) {
  const raw = String((e && (e.raw?.message || e.message)) || '');
  return /PGRST202|Could not find the function|schema cache|does not exist/i.test(raw)
    || /not initialised/i.test(raw);
}

function smmAvailableCard(t) {
  const m = platformMeta(t.platform);
  return `<div class="card card-pad">
    <div class="row" style="gap:12px;align-items:flex-start">
      <span class="task-ic" style="background:${m.bg};color:${m.color}">${platformIcon(t.platform, 20)}</span>
      <div style="flex:1;min-width:0">
        <div class="row" style="gap:8px;flex-wrap:wrap">
          <span class="badge" style="color:${m.color};background:${m.bg}">${esc(m.label)}</span>
          <span class="badge gold">${esc(usdt(t.reward))} USDT</span>
          <span class="badge grey">${Number(t.quantity_left || 0)} unit(s) left</span>
        </div>
        <div class="strong mt-10">${esc(t.title)}</div>
        <div class="tiny dim mt-6 mono truncate">${esc(t.target_url || '')}</div>
        ${t.instructions_preview ? `<div class="tiny dim mt-6">${esc(t.instructions_preview)}</div>` : ''}
      </div>
    </div>
    <button class="btn btn-primary btn-block mt-12" type="button" data-smm-open="${esc(t.id)}">Open task</button>
  </div>`;
}

function smmMineRow(t) {
  const m = platformMeta(t.platform);
  return `<button class="list-row" type="button" style="width:100%;text-align:left;background:none" data-smm-open="${esc(t.id)}">
    <span class="task-ic" style="background:${m.bg};color:${m.color};width:38px;height:38px">${platformIcon(t.platform, 18)}</span>
    <div class="list-main" style="min-width:0">
      <div class="row" style="gap:8px;flex-wrap:wrap"><span class="list-title truncate">${esc(t.service_name || 'SMM task')}</span>${statusBadge(t.status)}</div>
      <div class="list-sub">#${esc(t.order_short || '')} · unit ${Number(t.seq || 0)} · ${esc(usdt(t.reward))} USDT · ${esc(ago(t.reviewed_at || t.submitted_at || t.claimed_at || t.created_at))}</div>
      ${t.review_note ? `<div class="tiny red mt-6">${esc(t.review_note)}</div>` : ''}
    </div>
    ${icon('chevronRight', 16)}
  </button>`;
}

export async function renderSmmTasks(root) {
  let tab = 'available';
  let offset = 0;
  const limit = 20;
  let total = 0;
  let loading = false;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Earn</span><h2>SMM tasks</h2><p>Single social actions released in batches from paid orders. Each task pays after a human checks your screenshot.</p></div>
      <div class="row-wrap" style="gap:8px">
        <a class="btn btn-ghost" href="#/tasks">${icon('tasks', 16)} Campaign tasks</a>
        <a class="btn btn-ghost" href="#/my-tasks">${icon('checkCircle', 16)} My tasks</a>
      </div>
    </div>

    <div class="tabs" id="st-tabs" style="margin-bottom:14px">
      ${SMM_TABS.map(([v, l]) => `<button class="tab ${v === tab ? 'active' : ''}" type="button" data-tab="${v}">${l}</button>`).join('')}
    </div>
    <div id="st-list">${loadingBlock('Loading SMM tasks')}</div>
    <div class="center mt-18"><button class="btn btn-ghost hide" id="st-more" type="button">Load more</button></div>`;

  const listEl = root.querySelector('#st-list');
  const moreBtn = root.querySelector('#st-more');

  const paint = (items) => {
    if (!items.length) {
      listEl.innerHTML = emptyState({
        iconName: 'zap',
        title: tab === 'available' ? 'No SMM tasks released right now' : 'Nothing in this tab',
        text: tab === 'available'
          ? 'Tasks appear here in batches as buyers\u2019 orders are released. New batches arrive automatically.'
          : 'Try another tab.'
      });
      moreBtn.classList.add('hide');
      return;
    }
    listEl.innerHTML = tab === 'available'
      ? `<div class="col" style="gap:12px">${items.map(smmAvailableCard).join('')}</div>`
      : `<div class="card"><div class="card-body"><div class="list">${items.map(smmMineRow).join('')}</div></div></div>`;
    moreBtn.classList.toggle('hide', tab === 'available' || items.length >= total || total === 0);
  };

  let items = [];

  const load = async (reset = true) => {
    if (loading) return;
    loading = true;
    if (reset) offset = 0;
    if (reset) listEl.innerHTML = loadingBlock('Loading SMM tasks');
    if (!reset) setBusy(moreBtn, true, 'Loading');
    try {
      if (tab === 'available') {
        const res = await rpc('smm_worker_feed', { p_limit: 50 });
        items = res?.items || [];
        total = items.length;
      } else {
        const res = await rpc('smm_my_tasks', { p_status: tab, p_limit: limit, p_offset: offset });
        const page = res?.items || [];
        items = reset ? page : [...items, ...page];
        total = Number(res?.total || 0);
      }
      paint(items);
    } catch (e) {
      listEl.innerHTML = errorPanel(smmRpcMissing(e) ? SMM_MISSING_SQL : friendlyError(e));
      moreBtn.classList.add('hide');
    } finally {
      loading = false;
      setBusy(moreBtn, false);
    }
  };

  listEl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-smm-open]');
    if (b) openSmmTask(root, b.dataset.smmOpen);
  });

  root.querySelector('#st-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    tab = b.dataset.tab;
    root.querySelectorAll('#st-tabs .tab').forEach((x) => x.classList.toggle('active', x === b));
    load(true);
  });

  moreBtn.addEventListener('click', () => { offset += limit; load(false); });

  await load(true);
}

async function openSmmTask(root, taskId, onDone) {
  let data;
  try {
    data = await rpc('smm_task_detail', { p_task_id: taskId });
  } catch (e) {
    toast(smmRpcMissing(e) ? SMM_MISSING_SQL : friendlyError(e), 'error', 9000);
    return;
  }
  if (!data || !data.task) {
    toast('That SMM task was not found. Reload the list.', 'error');
    return;
  }

  const t = data.task;
  const s = data.service || {};
  const o = data.order || {};
  const sub = data.submission || null;
  const m = platformMeta(s.platform);
  const target = safeHttpUrl(o.target_link);

  let action = '';
  if (t.status === 'available') {
    action = `<button class="btn btn-primary btn-lg btn-block" type="button" data-smm-start>${icon('play', 17)} Claim and start</button>
      <p class="hint center mt-6">The claim is held for ${esc(String(settingNumber('claim_window_minutes', 30)))} minutes. The timer starts when you open the task.</p>`;
  } else if (t.status === 'claimed' && t.mine) {
    action = `<button class="btn btn-primary btn-lg btn-block" type="button" data-smm-start>${icon('play', 17)} Start task</button>`;
  } else if (t.status === 'submitted') {
    action = `<div class="alert info">${icon('clock', 17)}<div>Proof submitted. A verifier is checking it now.</div></div>`;
  } else if (t.status === 'approved') {
    action = `<div class="alert success">${icon('checkCircle', 17)}<div>Approved. ${esc(usdt(t.reward))} USDT was credited to your available balance.</div></div>`;
  } else if (t.status === 'rejected') {
    action = `<div class="alert error">${icon('xCircle', 17)}<div><strong>Proof rejected.</strong><br>${esc(sub?.review_note || 'The proof did not match the order.')}</div></div>`;
  } else if (t.status === 'expired') {
    action = `<div class="alert warn">${icon('clock', 17)}<div>This claim expired and the unit returned to the order.</div></div>`;
  } else {
    action = `<div class="alert info">${icon('info', 17)}<div>This task is ${esc(String(t.status || 'unavailable'))}.</div></div>`;
  }

  const modal = openModal({
    title: s.name || 'SMM task',
    subtitle: `${m.label} · unit ${Number(t.seq || 0)} · ${usdt(t.reward)} USDT`,
    body: `<div class="row" style="gap:12px;align-items:flex-start">
        <span class="task-ic" style="background:${m.bg};color:${m.color};width:44px;height:44px">${platformIcon(s.platform, 21)}</span>
        <div style="flex:1;min-width:0">
          <div class="row" style="gap:8px;flex-wrap:wrap">${statusBadge(t.status)}<span class="badge gold">${esc(usdt(t.reward))} USDT</span></div>
          <div class="tiny dim mono mt-6 truncate">Order #${esc(o.short_id || '')} · ${Number(o.quantity || 0)} units</div>
        </div>
      </div>

      ${target
        ? `<a class="btn btn-soft btn-block mt-14" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 16)} Open target</a>`
        : `<div class="alert error mt-14">${icon('alert', 17)}<div>This order has an invalid target link. Contact support.</div></div>`}

      <h3 style="font-size:13px" class="mb-10 mt-18">Instructions</h3>
      <div class="panel panel-pad" style="white-space:pre-wrap;font-size:13.5px;line-height:1.7;color:var(--muted)">${esc(s.instructions || 'Complete the action shown on the target link with your own account, then upload a screenshot.')}</div>

      <div class="alert info mt-14">${icon('shield', 17)}<div><strong>Never share passwords.</strong> TM GROW only needs the public action and a screenshot.</div></div>

      ${sub && (sub.status === 'pending' || sub.status === 'approved') ? `<div class="card card-pad mt-14">
        <div class="row-between"><span class="strong small">Your submission</span>${statusBadge(sub.status)}</div>
        <div class="tiny dim mt-6">${Number(Array.isArray(sub.proof_paths) && sub.proof_paths.length ? sub.proof_paths.length : 1)} screenshot(s)${sub.proof_link ? ' · proof link attached' : ''} · submitted ${esc(dateTime(sub.created_at))}</div>
      </div>` : ''}

      <div class="mt-14">${action}</div>`,
    footer: '<button class="btn btn-ghost" type="button" data-close>Close</button>'
  });
  modal.root.querySelector('[data-close]').onclick = () => modal.close();

  const startBtn = modal.root.querySelector('[data-smm-start]');
  if (!startBtn) return;

  startBtn.addEventListener('click', async () => {
    setBusy(startBtn, true, 'Starting');
    try {
      if (t.status === 'available') {
        await rpc('smm_claim_task', { p_task_id: t.id });
      }
      const started = await rpc('smm_start_task', { p_task_id: t.id });
      modal.close();
      openSmmRunner(root, data, started, onDone);
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
      setBusy(startBtn, false);
    }
  });
}

function openSmmRunner(root, data, started, onDone) {
  const t = data.task;
  const s = data.service || {};
  const o = data.order || {};
  const target = safeHttpUrl(o.target_link);
  const seconds = Math.max(5, Number(started?.required_seconds || 30));
  let endsAt = started?.timer_ends_at
    ? new Date(started.timer_ends_at).getTime()
    : Date.now() + seconds * 1000;
  const startedAtMs = started?.timer_started_at
    ? new Date(started.timer_started_at).getTime()
    : Date.now();
  const clock = (v) => `${String(Math.floor(Math.max(0, v) / 60)).padStart(2, '0')}:${String(Math.max(0, v) % 60).padStart(2, '0')}`;
  const ruleLabel = String(started?.rule || 'default').replace(':', ' · ');

  const files = [];
  const urls = [];
  let ticker = null;

  const modal = openModal({
    title: s.name || 'SMM task',
    subtitle: `Unit ${Number(t.seq || 0)} · ${usdt(t.reward)} USDT`,
    body: `<div class="runner-top">
        <div class="runner-timer" data-timer-box>
          <span>Time left</span>
          <b data-timer>${clock(seconds)}</b>
        </div>
        ${target ? `<a class="runner-open" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 15)} Open task</a>` : ''}
      </div>
      <div class="tiny dim center mt-6">Automatic timer · ${seconds}s · ${esc(ruleLabel)}</div>

      <details class="mt-14" open>
        <summary class="tiny dim" style="cursor:pointer">Instructions</summary>
        <div class="small muted mt-6" style="white-space:pre-wrap;line-height:1.65">${esc(s.instructions || 'Complete the action on the target link with your own account.')}</div>
      </details>

      <div class="field mt-14">
        <label class="label" for="smm-exec-link">Proof link <span class="hint">(optional)</span></label>
        <input class="input" id="smm-link" type="url" placeholder="https://..." />
      </div>

      <label class="dropzone mt-14" id="smm-drop" for="smm-files">
        ${icon('upload', 24)}
        <div class="dz-title" id="smm-dz-title">Click to select screenshot 0/6</div>
        <div class="dz-sub">JPG, PNG or WebP · max 6 images, 5 MB each</div>
      </label>
      <input id="smm-files" type="file" accept="image/png,image/jpeg,image/webp" multiple class="hide" />
      <div class="proof-grid mt-10" id="smm-previews"></div>

      <div class="field mt-14">
        <label class="label" for="smm-note">Note for the verifier <span class="hint">(optional)</span></label>
        <textarea class="textarea" id="smm-note" maxlength="500" placeholder="Your username on the platform, anything the verifier should know…"></textarea>
      </div>`,
    footer: `<div class="runner-footer">
      <button class="btn btn-ghost runner-giveup" type="button" data-give-up>Close</button>
      <button class="btn runner-submit is-waiting" type="button" data-submit-proof disabled>Please wait ${clock(seconds)}</button>
    </div>`,
    onClose: () => {
      if (ticker) clearInterval(ticker);
      urls.forEach((u) => URL.revokeObjectURL(u));
    }
  });

  const timerEl = modal.root.querySelector('[data-timer]');
  const timerBox = modal.root.querySelector('[data-timer-box]');
  const submitBtn = modal.root.querySelector('[data-submit-proof]');
  const previews = modal.root.querySelector('#smm-previews');
  const input = modal.root.querySelector('#smm-files');
  const drop = modal.root.querySelector('#smm-drop');
  const dzTitle = modal.root.querySelector('#smm-dz-title');

  const syncSubmit = () => {
    const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
    const ready = left === 0 && files.length > 0;
    submitBtn.disabled = !ready;
    submitBtn.classList.toggle('is-waiting', !ready);
    submitBtn.classList.toggle('is-ready', ready);
    if (left > 0) submitBtn.textContent = `Please wait ${clock(left)}`;
    else submitBtn.textContent = files.length > 0 ? 'Submit proof' : 'Add a screenshot';
    if (dzTitle) dzTitle.textContent = `Click to select screenshot ${files.length}/6`;
  };

  ticker = setInterval(() => {
    const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
    if (!timerEl || !timerEl.isConnected) { clearInterval(ticker); ticker = null; return; }
    timerEl.textContent = clock(left);
    if (left === 0) {
      clearInterval(ticker);
      ticker = null;
      timerBox?.classList.add('done');
    }
    syncSubmit();
  }, 250);

  const renderPreviews = () => {
    urls.forEach((u) => URL.revokeObjectURL(u));
    urls.length = 0;
    previews.innerHTML = files.map((f, i) => {
      const u = URL.createObjectURL(f);
      urls.push(u);
      return `<div class="proof-preview"><img src="${u}" alt="Screenshot ${i + 1}" /><button class="pp-remove" type="button" data-remove="${i}" aria-label="Remove">${icon('x', 14)}</button></div>`;
    }).join('');
    previews.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', () => {
      files.splice(Number(b.dataset.remove), 1);
      renderPreviews();
      syncSubmit();
    }));
  };

  const addFiles = (list) => {
    Array.from(list || []).forEach((f) => {
      if (files.length >= 6) { toast('Up to 6 screenshots per task.', 'error'); return; }
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { toast('Use JPG, PNG or WebP screenshots.', 'error'); return; }
      if (f.size > 5 * 1024 * 1024) { toast('Each screenshot must be under 5 MB.', 'error'); return; }
      files.push(f);
    });
    renderPreviews();
    syncSubmit();
  };

  input.addEventListener('change', () => { addFiles(input.files); input.value = ''; });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', (e) => addFiles(e.dataTransfer?.files));

  modal.root.querySelector('[data-give-up]').addEventListener('click', () => modal.close());

  submitBtn.addEventListener('click', async () => {
    if (submitBtn.disabled) return;
    setBusy(submitBtn, true, 'Uploading');
    try {
      const paths = [];
      let firstHash = null;
      for (const f of files) {
        const { path, hash } = await uploadProofFile(f, state.profile.id);
        paths.push(path);
        if (!firstHash && hash) firstHash = hash;
      }
      await rpc('smm_submit_proof', {
        p_task_id: t.id,
        p_proof_paths: paths,
        p_proof_link: (modal.root.querySelector('#smm-link')?.value || '').trim() || null,
        p_note: (modal.root.querySelector('#smm-note')?.value || '').trim() || null,
        p_proof_hash: firstHash,
        p_time_spent: Math.max(0, Math.min(86400, Math.ceil((Date.now() - startedAtMs) / 1000)))
      });
      toast('Proof submitted. The reward is pending verification.', 'success');
      modal.close();
      await freshContext();
      if (typeof onDone === 'function') await onDone();
      else await renderSmmTasks(root);
    } catch (e) {
      const raw = String((e && (e.raw?.message || e.message)) || '');
      if (/TIMER_NOT_FINISHED/i.test(raw)) {
        try {
          const fresh = await rpc('smm_task_detail', { p_task_id: t.id });
          const end = fresh?.task?.timer_ends_at;
          if (end) endsAt = new Date(end).getTime();
        } catch (_) { /* keep the local deadline */ }
        toast('The server timer has not finished yet. The countdown is now synced to the real deadline.', 'error', 8000);
        syncSubmit();
      } else {
        toast(friendlyError(e), 'error', 7000);
      }
      setBusy(submitBtn, false);
    }
  });

  syncSubmit();
}

/* =========================================================== PRESENTATION ==
   Number counter animation, rank tiers and the worker analytics page. Pure
   display code: every number it shows is a real value from the wallet, the
   ledger or approved tasks. */

const WEEK_TIERS = [
  [2.5, 'Elite'], [1, 'Diamond'], [0.5, 'Platinum'],
  [0.15, 'Gold'], [0.05, 'Silver'], [0, 'Bronze']
];
const LIFETIME_TIERS = [
  [5000, 'Elite'], [1000, 'Diamond'], [250, 'Platinum'],
  [50, 'Gold'], [10, 'Silver'], [0, 'Bronze']
];

function tierBadge(tiers, earned, title) {
  const e = Number(earned || 0);
  const tier = (tiers.find(([min]) => e >= min) || tiers[tiers.length - 1])[1];
  return `<span class="tier-badge tier-${esc(tier)}"${title ? ` title="${esc(title)}"` : ''}>${icon('star', 10)} ${esc(tier)}</span>`;
}

function rankTierBadge(earned, title) {
  return tierBadge(WEEK_TIERS, earned, title);
}

function lifetimeTierBadge(earned, title) {
  return tierBadge(LIFETIME_TIERS, earned, title);
}

function animateCounters(scope) {
  if (!scope) return;
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  scope.querySelectorAll('[data-count-to]').forEach((el) => {
    const target = Number(el.dataset.countTo || 0);
    const dec = Number(el.dataset.countDecimals || 0);
    if (!Number.isFinite(target)) return;
    const fmt = (v) => v.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
    if (reduce || target === 0) { el.textContent = fmt(target); return; }
    const start = performance.now();
    const dur = 650;
    const tick = (now) => {
      if (!el.isConnected) return;
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = fmt(target * eased);
      if (t < 1) requestAnimationFrame(tick);
      else el.textContent = fmt(target);
    };
    requestAnimationFrame(tick);
  });
}

function barChart(values, tone, fmt) {
  const max = Math.max(...values.map((v) => Number(v) || 0), 0.000001);
  return `<div class="bar-chart">${values.map((v) => {
    const n = Number(v) || 0;
    const h = Math.max(2, Math.round((n / max) * 100));
    return `<div class="bar-col" title="${esc(fmt(n))}"><i style="height:${h}%;background:${tone}"></i></div>`;
  }).join('')}</div>`;
}

/* ============================================================ ANALYTICS === */
export async function renderWorkerAnalytics(root) {
  root.innerHTML = loadingBlock('Loading analytics');
  await freshContext();

  const [ledgerRes, tasksRes] = await Promise.all([
    sb.from('ledger_entries')
      .select('kind,available_delta,created_at')
      .order('created_at', { ascending: false }).limit(400),
    rpc('my_tasks', { p_status: 'approved', p_limit: 100, p_offset: 0 }).catch(() => ({ items: [] }))
  ]);

  const entries = ledgerRes.error ? [] : (ledgerRes.data || []);
  const approved = tasksRes?.items || [];
  const EARN = new Set(['task_reward', 'smm_task_reward', 'referral_bonus']);
  const earnings = entries.filter((e) => EARN.has(e.kind) && Number(e.available_delta) > 0);

  const dayKey = (ts) => new Date(ts).toISOString().slice(0, 10);
  const byDay = new Map();
  earnings.forEach((e) => {
    const k = dayKey(e.created_at);
    byDay.set(k, (byDay.get(k) || 0) + Number(e.available_delta));
  });
  const tasksByDay = new Map();
  approved.forEach((t) => {
    const k = dayKey(t.reviewed_at || t.submitted_at || t.created_at);
    tasksByDay.set(k, (tasksByDay.get(k) || 0) + 1);
  });

  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - (13 - i));
    const k = d.toISOString().slice(0, 10);
    return { k, earn: byDay.get(k) || 0, tasks: tasksByDay.get(k) || 0 };
  });

  const sum = (arr) => arr.reduce((s, x) => s + x, 0);
  const today = days[13].earn;
  const week = sum(days.slice(7).map((d) => d.earn));
  const fortnight = sum(days.map((d) => d.earn));
  const total = Number(state.wallet?.lifetime_earned || 0);
  const anyData = fortnight > 0 || approved.length > 0;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Performance</span><h2>Analytics</h2><p>Your approved rewards and completed tasks over time.</p></div>
      <a class="btn btn-ghost" href="#/history">${icon('book', 15)} Full history</a>
    </div>

    <section class="stat-grid" aria-label="Earnings summary">
      <div class="stat-box"><h3 class="c-green">${esc(usdt(today))}</h3><p>${icon('coin', 12)} Earned today</p></div>
      <div class="stat-box"><h3 class="c-green">${esc(usdt(week))}</h3><p>${icon('trending', 12)} Last 7 days</p></div>
      <div class="stat-box"><h3 class="c-green">${esc(usdt(fortnight))}</h3><p>${icon('trending', 12)} Last 14 days</p></div>
      <div class="stat-box"><h3 class="c-orange">${esc(usdt(total))}</h3><p>${icon('wallet', 12)} Lifetime</p></div>
    </section>

    ${anyData ? `
    <div class="grid grid-2" style="align-items:start">
      <div class="card card-pad">
        <div class="row-between mb-10"><h3 style="font-size:13px">Earnings, last 14 days</h3><span class="badge grey">USDT</span></div>
        ${barChart(days.map((d) => d.earn), '#26a17b', (v) => `${usdt(v)} USDT`)}
      </div>
      <div class="card card-pad">
        <div class="row-between mb-10"><h3 style="font-size:13px">Tasks completed, last 14 days</h3><span class="badge grey">count</span></div>
        ${barChart(days.map((d) => d.tasks), '#ff6b35', (v) => `${v} task${v === 1 ? '' : 's'}`)}
      </div>
    </div>
    <p class="tiny dim center mt-14">Computed from your own ledger and approved tasks. Older history stays in your transaction record.</p>`
      : emptyState({
        iconName: 'chart',
        title: 'No approved activity in the last 14 days',
        text: 'Charts fill in as soon as proofs are approved and rewards are released.',
        action: '<a class="btn btn-primary" href="#/tasks">Browse tasks</a>'
      })}`;
}


/* ========================================================== ANNOUNCEMENTS === */
export async function renderAnnouncements(root) {
  root.innerHTML = loadingBlock('Loading announcements');
  let rows = [];
  try {
    rows = (await rpc('my_announcements', { p_limit: 30 })) || [];
  } catch (e) {
    root.innerHTML = errorPanel(friendlyError(e));
    return;
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Inbox</span><h2>Announcements</h2><p>Messages published by the TM GROW team. Only real, sent announcements appear here.</p></div>
    </div>
    ${rows.length ? `<div class="col" style="gap:14px">${rows.map((a) => {
      const img = safeHttpUrl(a.image_url);
      const link = safeHttpUrl(a.link_url);
      return `<article class="card card-pad">
        ${img ? `<img src="${esc(img)}" alt="" style="width:100%;border-radius:12px;margin-bottom:12px;max-height:220px;object-fit:cover" />` : ''}
        <div class="row-between" style="gap:10px;align-items:flex-start;flex-wrap:wrap">
          <h3 style="font-size:16px">${esc(a.title)}</h3>
          <span class="tiny dim">${esc(ago(a.sent_at))}</span>
        </div>
        <p class="small muted mt-8" style="white-space:pre-wrap;line-height:1.7">${esc(a.body)}</p>
        ${link ? `<a class="btn btn-ghost btn-sm mt-12" href="${esc(link)}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Open link</a>` : ''}
      </article>`;
    }).join('')}</div>` : emptyState({
      iconName: 'bell',
      title: 'No announcements yet',
      text: 'Platform announcements appear here once an administrator publishes them.'
    })}`;
}

/* ========================================================== TRUST CENTER === */
export async function renderTrustCenter(root) {
  await freshContext();
  root.innerHTML = loadingBlock('Reading your trust data');

  const p = state.profile || {};
  const c = state.counts || {};
  const trust = Math.max(0, Math.min(1000, Number(p.trust_score ?? 549)));
  const label = trust >= 850 ? 'Whitelist' : trust >= 550 ? 'Trusted' : trust >= 250 ? 'Established' : 'Newbie';
  const nextAt = trust >= 850 ? 1000 : trust >= 550 ? 850 : trust >= 250 ? 550 : 250;

  const [withdrawals, identities, social] = await Promise.all([
    sb.from('withdrawals').select('id,amount,status,created_at').eq('status', 'paid')
      .order('created_at', { ascending: false }).limit(5),
    rpc('my_identities').catch(() => []),
    rpc('my_social_accounts').catch(() => [])
  ]);

  const paid = withdrawals.error ? [] : (withdrawals.data || []);
  const ids = Array.isArray(identities) ? identities : [];
  const accounts = Array.isArray(social) ? social : [];
  const linked = accounts.filter((a) => a && a.status === 'linked');
  const provider = state.session?.user?.app_metadata?.provider || (ids[0]?.provider || 'email');
  const emailConfirmed = !!state.session?.user?.email_confirmed_at;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Reputation</span><h2>Trust center</h2><p>Every number on this page is read from your account, tasks and payouts.</p></div>
      <a class="btn btn-ghost btn-sm" href="#/my-tasks">${icon('checkCircle', 14)} My tasks</a>
    </div>

    <div class="card card-pad" style="background:radial-gradient(circle at 10% 0%, rgba(249,115,22,.16), transparent 55%), var(--surface);border-color:rgba(249,115,22,.24)">
      <div class="row-between" style="gap:12px;align-items:flex-end;flex-wrap:wrap">
        <div>
          <div class="kpi-label">Trust score</div>
          <div style="font-size:34px;font-weight:800;letter-spacing:-1.4px;margin-top:4px">${trust} <span class="small muted">/ 1000</span></div>
        </div>
        <span class="badge gold">${esc(label)}</span>
      </div>
      <div class="progress trust-progress mt-12"><i style="width:${Math.round(trust / 10)}%"></i></div>
      <div class="tiny dim mt-6">${nextAt > trust ? `${nextAt - trust} points to the next tier (${nextAt}).` : 'Top trust tier reached.'} Approved tasks add +1, high-value ones +2; rejected proofs lower the score.</div>
    </div>

    <div class="kpis mt-18">
      ${kpi({ label: 'Approved tasks', value: Number(c.my_approved_tasks || 0), iconName: 'checkCircle', tone: 'green', foot: 'Released rewards' })}
      ${kpi({ label: 'Pending review', value: Number(c.my_pending_submissions || 0), iconName: 'clock', tone: 'gold', foot: 'Waiting on a verifier' })}
      ${kpi({ label: 'Rejected', value: Number(c.my_rejected_tasks || 0), iconName: 'xCircle', tone: 'red', foot: 'With a stated reason' })}
      ${kpi({ label: 'Paid withdrawals', value: paid.length, iconName: 'wallet', tone: 'blue', foot: paid[0] ? `Last ${esc(usdt(paid[0].amount))} USDT` : 'None yet' })}
    </div>

    <div class="grid grid-2 mt-18" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>Account verification</h3><span class="badge ${emailConfirmed || p.telegram_id ? 'green' : 'grey'}">${emailConfirmed || p.telegram_id ? 'Verified sign-in' : 'Limited'}</span></div>
        <div class="card-body">
          <div class="list">
            <div class="list-row"><div class="list-main"><div class="list-title">Sign-in provider</div><div class="list-sub">${esc(String(provider).replace('custom:', ''))}</div></div>${emailConfirmed || p.telegram_id ? '<span class="badge green">OK</span>' : '<span class="badge grey">—</span>'}</div>
            <div class="list-row"><div class="list-main"><div class="list-title">Telegram</div><div class="list-sub">${p.telegram_id ? 'Linked to this account' : 'Not linked'}</div></div>${p.telegram_id ? '<span class="badge green">OK</span>' : '<span class="badge grey">—</span>'}</div>
            <div class="list-row"><div class="list-main"><div class="list-title">Task accounts</div><div class="list-sub">${linked.length} verified social account${linked.length === 1 ? '' : 's'}</div></div><a class="btn btn-ghost btn-sm" href="#/accounts">Manage</a></div>
            <div class="list-row"><div class="list-main"><div class="list-title">Account status</div><div class="list-sub">${esc(String(p.status || 'active'))}</div></div>${statusBadge(p.status || 'active')}</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>Payout record</h3><a class="small brand-text" href="#/history">Full history</a></div>
        <div class="card-body">
          ${paid.length ? `<div class="list">${paid.map((w) => `
            <div class="list-row">
              <div class="list-main"><div class="list-title">${esc(usdt(w.amount))} USDT</div><div class="list-sub">${esc(ago(w.created_at))}</div></div>
              ${statusBadge('paid', 'Completed')}
            </div>`).join('')}</div>` : '<p class="small muted">No completed withdrawal yet. Paid payouts appear here with their real amount.</p>'}
        </div>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Feedback</h3><span class="badge grey">Verified only</span></div>
      <div class="card-body">
        <p class="small muted">TM GROW does not publish invented ratings or reviews. When a verified public business profile exists, its real reviews can be linked here.</p>
      </div>
    </div>`;
}
