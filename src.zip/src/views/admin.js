/* Master admin panel.
   Every action calls a SECURITY DEFINER RPC that re-checks the caller's
   role on the server and writes an audit row. The UI hides controls a role
   cannot use, but hiding is never the only protection. */

import { rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import { state, loadPublicData } from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, usdt, ago, shortDate, dateTime, statusBadge, platformMeta, platformIcon,
  toast, openModal, confirmDialog, loadingBlock, emptyState, errorPanel, signedProofUrl,
  safeHttpUrl, setBusy, pct, debounce, copyText, jsonPretty, uploadProofFile
} from '../lib/ui.js?v=2025-10-12-39';

const ROLES = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER', 'SUPPORT', 'FINANCE'];

/* Reportable suspension reasons. The key is stored for reporting; the text is
   what the user reads and can be edited before saving. */
const SUSPEND_REASONS = [
  ['automation_tools', 'Using automation tools or bots'],
  ['fake_submissions', 'Fake task submissions'],
  ['duplicate_accounts', 'Duplicate accounts'],
  ['suspicious_login', 'Suspicious login activity'],
  ['vpn_proxy', 'VPN or proxy abuse'],
  ['reused_proofs', 'Reused screenshots or proofs'],
  ['referral_abuse', 'Manipulating referrals'],
  ['spam_fraud', 'Spam or fraudulent activity'],
  ['tos_violation', 'Terms of Service violation'],
  ['other', 'Other (custom reason)']
];

const RISK_LABEL = {
  1: ['green', 'LOW'],
  2: ['gold', 'MEDIUM'],
  3: ['orange', 'HIGH'],
  4: ['red', 'CRITICAL']
};

function riskOf(severity) {
  const s = Math.max(1, Math.min(4, Number(severity) || 1));
  return RISK_LABEL[s];
}

const ROLE_HINT = {
  OWNER: 'Full platform control: admin roles, settings, money and moderation.',
  SUPER_ADMIN: 'Everything except granting the OWNER role.',
  ADMIN: 'Users, campaigns, services, countries, settings and audit.',
  MODERATOR: 'Users, campaigns, tasks and proof review.',
  VERIFIER: 'Proof verification only.',
  SUPPORT: 'Support inbox, announcements and read-only finance.',
  FINANCE: 'Deposits, withdrawals, ledger, balances and settings read.'
};

function allowed(roles) {
  return roles.includes(state.profile?.admin_role);
}

function forbiddenHTML(roles) {
  return `<div class="card card-pad center" style="max-width:540px;margin:30px auto;padding:44px 22px">
    <div class="empty-ic">${icon('lock', 22)}</div>
    <h2 style="font-size:18px;margin-bottom:8px">Your role cannot open this page</h2>
    <p class="small muted" style="margin-bottom:16px">This section needs one of: ${roles.map(esc).join(', ')}. Your role is ${esc(state.profile?.admin_role || 'none')}. The server enforces the same rule, so no data is loaded.</p>
    <a class="btn btn-ghost" href="#/admin">Back to overview</a>
  </div>`;
}

function kpi({ label, value, suffix = '', foot = '', iconName = 'chart', tone = '' }) {
  return `<div class="kpi ${tone}">
    <div class="kpi-top">
      <div class="kpi-label">${esc(label)}</div>
      <span class="kpi-ic">${icon(iconName, 16)}</span>
    </div>
    <div class="kpi-num">${value}${suffix ? `<small>${esc(suffix)}</small>` : ''}</div>
    ${foot ? `<div class="kpi-foot">${foot}</div>` : ''}
  </div>`;
}

function money(n) { return `${esc(usdt(n))} <span class="small muted">USDT</span>`; }

/* Glass StatsCard — vanilla translation of the reference React/Framer-Motion
   component (glass card, y:-5 hover lift, emerald growth indicator). The lift
   and glow live in styles/app.css under .shell .stats-card; markup stays plain
   so every admin page can reuse it. `delta` is only rendered when a real,
   live-derived change exists — no invented percentages. */
function statsCard({ title, value, suffix = '', delta = '', foot = '', iconName = 'chart', tone = 'brand' }) {
  return `<div class="stats-card" data-tone="${esc(tone)}">
    <div class="sc-top">
      <div class="sc-main">
        <p class="sc-label">${esc(title)}</p>
        <h2 class="sc-value">${value}${suffix ? `<small>${esc(suffix)}</small>` : ''}</h2>
        ${delta ? `<p class="sc-delta up">${icon('arrowUpRight', 13)}${esc(delta)}</p>` : ''}
        ${foot ? `<p class="sc-foot">${esc(foot)}</p>` : ''}
      </div>
      <span class="sc-icon">${icon(iconName, 20)}</span>
    </div>
  </div>`;
}

function tableHtml(headers, rows) {
  return `<div class="table-wrap responsive">
    <table class="table responsive-table">
      <thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>
      <tbody>${rows.join('')}</tbody>
    </table>
  </div>`;
}

function pagerHtml(total, limit, offset) {
  const from = total === 0 ? 0 : offset + 1;
  const to = Math.min(total, offset + limit);
  return `<div class="pager"><span>${from}–${to} of ${total}</span>
    <div class="pager-btns">
      <button class="btn btn-ghost btn-sm" type="button" data-page="prev" ${offset <= 0 ? 'disabled' : ''}>Previous</button>
      <button class="btn btn-ghost btn-sm" type="button" data-page="next" ${offset + limit >= total ? 'disabled' : ''}>Next</button>
    </div></div>`;
}

function bindPager(container, { limit, offset, total, setOffset, reload }) {
  const prev = container.querySelector('[data-page="prev"]');
  const next = container.querySelector('[data-page="next"]');
  if (prev) prev.addEventListener('click', () => { setOffset(Math.max(0, offset - limit)); reload(); });
  if (next) next.addEventListener('click', () => { setOffset(offset + limit); reload(); });
}

function bindCopy(container) {
  container.querySelectorAll('[data-copy]').forEach((b) => b.addEventListener('click', async (e) => {
    e.stopPropagation();
    const ok = await copyText(b.dataset.copy || '');
    toast(ok ? 'Copied.' : 'Copy failed.', ok ? 'success' : 'error');
  }));
}

/* Modal that resolves with the text typed, or null when cancelled. */
function askNote(title, hint, label = 'Note', confirmLabel = 'Submit', danger = true) {
  return new Promise((resolve) => {
    let result = null;
    const m = openModal({
      title,
      body: `${hint ? `<p class="small muted" style="line-height:1.65">${esc(hint)}</p>` : ''}
        <div class="field mt-14">
          <label class="label">${esc(label)} <span class="hint">(optional)</span></label>
          <textarea class="textarea" id="ask-note" maxlength="600" placeholder="Write a short note…"></textarea>
        </div>`,
      footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" type="button" data-ok>${esc(confirmLabel)}</button>`,
      onClose: () => resolve(result)
    });
    m.root.querySelector('[data-cancel]').onclick = () => { result = null; m.close(); };
    m.root.querySelector('[data-ok]').onclick = () => {
      result = m.root.querySelector('#ask-note').value.trim();
      m.close();
    };
  });
}

function areaChart(series, valueKey = 'approved', legend = 'approved tasks', unit = '') {
  const pts = series || [];
  if (pts.length < 2) return '<p class="small muted">Not enough days to draw a trend yet.</p>';
  const val = (p) => Number(p?.[valueKey] || 0);
  const w = 600;
  const h = 150;
  const pad = 8;
  const max = Math.max(1, ...pts.map(val));
  const step = (w - pad * 2) / (pts.length - 1);
  const coords = pts.map((p, i) => [
    pad + i * step,
    h - pad - (val(p) / max) * (h - pad * 2)
  ]);
  const line = coords.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  const area = `${line} L${(pad + (pts.length - 1) * step).toFixed(1)} ${h - pad} L${pad} ${h - pad} Z`;
  const grad = `chart-gradient-${valueKey}`;
  const last = pts[pts.length - 1];
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="${esc(legend)} per day">
    <defs>
      <linearGradient id="${grad}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="rgba(255,122,24,0.45)" />
        <stop offset="100%" stop-color="rgba(255,122,24,0)" />
      </linearGradient>
    </defs>
    <path class="area" fill="url(#${grad})" d="${area}" />
    <path class="line" d="${line}" />
  </svg>
  <div class="row-between tiny dim mt-6">
    <span>${esc(pts[0].date)}</span>
    <span>${Number(val(last))}${unit ? ' ' + esc(unit) : ''} ${esc(legend)} on ${esc(last.date)}</span>
    <span>${esc(last.date)}</span>
  </div>`;
}

/* ============================================================== OVERVIEW === */
export async function renderAdminOverview(root) {
  let days = 7;
  let data = null;
  let modules = null;

  const load = async () => {
    root.innerHTML = loadingBlock('Reading platform data');
    try {
      const [overview, features] = await Promise.all([
        rpc('admin_overview', { p_days: days }),
        rpc('admin_feature_status').catch(() => null)
      ]);
      data = overview;
      modules = features;
      if (features) state.featureStatus = features;
    } catch (e) {
      root.innerHTML = errorPanel(friendlyError(e));
      return;
    }
    paint();
  };

  const paint = () => {
    const t = data?.totals || {};
    const f = data?.finance || {};
    const series = data?.series || [];
    const top = data?.top_services || [];
    const maintenance = state.settings?.maintenance === true;
    const ms = modules || state.featureStatus || null;
    const modCounts = ms?.counts || {};
    const attention = (ms?.modules || [])
      .filter((m) => ['needs_config', 'error', 'disabled'].includes(m.status))
      .slice(0, 6);

    root.innerHTML = `<div class="page-head">
        <div><span class="eyebrow">Control room</span><h2>Master Command Center</h2><p>Monitor, manage and control your entire TM Grow platform. Every figure is read live from the database at ${esc(dateTime(data.generated_at))}.</p></div>
        <div class="row-wrap">
          ${[7, 30, 90].map((d) => `<button class="chip ${d === days ? 'active' : ''}" type="button" data-days="${d}">${d} days</button>`).join('')}
          <button class="btn btn-ghost btn-sm" type="button" data-refresh>${icon('refresh', 14)} Refresh</button>
        </div>
      </div>

      <div class="status-strip">
        <div class="status-item">
          <span class="status-dot ${maintenance ? 'warn' : 'ok'}"></span>
          <span class="status-label">Platform</span>
          <strong>${maintenance ? 'Maintenance' : 'Live'}</strong>
        </div>
        <div class="status-item">
          <span class="status-dot ok"></span>
          <span class="status-label">Database</span>
          <strong>Connected</strong>
        </div>
        <div class="status-item">
          <span class="status-dot ${state.session ? 'ok' : 'warn'}"></span>
          <span class="status-label">Auth</span>
          <strong>${state.session ? 'Session active' : 'No session'}</strong>
        </div>
        <div class="status-item">
          <span class="status-dot ${Number(modCounts.error || 0) > 0 ? 'err' : 'ok'}"></span>
          <span class="status-label">Modules</span>
          <strong>${Number(modCounts.active || 0)} active / ${Number(modCounts.error || 0)} failing</strong>
        </div>
        <div class="status-item">
          <span class="status-icon">${icon('shield', 15)}</span>
          <span class="status-label">Verification</span>
          <strong>${Number(t.proofs_pending || 0)} waiting</strong>
        </div>
        <div class="status-item">
          <span class="status-icon">${icon('wallet', 15)}</span>
          <span class="status-label">Payouts</span>
          <strong>${Number(t.withdrawals_pending || 0)} pending</strong>
        </div>
      </div>

      ${allowed(['OWNER', 'SUPER_ADMIN']) ? `<div class="card card-pad mt-14" style="border-color:${maintenance ? 'rgba(255,84,104,.38)' : 'var(--line)'}">
        <div class="row-between" style="gap:14px;flex-wrap:wrap">
          <div style="min-width:220px">
            <div class="strong" style="font-size:14px">Maintenance mode ${maintenance ? '<span class="badge red">On</span>' : '<span class="badge grey">Off</span>'}</div>
            <div class="tiny dim mt-6">${maintenance
              ? 'Every worker and buyer sees “We’ll be back soon”. Admins keep access and can turn it off.'
              : 'Turning it on freezes the app for everyone except signed-in admins.'}</div>
          </div>
          <button class="btn ${maintenance ? 'btn-danger' : 'btn-soft'} btn-sm" type="button" data-maintenance="${maintenance ? '0' : '1'}" data-maintenance-toggle>
            ${maintenance ? 'Turn maintenance off' : 'Turn maintenance on'}
          </button>
        </div>
      </div>` : ''}

      <div class="stats-grid mt-14">
        ${statsCard({ title: 'Total users', value: Number(t.users || 0), delta: `+${Number(t.new_users || 0)} new in ${Number(data.days || days)}d`, foot: `${Number(t.admins || 0)} admin accounts`, iconName: 'users', tone: 'brand' })}
        ${statsCard({ title: 'Workers', value: Number(t.workers || 0), foot: 'Registered worker accounts', iconName: 'target', tone: 'gold' })}
        ${statsCard({ title: 'Buyers', value: Number(t.buyers || 0), foot: 'Fund campaigns in escrow', iconName: 'megaphone', tone: 'blue' })}
        ${statsCard({ title: 'Active campaigns', value: Number(t.campaigns_active || 0), foot: `${Number(t.campaigns_pending || 0)} pending review · ${Number(t.campaigns_completed || 0)} completed`, iconName: 'layers', tone: 'green' })}
        ${statsCard({ title: 'Available tasks', value: Number(t.tasks_available || 0), delta: `${Number(t.approved_in_range || 0)} approved in ${Number(data.days || days)}d`, foot: `${Number(t.tasks_claimed || 0)} claimed right now`, iconName: 'tasks', tone: 'violet' })}
        ${statsCard({ title: 'Pending verification', value: Number(t.proofs_pending || 0), foot: Number(t.proofs_oldest_hours || 0) > 0 ? `Oldest ${Number(t.proofs_oldest_hours)}h in queue` : 'Queue is clear', iconName: 'shield', tone: 'gold' })}
        ${statsCard({ title: 'Pending withdrawals', value: Number(t.withdrawals_pending || 0), foot: `${esc(usdt(t.withdrawals_pending_amount))} USDT requested`, iconName: 'wallet', tone: 'red' })}
        ${statsCard({ title: 'Total revenue', value: esc(usdt(f.revenue)), suffix: 'USDT', foot: `Rewards paid (lifetime) ${esc(usdt(f.rewards_paid))} USDT`, iconName: 'trending', tone: 'green' })}
      </div>

      <div class="grid grid-2 mt-18" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Approved tasks per day</h3><span class="badge grey">${Number(data.days || days)} days</span></div>
          <div class="card-body">${areaChart(series)}</div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Rewards paid per day</h3><span class="badge gold">USDT</span></div>
          <div class="card-body">${areaChart(series, 'rewards', 'rewards', 'USDT')}</div>
        </div>
      </div>

      <div class="grid grid-2 mt-18" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Finance</h3><span class="badge gold">USDT</span></div>
          <div class="card-body">
            <div class="row-between small"><span class="muted">Available in user wallets</span><span class="strong">${money(f.available)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Pending (awaiting review)</span><span>${money(f.pending)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Reserved (escrow + payouts)</span><span>${money(f.reserved)}</span></div>
            <div class="divider"></div>
            <div class="row-between small"><span class="muted">Platform revenue</span><span class="strong gold-text">${money(f.revenue)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Rewards paid (lifetime)</span><span>${money(f.rewards_paid)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Rewards paid in range</span><span>${money(f.rewards_paid_in_range)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Deposits approved</span><span>${money(f.deposits_approved)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Withdrawals paid</span><span>${money(f.withdrawals_paid)}</span></div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Module status</h3><a class="small brand-text" href="#/admin/system">Details</a></div>
          <div class="card-body">
            ${ms ? `
              <div class="row-wrap mb-10">
                <span class="badge green">${Number(modCounts.active || 0)} active</span>
                <span class="badge gold">${Number(modCounts.needs_config || 0)} need setup</span>
                <span class="badge grey">${Number(modCounts.coming_soon || 0)} coming soon</span>
                ${Number(modCounts.error || 0) > 0 ? `<span class="badge red">${Number(modCounts.error)} error</span>` : ''}
              </div>
              <div class="tiny dim mb-10">Read live from <span class="mono">admin_feature_status()</span> at ${esc(dateTime(ms.checked_at))}.</div>
              ${attention.length ? `<div class="list">${attention.map((m) => `
                <div class="list-row">
                  <span class="badge ${m.status === 'error' ? 'red' : m.status === 'disabled' ? 'grey' : 'gold'}">${m.status === 'needs_config' ? 'Setup' : m.status === 'error' ? 'Error' : 'Off'}</span>
                  <div class="list-main" style="min-width:0">
                    <div class="list-title">${esc(m.label)}</div>
                    <div class="list-sub truncate">${esc(m.detail || '')}</div>
                  </div>
                </div>`).join('')}</div>`
                : '<p class="small muted">Every installed module is active. Planned modules stay labelled “soon” in the navigation.</p>'}
            ` : '<p class="small muted">Run <span class="mono">supabase/admin-control-room.sql</span> to read the real status of every module.</p>'}
          </div>
        </div>
      </div>

      <div class="grid grid-3 mt-18" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Work queues</h3><span class="badge orange">Live</span></div>
          <div class="card-body">
            <a class="list-row" href="#/admin/proofs"><span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('shield', 15)}</span><div class="list-main"><div class="list-title">Proof verification</div><div class="list-sub">${Number(t.proofs_pending || 0)} waiting · ${Number(t.approved_in_range || 0)} approved in range</div></div>${icon('chevronRight', 15)}</a>
            <a class="list-row" href="#/admin/withdrawals"><span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('wallet', 15)}</span><div class="list-main"><div class="list-title">Withdrawals</div><div class="list-sub">${Number(t.withdrawals_pending || 0)} open request(s)</div></div>${icon('chevronRight', 15)}</a>
            <a class="list-row" href="#/admin/deposits"><span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('download', 15)}</span><div class="list-main"><div class="list-title">Deposits</div><div class="list-sub">${Number(t.deposits_pending || 0)} waiting for finance</div></div>${icon('chevronRight', 15)}</a>
            <a class="list-row" href="#/admin/flags"><span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('flag', 15)}</span><div class="list-main"><div class="list-title">Fraud flags</div><div class="list-sub">${Number(t.open_flags || 0)} open</div></div>${icon('chevronRight', 15)}</a>
            <a class="list-row" href="#/admin/support"><span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('ticket', 15)}</span><div class="list-main"><div class="list-title">Support</div><div class="list-sub">${Number(t.open_tickets || 0)} open ticket(s)</div></div>${icon('chevronRight', 15)}</a>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Tasks &amp; campaigns</h3><span class="badge grey">All time</span></div>
          <div class="card-body">
            <div class="row-between small"><span class="muted">Available tasks</span><span>${Number(t.tasks_available || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Claimed</span><span>${Number(t.tasks_claimed || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Submitted</span><span>${Number(t.tasks_submitted || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Approved</span><span class="green">${Number(t.tasks_approved || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Rejected</span><span class="red">${Number(t.tasks_rejected || 0)}</span></div>
            <div class="divider"></div>
            <div class="row-between small"><span class="muted">Active campaigns</span><span>${Number(t.campaigns_active || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Pending review</span><span>${Number(t.campaigns_pending || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Completed</span><span>${Number(t.campaigns_completed || 0)}</span></div>
            <div class="row-between small mt-6"><span class="muted">Admins</span><span>${Number(t.admins || 0)}</span></div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Top services</h3><a class="small brand-text" href="#/admin/services">Pricing</a></div>
          <div class="card-body">
            ${top.length ? `<div class="list">${top.map((s) => {
              const m = platformMeta(s.platform);
              return `<div class="list-row">
                <span class="task-ic" style="background:${m.bg};color:${m.color};width:30px;height:30px">${platformIcon(s.platform, 15)}</span>
                <div class="list-main">
                  <div class="list-title">${esc(s.service_name)}</div>
                  <div class="list-sub">${Number(s.approved)} approved · ${esc(usdt(s.spend))} USDT</div>
                </div>
              </div>`;
            }).join('')}</div>` : '<p class="small muted">No approved deliveries in this range yet.</p>'}
          </div>
        </div>
      </div>`;

    root.querySelectorAll('[data-days]').forEach((b) => b.addEventListener('click', () => {
      days = Number(b.dataset.days);
      load();
    }));
    const refresh = root.querySelector('[data-refresh]');
    if (refresh) refresh.addEventListener('click', load);

    const mtBtn = root.querySelector('[data-maintenance-toggle]');
    if (mtBtn) mtBtn.addEventListener('click', async () => {
      const on = mtBtn.dataset.maintenance === '1';
      const ok = await confirmDialog({
        title: on ? 'Turn maintenance mode on?' : 'Turn maintenance mode off?',
        message: on
          ? 'Workers and buyers will see the “We’ll be back soon” screen until you turn it off. Admins keep access.'
          : 'The worker and buyer apps become available again immediately.',
        confirmLabel: on ? 'Turn on' : 'Turn off'
      });
      if (!ok) return;
      setBusy(mtBtn, true, 'Saving');
      try {
        await rpc('admin_update_setting', { p_key: 'maintenance', p_value: on, p_is_public: true });
        await loadPublicData();
        toast(on ? 'Maintenance mode is on.' : 'Maintenance mode is off.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(mtBtn, false);
      }
    });
  };

  await load();
}

/* ================================================================= USERS === */
export async function renderUsersPanel(root, opts = {}) {
  let q = '';
  let status = '';
  let role = opts.role || '';
  let offset = 0;
  const limit = 25;
  let total = 0;
  let rows = [];

  root.innerHTML = `${opts.title ? `<div class="page-head">
      <div><span class="eyebrow">People</span><h2>${esc(opts.title)}</h2><p>${esc(opts.sub || '')}</p></div>
      ${opts.role === 'worker' ? '<a class="btn btn-ghost btn-sm" href="#/admin/wallets">Wallets</a>' : ''}
      ${opts.role === 'buyer' ? '<a class="btn btn-ghost btn-sm" href="#/admin/campaigns">Campaigns</a>' : ''}
    </div>` : ''}
    <div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="u-q" placeholder="Name, email or referral code" autocomplete="off" /></div>
      <select class="select input-sm" id="u-status" style="max-width:160px">
        <option value="">All statuses</option>
        <option value="active">Active</option>
        <option value="suspended">Suspended</option>
        <option value="banned">Banned</option>
      </select>
      ${opts.role ? '' : `<select class="select input-sm" id="u-role" data-user-role style="max-width:160px">
        <option value="">All account types</option>
        <option value="worker">Workers</option>
        <option value="buyer">Buyers</option>
        <option value="admin">Admins</option>
      </select>`}
    </div>
    <div id="u-list">${loadingBlock('Loading users')}</div>`;

  const listEl = root.querySelector('#u-list');

  const load = async () => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const scrollY = window.scrollY;
    if (wasLoaded) listEl.classList.add('is-refreshing');
    else listEl.innerHTML = loadingBlock('Loading users');
    try {
      const res = await rpc('admin_list_users', {
        p_query: q || null,
        p_status: status || null,
        p_role: role || null,
        p_limit: limit,
        p_offset: offset
      });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['User', 'Type', 'Status', 'Available', 'Pending', 'Earned', 'Approved', 'Joined'],
      rows.map((u) => `<tr data-user="${esc(u.id)}" style="cursor:pointer">
        <td data-label="User">
          <div class="row" style="gap:8px">
            <span class="avatar xs">${u.avatar_url ? `<img src="${esc(u.avatar_url)}" alt="" />` : esc((u.full_name || u.email || 'U').slice(0, 2).toUpperCase())}</span>
            <div style="min-width:0"><div class="truncate">${esc(u.full_name || 'Unnamed')}</div><div class="tiny dim truncate">${esc(u.email || '')}</div></div>
          </div>
        </td>
        <td data-label="Type">${u.admin_role ? `<span class="badge gold">${esc(u.admin_role.replace('_', ' '))}</span>` : u.is_buyer ? '<span class="badge blue">Buyer</span>' : '<span class="badge orange">Worker</span>'}</td>
        <td data-label="Status">${statusBadge(u.status)}</td>
        <td data-label="Available" class="num">${esc(usdt(u.available))}</td>
        <td data-label="Pending" class="num">${esc(usdt(u.pending))}</td>
        <td data-label="Earned" class="num gold-text">${esc(usdt(u.lifetime_earned))}</td>
        <td data-label="Approved" class="num">${Number(u.approved_tasks || 0)}</td>
        <td data-label="Joined">${esc(shortDate(u.created_at))}</td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'users', title: 'No users match', text: 'Clear the filters to see every account.' });
    listEl.dataset.loaded = '1';
    if (wasLoaded) {
      listEl.classList.remove('is-refreshing');
      window.scrollTo(0, scrollY);
    }

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
    listEl.querySelectorAll('[data-user]').forEach((tr) => tr.addEventListener('click', () => openUserModal(tr.dataset.user, load)));
  };

  root.querySelector('#u-q').addEventListener('input', debounce((e) => {
    q = e.target.value.trim();
    offset = 0;
    load();
  }, 320));
  root.querySelector('#u-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; load(); });
  const roleSelect = root.querySelector('[data-user-role]');
  if (roleSelect) roleSelect.addEventListener('change', (e) => { role = e.target.value; offset = 0; load(); });

  await load();
}

/* All users, then the two dedicated views the Master Admin Panel links to. */
export async function renderAdminUsers(root) {
  return renderUsersPanel(root, {});
}

export async function renderAdminWorkers(root) {
  return renderUsersPanel(root, {
    role: 'worker',
    title: 'Worker management',
    sub: 'Earnings, approved work, pending reviews and account state.'
  });
}

export async function renderAdminBuyers(root) {
  return renderUsersPanel(root, {
    role: 'buyer',
    title: 'Buyer management',
    sub: 'Wallet, campaigns, spending and account state.'
  });
}

async function openUserModal(id, refresh) {
  let d;
  try {
    d = await rpc('admin_user_detail', { p_user_id: id });
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }

  const p = d.profile || {};
  const w = d.wallet || {};
  const s = d.stats || {};
  const ledger = d.ledger || [];
  const canStatus = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR']);
  const canRole = allowed(['OWNER']);
  const canMoney = allowed(['OWNER', 'SUPER_ADMIN', 'FINANCE']);

  const m = openModal({
    title: p.full_name || p.email || 'User',
    subtitle: p.email || '',
    wide: true,
    body: `<div class="row-wrap mb-16">
        ${p.admin_role ? `<span class="badge gold">${esc(p.admin_role.replace('_', ' '))}</span>` : ''}
        <span class="badge ${p.is_buyer ? 'blue' : 'orange'}">${p.is_buyer ? 'Buyer' : 'Worker'}</span>
        ${p.is_worker ? '<span class="badge grey">Worker enabled</span>' : ''}
        ${statusBadge(p.status)}
        <span class="badge grey">Trust ${Number(p.trust_score || 0)}</span>
        <span class="badge grey">${esc(p.country_code || 'No country')}</span>
      </div>

      <div class="grid grid-3" style="gap:10px">
        <div class="panel panel-pad"><div class="tiny dim">Available</div><div class="strong">${esc(usdt(w.available))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Pending</div><div class="strong">${esc(usdt(w.pending))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Reserved</div><div class="strong">${esc(usdt(w.reserved))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Lifetime earned</div><div class="strong">${esc(usdt(w.lifetime_earned))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Approved tasks</div><div class="strong">${Number(s.approved_tasks || 0)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Rejected tasks</div><div class="strong">${Number(s.rejected_tasks || 0)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Campaigns</div><div class="strong">${Number(s.campaigns || 0)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Open withdrawals</div><div class="strong">${Number(s.open_withdrawals || 0)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Referrals</div><div class="strong">${Number(s.referrals || 0)}</div></div>
      </div>

      ${canStatus ? `<hr class="divider" />
      <form id="au-suspend" class="col" style="gap:10px">
        <h3 style="font-size:13px">Suspension &amp; restrictions</h3>
        <p class="tiny dim">Enforced by the database: claiming, submitting, campaigns, deposits and withdrawals are blocked immediately and open claims are released. Wallet balances and ledger history are never touched.</p>
        <div class="field-row">
          <div class="field"><label class="label">Type</label>
            <select class="select" name="kind">
              <option value="temporary" ${p.suspension_kind === 'temporary' ? 'selected' : ''}>Temporary suspension</option>
              <option value="permanent" ${p.suspension_kind === 'permanent' ? 'selected' : ''}>Permanent suspension</option>
              <option value="under_review" ${p.suspension_kind === 'under_review' ? 'selected' : ''}>Under investigation</option>
              <option value="restricted" ${p.suspension_kind === 'restricted' ? 'selected' : ''}>Restricted — withdrawals blocked</option>
            </select>
          </div>
          <div class="field"><label class="label">Expires (temporary)</label>
            <input class="input" name="expires" type="datetime-local" value="${p.suspension_expires_at ? new Date(p.suspension_expires_at).toISOString().slice(0, 16) : ''}" />
          </div>
        </div>
        <div class="field"><label class="label">Reason category</label>
          <select class="select" name="reason_key" data-reason-key>
            <option value="">Custom reason</option>
            ${SUSPEND_REASONS.map(([k, label]) => `<option value="${k}" ${p.suspension_reason_key === k ? 'selected' : ''}>${esc(label)}</option>`).join('')}
          </select>
          <span class="hint">Picking a category fills the reason below; you can edit it before saving.</span>
        </div>
        <div class="field"><label class="label">Reason (shown to the user)</label>
          <input class="input" name="reason" data-reason-input maxlength="200" required value="${esc(p.suspension_reason || '')}" /></div>
        <div class="field"><label class="label">Internal admin note</label>
          <input class="input" name="note" maxlength="300" value="${esc(p.suspension_note || '')}" /></div>
        <div class="field"><label class="label">Evidence screenshots <span class="hint">(optional, up to 3, JPG/PNG/WebP/PDF)</span></label>
          <input class="input" name="evidence" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple />
          ${(d.suspension?.evidence || []).length
            ? `<div class="row-wrap mt-6">${(d.suspension.evidence || []).map((path) => `<button class="btn btn-ghost btn-sm" type="button" data-evidence="${esc(path)}">${icon('eye', 13)} Evidence</button>`).join('')}</div>`
            : ''}
        </div>
        <label class="check"><input type="checkbox" name="appeal" ${p.suspension_appeal_allowed !== false ? 'checked' : ''} /> <span>Allow appeals</span></label>
        <div class="row-wrap">
          <button class="btn btn-danger btn-sm" type="submit">Suspend / restrict</button>
          ${p.status !== 'active' || p.withdrawals_blocked ? '<button class="btn btn-soft btn-sm" type="button" data-restore>Restore access</button>' : ''}
        </div>
      </form>` : ''}

      ${canRole ? `<hr class="divider" />
      <form id="au-role" class="col" style="gap:10px">
        <h3 style="font-size:13px">Admin role</h3>
        <p class="tiny dim">Only an OWNER can change admin roles. Removing the role keeps the account as a normal user.</p>
        <div class="field-row">
          <div class="field"><label class="label">Role</label>
            <select class="select" name="role">
              <option value="">No admin role</option>
              ${ROLES.map((r) => `<option value="${r}" ${p.admin_role === r ? 'selected' : ''}>${r.replace('_', ' ')} — ${esc(ROLE_HINT[r])}</option>`).join('')}
            </select>
          </div>
        </div>
        <button class="btn btn-ghost btn-sm" type="submit">Save role</button>
      </form>` : ''}

      ${canMoney ? `<hr class="divider" />
      <form id="au-money" class="col" style="gap:10px">
        <h3 style="font-size:13px">Manual balance adjustment</h3>
        <p class="tiny dim">Positive credits, negative debits. Every adjustment writes an immutable ledger row (with balances after the move) and an audit entry, and requires a reason. Negative balances are refused by the server.</p>
        <div class="grid grid-3" style="gap:10px">
          <div class="field"><label class="label">Available</label><input class="input" name="available" type="number" step="0.000001" value="0" /></div>
          <div class="field"><label class="label">Pending</label><input class="input" name="pending" type="number" step="0.000001" value="0" /></div>
          <div class="field"><label class="label">Reserved</label><input class="input" name="reserved" type="number" step="0.000001" value="0" /></div>
        </div>
        <div class="field"><label class="label">Reason</label><input class="input" name="reason" maxlength="200" required placeholder="e.g. Compensation for task #123" /></div>
        <button class="btn btn-soft btn-sm" type="submit">Apply adjustment</button>
      </form>

      <hr class="divider" />
      <div class="row-between" style="gap:12px;flex-wrap:wrap">
        <div style="min-width:200px">
          <div class="strong" style="font-size:13px">Wallet ${w.frozen ? '<span class="badge red">Frozen</span>' : '<span class="badge green">Active</span>'}</div>
          <div class="tiny dim mt-6">${w.frozen
            ? esc(w.frozen_reason || 'Outgoing transfers are paused. Balance and ledger are untouched.')
            : 'Withdrawals and campaign funding work normally. This is separate from the account status.'}</div>
        </div>
        <button class="btn ${w.frozen ? 'btn-soft' : 'btn-danger'} btn-sm" type="button" data-freeze-wallet="${w.frozen ? '0' : '1'}">
          ${w.frozen ? 'Unfreeze wallet' : 'Freeze wallet'}
        </button>
      </div>` : ''}

      <hr class="divider" />
      <h3 style="font-size:13px" class="mb-10">Internal admin notes</h3>
      <form id="au-note" class="row" style="gap:8px;align-items:flex-start">
        <input class="input" name="note" maxlength="600" placeholder="Visible to admins only" style="flex:1" />
        <button class="btn btn-soft btn-sm" type="submit">Add note</button>
      </form>
      ${(d.notes || []).length ? `<div class="list mt-10">${(d.notes || []).map((n) => `
        <div class="list-row">
          <div class="list-main"><div class="list-title">${esc(n.note)}</div><div class="list-sub">${esc(n.admin_name || 'Admin')} · ${esc(ago(n.created_at))}</div></div>
          ${n.kind ? `<span class="badge grey">${esc(n.kind)}</span>` : ''}
        </div>`).join('')}</div>` : '<p class="small muted mt-10">No notes yet.</p>'}

      <hr class="divider" />
      <h3 style="font-size:13px" class="mb-10">Recent tasks</h3>
      ${(d.tasks || []).length ? `<div class="list">${(d.tasks || []).slice(0, 8).map((t) => `
        <div class="list-row">
          <div class="list-main"><div class="list-title truncate">${esc(t.campaign || 'Task')}</div><div class="list-sub">${esc(t.platform || '')} · ${esc(usdt(t.reward))} USDT · ${esc(ago(t.created_at))}</div></div>
          ${statusBadge(t.status)}
        </div>`).join('')}</div>` : '<p class="small muted">No tasks yet.</p>'}

      <hr class="divider" />
      <h3 style="font-size:13px" class="mb-10">Recent proofs</h3>
      ${(d.submissions || []).length ? `<div class="list">${(d.submissions || []).slice(0, 8).map((x) => `
        <div class="list-row">
          <div class="list-main">
            <div class="list-title truncate">${esc(x.campaign || 'Proof')}</div>
            <div class="list-sub">${esc(ago(x.created_at))}${x.duplicate_hash ? ' · duplicate hash' : ''}${x.review_note ? ` · ${esc(x.review_note)}` : ''}</div>
          </div>
          <div class="row-wrap">
            ${statusBadge(x.status)}
            ${(x.proof_paths?.[0] || x.proof_path) ? `<button class="btn btn-ghost btn-sm" type="button" data-proof="${esc(x.proof_paths?.[0] || x.proof_path)}">View</button>` : ''}
          </div>
        </div>`).join('')}</div>` : '<p class="small muted">No proofs yet.</p>'}

      <hr class="divider" />
      <h3 style="font-size:13px" class="mb-10">Login history</h3>
      ${(d.logins || []).length ? `<div class="list">${(d.logins || []).slice(0, 6).map((e) => `
        <div class="list-row">
          <div class="list-main"><div class="list-title truncate">${esc(e.platform || 'web')}</div><div class="list-sub truncate">${esc(e.user_agent || 'unknown device')}</div></div>
          <span class="tiny dim">${esc(ago(e.created_at))}</span>
        </div>`).join('')}</div>` : '<p class="small muted">No logins recorded yet.</p>'}

      <hr class="divider" />
      <h3 style="font-size:13px" class="mb-10">Recent ledger</h3>
      ${ledger.length ? `<div class="list">${ledger.map((l) => `
        <div class="list-row">
          <div class="list-main"><div class="list-title">${esc(l.kind)}</div><div class="list-sub">${esc(l.note || '')} · ${esc(ago(l.created_at))}</div></div>
          <span class="small ${Number(l.available_delta) >= 0 ? 'green' : 'red'}">${Number(l.available_delta) >= 0 ? '+' : ''}${esc(usdt(l.available_delta))}</span>
        </div>`).join('')}</div>` : '<p class="small muted">No ledger entries.</p>'}

      <hr class="divider" />
      <div class="grid grid-2" style="gap:14px">
        <div>
          <h3 style="font-size:13px" class="mb-10">Withdrawals</h3>
          ${(d.withdrawals || []).length ? `<div class="list">${d.withdrawals.map((x) => `
            <div class="list-row"><div class="list-main"><div class="list-title">${esc(usdt(x.amount))} USDT</div><div class="list-sub mono truncate">${esc(x.address)}</div></div>${statusBadge(x.status)}</div>`).join('')}</div>` : '<p class="small muted">None.</p>'}
        </div>
        <div>
          <h3 style="font-size:13px" class="mb-10">Deposits</h3>
          ${(d.deposits || []).length ? `<div class="list">${d.deposits.map((x) => `
            <div class="list-row"><div class="list-main"><div class="list-title">${esc(usdt(x.amount))} USDT</div><div class="list-sub">${esc(ago(x.created_at))}</div></div>${statusBadge(x.status)}</div>`).join('')}</div>` : '<p class="small muted">None.</p>'}
        </div>
      </div>`
  });

  const reopen = () => {
    m.close();
    if (refresh) refresh();
    openUserModal(id, refresh);
  };

  const suspendForm = m.root.querySelector('#au-suspend');
  if (suspendForm) suspendForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(suspendForm);
    const kind = String(fd.get('kind') || 'permanent');
    const reason = String(fd.get('reason') || '').trim();
    const reasonKey = String(fd.get('reason_key') || '').trim() || null;
    const note = String(fd.get('note') || '').trim();
    const appeal = fd.get('appeal') === 'on';
    const rawExpiry = String(fd.get('expires') || '');
    if (!reason) return toast('A reason is required — the user sees it.', 'error');
    if (kind === 'temporary' && !rawExpiry) return toast('A temporary suspension needs an expiry date.', 'error');
    const expires = rawExpiry ? new Date(rawExpiry).toISOString() : null;

    const ok = await confirmDialog({
      title: kind === 'restricted' ? 'Restrict this account?' : 'Suspend this account?',
      message: kind === 'restricted'
        ? 'The user keeps browsing but cannot withdraw or fund campaigns. Claims stay open.'
        : 'The user is signed out of every operation immediately: no claiming, submitting, campaigns, deposits or withdrawals. Wallet and history are untouched. Open claims go back to the marketplace.',
      confirmLabel: kind === 'restricted' ? 'Restrict' : 'Suspend',
      danger: true
    });
    if (!ok) return;

    const btn = suspendForm.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      const files = Array.from(suspendForm.querySelector('[name=evidence]')?.files || []).slice(0, 3);
      const evidence = [];
      for (const file of files) {
        const up = await uploadProofFile(file, state.profile.id);
        evidence.push(up.path);
      }

      await rpc('admin_suspend_user', {
        p_user_id: id,
        p_kind: kind,
        p_reason: reason,
        p_expires_at: expires,
        p_note: note || null,
        p_appeal_allowed: appeal,
        p_reason_key: reasonKey,
        p_evidence: evidence
      });
      toast(kind === 'restricted' ? 'Account restricted.' : 'Account suspended.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  const reasonKeyEl = m.root.querySelector('[data-reason-key]');
  if (reasonKeyEl) reasonKeyEl.addEventListener('change', () => {
    const found = SUSPEND_REASONS.find(([k]) => k === reasonKeyEl.value);
    const input = m.root.querySelector('[data-reason-input]');
    if (found && input && found[0] !== 'other') input.value = found[1];
  });

  const restoreBtn = m.root.querySelector('[data-restore]');
  if (restoreBtn) restoreBtn.addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Restore this account?',
      message: 'The user regains access immediately and is notified. Wallet and ledger stay exactly as they are.',
      confirmLabel: 'Restore access'
    });
    if (!ok) return;
    setBusy(restoreBtn, true, 'Restoring');
    try {
      await rpc('admin_restore_user', { p_user_id: id, p_note: 'Restored from the admin panel' });
      toast('Account restored.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(restoreBtn, false);
    }
  });

  const roleForm = m.root.querySelector('#au-role');
  if (roleForm) roleForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const next = String(new FormData(roleForm).get('role') || '');
    const ok = await confirmDialog({
      title: 'Change admin role?',
      message: next ? `The account gets the ${next} role immediately, with everything that role can do.` : 'The account loses all admin access. Its user data is untouched.',
      confirmLabel: 'Save role',
      danger: true
    });
    if (!ok) return;
    const btn = roleForm.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_set_admin_role', { p_user_id: id, p_admin_role: next || null });
      toast('Admin role saved.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  if (canRole) {
    m.root.querySelector('#au-role')?.insertAdjacentHTML('afterend', `
      <form id="au-caps" class="col" style="gap:10px">
        <h3 style="font-size:13px">Account capabilities</h3>
        <p class="tiny dim">Promote or demote between Worker and Buyer. One account can hold both. Every change is audited.</p>
        <label class="check"><input type="checkbox" name="is_worker" ${p.is_worker ? 'checked' : ''} /> <span>Worker — can claim and complete tasks</span></label>
        <label class="check"><input type="checkbox" name="is_buyer" ${p.is_buyer ? 'checked' : ''} /> <span>Buyer — can fund campaigns and order services</span></label>
        <button class="btn btn-soft btn-sm" type="submit">Save capabilities</button>
      </form>`);
  }

  const capsForm = m.root.querySelector('#au-caps');
  if (capsForm) capsForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(capsForm);
    const isWorker = fd.get('is_worker') === 'on';
    const isBuyer = fd.get('is_buyer') === 'on';
    if (!isWorker && !isBuyer) return toast('The account must keep at least one capability. Use suspension instead.', 'error');
    const ok = await confirmDialog({
      title: 'Update account capabilities?',
      message: `Worker: ${isWorker ? 'on' : 'off'} · Buyer: ${isBuyer ? 'on' : 'off'}. Wallet balances and history are untouched.`,
      confirmLabel: 'Save capabilities'
    });
    if (!ok) return;
    const btn = capsForm.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_set_user_caps', { p_user_id: id, p_is_worker: isWorker, p_is_buyer: isBuyer });
      toast('Capabilities saved.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  const moneyForm = m.root.querySelector('#au-money');
  if (moneyForm) moneyForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(moneyForm);
    const available = Number(fd.get('available') || 0);
    const pending = Number(fd.get('pending') || 0);
    const reserved = Number(fd.get('reserved') || 0);
    const reason = String(fd.get('reason') || '').trim();
    if (!reason) return toast('A reason is required.', 'error');
    if (!available && !pending && !reserved) return toast('Enter at least one balance change.', 'error');
    const ok = await confirmDialog({
      title: 'Adjust this balance?',
      message: `Available ${available >= 0 ? '+' : ''}${usdt(available)}, pending ${pending >= 0 ? '+' : ''}${usdt(pending)}, reserved ${reserved >= 0 ? '+' : ''}${usdt(reserved)}. The user is notified and the ledger records it.`,
      confirmLabel: 'Apply adjustment',
      danger: true
    });
    if (!ok) return;
    const btn = moneyForm.querySelector('button[type=submit]');
    setBusy(btn, true, 'Applying');
    try {
      await rpc('admin_adjust_balance', {
        p_user_id: id,
        p_available: available,
        p_pending: pending,
        p_reserved: reserved,
        p_reason: reason
      });
      toast('Balance adjusted.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  const freezeBtn = m.root.querySelector('[data-freeze-wallet]');
  if (freezeBtn) freezeBtn.addEventListener('click', async () => {
    const freeze = freezeBtn.dataset.freezeWallet === '1';
    let reason = null;

    if (freeze) {
      reason = await askNote(
        'Freeze this wallet?',
        'Outgoing transfers stop immediately: withdrawals, campaign funding and anything that debits this wallet. Balances, pending rewards and the ledger are untouched. The user is told, and the reason is shown to them.',
        'Reason (shown to the user)',
        'Freeze wallet',
        true
      );
      if (reason === null) return;
    } else {
      const ok = await confirmDialog({
        title: 'Unfreeze this wallet?',
        message: 'Withdrawals and campaign funding work again immediately. No balance changes.',
        confirmLabel: 'Unfreeze'
      });
      if (!ok) return;
    }

    setBusy(freezeBtn, true, freeze ? 'Freezing' : 'Unfreezing');
    try {
      await rpc('admin_freeze_wallet', { p_user_id: id, p_frozen: freeze, p_reason: reason });
      toast(freeze ? 'Wallet frozen.' : 'Wallet unfrozen.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(freezeBtn, false);
    }
  });

  const noteForm = m.root.querySelector('#au-note');
  if (noteForm) noteForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const note = String(new FormData(noteForm).get('note') || '').trim();
    if (!note) return toast('Write a note first.', 'error');
    const btn = noteForm.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_add_note', { p_user_id: id, p_note: note, p_kind: 'note' });
      toast('Note added.', 'success');
      reopen();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  m.root.querySelectorAll('[data-proof]').forEach((b) => b.addEventListener('click', async () => {
    const url = await signedProofUrl(b.dataset.proof);
    if (!url) return toast('Could not open that proof.', 'error');
    window.open(url, '_blank', 'noopener');
  }));

  m.root.querySelectorAll('[data-evidence]').forEach((b) => b.addEventListener('click', async () => {
    const url = await signedProofUrl(b.dataset.evidence);
    if (!url) return toast('Could not open that file.', 'error');
    window.open(url, '_blank', 'noopener');
  }));
}

/* ================================================================= TASKS === */
export async function renderAdminTasks(root) {
  let status = '';
  let q = '';
  let offset = 0;
  const limit = 30;
  let total = 0;
  /* Bulk selection: a Set of task ids on the current page. Cleared when a
     filter changes or a bulk action completes. */
  const selected = new Set();
  let rows = [];

  root.innerHTML = `<div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="t-q" placeholder="Search campaign title" autocomplete="off" /></div>
      <select class="select input-sm" id="t-status" style="max-width:170px">
        <option value="">All statuses</option>
        ${['available', 'claimed', 'submitted', 'approved', 'rejected', 'expired', 'cancelled'].map((v) => `<option value="${v}">${v}</option>`).join('')}
      </select>
      ${allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR'])
        ? `<button class="btn btn-soft btn-sm" type="button" data-new-slots>${icon('plus', 14)} Add task slots</button>`
        : ''}
    </div>
    <div id="t-bulk" class="bulk-bar hide"></div>
    <div id="t-list">${loadingBlock('Loading tasks')}</div>`;

  const listEl = root.querySelector('#t-list');
  const bulkEl = root.querySelector('#t-bulk');
  const canManage = () => allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR']);

  /* Soft refresh: dim the existing table instead of collapsing it to a
     spinner, then restore the exact scroll offset after the new rows land.
     The page never jumps to the top after a single-row or bulk action. */
  const load = async ({ fresh = false } = {}) => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const refreshing = wasLoaded && !fresh;
    const scrollY = window.scrollY;
    if (!refreshing) listEl.innerHTML = loadingBlock('Loading tasks');
    else listEl.classList.add('is-refreshing');
    try {
      const res = await rpc('admin_list_tasks', { p_status: status || null, p_search: q || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    const manageable = rows.filter((t) => canManage() && ['available', 'cancelled'].includes(t.status));
    if (!selected.size) bulkEl.classList.add('hide');
    bulkEl.innerHTML = selected.size ? `<div class="row-wrap" style="gap:8px">
        <span class="badge orange">${selected.size} selected</span>
        <button class="btn btn-ghost btn-sm" type="button" data-bulk-select-page>Select all on page</button>
        <button class="btn btn-danger btn-sm" type="button" data-bulk="cancelled">Disable selected</button>
        <button class="btn btn-soft btn-sm" type="button" data-bulk="available">Publish selected</button>
        <button class="btn btn-ghost btn-sm" type="button" data-bulk-clear>Clear selection</button>
      </div>` : '';

    listEl.innerHTML = rows.length ? tableHtml(
      ['Task', 'Campaign', 'Worker', 'Reward', 'Status', 'Created', ''],
      rows.map((t) => `<tr>
        <td data-label="Task"><div class="row" style="gap:8px">
          ${canManage() && ['available', 'cancelled'].includes(t.status) ? `<input type="checkbox" class="bulk-check" data-bulk-check="${esc(t.id)}" ${selected.has(t.id) ? 'checked' : ''} aria-label="Select task" />` : ''}
          <span class="mono tiny">${esc(String(t.id).slice(0, 8))}</span>
        </div></td>
        <td data-label="Campaign">${esc(t.campaign_title || '')}</td>
        <td data-label="Worker">${esc(t.worker_name || '—')}</td>
        <td data-label="Reward" class="num">${esc(usdt(t.reward))}</td>
        <td data-label="Status">${statusBadge(t.status)}</td>
        <td data-label="Created">${esc(shortDate(t.created_at))}</td>
        <td data-label="">
          ${canManage() ? `<button class="btn btn-ghost btn-sm" type="button" data-task-verif="${esc(t.campaign_id)}" data-title="${esc(t.campaign_title || '')}">Verification</button>` : ''}
          ${canManage() && ['available', 'cancelled'].includes(t.status)
            ? `<button class="btn btn-ghost btn-sm" type="button"
                 data-task-status="${esc(t.id)}"
                 data-next="${t.status === 'available' ? 'cancelled' : 'available'}">
                 ${t.status === 'available' ? 'Disable' : 'Publish'}
               </button>`
            : ''}
        </td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'tasks', title: 'No tasks match', text: 'Tasks are generated when a campaign is funded.' });
    listEl.dataset.loaded = '1';

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });

    if (refreshing) window.scrollTo(0, scrollY);

    listEl.querySelectorAll('[data-bulk-check]').forEach((cb) => cb.addEventListener('change', () => {
      if (cb.checked) selected.add(cb.dataset.bulkCheck);
      else selected.delete(cb.dataset.bulkCheck);
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk-select-page]').forEach((b) => b.addEventListener('click', () => {
      manageable.forEach((t) => selected.add(t.id));
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk-clear]').forEach((b) => b.addEventListener('click', () => {
      selected.clear();
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk]').forEach((b) => b.addEventListener('click', async () => {
      const next = b.dataset.bulk;
      const ids = rows.filter((t) => selected.has(t.id) && ['available', 'cancelled'].includes(t.status)).map((t) => t.id);
      if (!ids.length) return toast('No eligible tasks in the selection.', 'error');
      const ok = await confirmDialog({
        title: next === 'cancelled' ? `Disable ${ids.length} task(s)?` : `Publish ${ids.length} task(s)?`,
        message: next === 'cancelled'
          ? 'Each slot leaves the marketplace. Claimed tasks are released and their workers are notified. Nothing else changes.'
          : 'Each slot becomes claimable again at its campaign reward.',
        confirmLabel: next === 'cancelled' ? `Disable ${ids.length}` : `Publish ${ids.length}`,
        danger: next === 'cancelled'
      });
      if (!ok) return;
      setBusy(b, true, `0/${ids.length}`);
      let done = 0;
      const failures = [];
      for (const id of ids) {
        try {
          await rpc('admin_set_task_status', { p_task_id: id, p_status: next });
        } catch (e) {
          failures.push(`${String(id).slice(0, 8)} — ${friendlyError(e)}`);
        }
        done += 1;
        b.querySelector('span.spinner')?.remove();
        b.innerHTML = `<span class="spinner"></span><span>${done}/${ids.length}</span>`;
      }
      selected.clear();
      if (failures.length) {
        const m = openModal({
          title: 'Bulk action finished',
          subtitle: `${ids.length - failures.length} succeeded · ${failures.length} failed`,
          body: `<div class="list">${failures.map((f) => `<div class="list-row"><div class="list-main"><div class="list-title small red">${esc(f)}</div></div></div>`).join('')}</div>`,
          footer: '<button class="btn btn-primary" type="button" data-ok>Close</button>'
        });
        m.root.querySelector('[data-ok]').onclick = () => m.close();
      } else {
        toast(`${ids.length} task(s) ${next === 'cancelled' ? 'disabled' : 'published'}.`, 'success');
      }
      await load();
    }));

    listEl.querySelectorAll('[data-task-verif]').forEach((b) => b.addEventListener('click', () => openTaskVerification(b.dataset.taskVerif, b.dataset.title)));

    listEl.querySelectorAll('[data-task-status]').forEach((b) => b.addEventListener('click', async () => {
      const next = b.dataset.next;
      const ok = await confirmDialog({
        title: next === 'cancelled' ? 'Disable this task?' : 'Publish this task?',
        message: next === 'cancelled'
          ? 'The slot leaves the marketplace. A worker who already claimed it is notified and loses nothing.'
          : 'The task becomes claimable again at the campaign reward.',
        confirmLabel: next === 'cancelled' ? 'Disable' : 'Publish',
        danger: next === 'cancelled'
      });
      if (!ok) return;
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_set_task_status', { p_task_id: b.dataset.taskStatus, p_status: next });
        toast(next === 'cancelled' ? 'Task disabled.' : 'Task published.', 'success');
        await load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  root.querySelector('#t-q').addEventListener('input', debounce((e) => { q = e.target.value.trim(); offset = 0; selected.clear(); load({ fresh: true }); }, 320));
  root.querySelector('#t-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; selected.clear(); load({ fresh: true }); });

  const slotsBtn = root.querySelector('[data-new-slots]');
  if (slotsBtn) slotsBtn.addEventListener('click', () => openTaskSlotsModal(() => load({ fresh: true })));

  await load();
}

/* Generates extra task slots on an already funded campaign. The server caps
   the count at the campaign's remaining quantity, so this can never promise
   more rewards than the escrow can pay. */
async function openTaskSlotsModal(reload) {
  let campaigns = [];
  try {
    const [active, pending] = await Promise.all([
      rpc('admin_list_campaigns', { p_status: 'active', p_limit: 100, p_offset: 0 }),
      rpc('admin_list_campaigns', { p_status: 'pending', p_limit: 100, p_offset: 0 })
    ]);
    campaigns = [...(active?.items || []), ...(pending?.items || [])];
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }
  if (!campaigns.length) {
    toast('There are no active or pending campaigns to add slots to.', 'info');
    return;
  }

  const m = openModal({
    title: 'Add task slots',
    subtitle: 'Funded campaigns only',
    body: `<div class="field"><label class="label">Campaign</label>
        <select class="select" id="ts-campaign">
          ${campaigns.map((c) => `<option value="${esc(c.id)}">${esc(c.title)} — ${Math.max(0, Number(c.quantity || 0) - Number(c.approved_count || 0))} left</option>`).join('')}
        </select>
      </div>
      <div class="field mt-12"><label class="label">How many slots</label>
        <input class="input" id="ts-count" type="number" min="1" step="1" value="10" />
      </div>
      <div class="alert info mt-14">${icon('info', 17)}<div>A slot is one claimable task at the campaign reward. The server refuses any count that would go past the campaign quantity.</div></div>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
      <button class="btn btn-primary" type="button" data-create>Create slots</button>`
  });

  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-create]').onclick = async (e) => {
    const btn = e.currentTarget;
    const campaignId = m.root.querySelector('#ts-campaign').value;
    const count = Number(m.root.querySelector('#ts-count').value || 0);
    if (!campaignId) return toast('Choose a campaign.', 'error');
    if (!Number.isFinite(count) || count < 1) return toast('Enter at least one slot.', 'error');

    setBusy(btn, true, 'Creating');
    try {
      const res = await rpc('admin_create_task_slots', { p_campaign_id: campaignId, p_count: count });
      toast(`${Number(res?.created || 0)} task slot(s) created.`, 'success');
      m.close();
      if (reload) reload();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  };
}

/* ============================================================= CAMPAIGNS === */
export async function renderAdminCampaigns(root) {
  let status = '';
  let q = '';
  let offset = 0;
  const limit = 30;
  let total = 0;
  const selected = new Set();
  let rows = [];

  root.innerHTML = `<div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="c-q" placeholder="Search campaign title" autocomplete="off" /></div>
      <select class="select input-sm" id="c-status" style="max-width:170px">
        <option value="">All statuses</option>
        ${['pending', 'active', 'paused', 'completed', 'cancelled', 'rejected'].map((v) => `<option value="${v}">${v}</option>`).join('')}
      </select>
    </div>
    <div id="c-bulk" class="bulk-bar hide"></div>
    <div id="c-list">${loadingBlock('Loading campaigns')}</div>`;

  const listEl = root.querySelector('#c-list');
  const bulkEl = root.querySelector('#c-bulk');

  const load = async ({ fresh = false } = {}) => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const refreshing = wasLoaded && !fresh;
    const scrollY = window.scrollY;
    if (!refreshing) listEl.innerHTML = loadingBlock('Loading campaigns');
    else listEl.classList.add('is-refreshing');
    try {
      const res = await rpc('admin_list_campaigns', { p_status: status || null, p_search: q || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    const canReview = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR']);
    if (!selected.size) bulkEl.classList.add('hide');
    const pendingSelected = rows.filter((c) => selected.has(c.id) && c.status === 'pending').length;
    bulkEl.innerHTML = selected.size ? `<div class="row-wrap" style="gap:8px">
        <span class="badge orange">${selected.size} selected</span>
        <button class="btn btn-ghost btn-sm" type="button" data-bulk-select-page>Select all on page</button>
        ${canReview ? `<button class="btn btn-soft btn-sm" type="button" data-bulk-act="pause">Pause selected</button>
        <button class="btn btn-soft btn-sm" type="button" data-bulk-act="resume">Resume selected</button>
        ${pendingSelected ? `<button class="btn btn-soft btn-sm" type="button" data-bulk-act="approve">Approve ${pendingSelected} pending</button>
        <button class="btn btn-danger btn-sm" type="button" data-bulk-act="reject">Reject ${pendingSelected} pending</button>` : ''}
        <button class="btn btn-danger btn-sm" type="button" data-bulk-act="cancel">Cancel &amp; refund selected</button>` : ''}
        <button class="btn btn-ghost btn-sm" type="button" data-bulk-clear>Clear selection</button>
      </div>` : '';

    listEl.innerHTML = rows.length ? tableHtml(
      ['Campaign', 'Buyer', 'Progress', 'Budget', 'Escrow', 'Fee', 'Status', ''],
      rows.map((c) => `<tr>
        <td data-label="Campaign"><div class="row" style="gap:8px">
          ${canReview ? `<input type="checkbox" class="bulk-check" data-bulk-check="${esc(c.id)}" ${selected.has(c.id) ? 'checked' : ''} aria-label="Select campaign" />` : ''}
          ${platformIcon(c.platform, 15)}<span class="truncate">${esc(c.title)}</span>
        </div></td>
        <td data-label="Buyer">${esc(c.buyer_name || '')}</td>
        <td data-label="Progress">${Number(c.approved_count || 0)}/${Number(c.quantity || 0)} <span class="tiny dim">· ${Number(c.rejected_count || 0)} rejected</span></td>
        <td data-label="Budget" class="num">${esc(usdt(c.total_budget))}</td>
        <td data-label="Escrow" class="num">${esc(usdt(c.reserved_remaining))}</td>
        <td data-label="Fee" class="num">${esc(usdt(c.fee_amount))}</td>
        <td data-label="Status">${statusBadge(c.status)}</td>
        <td data-label="Actions" class="cell-actions">
          ${canReview && c.status === 'pending' ? `<button class="btn btn-soft btn-sm" type="button" data-review="${esc(c.id)}">Review</button>` : ''}
        </td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'megaphone', title: 'No campaigns match', text: 'Campaigns appear here the moment a buyer funds one.' });
    listEl.dataset.loaded = '1';

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
    if (refreshing) window.scrollTo(0, scrollY);

    listEl.querySelectorAll('[data-bulk-check]').forEach((cb) => cb.addEventListener('change', () => {
      if (cb.checked) selected.add(cb.dataset.bulkCheck);
      else selected.delete(cb.dataset.bulkCheck);
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk-select-page]').forEach((b) => b.addEventListener('click', () => {
      rows.filter((c) => canReview).forEach((c) => selected.add(c.id));
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk-clear]').forEach((b) => b.addEventListener('click', () => {
      selected.clear();
      load({ fresh: true });
    }));
    bulkEl.querySelectorAll('[data-bulk-act]').forEach((b) => b.addEventListener('click', async () => {
      const act = b.dataset.bulkAct;
      const ids = rows.filter((c) => selected.has(c.id)).map((c) => c.id);
      if (!ids.length) return toast('No campaigns in the selection.', 'error');

      let note = null;
      if (act === 'reject') {
        note = await askNote(`Reject ${ids.length} campaign(s)`, 'The same note is stored on every rejected campaign and the escrow is refunded to each buyer.', 'Reason', `Reject & refund ${ids.length}`);
        if (note === null) return;
        if (!note) return toast('A rejection note is required.', 'error');
      }
      const copy = {
        pause: ['Pause campaigns?', 'Active campaigns stop showing new tasks. Claimed tasks can still be submitted and reviewed.', 'Pause'],
        resume: ['Resume campaigns?', 'Available tasks become visible to workers again.', 'Resume'],
        cancel: ['Cancel and refund campaigns?', 'Each campaign returns its unspent escrow to its buyer. Pending proofs are rejected and their rewards reversed. This cannot be undone.', 'Cancel & refund'],
        approve: ['Approve pending campaigns?', 'Each pending campaign is approved and its task slots go live immediately. Confirm every item is legitimate.', 'Approve all'],
        reject: [`Reject ${ids.length} campaign(s)?`, 'Each pending campaign is rejected and its full escrow is refunded to the buyer with your note. This cannot be undone.', 'Reject & refund all']
      }[act];
      const ok = await confirmDialog({ title: copy[0], message: copy[1], confirmLabel: copy[2], danger: act === 'cancel' || act === 'reject' });
      if (!ok) return;

      setBusy(b, true, `0/${ids.length}`);
      let done = 0;
      const failures = [];
      for (const c of rows.filter((x) => selected.has(x.id))) {
        try {
          if (act === 'approve' || act === 'reject') {
            await rpc('admin_review_campaign', { p_campaign_id: c.id, p_approve: act === 'approve', p_note: note });
          } else {
            await rpc('admin_set_campaign_status', { p_campaign_id: c.id, p_action: act });
          }
        } catch (e) {
          failures.push(`${c.title || String(c.id).slice(0, 8)} — ${friendlyError(e)}`);
        }
        done += 1;
        b.innerHTML = `<span class="spinner"></span><span>${done}/${ids.length}</span>`;
      }
      selected.clear();
      if (failures.length) {
        const m = openModal({
          title: 'Bulk action finished',
          subtitle: `${ids.length - failures.length} succeeded · ${failures.length} failed`,
          body: `<div class="list">${failures.map((f) => `<div class="list-row"><div class="list-main"><div class="list-title small red">${esc(f)}</div></div></div>`).join('')}</div>`,
          footer: '<button class="btn btn-primary" type="button" data-ok>Close</button>'
        });
        m.root.querySelector('[data-ok]').onclick = () => m.close();
      } else {
        toast(`${ids.length} campaign(s) updated.`, 'success');
      }
      await load();
    }));

    listEl.querySelectorAll('[data-review]').forEach((b) => b.addEventListener('click', () => {
      const c = rows.find((x) => x.id === b.dataset.review);
      if (c) reviewCampaign(c, () => load({ fresh: true }));
    }));
  };

  root.querySelector('#c-q').addEventListener('input', debounce((e) => { q = e.target.value.trim(); offset = 0; selected.clear(); load({ fresh: true }); }, 320));
  root.querySelector('#c-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; selected.clear(); load({ fresh: true }); });
  await load();
}

function reviewCampaign(c, reload) {
  const m = openModal({
    title: 'Review campaign',
    subtitle: c.title,
    wide: true,
    body: `<div class="grid grid-3" style="gap:10px">
        <div class="panel panel-pad"><div class="tiny dim">Buyer</div><div class="strong truncate">${esc(c.buyer_name || '')}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Quantity</div><div class="strong">${Number(c.quantity || 0)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Reward each</div><div class="strong">${esc(usdt(c.reward_per_task))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Budget</div><div class="strong">${esc(usdt(c.total_budget))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Fee</div><div class="strong">${esc(usdt(c.fee_amount))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Escrow</div><div class="strong">${esc(usdt(c.reserved_remaining))}</div></div>
      </div>
      <div class="field mt-14">
        <label class="label">Review note</label>
        <textarea class="textarea" id="rc-note" maxlength="500" placeholder="Shown to the buyer when the campaign is rejected."></textarea>
      </div>
      <div class="alert info mt-14">${icon('info', 17)}<div>Approving creates the task slots immediately and makes them visible to eligible workers. Rejecting refunds the whole escrow to the buyer.</div></div>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
      <button class="btn btn-danger" type="button" data-reject>Reject &amp; refund</button>
      <button class="btn btn-primary" type="button" data-approve>Approve campaign</button>`
  });

  const act = async (approve) => {
    const note = m.root.querySelector('#rc-note').value.trim();
    if (!approve && !note) return toast('Add a note explaining the rejection.', 'error');
    const ok = await confirmDialog({
      title: approve ? 'Approve campaign?' : 'Reject and refund?',
      message: approve
        ? `${Number(c.quantity || 0)} task slots become visible to workers right away.`
        : `${usdt(c.reserved_remaining)} USDT returns to the buyer's available balance.`,
      confirmLabel: approve ? 'Approve' : 'Reject & refund',
      danger: !approve
    });
    if (!ok) return;
    try {
      await rpc('admin_review_campaign', { p_campaign_id: c.id, p_approve: approve, p_note: note || null });
      toast(approve ? 'Campaign approved and live.' : 'Campaign rejected and escrow refunded.', 'success');
      m.close();
      reload();
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
    }
  };

  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-approve]').onclick = () => act(true);
  m.root.querySelector('[data-reject]').onclick = () => act(false);
}

/* ================================================================= PROOFS === */
export async function renderAdminProofs(root) {
  let status = 'pending';
  let q = '';
  let offset = 0;
  const limit = 20;
  let total = 0;

  root.innerHTML = `<div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="p-q" placeholder="Campaign title or target link" autocomplete="off" /></div>
      <select class="select input-sm" id="p-status" style="max-width:170px">
        <option value="pending" selected>Pending review</option>
        <option value="approved">Approved</option>
        <option value="rejected">Rejected</option>
        <option value="">All statuses</option>
      </select>
    </div>
    <div id="p-list">${loadingBlock('Loading proofs')}</div>`;

  const listEl = root.querySelector('#p-list');
  const canReview = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER']);

  const load = async () => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const scrollY = window.scrollY;
    if (wasLoaded) listEl.classList.add('is-refreshing');
    else listEl.innerHTML = loadingBlock('Loading proofs');
    let rows = [];
    try {
      const res = await rpc('admin_list_submissions', { p_status: status || null, p_search: q || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    const urls = {};
    await Promise.all(rows.map(async (s) => {
      const list = Array.isArray(s.proof_paths) && s.proof_paths.length
        ? s.proof_paths
        : (s.proof_path ? [s.proof_path] : []);
      const signed = await Promise.all(list.map((p) => signedProofUrl(p, 1800).catch(() => '')));
      urls[s.id] = signed.filter(Boolean);
    }));

    listEl.innerHTML = rows.length ? `<div class="col" style="gap:14px">
      ${rows.map((s) => {
        const target = safeHttpUrl(s.target_url);
        return `<div class="card card-pad">
          <div class="row" style="gap:14px;align-items:flex-start;flex-wrap:wrap">
            <div class="proof-strip">
              ${(urls[s.id] || []).length
                ? urls[s.id].map((u, i) => `<img src="${esc(u)}" alt="Proof ${i + 1}" class="proof-thumb sm" data-proof="${esc(s.id)}" data-idx="${i}" />`).join('')
                : `<span class="proof-thumb" style="display:grid;place-items:center;color:var(--dim)">${icon('image', 18)}</span>`}
            </div>
            <div style="flex:1;min-width:200px">
              <div class="row" style="gap:8px;flex-wrap:wrap">
                ${statusBadge(s.status)}
                ${s.duplicate_hash ? '<span class="badge red">Duplicate image</span>' : ''}
                <span class="badge gold">${esc(usdt(s.reward))} USDT</span>
                ${s.worker_country ? `<span class="badge grey">${esc(s.worker_country)}</span>` : ''}
              </div>
              <div class="strong mt-10">${esc(s.campaign_title || '')}</div>
              <div class="small muted mt-6">${esc(s.worker_name || 'Worker')} · submitted ${esc(ago(s.created_at))}${s.reviewed_at ? ` · reviewed ${esc(ago(s.reviewed_at))}` : ''}</div>
              ${s.note ? `<div class="panel panel-pad mt-10 small">${esc(s.note)}</div>` : ''}
              ${safeHttpUrl(s.proof_link) ? `<a class="btn btn-ghost btn-sm mt-10" href="${esc(safeHttpUrl(s.proof_link))}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Open proof link</a>` : ''}
              <div class="tiny dim mt-6">${(urls[s.id] || []).length || 1} screenshot${((urls[s.id] || []).length || 1) === 1 ? '' : 's'}${s.time_spent_seconds ? ` · ${Number(s.time_spent_seconds)}s on task` : ''}</div>
              ${target ? `<a class="btn btn-ghost btn-sm mt-10" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Open target</a>` : ''}
              ${s.instructions ? `<details class="mt-10"><summary class="tiny dim" style="cursor:pointer">Campaign instructions</summary><div class="tiny muted mt-6" style="white-space:pre-wrap;line-height:1.6">${esc(s.instructions)}</div></details>` : ''}
              ${s.review_note ? `<div class="tiny ${s.status === 'rejected' ? 'red' : 'dim'} mt-10">${esc(s.review_note)}</div>` : ''}
            </div>
            ${canReview && s.status === 'pending' ? `<div class="row" style="gap:6px">
              <button class="btn btn-success btn-sm" type="button" data-approve="${esc(s.id)}">Approve</button>
              <button class="btn btn-danger btn-sm" type="button" data-reject="${esc(s.id)}">Reject</button>
            </div>` : ''}
          </div>
        </div>`;
      }).join('')}
    </div>
    ${pagerHtml(total, limit, offset)}` : emptyState({ iconName: 'shield', title: status === 'pending' ? 'No proofs waiting' : 'No proofs match', text: status === 'pending' ? 'The queue is clear. New submissions appear here in real time.' : 'Try another status or clear the search.' });

    listEl.querySelectorAll('[data-proof]').forEach((img) => img.addEventListener('click', () => {
      const subId = img.dataset.proof;
      const list = urls[subId] || [];
      const viewer = openModal({
        title: 'Proof',
        subtitle: `${list.length} screenshot${list.length === 1 ? '' : 's'}`,
        wide: true,
        body: `<div class="col" style="gap:12px">${list.map((u, i) => `<img src="${esc(u)}" alt="Proof ${i + 1}" class="proof-full" />`).join('')}</div>`,
        footer: '<button class="btn btn-ghost" type="button" data-close-img>Close</button>'
      });
      const closeImg = viewer.root.querySelector('[data-close-img]');
      if (closeImg) closeImg.onclick = () => viewer.close();
    }));

    listEl.dataset.loaded = '1';
    if (wasLoaded) {
      listEl.classList.remove('is-refreshing');
      window.scrollTo(0, scrollY);
    }

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });

    if (canReview) {
      listEl.querySelectorAll('[data-approve]').forEach((b) => b.addEventListener('click', () => decideProof(rows.find((x) => x.id === b.dataset.approve), true, load)));
      listEl.querySelectorAll('[data-reject]').forEach((b) => b.addEventListener('click', () => decideProof(rows.find((x) => x.id === b.dataset.reject), false, load)));
    }
  };

  root.querySelector('#p-q').addEventListener('input', debounce((e) => { q = e.target.value.trim(); offset = 0; load(); }, 320));
  root.querySelector('#p-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; load(); });
  await load();
}

async function decideProof(sub, approve, reload) {
  if (!sub) return;
  let note = null;
  if (approve) {
    const ok = await confirmDialog({
      title: 'Approve this proof?',
      message: `${usdt(sub.reward)} USDT is released from the campaign escrow to ${sub.worker_name || 'the worker'}, plus the referral commission if any. This cannot be undone.`,
      confirmLabel: 'Approve & pay'
    });
    if (!ok) return;
  } else {
    note = await askNote(
      'Reject this proof',
      'The worker sees this note, so be specific: what was missing or wrong?',
      'Rejection reason',
      'Reject proof'
    );
    if (note === null) return;
    if (!note) { toast('A rejection reason is required.', 'error'); return; }
  }

  try {
    await rpc('review_submission', { p_submission_id: sub.id, p_approve: approve, p_note: note });
    toast(approve ? 'Proof approved and reward released.' : 'Proof rejected and escrow returned.', 'success');
    reload();
  } catch (e) {
    toast(friendlyError(e), 'error', 6500);
  }
}

/* =============================================================== DEPOSITS === */
export async function renderAdminDeposits(root) {
  let status = 'pending';
  let offset = 0;
  const limit = 30;
  let total = 0;
  const canReview = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE']);

  root.innerHTML = `<div class="filter-bar">
      <select class="select input-sm" id="d-status" style="max-width:180px">
        <option value="pending" selected>Pending</option>
        <option value="approved">Approved</option>
        <option value="rejected">Rejected</option>
        <option value="">All</option>
      </select>
      <span class="tiny dim">Deposits are credited only after the transaction is checked on-chain.</span>
    </div>
    <div id="d-list">${loadingBlock('Loading deposits')}</div>`;

  const listEl = root.querySelector('#d-list');

  const load = async () => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const scrollY = window.scrollY;
    if (wasLoaded) listEl.classList.add('is-refreshing');
    else listEl.innerHTML = loadingBlock('Loading deposits');
    let rows = [];
    try {
      const res = await rpc('admin_list_deposits', { p_status: status || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['User', 'Amount', 'Method', 'Tx hash', 'Requested', 'Status', ''],
      rows.map((d) => `<tr>
        <td data-label="User"><div class="truncate">${esc(d.user_name || '')}</div><div class="tiny dim truncate">${esc(d.user_email || '')}</div></td>
        <td data-label="Amount" class="num gold-text">${esc(usdt(d.amount))}</td>
        <td data-label="Method">${esc(String(d.method || '').replace('_', ' '))}</td>
        <td data-label="Tx hash"><span class="mono tiny">${d.tx_hash ? `${esc(String(d.tx_hash).slice(0, 12))}…` : '—'}</span></td>
        <td data-label="Requested">${esc(ago(d.created_at))}</td>
        <td data-label="Status">${statusBadge(d.status)}</td>
        <td data-label="Actions" class="cell-actions"><button class="btn btn-ghost btn-sm" type="button" data-open="${esc(d.id)}">Open</button></td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'download', title: 'No deposits here', text: 'Buyer deposits appear as soon as they are submitted.' });
    listEl.dataset.loaded = '1';
    if (wasLoaded) {
      listEl.classList.remove('is-refreshing');
      window.scrollTo(0, scrollY);
    }

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
    listEl.querySelectorAll('[data-open]').forEach((b) => b.addEventListener('click', () => {
      const d = rows.find((x) => x.id === b.dataset.open);
      if (d) openDeposit(d, canReview, load);
    }));
  };

  root.querySelector('#d-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; load(); });
  await load();
}

async function openDeposit(d, canReview, reload) {
  let url = '';
  if (d.proof_path) url = await signedProofUrl(d.proof_path, 1800).catch(() => '');

  const m = openModal({
    title: `${usdt(d.amount)} USDT deposit`,
    subtitle: d.user_name || d.user_email || '',
    wide: true,
    body: `<div class="grid grid-3" style="gap:10px">
        <div class="panel panel-pad"><div class="tiny dim">Method</div><div class="strong">${esc(String(d.method || '').replace('_', ' '))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Requested</div><div class="strong">${esc(dateTime(d.created_at))}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Status</div><div>${statusBadge(d.status)}</div></div>
      </div>
      <h3 style="font-size:13px" class="mt-18 mb-6">Transaction hash</h3>
      ${d.tx_hash
        ? `<div class="row"><a class="mono-box" style="flex:1" href="https://bscscan.com/tx/${esc(d.tx_hash)}" target="_blank" rel="noopener noreferrer">${esc(d.tx_hash)}</a><button class="btn btn-ghost btn-sm" type="button" data-copy="${esc(d.tx_hash)}">${icon('copy', 14)}</button></div>`
        : '<div class="alert warn">' + icon('alert', 17) + '<div>No transaction hash was submitted. Verify the payment another way before approving.</div></div>'}
      <h3 style="font-size:13px" class="mt-18 mb-6">Proof</h3>
      ${url ? `<img src="${esc(url)}" alt="Deposit proof" class="proof-full" />` : '<p class="small muted">No readable proof file.</p>'}
      ${d.admin_note ? `<div class="alert info mt-14">${icon('info', 17)}<div>${esc(d.admin_note)}</div></div>` : ''}
      <div class="field mt-18"><label class="label">Finance note</label><textarea class="textarea" id="dep-note" maxlength="500" placeholder="Optional note stored with the decision."></textarea></div>`,
    footer: canReview && d.status === 'pending'
      ? `<button class="btn btn-ghost" type="button" data-close>Close</button>
         <button class="btn btn-danger" type="button" data-reject>Reject</button>
         <button class="btn btn-primary" type="button" data-approve>Approve &amp; credit</button>`
      : '<button class="btn btn-ghost" type="button" data-close>Close</button>'
  });

  bindCopy(m.root);
  const close = m.root.querySelector('[data-close]');
  if (close) close.onclick = () => m.close();

  const decide = async (approve) => {
    const note = m.root.querySelector('#dep-note')?.value.trim() || '';
    const ok = await confirmDialog({
      title: approve ? 'Credit this deposit?' : 'Reject this deposit?',
      message: approve
        ? `${usdt(d.amount)} USDT is added to the user's available balance. Only do this after confirming the transaction on-chain.`
        : 'The user is notified with your note. No balance changes.',
      confirmLabel: approve ? 'Credit deposit' : 'Reject deposit',
      danger: !approve
    });
    if (!ok) return;
    try {
      await rpc('admin_review_deposit', { p_deposit_id: d.id, p_approve: approve, p_note: note || null });
      toast(approve ? 'Deposit credited.' : 'Deposit rejected.', 'success');
      m.close();
      reload();
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
    }
  };

  const approveBtn = m.root.querySelector('[data-approve]');
  const rejectBtn = m.root.querySelector('[data-reject]');
  if (approveBtn) approveBtn.onclick = () => decide(true);
  if (rejectBtn) rejectBtn.onclick = () => decide(false);
}

/* ============================================================ WITHDRAWALS === */
export async function renderAdminWithdrawals(root) {
  let status = 'pending';
  let offset = 0;
  const limit = 30;
  let total = 0;
  const canReview = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE']);

  root.innerHTML = `<div class="filter-bar">
      <select class="select input-sm" id="w-status" style="max-width:190px">
        <option value="pending" selected>Pending</option>
        <option value="approved">Approved</option>
        <option value="processing">Processing</option>
        <option value="paid">Paid</option>
        <option value="rejected">Rejected</option>
        <option value="">All</option>
      </select>
      <span class="tiny dim">Funds are held when requested, released on payout, and refunded on rejection.</span>
    </div>
    <div id="w-list">${loadingBlock('Loading withdrawals')}</div>`;

  const listEl = root.querySelector('#w-list');

  const load = async () => {
    const wasLoaded = listEl.dataset.loaded === '1';
    const scrollY = window.scrollY;
    if (wasLoaded) listEl.classList.add('is-refreshing');
    else listEl.innerHTML = loadingBlock('Loading withdrawals');
    let rows = [];
    try {
      const res = await rpc('admin_list_withdrawals', { p_status: status || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['User', 'Amount', 'Address', 'Requested', 'Status', ''],
      rows.map((w) => `<tr>
        <td data-label="User"><div class="truncate">${esc(w.user_name || '')}</div><div class="tiny dim truncate">${esc(w.user_email || '')}</div></td>
        <td data-label="Amount" class="num gold-text">${esc(usdt(w.amount))}</td>
        <td data-label="Address"><span class="mono tiny">${esc(String(w.address || '').slice(0, 10))}…${esc(String(w.address || '').slice(-6))}</span></td>
        <td data-label="Requested">${esc(ago(w.created_at))}</td>
        <td data-label="Status">${statusBadge(w.status)}</td>
        <td data-label="Actions" class="cell-actions"><button class="btn btn-ghost btn-sm" type="button" data-open="${esc(w.id)}">Open</button></td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'wallet', title: 'No withdrawals here', text: 'Worker payout requests appear the moment they are submitted.' });
    listEl.dataset.loaded = '1';
    if (wasLoaded) {
      listEl.classList.remove('is-refreshing');
      window.scrollTo(0, scrollY);
    }

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
    listEl.querySelectorAll('[data-open]').forEach((b) => b.addEventListener('click', () => {
      const w = rows.find((x) => x.id === b.dataset.open);
      if (w) openWithdrawal(w, canReview, load);
    }));
  };

  root.querySelector('#w-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; load(); });
  await load();
}

function openWithdrawal(w, canReview, reload) {
  const final = ['paid', 'rejected'].includes(w.status);
  const m = openModal({
    title: `${usdt(w.amount)} USDT payout`,
    subtitle: w.user_name || w.user_email || '',
    wide: true,
    body: `<div class="grid grid-3" style="gap:10px">
        <div class="panel panel-pad"><div class="tiny dim">Status</div><div>${statusBadge(w.status)}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Network</div><div class="strong">${esc(w.network || 'BEP20')}</div></div>
        <div class="panel panel-pad"><div class="tiny dim">Requested</div><div class="strong">${esc(dateTime(w.created_at))}</div></div>
      </div>
      <h3 style="font-size:13px" class="mt-18 mb-6">Destination address</h3>
      <div class="row">
        <span class="mono-box" style="flex:1">${esc(w.address)}</span>
        <button class="btn btn-ghost btn-sm" type="button" data-copy="${esc(w.address)}">${icon('copy', 14)}</button>
      </div>
      ${w.tx_hash ? `<h3 style="font-size:13px" class="mt-18 mb-6">Transaction</h3>
        <a class="mono-box" style="display:block" href="https://bscscan.com/tx/${esc(w.tx_hash)}" target="_blank" rel="noopener noreferrer">${esc(w.tx_hash)}</a>` : ''}
      ${w.admin_note ? `<div class="alert info mt-14">${icon('info', 17)}<div>${esc(w.admin_note)}</div></div>` : ''}
      ${!final && canReview ? `<div class="field mt-18"><label class="label">Internal note</label><textarea class="textarea" id="wd-note" maxlength="500" placeholder="Optional note stored with this decision."></textarea></div>
      <div class="alert warn mt-14">${icon('alert', 17)}<div>Send USDT on BNB Smart Chain (BEP-20) from your own wallet, then record the real transaction hash. The app never sends funds by itself.</div></div>` : ''}`,
    footer: `<button class="btn btn-ghost" type="button" data-close>Close</button>
      ${!final && canReview ? `
        ${w.status === 'pending' ? '<button class="btn btn-ghost" type="button" data-approve>Approve</button>' : ''}
        ${w.status === 'approved' ? '<button class="btn btn-ghost" type="button" data-processing>Mark processing</button>' : ''}
        <button class="btn btn-danger" type="button" data-reject>Reject &amp; refund</button>
        <button class="btn btn-primary" type="button" data-pay>Record payout</button>` : ''}`
  });

  bindCopy(m.root);
  const close = m.root.querySelector('[data-close]');
  if (close) close.onclick = () => m.close();

  const note = () => m.root.querySelector('#wd-note')?.value.trim() || null;

  const simple = (action, title, message, danger) => async () => {
    const ok = await confirmDialog({ title, message, confirmLabel: title, danger });
    if (!ok) return;
    try {
      await rpc('admin_review_withdrawal', { p_withdrawal_id: w.id, p_action: action, p_tx_hash: null, p_note: note() });
      toast('Withdrawal updated.', 'success');
      m.close();
      reload();
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
    }
  };

  const approveBtn = m.root.querySelector('[data-approve]');
  if (approveBtn) {
    approveBtn.onclick = simple(
      'approve',
      'Approve withdrawal',
      `${usdt(w.amount)} USDT stays held and becomes ready for payout.`,
      false
    );
  }

  const procBtn = m.root.querySelector('[data-processing]');
  if (procBtn) {
    procBtn.onclick = simple('processing', 'Mark as processing', 'Use this while the transfer is in flight.', false);
  }

  const rejectBtn = m.root.querySelector('[data-reject]');
  if (rejectBtn) {
    rejectBtn.onclick = async () => {
      const reason = await askNote('Reject withdrawal', 'The user is notified and the amount returns to their available balance.', 'Reason', 'Reject & refund');
      if (reason === null) return;
      try {
        await rpc('admin_review_withdrawal', { p_withdrawal_id: w.id, p_action: 'reject', p_tx_hash: null, p_note: reason || note() });
        toast('Withdrawal rejected and refunded.', 'success');
        m.close();
        reload();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
      }
    };
  }

  const payBtn = m.root.querySelector('[data-pay]');
  if (payBtn) {
    payBtn.onclick = () => {
      const p = openModal({
        title: 'Record payout',
        subtitle: `${usdt(w.amount)} USDT · ${w.user_name || ''}`,
        body: `<div class="field">
            <label class="label">BEP-20 transaction hash</label>
            <input class="input mono" id="pay-hash" placeholder="0x…" />
            <span class="hint">Copy it from your wallet or BscScan. The server rejects anything that is not a real 64-character hash.</span>
          </div>
          <div class="alert warn mt-14">${icon('alert', 17)}<div>Only record a payout you have actually sent. This marks the withdrawal paid and can't be undone.</div></div>`,
        footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
          <button class="btn btn-primary" type="button" data-confirm>Mark paid</button>`
      });
      p.root.querySelector('[data-cancel]').onclick = () => p.close();
      p.root.querySelector('[data-confirm]').onclick = async () => {
        const hash = p.root.querySelector('#pay-hash').value.trim();
        if (!/^0x[a-fA-F0-9]{64}$/.test(hash)) return toast('Enter a valid 0x + 64 hex transaction hash.', 'error');
        const ok = await confirmDialog({
          title: 'Mark this withdrawal paid?',
          message: `${usdt(w.amount)} USDT is marked paid with ${hash.slice(0, 12)}… and removed from held funds.`,
          confirmLabel: 'Mark paid',
          danger: true
        });
        if (!ok) return;
        try {
          await rpc('admin_review_withdrawal', { p_withdrawal_id: w.id, p_action: 'pay', p_tx_hash: hash, p_note: note() });
          toast('Payout recorded.', 'success');
          p.close();
          m.close();
          reload();
        } catch (e) {
          toast(friendlyError(e), 'error', 6500);
        }
      };
    };
  }
}

/* ================================================================= LEDGER === */
export async function renderAdminLedger(root) {
  if (!allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE', 'SUPPORT'])) {
    root.innerHTML = forbiddenHTML(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE', 'SUPPORT']);
    return;
  }

  let kind = '';
  let offset = 0;
  const limit = 40;
  let total = 0;

  const KINDS = [
    'task_reward', 'task_pending', 'task_refund', 'escrow_release', 'escrow_return',
    'campaign_funding', 'campaign_refund', 'deposit', 'withdrawal_hold', 'withdrawal_paid',
    'withdrawal_refund', 'referral_bonus', 'admin_adjustment'
  ];

  root.innerHTML = `<div class="filter-bar">
      <select class="select input-sm" id="l-kind" style="max-width:220px">
        <option value="">All entry kinds</option>
        ${KINDS.map((k) => `<option value="${k}">${k}</option>`).join('')}
      </select>
      <span class="tiny dim">Ledger rows are append-only. Filter a single user from the Users page.</span>
    </div>
    <div id="l-list">${loadingBlock('Loading ledger')}</div>`;

  const listEl = root.querySelector('#l-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading ledger');
    let rows = [];
    try {
      const res = await rpc('admin_list_ledger', { p_kind: kind || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['User', 'Kind', 'Available', 'Pending', 'Reserved', 'Balance after', 'When'],
      rows.map((l) => `<tr>
        <td data-label="User"><div class="truncate">${esc(l.user_name || '')}</div><div class="tiny dim mono truncate">${esc(String(l.user_id).slice(0, 8))}</div></td>
        <td data-label="Kind"><span class="badge grey">${esc(l.kind)}</span>${l.note ? `<div class="tiny dim mt-6">${esc(l.note)}</div>` : ''}</td>
        <td data-label="Available" class="num ${Number(l.available_delta) >= 0 ? 'green' : 'red'}">${Number(l.available_delta) >= 0 ? '+' : ''}${esc(usdt(l.available_delta))}</td>
        <td data-label="Pending" class="num">${Number(l.pending_delta) ? esc(usdt(l.pending_delta)) : '—'}</td>
        <td data-label="Reserved" class="num">${Number(l.reserved_delta) ? esc(usdt(l.reserved_delta)) : '—'}</td>
        <td data-label="Balance after" class="num">${esc(usdt(l.available_after))}</td>
        <td data-label="When">${esc(dateTime(l.created_at))}</td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'book', title: 'No ledger entries', text: 'Wallet movements appear here as soon as money moves.' });

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
  };

  root.querySelector('#l-kind').addEventListener('change', (e) => { kind = e.target.value; offset = 0; load(); });
  await load();
}

/* =============================================================== SERVICES === */
export async function renderAdminServices(root) {
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Catalogue</span><h2>Services &amp; pricing</h2><p>Worker rewards and quantity limits. Changes apply to new campaigns only.</p></div>
      ${canEdit ? `<button class="btn btn-primary" type="button" data-new>${icon('plus', 16)} New service</button>` : '<span class="badge grey">Read only</span>'}
    </div>
    <div id="s-list">${loadingBlock('Loading services')}</div>`;

  const listEl = root.querySelector('#s-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading services');
    let rows = [];
    try {
      rows = (await rpc('admin_list_services')) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['Service', 'Reward', 'Quantity', 'Sort', 'Status', ''],
      rows.map((s) => `<tr>
        <td data-label="Service"><div class="row" style="gap:8px">${platformIcon(s.platform, 15)}<div><div>${esc(s.name)}</div><div class="tiny dim truncate">${esc(s.description || '')}</div></div></div></td>
        <td data-label="Reward">${esc(usdt(s.default_reward))} <span class="tiny dim">/ min ${esc(usdt(s.min_reward))}</span></td>
        <td data-label="Quantity">${Number(s.min_quantity)}–${Number(s.max_quantity)}</td>
        <td data-label="Sort">${Number(s.sort_order || 0)}</td>
        <td data-label="Status">${s.active ? '<span class="badge green">Active</span>' : '<span class="badge grey">Hidden</span>'}</td>
        <td data-label="Actions" class="cell-actions">
          ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-toggle="${esc(s.id)}">${s.active ? 'Hide' : 'Show'}</button>
          <button class="btn btn-soft btn-sm" type="button" data-edit="${esc(s.id)}">Edit</button>` : ''}
        </td>
      </tr>`)
    ) : emptyState({ iconName: 'layers', title: 'No services', text: 'Create at least one service before buyers can order.' });

    if (!canEdit) return;

    listEl.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => {
      const s = rows.find((x) => x.id === b.dataset.edit);
      if (s) serviceModal(s, load);
    }));

    listEl.querySelectorAll('[data-toggle]').forEach((b) => b.addEventListener('click', async () => {
      const s = rows.find((x) => x.id === b.dataset.toggle);
      if (!s) return;
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_upsert_service', {
          p_payload: {
            id: s.id,
            platform: s.platform,
            name: s.name,
            description: s.description || '',
            default_reward: Number(s.default_reward),
            min_reward: Number(s.min_reward),
            min_quantity: Number(s.min_quantity),
            max_quantity: Number(s.max_quantity),
            active: !s.active,
            sort_order: Number(s.sort_order || 100)
          }
        });
        toast(s.active ? 'Service hidden.' : 'Service is live.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  const newBtn = root.querySelector('[data-new]');
  if (newBtn) newBtn.addEventListener('click', () => serviceModal(null, load));
  await load();
}

function serviceModal(s, reload) {
  const isNew = !s;
  const m = openModal({
    title: isNew ? 'New service' : 'Edit service',
    subtitle: isNew ? 'It becomes orderable as soon as it is active.' : s.name,
    body: `<form id="svc-form" class="col" style="gap:12px">
      <div class="field-row">
        <div class="field"><label class="label">Platform</label>
          <select class="select" name="platform">
            ${['youtube', 'instagram', 'tiktok', 'facebook', 'x', 'telegram', 'reddit', 'spotify', 'discord', 'website'].map((p) => `<option value="${p}" ${s?.platform === p ? 'selected' : ''}>${platformMeta(p).label}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label class="label">Name</label><input class="input" name="name" required value="${esc(s?.name || '')}" maxlength="80" /></div>
      </div>
      <div class="field"><label class="label">Description</label><input class="input" name="description" value="${esc(s?.description || '')}" maxlength="200" /></div>
      <div class="field-row">
        <div class="field"><label class="label">Default reward (USDT)</label><input class="input" name="default_reward" type="number" step="0.000001" min="0.000001" required value="${s ? Number(s.default_reward) : '0.02'}" /></div>
        <div class="field"><label class="label">Minimum reward (USDT)</label><input class="input" name="min_reward" type="number" step="0.000001" min="0.000001" required value="${s ? Number(s.min_reward) : '0.01'}" /></div>
      </div>
      <div class="field-row">
        <div class="field"><label class="label">Minimum quantity</label><input class="input" name="min_quantity" type="number" step="1" min="1" required value="${s ? Number(s.min_quantity) : 10}" /></div>
        <div class="field"><label class="label">Maximum quantity</label><input class="input" name="max_quantity" type="number" step="1" min="1" required value="${s ? Number(s.max_quantity) : 20000}" /></div>
      </div>
      <div class="field-row">
        <div class="field"><label class="label">Sort order</label><input class="input" name="sort_order" type="number" step="1" value="${s ? Number(s.sort_order || 100) : 100}" /></div>
        <div class="field"><label class="label">Visibility</label>
          <select class="select" name="active">
            <option value="true" ${!s || s.active ? 'selected' : ''}>Active</option>
            <option value="false" ${s && !s.active ? 'selected' : ''}>Hidden</option>
          </select>
        </div>
      </div>
      <button class="btn btn-primary" type="submit">${isNew ? 'Create service' : 'Save changes'}</button>
    </form>`
  });

  m.root.querySelector('#svc-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      platform: String(fd.get('platform')),
      name: String(fd.get('name')).trim(),
      description: String(fd.get('description') || '').trim(),
      default_reward: Number(fd.get('default_reward')),
      min_reward: Number(fd.get('min_reward')),
      min_quantity: Number(fd.get('min_quantity')),
      max_quantity: Number(fd.get('max_quantity')),
      sort_order: Number(fd.get('sort_order') || 100),
      active: String(fd.get('active')) === 'true'
    };
    if (!isNew) payload.id = s.id;
    if (payload.max_quantity < payload.min_quantity) return toast('Max quantity must be greater than min quantity.', 'error');
    if (payload.min_reward > payload.default_reward * 50) return toast('Minimum reward is out of range.', 'error');

    const btn = e.currentTarget.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_upsert_service', { p_payload: payload });
      toast(isNew ? 'Service created.' : 'Service updated.', 'success');
      m.close();
      reload();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });
}

/* ============================================================== COUNTRIES === */
export async function renderAdminCountries(root) {
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Markets</span><h2>Countries</h2><p>Availability for workers and buyers per market.</p></div>
      ${canEdit ? `<button class="btn btn-primary" type="button" data-new-country>${icon('plus', 16)} Add country</button>` : '<span class="badge grey">Read only</span>'}
    </div>
    <div id="ct-list">${loadingBlock('Loading countries')}</div>`;

  const listEl = root.querySelector('#ct-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading countries');
    let rows = [];
    try {
      rows = (await rpc('admin_list_countries')) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['Code', 'Country', 'Active', 'Workers', 'Buyers', ''],
      rows.map((c) => `<tr>
        <td data-label="Code"><span class="mono">${esc(c.code)}</span></td>
        <td data-label="Country">${esc(c.name)}</td>
        <td data-label="Active">${c.active ? '<span class="badge green">Yes</span>' : '<span class="badge grey">No</span>'}</td>
        <td data-label="Workers">${c.allow_workers ? 'Yes' : 'No'}</td>
        <td data-label="Buyers">${c.allow_buyers ? 'Yes' : 'No'}</td>
        <td data-label="Actions" class="cell-actions">${canEdit ? `<button class="btn btn-soft btn-sm" type="button" data-edit-country="${esc(c.code)}">Edit</button>` : ''}</td>
      </tr>`)
    ) : emptyState({ iconName: 'globe', title: 'No countries', text: 'Add the markets you serve.' });

    if (!canEdit) return;
    listEl.querySelectorAll('[data-edit-country]').forEach((b) => b.addEventListener('click', () => {
      const c = rows.find((x) => x.code === b.dataset.editCountry);
      if (c) countryModal(c, load);
    }));
  };

  const newBtn = root.querySelector('[data-new-country]');
  if (newBtn) newBtn.addEventListener('click', () => countryModal(null, load));
  await load();
}

function countryModal(c, reload) {
  const isNew = !c;
  const m = openModal({
    title: isNew ? 'Add country' : `Edit ${c.name}`,
    body: `<form id="ct-form" class="col" style="gap:12px">
      <div class="field-row">
        <div class="field"><label class="label">ISO code</label><input class="input mono" name="code" maxlength="2" required value="${esc(c?.code || '')}" placeholder="BD" ${isNew ? '' : 'disabled'} /></div>
        <div class="field"><label class="label">Name</label><input class="input" name="name" required value="${esc(c?.name || '')}" maxlength="80" /></div>
      </div>
      <label class="check"><input type="checkbox" name="active" ${!c || c.active ? 'checked' : ''} /> <span>Active market</span></label>
      <label class="check"><input type="checkbox" name="allow_workers" ${!c || c.allow_workers ? 'checked' : ''} /> <span>Accept workers</span></label>
      <label class="check"><input type="checkbox" name="allow_buyers" ${!c || c.allow_buyers ? 'checked' : ''} /> <span>Accept buyers</span></label>
      <button class="btn btn-primary" type="submit">${isNew ? 'Add country' : 'Save changes'}</button>
    </form>`
  });

  m.root.querySelector('#ct-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const code = String(fd.get('code') || '').toUpperCase().trim();
    const name = String(fd.get('name') || '').trim();
    if (!/^[A-Z]{2}$/.test(code)) return toast('Code must be two letters.', 'error');
    if (!name) return toast('Name is required.', 'error');
    const btn = e.currentTarget.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_upsert_country', {
        p_code: code,
        p_name: name,
        p_active: fd.get('active') === 'on',
        p_allow_workers: fd.get('allow_workers') === 'on',
        p_allow_buyers: fd.get('allow_buyers') === 'on'
      });
      toast('Country saved.', 'success');
      m.close();
      reload();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });
}

/* ================================================================ SUPPORT === */
export async function renderAdminSupport(root) {
  let status = 'open';
  let offset = 0;
  const limit = 30;
  let total = 0;

  root.innerHTML = `<div class="filter-bar">
      <select class="select input-sm" id="sup-status" style="max-width:180px">
        <option value="open" selected>Open</option>
        <option value="pending">Pending</option>
        <option value="resolved">Resolved</option>
        <option value="closed">Closed</option>
        <option value="">All</option>
      </select>
    </div>
    <div id="sup-list">${loadingBlock('Loading tickets')}</div>`;

  const listEl = root.querySelector('#sup-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading tickets');
    let rows = [];
    try {
      const res = await rpc('admin_list_tickets', { p_status: status || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? `<div class="card"><div class="card-body"><div class="list">
      ${rows.map((t) => `<a class="list-row" href="#/admin/support" data-ticket="${esc(t.id)}">
        <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${icon('ticket', 16)}</span>
        <div class="list-main">
          <div class="row" style="gap:8px;flex-wrap:wrap"><span class="list-title">${esc(t.subject)}</span>${statusBadge(t.status)}</div>
          <div class="list-sub truncate">${esc(t.last_message || 'No messages')}</div>
          <div class="tiny dim mt-6">${esc(t.user_name || '')} · ${esc(t.category)} · updated ${esc(ago(t.updated_at))}</div>
        </div>
        ${icon('chevronRight', 16)}
      </a>`).join('')}
    </div></div>${pagerHtml(total, limit, offset)}</div>` : emptyState({ iconName: 'ticket', title: 'No tickets here', text: 'Support requests from workers and buyers appear here.' });

    listEl.querySelectorAll('[data-ticket]').forEach((a) => a.addEventListener('click', (e) => {
      e.preventDefault();
      openTicket(a.dataset.ticket, load);
    }));
    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
  };

  root.querySelector('#sup-status').addEventListener('change', (e) => { status = e.target.value; offset = 0; load(); });
  await load();
}

async function openTicket(id, reload) {
  let d;
  try {
    d = await rpc('get_ticket', { p_ticket_id: id });
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }
  const t = d.ticket || {};
  const messages = d.messages || [];

  const m = openModal({
    title: t.subject || 'Ticket',
    subtitle: `${t.category || ''} · opened ${dateTime(t.created_at)}`,
    wide: true,
    body: `<div class="chat" id="sup-chat" style="max-height:46dvh;overflow:auto;padding-right:4px">
        ${messages.map((x) => `<div class="chat-msg ${x.is_staff ? '' : 'user'}">
          <span class="avatar">${x.is_staff ? 'TM' : 'U'}</span>
          <div><div class="chat-bubble">${esc(x.body)}</div><div class="tiny dim mt-6">${x.is_staff ? 'Support' : 'User'} · ${esc(ago(x.created_at))}</div></div>
        </div>`).join('') || '<p class="small muted">No messages yet.</p>'}
      </div>
      <div class="field mt-14">
        <label class="label">Reply</label>
        <textarea class="textarea" id="sup-reply" maxlength="4000" placeholder="Write a clear reply…"></textarea>
      </div>
      <div class="field mt-10">
        <label class="label">Set status after replying</label>
        <select class="select" id="sup-set-status">
          ${['open', 'pending', 'resolved', 'closed'].map((s) => `<option value="${s}" ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Close</button>
      <button class="btn btn-primary" type="button" data-send>${icon('send', 15)} Send reply</button>`
  });

  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-send]').onclick = async (e) => {
    const body = m.root.querySelector('#sup-reply').value.trim();
    const next = m.root.querySelector('#sup-set-status').value;
    if (!body) return toast('Write a reply first.', 'error');
    setBusy(e.currentTarget, true, 'Sending');
    try {
      await rpc('admin_ticket_reply', { p_ticket_id: id, p_body: body, p_status: next });
      toast('Reply sent.', 'success');
      m.close();
      reload();
      openTicket(id, reload);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(e.currentTarget, false);
    }
  };
}

/* ================================================================== FLAGS === */
export async function renderAdminFlags(root) {
  let status = 'open';

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Security</span><h2>Fraud &amp; security</h2><p>Detection flags suspicious patterns for a human decision. It never bans, freezes or moves money on its own.</p></div>
      ${allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR'])
        ? `<button class="btn btn-soft" type="button" data-scan>${icon('shield', 15)} Run detection scan</button>`
        : ''}
    </div>
    <div id="f-kpis" class="kpis"></div>
    <div class="filter-bar mt-18">
      <select class="select input-sm" id="f-status" style="max-width:180px">
        <option value="open" selected>Open</option>
        <option value="reviewing">Reviewing</option>
        <option value="resolved">Resolved</option>
        <option value="dismissed">Dismissed</option>
        <option value="">All</option>
      </select>
      <span class="tiny dim">Every flag is written by the server from real rows (proof hashes, rejection rates, timers, referral and withdrawal bursts).</span>
    </div>
    <div id="f-list">${loadingBlock('Loading flags')}</div>`;

  const listEl = root.querySelector('#f-list');
  const kpiEl = root.querySelector('#f-kpis');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading flags');
    let rows = [];
    let ov = null;
    try {
      const [flags, overview] = await Promise.all([
        rpc('admin_list_flags', { p_status: status || null, p_limit: 100 }),
        rpc('admin_fraud_overview').catch(() => null)
      ]);
      rows = flags || [];
      ov = overview;
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    const c = ov?.counts || {};
    kpiEl.innerHTML = `<div class="kpis">
      ${kpi({ label: 'Open flags', value: Number(c.open || 0), iconName: 'flag', tone: 'gold', foot: 'Awaiting a decision' })}
      ${kpi({ label: 'High / critical', value: Number(c.high || 0) + Number(c.critical || 0), iconName: 'alert', tone: Number(c.critical || 0) > 0 ? 'red' : 'orange', foot: `${Number(c.critical || 0)} critical` })}
      ${kpi({ label: 'Suspended', value: Number(c.suspended || 0), iconName: 'lock', tone: 'violet', foot: `${Number(c.restricted || 0)} restricted` })}
      ${kpi({ label: 'Frozen wallets', value: Number(c.frozen_wallets || 0), iconName: 'wallet', tone: 'blue', foot: 'Outflows paused' })}
    </div>`;

    listEl.innerHTML = rows.length ? `<div class="col" style="gap:12px">
      ${rows.map((f) => {
        const [tone, risk] = riskOf(f.severity);
        return `<div class="card card-pad">
        <div class="row" style="gap:10px;align-items:flex-start;flex-wrap:wrap">
          <span class="empty-ic" style="width:36px;height:36px;margin:0;border-radius:10px;color:${tone === 'red' ? 'var(--red)' : tone === 'orange' ? 'var(--brand)' : 'var(--gold)'}">${icon('flag', 17)}</span>
          <div style="flex:1;min-width:200px">
            <div class="row" style="gap:8px;flex-wrap:wrap">
              <span class="strong">${esc(f.kind)}</span>
              <span class="badge ${tone}">${risk}</span>
              <span class="badge grey">Severity ${Number(f.severity)}</span>
              ${statusBadge(f.status)}
            </div>
            <div class="small muted mt-6">${esc(f.user_name || 'Unknown user')}${f.user_status ? ` · ${esc(f.user_status)}` : ''} · ${esc(ago(f.created_at))}</div>
            <details class="mt-10"><summary class="tiny dim" style="cursor:pointer">Evidence</summary><div class="mono-box mt-6">${esc(jsonPretty(f.details))}</div></details>
          </div>
          <div class="row-wrap">
            ${f.user_id ? `<button class="btn btn-ghost btn-sm" type="button" data-open-user="${esc(f.user_id)}">Open user</button>` : ''}
            ${f.status !== 'resolved' && f.status !== 'dismissed'
              ? `<button class="btn btn-soft btn-sm" type="button" data-resolve="${esc(f.id)}">Resolve</button>`
              : ''}
          </div>
        </div>
      </div>`;
      }).join('')}
    </div>` : emptyState({ iconName: 'flag', title: 'No flags here', text: 'Nothing has been flagged for this status. Run the detection scan to check the current data.' });

    listEl.querySelectorAll('[data-open-user]').forEach((b) => b.addEventListener('click', () => openUserModal(b.dataset.openUser, load)));

    listEl.querySelectorAll('[data-resolve]').forEach((b) => b.addEventListener('click', async () => {
      const f = rows.find((x) => x.id === b.dataset.resolve);
      const note = await askNote('Resolve flag', `Resolving "${f?.kind || 'flag'}". Record what you found so the audit trail is complete.`, 'Resolution', 'Resolve', false);
      if (note === null) return;
      try {
        await rpc('admin_resolve_flag', { p_flag_id: b.dataset.resolve, p_note: note || null });
        toast('Flag resolved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
      }
    }));
  };

  const scan = root.querySelector('[data-scan]');
  if (scan) scan.addEventListener('click', async () => {
    setBusy(scan, true, 'Scanning');
    try {
      const res = await rpc('admin_scan_fraud');
      const flagged = res?.flagged || {};
      const total = Object.values(flagged).reduce((a, b) => a + Number(b || 0), 0);
      toast(total > 0 ? `${total} new flag(s) created for review.` : 'Scan finished — nothing new to flag.', total > 0 ? 'info' : 'success', 7000);
      load();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      if (scan.isConnected) setBusy(scan, false);
    }
  });

  root.querySelector('#f-status').addEventListener('change', (e) => { status = e.target.value; load(); });
  await load();
}

/* =============================================================== SETTINGS === */
export async function renderAdminSettings(root) {
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN']);
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Configuration</span><h2>Platform settings</h2><p>Fees, limits and public copy. Public values are readable by visitors.</p></div>
      ${canEdit ? '' : '<span class="badge grey">Read only</span>'}
    </div>
    <div id="st-list">${loadingBlock('Loading settings')}</div>`;

  const listEl = root.querySelector('#st-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading settings');
    let rows = [];
    try {
      rows = (await rpc('admin_get_settings')) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    const pub = rows.filter((r) => r.is_public);
    const priv = rows.filter((r) => !r.is_public);

    const section = (title, list, hint) => `<div class="card mt-18">
      <div class="card-head"><h3>${esc(title)}</h3><span class="badge grey">${list.length}</span></div>
      <div class="card-body">
        <p class="small muted mb-10">${hint}</p>
        <div class="list">
          ${list.map((s) => `<div class="list-row">
            <div class="list-main">
              <div class="list-title mono">${esc(s.key)}</div>
              <div class="list-sub">${esc(valueLabel(s.value))}</div>
              <div class="tiny dim mt-6">Updated ${esc(ago(s.updated_at))}</div>
            </div>
            ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-edit-setting="${esc(s.key)}">Edit</button>` : ''}
          </div>`).join('') || '<p class="small muted">Nothing here.</p>'}
        </div>
      </div>
    </div>`;

    listEl.innerHTML = section('Public settings', pub, 'Shown to visitors and signed-in users: fees, limits, deposit address and announcement.')
      + section('Private settings', priv, 'Used by the server only: commission, claim window, campaign auto-approval and open withdrawal cap.');

    if (!canEdit) return;
    listEl.querySelectorAll('[data-edit-setting]').forEach((b) => b.addEventListener('click', () => {
      const s = rows.find((x) => x.key === b.dataset.editSetting);
      if (s) settingModal(s, load);
    }));
  };

  await load();
}

function valueLabel(v) {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'string') return v || '(empty)';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return JSON.stringify(v);
}

function settingModal(s, reload) {
  const kind = s.value === null || s.value === undefined ? 'string'
    : typeof s.value === 'number' ? 'number'
      : typeof s.value === 'boolean' ? 'boolean'
        : typeof s.value === 'string' ? 'string' : 'json';

  const input = kind === 'number'
    ? `<input class="input" id="set-value" type="number" step="0.000001" value="${esc(String(s.value))}" />`
    : kind === 'boolean'
      ? `<select class="select" id="set-value"><option value="true" ${s.value === true ? 'selected' : ''}>true</option><option value="false" ${s.value === false ? 'selected' : ''}>false</option></select>`
      : kind === 'json'
        ? `<textarea class="textarea mono" id="set-value" rows="6">${esc(JSON.stringify(s.value, null, 2))}</textarea>`
        : `<input class="input" id="set-value" value="${esc(String(s.value ?? ''))}" />`;

  const m = openModal({
    title: s.key,
    subtitle: kind === 'json' ? 'JSON value' : `${kind} value`,
    body: `<div class="field"><label class="label">Value</label>${input}</div>
      <label class="check mt-14"><input type="checkbox" id="set-public" ${s.is_public ? 'checked' : ''} /> <span>Publicly readable</span></label>
      <div class="alert warn mt-14">${icon('alert', 17)}<div>Fees and limits apply to new campaigns and requests. Existing escrow is not recalculated.</div></div>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
      <button class="btn btn-primary" type="button" data-save>Save setting</button>`
  });

  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-save]').onclick = async (e) => {
    const raw = m.root.querySelector('#set-value').value;
    let value;
    if (kind === 'number') {
      const n = Number(raw);
      if (!Number.isFinite(n)) return toast('Enter a valid number.', 'error');
      value = n;
    } else if (kind === 'boolean') {
      value = raw === 'true';
    } else if (kind === 'json') {
      try { value = JSON.parse(raw); } catch (_) { return toast('That is not valid JSON.', 'error'); }
    } else {
      value = String(raw);
    }

    const isPublic = m.root.querySelector('#set-public').checked;
    setBusy(e.currentTarget, true, 'Saving');
    try {
      await rpc('admin_update_setting', { p_key: s.key, p_value: value, p_is_public: ['min_deposit', 'withdrawal_min'].includes(s.key) ? true : isPublic });
      toast('Setting saved.', 'success');
      m.close();
      reload();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(e.currentTarget, false);
    }
  };
}

/* ================================================================= ADMINS === */
export async function renderAdminAdmins(root) {
  const canGrant = allowed(['OWNER']);
  const promoteSql = "update public.profiles set admin_role = 'OWNER', status = 'active', is_suspended = false where lower(email) = lower('new-owner@example.com');";
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Access</span><h2>Admin accounts</h2><p>Roles are stored on the profile and enforced by every RPC.</p></div>
    </div>
    <div id="ad-list">${loadingBlock('Loading admins')}</div>`;

  const listEl = root.querySelector('#ad-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading admins');
    let rows = [];
    try {
      rows = (await rpc('admin_list_admins')) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = `<div class="card">
      <div class="card-head"><h3>Current admins</h3><span class="badge gold">${rows.length}</span></div>
      <div class="card-body">
        ${rows.length ? `<div class="list">${rows.map((a) => `<div class="list-row">
          <div class="list-main">
            <div class="row" style="gap:8px;flex-wrap:wrap"><span class="list-title">${esc(a.full_name || a.email || 'Admin')}</span><span class="badge gold">${esc(String(a.admin_role || '').replace('_', ' '))}</span>${statusBadge(a.status)}</div>
            <div class="list-sub">${esc(a.email || '')}</div>
          </div>
          ${canGrant ? `<select class="select input-sm" style="max-width:170px" data-role-user="${esc(a.id)}">
            ${ROLES.map((r) => `<option value="${r}" ${a.admin_role === r ? 'selected' : ''}>${r.replace('_', ' ')}</option>`).join('')}
          </select>` : ''}
        </div>`).join('')}</div>` : '<p class="small muted">No admin accounts yet. Run <span class="mono">supabase/promote-owner.sql</span> in the SQL editor to make the first owner, then reload.</p>'}
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Promote an owner</h3><span class="badge grey">SQL</span></div>
      <div class="card-body">
        <p class="small muted mb-10">Admin access is a database role, never a password in this app. Sign in once with the account you want to promote, then run this in <strong>Supabase → SQL Editor</strong>. The same statement is in <span class="mono">supabase/promote-owner.sql</span>, with role and Telegram variants.</p>
        <div class="mono-box" style="white-space:pre-wrap;word-break:break-word;line-height:1.6;font-size:12px">${esc(promoteSql)}</div>
        <div class="row-wrap mt-10">
          <button class="btn btn-soft btn-sm" type="button" data-copy-promote>${icon('copy', 14)} Copy SQL</button>
        </div>
        <p class="tiny dim mt-10">Telegram sign-in creates the email <span class="mono">tg&lt;telegram_id&gt;@telegram.tmgrow.app</span>; promote it with <span class="mono">where telegram_id = …</span> instead. A role change is re-checked by every admin RPC, so the browser cannot widen it.</p>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>What each role can do</h3><span class="badge grey">Enforced server-side</span></div>
      <div class="card-body">
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Role</th><th>Scope</th></tr></thead>
          <tbody>${ROLES.map((r) => `<tr><td><span class="badge ${r === 'OWNER' ? 'gold' : 'grey'}">${r.replace('_', ' ')}</span></td><td class="small muted">${esc(ROLE_HINT[r])}</td></tr>`).join('')}</tbody>
        </table></div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Only an OWNER can change another account's role. You cannot grant yourself a lower role when you are the last owner.</div></div>
      </div>
    </div>`;

    const copyPromote = listEl.querySelector('[data-copy-promote]');
    if (copyPromote) copyPromote.addEventListener('click', async () => {
      const ok = await copyText(promoteSql);
      toast(ok ? 'SQL copied. Paste it in Supabase → SQL Editor and run it.' : 'Copy failed — select the SQL manually.',
        ok ? 'success' : 'error', 7000);
    });

    if (!canGrant) return;
    listEl.querySelectorAll('[data-role-user]').forEach((sel) => sel.addEventListener('change', async () => {
      const next = sel.value;
      const ok = await confirmDialog({
        title: 'Change this admin role?',
        message: `The account moves to ${next} immediately. Server permissions change with it.`,
        confirmLabel: 'Save role',
        danger: true
      });
      if (!ok) { load(); return; }
      try {
        await rpc('admin_set_admin_role', { p_user_id: sel.dataset.roleUser, p_admin_role: next });
        toast('Role saved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        load();
      }
    }));
  };

  await load();
}

/* ================================================================== AUDIT === */
export async function renderAdminAudit(root) {
  if (!allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN'])) {
    root.innerHTML = forbiddenHTML(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
    return;
  }

  let q = '';
  let offset = 0;
  const limit = 40;
  let total = 0;

  root.innerHTML = `<div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="a-q" placeholder="Action or entity type" autocomplete="off" /></div>
      <span class="tiny dim">Entries are append-only and written by the server.</span>
    </div>
    <div id="a-list">${loadingBlock('Loading audit log')}</div>`;

  const listEl = root.querySelector('#a-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading audit log');
    let rows = [];
    try {
      const res = await rpc('admin_list_audit', { p_query: q || null, p_limit: limit, p_offset: offset });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['Action', 'Actor', 'Role', 'Entity', 'When', 'Details'],
      rows.map((a) => `<tr>
        <td data-label="Action"><span class="mono tiny">${esc(a.action)}</span></td>
        <td data-label="Actor">${esc(a.actor_name || 'System')}</td>
        <td data-label="Role">${esc(a.actor_role || '—')}</td>
        <td data-label="Entity">${esc(a.entity_type || '—')}${a.entity_id ? `<div class="tiny dim mono">${esc(String(a.entity_id).slice(0, 8))}</div>` : ''}</td>
        <td data-label="When">${esc(ago(a.created_at))}</td>
        <td data-label="Details">${a.details ? `<details><summary class="tiny dim" style="cursor:pointer">Show</summary><div class="mono-box mt-6">${esc(jsonPretty(a.details))}</div></details>` : '—'}</td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({ iconName: 'file', title: 'No audit entries', text: 'Server actions are recorded here as they happen.' });

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
  };

  root.querySelector('#a-q').addEventListener('input', debounce((e) => { q = e.target.value.trim(); offset = 0; load(); }, 320));
  await load();
}

/* ============================================================== REFERRALS === */
export async function renderAdminReferrals(root) {
  if (!allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE', 'SUPPORT'])) {
    root.innerHTML = forbiddenHTML(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE', 'SUPPORT']);
    return;
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Growth</span><h2>Referrals</h2><p>Who invited whom, at what rate, and what the referrer has earned in total from the referral programme.</p></div>
    </div>
    <div id="ref-list">${loadingBlock('Loading referrals')}</div>`;

  const listEl = root.querySelector('#ref-list');

  let rows = [];
  try {
    rows = (await rpc('admin_list_referrals', { p_limit: 200, p_offset: 0 })) || [];
  } catch (e) {
    listEl.innerHTML = errorPanel(friendlyError(e));
    return;
  }

  listEl.innerHTML = rows.length ? tableHtml(
    ['Referrer', 'Referred worker', 'Rate', 'Referrer earned', 'Linked'],
    rows.map((r) => `<tr>
      <td data-label="Referrer">${esc(r.referrer || '')}</td>
      <td data-label="Referred worker">${esc(r.referred || '')}</td>
      <td data-label="Rate">${Number(r.rate || 0)}%</td>
      <td data-label="Referrer earned" class="num gold-text">${esc(usdt(r.earned))}</td>
      <td data-label="Linked">${esc(shortDate(r.created_at))}</td>
    </tr>`)
  ) : emptyState({
    iconName: 'gift',
    title: 'No referrals yet',
    text: 'When a worker joins with an invite code, the link appears here and commission is recorded on approved proofs.'
  });

  listEl.insertAdjacentHTML('beforeend', '<p class="tiny dim mt-14">The "Referrer earned" column is the referrer\'s lifetime referral commission, shown on each of their referral rows.</p>');
}

/* ============================================================ ANNOUNCEMENTS === */
export async function renderAdminBroadcast(root) {
  const canSend = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'SUPPORT']);
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Communication</span><h2>Announcements</h2><p>Send an in-app notification to a real audience segment. Recipient counts come from the database.</p></div>
    </div>
    ${canSend ? `<div class="grid grid-2" style="align-items:start">
      <div class="card card-pad">
        <form id="bc-form" class="col" style="gap:13px">
          <div class="field"><label class="label">Title</label><input class="input" name="title" maxlength="120" required placeholder="e.g. Payout schedule update" /></div>
          <div class="field"><label class="label">Message</label><textarea class="textarea" name="body" maxlength="800" placeholder="Write the announcement text."></textarea></div>
          <div class="field"><label class="label">Audience</label>
            <select class="select" name="audience">
              <option value="all">Everyone</option>
              <option value="workers">Workers</option>
              <option value="buyers">Buyers</option>
              <option value="admins">Admins</option>
            </select>
          </div>
          <button class="btn btn-primary" type="submit">Send announcement</button>
        </form>
      </div>
      <div class="card card-pad">
        <h3 style="font-size:14px" class="mb-10">Before you send</h3>
        <div class="step-list">
          <div class="step"><span class="sn">1</span><span>Announcements arrive in the notifications inbox, not by email.</span></div>
          <div class="step"><span class="sn">2</span><span>Every send writes an audit entry with the exact recipient count.</span></div>
          <div class="step"><span class="sn">3</span><span>Keep it factual: no promises about payout timing you cannot keep.</span></div>
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div>There is no undo. Test the wording with the team first.</div></div>
      </div>
    </div>
    <div id="ann-box" class="mt-18">${loadingBlock('Loading Telegram announcements')}</div>` : forbiddenHTML(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'SUPPORT'])}`;

  const form = root.querySelector('#bc-form');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const title = String(fd.get('title') || '').trim();
    const body = String(fd.get('body') || '').trim();
    const audience = String(fd.get('audience') || 'all');
    if (title.length < 3) return toast('Give the announcement a clear title.', 'error');
    const ok = await confirmDialog({
      title: 'Send announcement?',
      message: `"${title}" goes to the ${audience} audience in their notifications inbox. This cannot be undone.`,
      confirmLabel: 'Send now'
    });
    if (!ok) return;
    const btn = form.querySelector('button[type=submit]');
    setBusy(btn, true, 'Sending');
    try {
      const res = await rpc('admin_broadcast', { p_title: title, p_body: body || null, p_audience: audience });
      toast(`Announcement sent to ${Number(res?.sent || 0)} account(s).`, 'success');
      form.reset();
      setBusy(btn, false);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  /* ---- Telegram announcements (draft, schedule, publish, history) ---- */
  const box = root.querySelector('#ann-box');
  if (!box) return;
  const canEditAnn = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  let saving = false;

  const collect = (f) => {
    const fd = new FormData(f);
    const t = String(fd.get('scheduled_at') || '').trim();
    return {
      title: String(fd.get('title') || '').trim(),
      body: String(fd.get('body') || '').trim(),
      audience: String(fd.get('audience') || 'all'),
      channel: String(fd.get('channel') || 'both'),
      image_url: String(fd.get('image_url') || '').trim() || null,
      link_url: String(fd.get('link_url') || '').trim() || null,
      scheduled_at: t ? new Date(t).toISOString() : null
    };
  };

  const loadAnn = async () => {
    box.innerHTML = loadingBlock('Loading Telegram announcements');
    let rows = [];
    try {
      const res = await rpc('admin_announcement_list', { p_limit: 30, p_offset: 0 });
      rows = res?.items || [];
    } catch (e) {
      box.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }

    box.innerHTML = `<div class="card">
      <div class="card-head"><h3>Telegram announcements</h3><span class="badge grey">${rows.length}</span></div>
      <div class="card-body">
        <form id="ann-form" class="col" style="gap:12px">
          <div class="grid grid-2">
            <div class="field"><label class="label">Title</label><input class="input" name="title" maxlength="140" required /></div>
            <div class="field"><label class="label">Audience</label><select class="select" name="audience">
              <option value="all">Everyone</option><option value="workers">Workers</option><option value="buyers">Buyers</option>
            </select></div>
          </div>
          <div class="field"><label class="label">Message</label><textarea class="textarea" name="body" rows="7" maxlength="3000" required placeholder="Write the announcement. Emojis and links are fine."></textarea></div>
          <div class="grid grid-2">
            <div class="field"><label class="label">Channel</label><select class="select" name="channel">
              <option value="both">Telegram + in-app</option><option value="telegram">Telegram only</option><option value="in_app">In-app only</option>
            </select></div>
            <div class="field"><label class="label">Schedule (optional)</label><input class="input" type="datetime-local" name="scheduled_at" /></div>
          </div>
          <div class="grid grid-2">
            <div class="field"><label class="label">Image URL (optional)</label><input class="input" name="image_url" placeholder="https://…" /></div>
            <div class="field"><label class="label">Link (optional)</label><input class="input" name="link_url" placeholder="https://…" /></div>
          </div>
          <div class="row-wrap">
            ${canEditAnn ? '<button class="btn btn-soft" type="button" data-ann-save>Save draft</button><button class="btn btn-primary" type="button" data-ann-publish>Save and publish</button>' : ''}
            <span class="tiny dim">One message per recipient. Scheduled drafts are published by the database job.</span>
          </div>
        </form>
      </div>
    </div>
    <div class="card mt-14">
      <div class="card-head"><h3>Broadcast history</h3><span class="badge grey">${rows.length}</span></div>
      <div class="card-body">
        ${rows.length ? tableHtml(['Title', 'Audience', 'Channel', 'Status', 'Recipients', 'Telegram', 'Created', ''], rows.map((a) => `<tr>
          <td data-label="Title">${esc(a.title)}</td>
          <td data-label="Audience">${esc(a.audience)}</td>
          <td data-label="Channel">${esc(a.channel)}</td>
          <td data-label="Status">${statusBadge(a.status === 'sent' ? 'approved' : a.status === 'failed' ? 'rejected' : a.status === 'sending' ? 'processing' : 'draft', a.status)}</td>
          <td data-label="Recipients" class="num">${Number(a.recipients || 0)}</td>
          <td data-label="Telegram" class="num">${Number(a.telegram_queued || 0)}</td>
          <td data-label="Created">${esc(ago(a.created_at))}</td>
          <td data-label="">${(a.status === 'draft' || a.status === 'scheduled') && canEditAnn
            ? `<div class="row-wrap"><button class="btn btn-ghost btn-sm" type="button" data-ann-edit="${esc(a.id)}">Edit</button><button class="btn btn-ghost btn-sm" type="button" data-ann-del="${esc(a.id)}">Delete</button><button class="btn btn-soft btn-sm" type="button" data-ann-pub="${esc(a.id)}">Publish</button></div>`
            : a.status === 'failed' ? `<span class="tiny red">${esc(a.error_text || '')}</span>` : ''}</td>
        </tr>`)) : '<p class="small muted">No Telegram announcement yet.</p>'}
      </div>
    </div>`;

    box.querySelectorAll('[data-ann-pub]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await confirmDialog({ title: 'Publish announcement?', message: 'This sends the saved message to the selected audience once.', confirmLabel: 'Publish' });
      if (!ok) return;
      setBusy(b, true, 'Sending');
      try {
        await rpc('admin_announcement_publish', { p_id: b.dataset.annPub });
        toast('Announcement published.', 'success');
        loadAnn();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(b, false);
      }
    }));

    box.querySelectorAll('[data-ann-del]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Delete this announcement?',
        message: 'Only drafts and scheduled announcements can be deleted. Sent messages stay in the history.',
        confirmLabel: 'Delete',
        danger: true
      });
      if (!ok) return;
      setBusy(b, true, 'Deleting');
      try {
        await rpc('admin_announcement_delete', { p_id: b.dataset.annDel });
        toast('Announcement deleted.', 'success');
        loadAnn();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(b, false);
      }
    }));

    box.querySelectorAll('[data-ann-edit]').forEach((b) => b.addEventListener('click', () => {
      const a = rows.find((x) => x.id === b.dataset.annEdit);
      if (!a) return;
      const m = openModal({
        title: 'Edit announcement',
        subtitle: a.status,
        wide: true,
        body: `<div class="col" style="gap:12px">
          <div class="field"><label class="label">Title</label><input class="input" id="ea-title" maxlength="140" value="${esc(a.title || '')}" /></div>
          <div class="field"><label class="label">Message</label><textarea class="textarea" id="ea-body" rows="7" maxlength="3000">${esc(a.body || '')}</textarea></div>
          <div class="grid grid-2">
            <div class="field"><label class="label">Audience</label><select class="select" id="ea-audience">
              ${['all','workers','buyers'].map((v) => `<option value="${v}" ${a.audience === v ? 'selected' : ''}>${v}</option>`).join('')}
            </select></div>
            <div class="field"><label class="label">Channel</label><select class="select" id="ea-channel">
              ${['both','telegram','in_app'].map((v) => `<option value="${v}" ${a.channel === v ? 'selected' : ''}>${v}</option>`).join('')}
            </select></div>
          </div>
          <div class="grid grid-2">
            <div class="field"><label class="label">Image URL</label><input class="input" id="ea-image" value="${esc(a.image_url || '')}" placeholder="https://…" /></div>
            <div class="field"><label class="label">Link</label><input class="input" id="ea-link" value="${esc(a.link_url || '')}" placeholder="https://…" /></div>
          </div>
          <div class="field"><label class="label">Schedule (optional)</label><input class="input" id="ea-schedule" type="datetime-local" value="${a.scheduled_at ? new Date(a.scheduled_at).toISOString().slice(0, 16) : ''}" /></div>
        </div>`,
        footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
          <button class="btn btn-primary" type="button" data-save>Save changes</button>`
      });
      m.root.querySelector('[data-cancel]').onclick = () => m.close();
      m.root.querySelector('[data-save]').onclick = async (e) => {
        const rawSchedule = m.root.querySelector('#ea-schedule').value;
        const payload = {
          id: a.id,
          title: m.root.querySelector('#ea-title').value.trim(),
          body: m.root.querySelector('#ea-body').value.trim(),
          audience: m.root.querySelector('#ea-audience').value,
          channel: m.root.querySelector('#ea-channel').value,
          image_url: m.root.querySelector('#ea-image').value.trim() || null,
          link_url: m.root.querySelector('#ea-link').value.trim() || null,
          scheduled_at: rawSchedule ? new Date(rawSchedule).toISOString() : null
        };
        if (payload.title.length < 3 || payload.body.length < 10) {
          return toast('Title and message are required.', 'error');
        }
        setBusy(e.currentTarget, true, 'Saving');
        try {
          await rpc('admin_announcement_save', { p_payload: payload });
          toast('Announcement saved.', 'success');
          m.close();
          loadAnn();
        } catch (err) {
          toast(friendlyError(err), 'error', 8000);
          setBusy(e.currentTarget, false);
        }
      };
    }));
  };

  box.addEventListener('click', (e) => {
    const saveBtn = e.target.closest('[data-ann-save]');
    const pubBtn = e.target.closest('[data-ann-publish]');
    if (!saveBtn && !pubBtn) return;
    const form = box.querySelector('#ann-form');
    if (!form || saving) return;
    const payload = collect(form);
    if (payload.title.length < 3 || payload.body.length < 10) {
      toast('Title and message are required.', 'error');
      return;
    }
    saving = true;
    const btn = pubBtn || saveBtn;
    setBusy(btn, true, 'Saving');
    (async () => {
      try {
        const res = await rpc('admin_announcement_save', { p_payload: payload });
        const id = res?.announcement?.id;
        if (pubBtn && id) {
          if (payload.scheduled_at) {
            toast('Saved as scheduled. The database publishes it at the set time.', 'success', 8000);
          } else {
            await rpc('admin_announcement_publish', { p_id: id });
            toast('Announcement published.', 'success');
          }
        } else {
          toast('Draft saved.', 'success');
        }
        saving = false;
        loadAnn();
      } catch (err) {
        saving = false;
        toast(friendlyError(err), 'error', 8000);
        setBusy(btn, false);
      }
    })();
  });

  loadAnn();
}

/* ============================================================ AI ASSISTANT === */
const AI_KEY = 'tmgrow-ai';

function readProvider() {
  try {
    const raw = localStorage.getItem(AI_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (_) { return null; }
}

function writeProvider(p) {
  try {
    if (p) localStorage.setItem(AI_KEY, JSON.stringify(p));
    else localStorage.removeItem(AI_KEY);
  } catch (_) { /* storage may be blocked */ }
}

function localAnswer(snap, question) {
  const t = snap.totals || {};
  const f = snap.finance || {};
  const q = String(question || '').toLowerCase();
  const hit = (...keys) => keys.some((k) => q.includes(k));
  const lines = [];
  const stamp = `Snapshot taken ${dateTime(snap.generated_at)} · last ${Number(snap.days || 7)} days · source: live database`;

  if (hit('proof', 'verif', 'review', 'queue')) {
    lines.push(`Proof queue: ${Number(t.proofs_pending || 0)} submission(s) waiting.`);
    if (Number(t.proofs_oldest_hours || 0) > 0) lines.push(`Oldest pending proof: ${Number(t.proofs_oldest_hours)} hours old.`);
    lines.push(`Approved in range: ${Number(t.approved_in_range || 0)} · rejected in range: ${Number(t.rejected_in_range || 0)}.`);
    (snap.pending_proofs || []).slice(0, 8).forEach((p) => {
      lines.push(`• ${p.worker} — ${p.campaign} (${p.platform}) — ${usdt(p.reward)} USDT${p.duplicate_hash ? ' — duplicate image flagged' : ''}`);
    });
    if (!(snap.pending_proofs || []).length) lines.push('No pending proofs to list.');
  } else if (hit('withdraw', 'payout', 'cash out', 'settle')) {
    lines.push(`Withdrawal queue: ${Number(t.withdrawals_pending || 0)} request(s) worth ${usdt(t.withdrawals_pending_amount)} USDT.`);
    if (Number(t.pending_withdrawal_oldest_hours || 0) > 0) lines.push(`Oldest open request: ${Number(t.pending_withdrawal_oldest_hours)} hours.`);
    (snap.withdrawal_queue || []).forEach((w) => lines.push(`• ${w.user} — ${usdt(w.amount)} USDT — ${w.status}`));
    lines.push(`Lifetime paid out: ${usdt(f.withdrawals_paid)} USDT.`);
  } else if (hit('deposit', 'fund', 'top up')) {
    lines.push(`Deposits waiting: ${Number(t.deposits_pending || 0)} request(s) worth ${usdt(t.deposits_pending_amount)} USDT.`);
    lines.push(`Approved deposits lifetime: ${usdt(f.deposits_approved)} USDT.`);
    lines.push('Deposit review is in the Deposits queue; approve only after checking the hash on-chain.');
  } else if (hit('flag', 'risk', 'fraud', 'abuse', 'duplicate')) {
    lines.push(`Open risk flags: ${Number(t.open_flags || 0)}.`);
    (snap.flags || []).forEach((fl) => lines.push(`• ${fl.kind} (severity ${fl.severity}) — ${fl.user}${fl.details?.hash ? ` — hash ${String(fl.details.hash).slice(0, 12)}…` : ''}`));
    if (!(snap.flags || []).length) lines.push('No open flags right now.');
  } else if (hit('ticket', 'support', 'help')) {
    lines.push(`Open support tickets: ${Number(t.open_tickets || 0)}.`);
    (snap.support_queue || []).forEach((s) => lines.push(`• ${s.subject} — ${s.status}`));
  } else if (hit('campaign', 'advertis', 'buyer', 'order')) {
    lines.push(`Campaigns: ${Number(t.campaigns_active || 0)} active, ${Number(t.campaigns_pending || 0)} pending review, ${Number(t.campaigns_completed || 0)} completed.`);
    lines.push(`Buyers: ${Number(t.buyers || 0)} accounts.`);
    (snap.top_services || []).forEach((s) => lines.push(`• ${s.service_name}: ${Number(s.approved)} approved, ${usdt(s.spend)} USDT spend`));
  } else if (hit('revenue', 'money', 'finance', 'fee', 'income', 'wallet', 'balance')) {
    lines.push(`Wallets: ${usdt(f.available)} USDT available, ${usdt(f.pending)} pending, ${usdt(f.reserved)} reserved.`);
    lines.push(`Platform revenue: ${usdt(f.revenue)} USDT.`);
    lines.push(`Rewards paid: ${usdt(f.rewards_paid)} USDT lifetime, ${usdt(f.rewards_paid_in_range)} USDT in range.`);
  } else if (hit('worker', 'user', 'account', 'signup')) {
    lines.push(`Accounts: ${Number(t.users || 0)} total, ${Number(t.workers || 0)} workers, ${Number(t.buyers || 0)} buyers, ${Number(t.admins || 0)} admins.`);
    lines.push(`New accounts in range: ${Number(t.new_users || 0)}.`);
  } else {
    lines.push(`Accounts: ${Number(t.users || 0)} (${Number(t.new_users || 0)} new in range).`);
    lines.push(`Proofs waiting: ${Number(t.proofs_pending || 0)} · open flags: ${Number(t.open_flags || 0)} · open tickets: ${Number(t.open_tickets || 0)}.`);
    lines.push(`Money: ${usdt(f.available)} USDT available, ${usdt(f.pending)} pending, ${usdt(f.reserved)} reserved, ${usdt(f.revenue)} revenue.`);
    lines.push(`Withdrawals open: ${Number(t.withdrawals_pending || 0)} worth ${usdt(t.withdrawals_pending_amount)} USDT · deposits waiting: ${Number(t.deposits_pending || 0)} worth ${usdt(t.deposits_pending_amount)} USDT.`);
  }

  lines.push('');
  lines.push('I can summarise, but I cannot move money or change roles. Use the queues and their confirmation dialogs for that.');
  return `${stamp}\n\n${lines.join('\n')}`;
}

async function providerAnswer(provider, snap, question) {
  const base = String(provider.base || '').replace(/\/+$/, '');
  const url = `${base}/chat/completions`;
  const system = 'You are the TM GROW admin analyst. Use ONLY the JSON snapshot supplied by the user. Never invent numbers, names or dates. If a value is missing, say it is not in the snapshot. Amounts are USDT. Be concise, use short plain lines, and never claim you changed anything.';
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${provider.key}` },
    body: JSON.stringify({
      model: provider.model,
      temperature: 0.2,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: `Snapshot JSON:\n${JSON.stringify(snap)}\n\nQuestion: ${question}` }
      ]
    })
  });
  if (!res.ok) throw new Error(`The provider answered ${res.status}.`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('The provider returned an empty answer.');
  return text;
}

export async function renderAdminAI(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  let snapshot = null;
  const messages = [];

  root.innerHTML = loadingBlock('Reading live platform data');
  try {
    snapshot = await rpc('admin_ai_snapshot', { p_days: 7 });
  } catch (e) {
    root.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
    return;
  }

  const t = snapshot.totals || {};
  const f = snapshot.finance || {};

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Assistant</span><h2>AI admin assistant</h2><p>Answers are computed from one live snapshot of your database. Nothing is invented, and nothing is changed here.</p></div>
      <div class="row-wrap">
        <button class="btn btn-ghost" type="button" data-refresh>${icon('refresh', 15)} Refresh snapshot</button>
      </div>
    </div>

    <div class="alert info">${icon('info', 17)}<div><strong>Snapshot:</strong> ${esc(dateTime(snapshot.generated_at))} · ${Number(snapshot.days || 7)} days. Recompute after you work a queue so the numbers match.</div></div>

    <div class="kpis mt-18">
      ${kpi({ label: 'Proofs waiting', value: Number(t.proofs_pending || 0), iconName: 'shield', tone: 'gold', foot: Number(t.proofs_oldest_hours || 0) > 0 ? `Oldest ${Number(t.proofs_oldest_hours)}h` : 'Queue clear' })}
      ${kpi({ label: 'Open flags', value: Number(t.open_flags || 0), iconName: 'flag', tone: 'red', foot: 'Fraud and duplicate checks' })}
      ${kpi({ label: 'Open tickets', value: Number(t.open_tickets || 0), iconName: 'ticket', tone: 'blue', foot: 'Support queue' })}
      ${kpi({ label: 'Money at rest', value: esc(usdt(Number(f.available || 0) + Number(f.pending || 0) + Number(f.reserved || 0))), suffix: 'USDT', iconName: 'wallet', tone: 'green', foot: `${esc(usdt(f.revenue))} revenue` })}
    </div>

    <div class="grid grid-2 mt-18" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>Conversation</h3><span class="badge grey" id="ai-source">Snapshot analyst</span></div>
        <div class="card-body">
          <div class="quick-prompts" id="ai-prompts">
            ${['What is in the proof queue?', 'Any withdrawal risk?', 'Finance summary', 'Fraud flags', 'Campaign health', 'Support backlog'].map((p) => `<button class="chip" type="button" data-prompt="${esc(p)}">${esc(p)}</button>`).join('')}
          </div>
          <div class="chat" id="ai-log" style="max-height:44dvh;overflow:auto"></div>
          <div class="chat-input mt-14">
            <textarea id="ai-input" placeholder="Ask about queues, risk or money…" maxlength="400"></textarea>
            <button class="btn btn-primary btn-icon" type="button" id="ai-send" aria-label="Send">${icon('send', 17)}</button>
          </div>
        </div>
      </div>

      <div class="col" style="gap:14px">
        <div class="card">
          <div class="card-head"><h3>Queues right now</h3><a class="small brand-text" href="#/admin/proofs">Open proofs</a></div>
          <div class="card-body">
            ${(snapshot.pending_proofs || []).length ? `<div class="list">${(snapshot.pending_proofs || []).slice(0, 5).map((p) => `
              <div class="list-row">
                <span class="empty-ic" style="width:30px;height:30px;margin:0;border-radius:9px">${platformIcon(p.platform, 14)}</span>
                <div class="list-main">
                  <div class="list-title truncate">${esc(p.campaign)}</div>
                  <div class="list-sub">${esc(p.worker)} · ${esc(usdt(p.reward))} USDT · ${esc(ago(p.created_at))}</div>
                </div>
                ${p.duplicate_hash ? '<span class="badge red">Dup</span>' : ''}
              </div>`).join('')}</div>` : '<p class="small muted">No pending proofs.</p>'}
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Withdrawal queue</h3><a class="small brand-text" href="#/admin/withdrawals">Open</a></div>
          <div class="card-body">
            ${(snapshot.withdrawal_queue || []).length ? `<div class="list">${(snapshot.withdrawal_queue || []).slice(0, 5).map((w) => `
              <div class="list-row">
                <div class="list-main"><div class="list-title">${esc(w.user)}</div><div class="list-sub">${esc(ago(w.created_at))}</div></div>
                <div class="right"><div class="strong">${esc(usdt(w.amount))}</div><div class="tiny dim">${esc(w.status)}</div></div>
              </div>`).join('')}</div>` : '<p class="small muted">No open withdrawals.</p>'}
          </div>
        </div>

        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-6">What the assistant will not do</h3>
          <p class="small muted" style="line-height:1.7">It never approves proofs, sends payouts, edits balances or changes roles. Those actions live in their queues, require your explicit confirmation, and are permission-checked again by the server.</p>
        </div>

        <div class="card card-pad" style="border-color:rgba(255,193,7,.28)">
          <div class="row" style="gap:8px"><span class="empty-ic" style="width:30px;height:30px;margin:0;border-radius:9px">${icon('shield', 15)}</span><h3 style="font-size:13px">Secure AI integration</h3></div>
          <p class="small muted mt-10" style="line-height:1.7">AI keys live only in Supabase Vault and are used server-side — never in browser JavaScript. The screenshot verification system (<span class="mono">supabase/ai-screenshot-verification.sql</span>) already follows this pattern: enable <span class="mono">ai_screenshot_enabled</span>, set <span class="mono">ai_verify_url</span> + <span class="mono">ai_verify_model</span> in settings and <span class="mono">ai_verify_key</span> in Vault.</p>
          <p class="tiny dim mt-10">This page intentionally offers no key entry field.</p>
        </div>
      </div>
    </div>`;

  const logEl = root.querySelector('#ai-log');
  const inputEl = root.querySelector('#ai-input');
  const sourceEl = root.querySelector('#ai-source');

  const renderLog = () => {
    logEl.innerHTML = messages.length ? messages.map((msg) => msg.role === 'you'
      ? `<div class="chat-msg user"><span class="avatar">You</span><div><div class="chat-bubble">${esc(msg.text)}</div></div></div>`
      : `<div class="chat-msg"><span class="avatar">AI</span><div><div class="chat-bubble">${esc(msg.text)}</div><div class="tiny dim mt-6">${esc(msg.source || 'Snapshot analyst')}</div></div></div>`
    ).join('') : `<p class="small muted">Ask a question, or pick a prompt above. The first answer is computed locally from the snapshot; no external service is contacted unless you connect a provider key.</p>`;
    logEl.scrollTop = logEl.scrollHeight;
  };

  const ask = async (text) => {
    const question = String(text || '').trim();
    if (!question) return;
    messages.push({ role: 'you', text: question });
    renderLog();
    inputEl.value = '';
    const provider = readProvider();
    let answer;
    if (provider?.key && provider?.base && provider?.model) {
      try {
        answer = await providerAnswer(provider, snapshot, question);
        messages.push({ role: 'ai', text: answer, source: `${provider.model} · snapshot ${dateTime(snapshot.generated_at)}` });
        sourceEl.textContent = provider.model;
      } catch (err) {
        answer = `The provider request failed (${err.message}). Here is the computed answer instead.\n\n${localAnswer(snapshot, question)}`;
        messages.push({ role: 'ai', text: answer, source: 'Fallback — snapshot analyst' });
      }
    } else {
      answer = localAnswer(snapshot, question);
      messages.push({ role: 'ai', text: answer, source: 'Computed from snapshot' });
    }
    renderLog();
  };

  root.querySelector('#ai-prompts').addEventListener('click', (e) => {
    const b = e.target.closest('[data-prompt]');
    if (b) ask(b.dataset.prompt);
  });
  root.querySelector('#ai-send').addEventListener('click', () => ask(inputEl.value));
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      ask(inputEl.value);
    }
  });

  root.querySelector('[data-refresh]').addEventListener('click', () => renderAdminAI(root));

  renderLog();
}

/* ======================================================= SOCIAL ACCOUNTS === */
/* Workers link a social account and paste a verification code into their
   profile; a verifier confirms it here. No social password is ever involved. */
export async function renderAdminSocial(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  let status = 'pending';

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Trust</span><h2>Task accounts</h2><p>Workers add a code to their own social profile and submit the link. Confirm the code before approving — the platform never asks for a password.</p></div>
    </div>
    <div class="filter-bar">
      ${[['pending', 'Pending'], ['linked', 'Verified'], ['rejected', 'Rejected'], ['', 'All']].map(([v, label]) => `
        <button class="chip ${status === v ? 'active' : ''}" type="button" data-soc-status="${v}">${label}</button>`).join('')}
    </div>
    <div id="soc-list">${loadingBlock('Loading task accounts')}</div>`;

  const listEl = root.querySelector('#soc-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading task accounts');
    let rows = [];
    try {
      rows = (await rpc('admin_list_social_accounts', { p_status: status || null, p_limit: 150 })) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? `<div class="card"><div class="card-body"><div class="list">
      ${rows.map((a) => {
        const m = platformMeta(a.platform);
        const url = safeHttpUrl(a.profile_url);
        return `<div class="list-row">
          <span class="task-ic" style="background:${m.bg};color:${m.color};width:32px;height:32px">${platformIcon(a.platform, 16)}</span>
          <div class="list-main" style="min-width:0">
            <div class="row" style="gap:8px;flex-wrap:wrap">
              <span class="list-title">${esc(m.label)} · @${esc(a.handle || '—')}</span>
              ${statusBadge(a.status === 'linked' ? 'approved' : a.status === 'rejected' ? 'rejected' : 'pending', a.status === 'linked' ? 'Verified' : a.status === 'rejected' ? 'Rejected' : 'Pending')}
            </div>
            <div class="list-sub truncate">${esc(a.user_name || '')} · submitted ${esc(ago(a.created_at))}</div>
            ${a.verification_code ? `<div class="tiny dim mt-6">Code in profile: <span class="mono">${esc(a.verification_code)}</span></div>` : ''}
          </div>
          <div class="row-wrap">
            ${url ? `<a class="btn btn-ghost btn-sm" href="${esc(url)}" target="_blank" rel="noopener">${icon('external', 14)} Profile</a>` : ''}
            ${a.status === 'pending' ? `
              <button class="btn btn-soft btn-sm" type="button" data-verify="${esc(a.id)}">Approve</button>
              <button class="btn btn-ghost btn-sm" type="button" data-reject="${esc(a.id)}">Reject</button>` : ''}
          </div>
        </div>`;
      }).join('')}
    </div></div></div>` : emptyState({
      iconName: 'link',
      title: status === 'pending' ? 'Nothing waiting' : 'No accounts here',
      text: 'Workers link their task accounts from Linked accounts; submissions land here for review.'
    });

    listEl.querySelectorAll('[data-verify]').forEach((b) => b.addEventListener('click', () => review(b.dataset.verify, true)));
    listEl.querySelectorAll('[data-reject]').forEach((b) => b.addEventListener('click', () => review(b.dataset.reject, false)));
  };

  const review = async (id, approve) => {
    const ok = await confirmDialog({
      title: approve ? 'Approve this account?' : 'Reject this account?',
      message: approve
        ? 'The worker can claim tasks that require this platform.'
        : 'The worker is told the code could not be found and can submit again.',
      confirmLabel: approve ? 'Approve' : 'Reject',
      danger: !approve
    });
    if (!ok) return;
    try {
      await rpc('admin_verify_social_account', { p_id: id, p_approve: approve });
      toast(approve ? 'Account verified.' : 'Account rejected.', 'success');
      load();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };

  root.querySelectorAll('[data-soc-status]').forEach((b) => b.addEventListener('click', () => {
    status = b.dataset.socStatus;
    root.querySelectorAll('[data-soc-status]').forEach((x) => x.classList.toggle('active', x === b));
    load();
  }));

  await load();
}

/* =============================================================== WALLETS === */
export async function renderAdminWallets(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'FINANCE', 'SUPPORT'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  root.innerHTML = loadingBlock('Reading wallets');
  let data;
  try {
    data = await rpc('admin_wallet_overview', { p_limit: 50 });
  } catch (e) {
    root.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
    return;
  }

  const t = data?.totals || {};
  const top = data?.top || [];
  const recent = data?.recent || [];

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Money</span><h2>Wallet management</h2><p>Balances held for every account. Adjustments go through <span class="mono">admin_adjust_balance</span>, which always writes a ledger row and an audit entry.</p></div>
      <a class="btn btn-ghost btn-sm" href="#/admin/ledger">Full ledger</a>
    </div>

    <div class="kpis">
      ${kpi({ label: 'Available', value: esc(usdt(t.available)), suffix: 'USDT', iconName: 'wallet', tone: 'green', foot: `${Number(t.wallets || 0)} wallets` })}
      ${kpi({ label: 'Pending rewards', value: esc(usdt(t.pending)), suffix: 'USDT', iconName: 'clock', tone: 'gold', foot: 'Awaiting proof review' })}
      ${kpi({ label: 'Reserved', value: esc(usdt(t.reserved)), suffix: 'USDT', iconName: 'lock', tone: 'violet', foot: 'Escrow + withdrawal holds' })}
      ${kpi({ label: 'TG Coin', value: esc(usdt(t.tg)), iconName: 'star', tone: 'orange', foot: `${esc(usdt(t.lifetime_earned))} earned lifetime` })}
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Largest balances</h3><span class="badge grey">${top.length}</span></div>
      <div class="card-body">
        ${top.length ? tableHtml(
          ['User', 'Status', 'Available', 'Pending', 'Reserved', 'Earned'],
          top.map((w) => `<tr>
            <td data-label="User"><div class="truncate">${esc(w.name || '')}</div><div class="tiny dim truncate">${esc(w.email || '')}${w.is_buyer ? ' · buyer' : ''}</div></td>
            <td data-label="Status">${statusBadge(w.status)}</td>
            <td data-label="Available" class="num">${esc(usdt(w.available))}</td>
            <td data-label="Pending" class="num">${esc(usdt(w.pending))}</td>
            <td data-label="Reserved" class="num">${esc(usdt(w.reserved))}</td>
            <td data-label="Earned" class="num gold-text">${esc(usdt(w.lifetime_earned))}</td>
          </tr>`)
        ) : '<p class="small muted">No wallets yet.</p>'}
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Recent movements</h3><a class="small brand-text" href="#/admin/ledger">Open ledger</a></div>
      <div class="card-body">
        ${recent.length ? `<div class="list">${recent.map((l) => `
          <div class="list-row">
            <div class="list-main"><div class="list-title">${esc(l.kind)}</div><div class="list-sub truncate">${esc(l.user_name || '')} · ${esc(l.note || '')} · ${esc(ago(l.created_at))}</div></div>
            <span class="small ${Number(l.available_delta) >= 0 ? 'green' : 'red'}">${Number(l.available_delta) >= 0 ? '+' : ''}${esc(usdt(l.available_delta))}</span>
          </div>`).join('')}</div>` : '<p class="small muted">No ledger entries yet.</p>'}
      </div>
    </div>`;
}

/* =========================================================== LEADERBOARD === */
export async function renderAdminLeaderboard(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  root.innerHTML = loadingBlock('Reading this week');
  let rows = [];
  try {
    rows = (await rpc('leaderboard_weekly', { p_limit: 50 })) || [];
  } catch (e) {
    root.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
    return;
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Earn</span><h2>Weekly leaderboard</h2><p>Ranked by approved reward entries since the start of this week. It is computed from the ledger, so it cannot be edited from here.</p></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Top earners</h3><span class="badge grey">${rows.length}</span></div>
      <div class="card-body">
        ${rows.length ? tableHtml(
          ['#', 'Worker', 'Country', 'Approved tasks', 'Earned'],
          rows.map((r, i) => `<tr>
            <td data-label="#" class="num">${i + 1}</td>
            <td data-label="Worker"><div class="truncate">${esc(r.name || '')}</div>${r.is_me ? '<div class="tiny dim">you</div>' : ''}</td>
            <td data-label="Country">${esc(r.country_code || '—')}</td>
            <td data-label="Tasks" class="num">${Number(r.tasks || 0)}</td>
            <td data-label="Earned" class="num">${esc(usdt(r.earned))} USDT</td>
          </tr>`)
        ) : emptyState({ iconName: 'trophy', title: 'No approved work this week', text: 'The board fills as proofs are approved; every row comes from a ledger entry.' })}
      </div>
    </div>`;
}

/* ======================================================== REWARDS & FEES === */
const REWARD_KEYS = [
  'coin_name', 'coin_symbol', 'tg_per_task', 'daily_checkin_tg',
  'referral_commission_pct', 'campaign_fee_pct',
  'withdrawal_fee_pct', 'withdrawal_fee_free_min',
  'withdrawal_min', 'min_deposit', 'high_value_min'
];

export async function renderAdminRewards(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN']);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Configuration</span><h2>Rewards, commissions and fees</h2><p>These settings are read live by the worker and buyer apps and by every money RPC.</p></div>
      ${canEdit ? '' : '<span class="badge grey">Read only</span>'}
    </div>
    <div id="rw-list">${loadingBlock('Loading settings')}</div>`;
  const host = root.querySelector('#rw-list');

  const load = async () => {
    host.innerHTML = loadingBlock('Loading settings');
    let rows = [];
    try {
      rows = (await rpc('admin_get_settings')) || [];
    } catch (e) {
      host.innerHTML = errorPanel(friendlyError(e));
      return;
    }
    const picked = REWARD_KEYS
      .map((k) => rows.find((r) => r.key === k))
      .filter(Boolean);

    host.innerHTML = `<div class="card">
      <div class="card-head"><h3>Live values</h3><span class="badge grey">${picked.length}</span></div>
      <div class="card-body">
        <div class="list">
          ${picked.map((s) => `<div class="list-row">
            <div class="list-main">
              <div class="list-title mono">${esc(s.key)}</div>
              <div class="list-sub">${esc(valueLabel(s.value))}</div>
            </div>
            ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-rw-edit="${esc(s.key)}">Edit</button>` : ''}
          </div>`).join('') || '<p class="small muted">Nothing here yet — run supabase/schema.sql.</p>'}
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div><span class="mono">tg_per_task</span> is the TG Coin bonus per approved task; <span class="mono">campaign_fee_pct</span> and the withdrawal fee apply to new operations only, existing escrow is not recalculated.</div></div>
      </div>
    </div>`;

    if (!canEdit) return;
    host.querySelectorAll('[data-rw-edit]').forEach((b) => b.addEventListener('click', () => {
      const s = picked.find((x) => x.key === b.dataset.rwEdit);
      if (s) settingModal(s, load);
    }));
  };

  await load();
}

/* ======================================================== SYSTEM STATUS === */
export async function renderAdminSystem(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  root.innerHTML = loadingBlock('Checking the database');
  let s;
  try {
    s = await rpc('admin_system_status');
  } catch (e) {
    root.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
      <div class="alert info mt-14">${icon('info', 17)}<div>This page needs <span class="mono">supabase/owner-access.sql</span>. Run it in the SQL editor, then reload.</div></div>`;
    return;
  }

  const me = s.me || {};
  const owner = s.owner || {};
  const c = s.counts || {};
  const schema = s.schema || {};

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Diagnostics</span><h2>System status</h2><p>Read live at ${esc(dateTime(s.generated_at))}. Role checks happen in the database on every request.</p></div>
      <button class="btn btn-ghost btn-sm" type="button" data-sys-refresh>${icon('refresh', 14)} Refresh</button>
    </div>

    <div class="kpis">
      ${kpi({ label: 'Your role', value: esc(me.role || 'none'), iconName: 'key', tone: 'gold', foot: esc(me.email || '') })}
      ${kpi({ label: 'Profiles', value: Number(c.profiles || 0), iconName: 'users', tone: 'blue', foot: `${Number(c.admins || 0)} admin account(s)` })}
      ${kpi({ label: 'Wallets', value: Number(c.wallets || 0), iconName: 'wallet', tone: 'green', foot: `${Number(c.tasks || 0)} tasks` })}
      ${kpi({ label: 'Database size', value: esc(s.database_size || '—'), iconName: 'database', foot: `Postgres ${esc(s.postgres_version || '')}` })}
    </div>

    <div class="grid grid-2 mt-18" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>OWNER configuration</h3><span class="badge ${owner.matches_me ? 'green' : 'grey'}">${owner.matches_me ? 'This is you' : 'Server setting'}</span></div>
        <div class="card-body">
          <div class="row-between small"><span class="muted">Configured email</span><span class="mono">${esc(owner.configured_email || 'not set')}</span></div>
          <div class="row-between small mt-6"><span class="muted">OWNER accounts</span><span>${Number(owner.owners || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Your id</span><span class="mono tiny truncate">${esc(me.id || '')}</span></div>
          <div class="row-between small mt-6"><span class="muted">Server role check</span><span class="green">enforced by RPCs</span></div>
          ${owner.matches_me ? `<button class="btn btn-soft btn-sm btn-block mt-14" type="button" data-sys-repair>${icon('shield', 14)} Repair my OWNER access</button>` : ''}
          <p class="tiny dim mt-10">The browser cannot grant a role. <span class="mono">claim_owner()</span> only works for the configured email, and only for a confirmed auth user.</p>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>Queues</h3><a class="small brand-text" href="#/admin/proofs">Proofs</a></div>
        <div class="card-body">
          <div class="row-between small"><span class="muted">Proofs waiting</span><span>${Number(c.proofs_pending || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Deposits waiting</span><span>${Number(c.deposits_pending || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Withdrawals open</span><span>${Number(c.withdrawals_open || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Submissions</span><span>${Number(c.submissions || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Settings rows</span><span>${Number(c.settings || 0)}</span></div>
          <div class="row-between small mt-6"><span class="muted">Telegram messages</span><span>${Number(c.notifications || 0)}</span></div>
          ${s.last_audit ? `<hr class="divider" /><div class="tiny dim">Last audit: <span class="mono">${esc(s.last_audit.action)}</span> by ${esc(s.last_audit.actor || 'system')} · ${esc(ago(s.last_audit.at))}</div>` : ''}
        </div>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Schema</h3><span class="badge grey">tables the app uses</span></div>
      <div class="card-body">
        <div class="list">
          ${Object.entries(schema).map(([name, present]) => `<div class="list-row">
            <div class="list-main"><div class="list-title mono">${esc(name)}</div><div class="list-sub">${present ? 'present' : 'not used by this schema'}</div></div>
            <span class="badge ${present ? 'green' : 'grey'}">${present ? 'OK' : '—'}</span>
          </div>`).join('')}
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Roles are stored in <span class="mono">profiles.admin_role</span>; this schema has no <span class="mono">admin_members</span> table, so a missing row there cannot block access. Admin RPCs re-check the role on every call.</div></div>
      </div>
    </div>`;

  root.querySelector('[data-sys-refresh]').addEventListener('click', () => renderAdminSystem(root));
  const repair = root.querySelector('[data-sys-repair]');
  if (repair) repair.addEventListener('click', async () => {
    setBusy(repair, true, 'Repairing');
    try {
      const res = await rpc('claim_owner');
      if (res?.ok) {
        toast('OWNER access confirmed. Reloading…', 'success');
        window.location.reload();
      } else {
        toast(`Not granted: ${res?.reason || 'unknown reason'}.`, 'error', 8000);
        setBusy(repair, false);
      }
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(repair, false);
    }
  });
}

/* ======================================================= SUSPENDED USERS === */
const SUSPEND_KIND_LABEL = {
  temporary: 'Temporary',
  permanent: 'Permanent',
  under_review: 'Under investigation',
  restricted: 'Restricted · withdrawals blocked'
};

export async function renderAdminSuspended(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  let mode = 'suspended';
  let q = '';
  let offset = 0;
  const limit = 30;
  let total = 0;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">People</span><h2>Suspended &amp; restricted accounts</h2><p>Suspension is enforced by database triggers: claiming, submitting, funding, deposits and withdrawals are blocked the moment it is saved. Wallet balances and history are preserved.</p></div>
    </div>
    <div class="filter-bar">
      ${[['suspended', 'Suspended'], ['restricted', 'Withdrawals blocked'], ['banned', 'Banned'], ['all', 'All']].map(([v, label]) => `
        <button class="chip ${mode === v ? 'active' : ''}" type="button" data-suspend-mode="${v}">${label}</button>`).join('')}
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="sus-q" placeholder="Name or email" autocomplete="off" /></div>
    </div>
    <div id="sus-list">${loadingBlock('Reading accounts')}</div>`;

  const listEl = root.querySelector('#sus-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Reading accounts');
    let rows = [];
    try {
      const res = await rpc('admin_suspended_users', {
        p_mode: mode, p_query: q || null, p_limit: limit, p_offset: offset
      });
      total = Number(res?.total || 0);
      rows = res?.items || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['Account', 'Type', 'Status', 'Reason', 'Expiry', 'Wallet', ''],
      rows.map((u) => `<tr>
        <td data-label="Account">
          <div class="truncate">${esc(u.full_name || 'Unnamed')}</div>
          <div class="tiny dim truncate">${esc(u.email || '')}</div>
        </td>
        <td data-label="Type"><span class="badge ${u.withdrawals_blocked ? 'orange' : 'red'}">${esc(SUSPEND_KIND_LABEL[u.suspension_kind] || (u.status === 'banned' ? 'Banned' : 'Suspended'))}</span></td>
        <td data-label="Status">${statusBadge(u.status)}</td>
        <td data-label="Reason" class="small muted">${esc(u.suspension_reason || '—')}</td>
        <td data-label="Expiry" class="small">${u.suspension_expires_at ? esc(dateTime(u.suspension_expires_at)) : (u.status === 'suspended' ? 'No expiry' : '—')}</td>
        <td data-label="Wallet" class="num">${esc(usdt(u.available))}</td>
        <td data-label="">
          <div class="row-wrap">
            <button class="btn btn-ghost btn-sm" type="button" data-open-user="${esc(u.id)}">Open</button>
            <button class="btn btn-soft btn-sm" type="button" data-restore-user="${esc(u.id)}">Restore</button>
          </div>
        </td>
      </tr>`)
    ) + pagerHtml(total, limit, offset) : emptyState({
      iconName: 'lock',
      title: 'Nobody here',
      text: 'No accounts match this filter. Suspensions appear here the moment an admin saves one.'
    });

    bindPager(listEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });

    listEl.querySelectorAll('[data-open-user]').forEach((b) => b.addEventListener('click', () => openUserModal(b.dataset.openUser, load)));
    listEl.querySelectorAll('[data-restore-user]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Restore this account?',
        message: 'Access returns immediately and the user is notified. The wallet and ledger are untouched.',
        confirmLabel: 'Restore access'
      });
      if (!ok) return;
      setBusy(b, true, 'Restoring');
      try {
        await rpc('admin_restore_user', { p_user_id: b.dataset.restoreUser, p_note: 'Restored from the suspended list' });
        toast('Account restored.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  root.querySelectorAll('[data-suspend-mode]').forEach((b) => b.addEventListener('click', () => {
    mode = b.dataset.suspendMode;
    offset = 0;
    root.querySelectorAll('[data-suspend-mode]').forEach((x) => x.classList.toggle('active', x === b));
    load();
  }));
  root.querySelector('#sus-q').addEventListener('input', debounce((e) => {
    q = e.target.value.trim();
    offset = 0;
    load();
  }, 320));

  await load();
}

/* ======================================================= AUTO MANAGER === */
export async function renderAdminAutomation(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }
  const canRun = allowed(['OWNER', 'SUPER_ADMIN']);
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN']);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Automation</span><h2>TM GROW AUTO MANAGER</h2><p>Jobs run in the database, triggered by Supabase Cron through the <span class="mono">automation-tick</span> function. No job moves user money: they expire claims, restore suspensions, flag abuse and send notifications.</p></div>
      <button class="btn btn-ghost btn-sm" type="button" data-auto-refresh>${icon('refresh', 14)} Refresh</button>
    </div>
    <div id="auto-body">${loadingBlock('Reading automation state')}</div>`;

  const body = root.querySelector('#auto-body');

  /* Manual runs go straight to the database. No Edge Function is involved. */
  const runAutomation = async (job = null) => {
    const res = await rpc('admin_automation_tick', { p_job: job || null });
    return res || {};
  };

  const load = async () => {
    body.innerHTML = loadingBlock('Reading automation state');
    let ov;
    try {
      ov = await rpc('admin_automation_status');
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/schema.sql</span> to create the automation tables, then reload.</div></div>`;
      return;
    }

    const jobs = ov?.jobs || [];
    const runs = ov?.runs || [];
    const counts = ov?.counts || {};
    const enabled = ov?.enabled === true;
    const lastRun = jobs.reduce((acc, j) => (j.last_run_at && (!acc || j.last_run_at > acc) ? j.last_run_at : acc), null);
    const online = enabled && lastRun && (Date.now() - new Date(lastRun).getTime()) < 36 * 3600 * 1000;
    const cronInstalled = ov?.cron_installed === true;
    const cronSchedule = ov?.cron_schedule || null;
    const mods = Array.isArray(ov?.modules) ? ov.modules : [];

    body.innerHTML = `<div class="kpis">
        ${kpi({ label: 'Bot status', value: online ? 'Online' : enabled ? 'Scheduled' : 'Offline', iconName: 'zap', tone: online ? 'green' : 'grey', foot: lastRun ? `Last run ${esc(ago(lastRun))}` : 'Never run' })}
        ${kpi({ label: 'Next run', value: ov?.next_run ? esc(dateTime(ov.next_run)) : '—', iconName: 'clock', foot: `${Number(counts.enabled || 0)} of ${Number(counts.jobs || 0)} jobs enabled` })}
        ${kpi({ label: 'Runs today', value: Number(counts.runs_today || 0), iconName: 'play', tone: 'blue', foot: `${Number(counts.success || 0)} successful lifetime` })}
        ${kpi({ label: 'Failed runs', value: Number(counts.failed || 0), iconName: 'xCircle', tone: Number(counts.failed || 0) ? 'red' : '', foot: 'See error logs below' })}
      </div>

      <div class="card card-pad mt-18" style="border-color:${enabled ? 'rgba(74,222,128,.32)' : 'var(--line)'}">
        <div class="row-between" style="gap:14px;flex-wrap:wrap;align-items:flex-start">
          <div style="min-width:240px">
            <div class="strong" style="font-size:14px">Scheduled execution ${enabled ? '<span class="badge green">On</span>' : '<span class="badge grey">Off</span>'}</div>
            <div class="tiny dim mt-6">${cronInstalled
              ? (cronSchedule
                ? `Scheduler: pg_cron job <span class="mono">tmgrow-automation-sweep</span> every <span class="mono">${esc(cronSchedule)}</span>, calling <span class="mono">automation_scheduled_tick()</span>. Manual runs work whether this is on or off.`
                : 'pg_cron is installed but <span class="mono">tmgrow-automation-sweep</span> is not scheduled yet. Run section 7 of <span class="mono">supabase/admin-control-room.sql</span>. Manual runs still work.')
              : 'pg_cron is not installed, so nothing runs on a schedule. Enable it in Supabase → Database → Extensions, then run <span class="mono">supabase/admin-control-room.sql</span> again. Manual runs work now.'}</div>
          </div>
          <div class="row-wrap">
            ${canEdit ? `<button class="btn ${enabled ? 'btn-danger' : 'btn-soft'} btn-sm" type="button" data-auto-toggle="${enabled ? 'false' : 'true'}">${enabled ? 'Turn scheduler off' : 'Turn scheduler on'}</button>` : ''}
            ${canRun ? `<button class="btn btn-primary btn-sm" type="button" data-auto-run>${icon('play', 14)} Run all jobs now</button>` : ''}
          </div>
        </div>
        <div class="alert info mt-14">${icon('shield', 17)}<div>Safety: jobs never approve payments, never change a wallet balance and never ban an account. Suspensions and payouts stay manual, with audit rows. Duplicate rewards are prevented by unique ledger keys and the Telegram dedupe key.</div></div>
      </div>

      <div class="card mt-18">
        <div class="card-head"><h3>Jobs</h3><span class="badge grey">${jobs.length}</span></div>
        <div class="card-body">
          ${jobs.length ? tableHtml(
            ['Job', 'Schedule', 'Last run', 'Status', 'Runs', 'Failures', ''],
            jobs.map((j) => `<tr>
              <td data-label="Job"><div class="truncate">${esc(j.name)}</div><div class="tiny dim mono">${esc(j.key)}</div></td>
              <td data-label="Schedule">every ${Number(j.schedule_minutes || 0)} min</td>
              <td data-label="Last run" class="small">${j.last_run_at ? esc(ago(j.last_run_at)) : '—'}</td>
              <td data-label="Status">${statusBadge(j.last_status === 'failed' ? 'rejected' : j.last_status === 'success' ? 'approved' : 'pending', j.last_status || 'Never run')}</td>
              <td data-label="Runs" class="num">${Number(j.runs || 0)}</td>
              <td data-label="Failures" class="num ${Number(j.failures || 0) > 0 ? 'red' : ''}">${Number(j.failures || 0)}</td>
              <td data-label="">
                <div class="row-wrap">
                  ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-auto-job-toggle="${esc(j.key)}" data-next="${j.enabled ? 'false' : 'true'}">${j.enabled ? 'Disable' : 'Enable'}</button>` : ''}
                  ${canRun ? `<button class="btn btn-ghost btn-sm" type="button" data-auto-job-run="${esc(j.key)}">Run</button>` : ''}
                </div>
              </td>
            </tr>`)
          ) : '<p class="small muted">No jobs yet — run supabase/schema.sql.</p>'}
        </div>
      </div>

      <div class="card mt-18">
        <div class="card-head"><h3>Automation modules</h3><span class="badge grey">${mods.length}</span></div>
        <div class="card-body">
          ${mods.length ? `<div class="list">${mods.map((m) => `
            <div class="list-row">
              <div class="list-main">
                <div class="list-title">${esc(m.name)} ${m.critical ? '<span class="badge red">critical</span>' : ''}</div>
                <div class="list-sub">${esc(m.description || '')}</div>
              </div>
              ${canEdit
                ? `<button class="btn btn-ghost btn-sm" type="button" data-auto-module="${esc(m.key)}" data-next="${m.enabled ? 'false' : 'true'}">${m.enabled ? 'Turn off' : 'Turn on'}</button>`
                : `<span class="badge ${m.enabled ? 'green' : 'grey'}">${m.enabled ? 'On' : 'Off'}</span>`}
            </div>`).join('')}</div>`
            : '<p class="small muted">Run <span class="mono">supabase/automation-engine.sql</span> to install per-module switches (verification, rewards, fraud, withdrawal safety).</p>'}
        </div>
      </div>

      <div class="card mt-18">
        <div class="card-head"><h3>Run history</h3><span class="badge grey">last ${runs.length}</span></div>
        <div class="card-body">
          ${runs.length ? `<div class="list">${runs.map((r) => `
            <div class="list-row">
              <span class="empty-ic" style="width:30px;height:30px;margin:0;border-radius:9px">${icon(r.status === 'failed' ? 'xCircle' : 'checkCircle', 15)}</span>
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(r.job_key)} <span class="tiny dim">· ${esc(r.trigger)}</span></div>
                <div class="list-sub truncate">${esc(r.error || JSON.stringify(r.summary || {}))}</div>
                <div class="tiny dim mt-6">${esc(dateTime(r.started_at))}</div>
              </div>
              ${statusBadge(r.status === 'failed' ? 'rejected' : 'approved', r.status)}
            </div>`).join('')}</div>` : '<p class="small muted">No runs recorded yet. Use "Run all jobs now" to test safely.</p>'}
        </div>
      </div>`;

    const toggle = body.querySelector('[data-auto-toggle]');
    if (toggle) toggle.addEventListener('click', async () => {
      const value = toggle.dataset.autoToggle === 'true';
      setBusy(toggle, true, 'Saving');
      try {
        await rpc('admin_update_setting', { p_key: 'automation_enabled', p_value: value, p_is_public: false });
        toast(value ? 'Scheduler enabled.' : 'Scheduler disabled.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(toggle, false);
      }
    });

    const runAll = body.querySelector('[data-auto-run]');
    if (runAll) runAll.addEventListener('click', async () => {
      setBusy(runAll, true, 'Running');
      try {
        const res = await runAutomation();
        if (res?.reason === 'AUTOMATION_DISABLED') {
          toast('Enable the scheduler first (or enable it to run all jobs).', 'info', 7000);
        } else {
          const failed = (res?.results || []).filter((x) => x.status === 'failed').length;
          toast(`${(res?.results || []).length} job(s) ran, ${failed} failed.`, failed ? 'error' : 'success', 7000);
        }
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(runAll, false);
      }
    });

    body.querySelectorAll('[data-auto-job-toggle]').forEach((b) => b.addEventListener('click', async () => {
      const enable = b.dataset.next === 'true';
      setBusy(b, true, 'Saving');
      try {
        await rpc('automation_set_job', { p_key: b.dataset.autoJobToggle, p_enabled: enable });
        toast(`Job ${enable ? 'enabled' : 'disabled'}.`, 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));

    body.querySelectorAll('[data-auto-job-run]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Running');
      try {
        const res = await runAutomation(b.dataset.autoJobRun);
        const result = (res?.results || [])[0];
        toast(result?.status === 'failed' ? `Job failed: ${result.error}` : 'Job finished.', result?.status === 'failed' ? 'error' : 'success', 7000);
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(b, false);
      }
    }));

    body.querySelectorAll('[data-auto-module]').forEach((b) => b.addEventListener('click', async () => {
      const enable = b.dataset.next === 'true';
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_automation_module_set', { p_key: b.dataset.autoModule, p_enabled: enable });
        toast(`Module ${enable ? 'enabled' : 'disabled'}.`, 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  root.querySelector('[data-auto-refresh]').addEventListener('click', load);
  await load();
}

/* ========================================================= USER ACTIVITY === */
const ACTIVITY_KINDS = [
  ['', 'All events'],
  ['registration', 'Registration'],
  ['login', 'Logins'],
  ['task_claimed', 'Tasks claimed'],
  ['task_submitted', 'Tasks submitted'],
  ['proof_submitted', 'Proofs submitted'],
  ['proof_reviewed', 'Proof reviews'],
  ['deposit', 'Deposits'],
  ['withdrawal', 'Withdrawals'],
  ['campaign', 'Campaigns'],
  ['referral', 'Referrals earned'],
  ['referral_join', 'Referred joins'],
  ['support', 'Support tickets'],
  ['admin_action', 'Admin actions'],
  ['risk_flag', 'Risk flags']
];

const ACTIVITY_ICON = {
  registration: 'user',
  login: 'key',
  task_claimed: 'target',
  task_submitted: 'checkCircle',
  proof_submitted: 'shield',
  proof_reviewed: 'checkCircle',
  deposit: 'download',
  withdrawal: 'wallet',
  campaign: 'layers',
  referral: 'gift',
  referral_join: 'users',
  support: 'ticket',
  admin_action: 'key',
  risk_flag: 'flag'
};

export async function renderAdminActivity(root, ctx = {}) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  const userId = ctx?.params?.id || null;
  let kind = '';
  let days = 90;
  let offset = 0;
  const limit = 40;
  let total = 0;
  let user = null;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Audit trail</span><h2>${userId ? 'Account activity' : 'User activity'}</h2><p>Every row below is a record that exists in the database: registrations, recorded logins, task claims, proofs and reviews, deposits, withdrawals, campaigns, referrals, support and admin actions. Nothing is reconstructed.</p></div>
      <div class="row-wrap">
        ${userId ? '<a class="btn btn-ghost btn-sm" href="#/admin/activity">All activity</a>' : '<a class="btn btn-ghost btn-sm" href="#/admin/risk">Risk history</a>'}
        <button class="btn btn-ghost btn-sm" type="button" data-act-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>
    <div class="filter-bar">
      <select class="select input-sm" id="act-kind" style="max-width:190px">
        ${ACTIVITY_KINDS.map(([v, l]) => `<option value="${esc(v)}" ${v === kind ? 'selected' : ''}>${esc(l)}</option>`).join('')}
      </select>
      <div class="row-wrap">
        ${[7, 30, 90].map((d) => `<button class="chip ${d === days ? 'active' : ''}" type="button" data-act-days="${d}">${d} days</button>`).join('')}
      </div>
    </div>
    <div id="act-body">${loadingBlock('Reading recorded events')}</div>`;

  const body = root.querySelector('#act-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading recorded events');
    let res = null;
    try {
      res = await rpc('admin_user_activity', {
        p_user: userId,
        p_kind: kind || null,
        p_from: new Date(Date.now() - days * 864e5).toISOString(),
        p_to: null,
        p_limit: limit,
        p_offset: offset
      });
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/admin-activity-risk.sql</span> to create the activity functions.</div></div>`;
      return;
    }

    const items = res?.items || [];
    total = Number(res?.total || 0);
    if (!user && userId && res?.items?.[0]) {
      user = { name: res.items[0].user_name, id: userId };
    }

    const missing = res?.missing || [];

    body.innerHTML = `
      ${user ? `<div class="card card-pad mb-14"><div class="row-between" style="gap:12px;flex-wrap:wrap"><div><div class="strong">${esc(user.name || 'Account')}</div><div class="tiny dim mono">${esc(userId)}</div></div><a class="btn btn-ghost btn-sm" href="#/admin/risk">Risk history</a></div></div>` : ''}
      ${missing.length ? `<div class="alert warn mb-14">${icon('alert', 17)}<div>Not recorded yet: ${esc(missing.join(', '))}. Login events need <span class="mono">supabase/advanced-management.sql</span>; the rest is already recorded.</div></div>` : ''}
      <div class="card">
        <div class="card-head"><h3>${userId ? 'Timeline' : 'Platform activity'}</h3><span class="badge grey">${total} event(s)</span></div>
        <div class="card-body">
          ${res?.logins_recorded === false ? `<div class="alert info mb-10">${icon('info', 17)}<div>Login history is not recorded on this database yet.</div></div>` : ''}
          ${total ? `<div class="list">${items.map((e) => `
            <div class="list-row">
              <span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon(ACTIVITY_ICON[e.kind] || 'file', 15)}</span>
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(e.title || e.kind)} ${e.status ? statusBadge(e.status) : ''}</div>
                <div class="list-sub truncate">${userId ? '' : `${esc(e.user_name || 'Unknown')} · `}${esc((ACTIVITY_KINDS.find(([v]) => v === e.kind) || [, e.kind])[1])}${e.actor ? ` · by ${esc(e.actor)}` : ''}</div>
                ${e.meta && Object.keys(e.meta).length ? `<div class="tiny dim mono truncate">${esc(JSON.stringify(e.meta).slice(0, 160))}</div>` : ''}
              </div>
              <div style="text-align:right;flex:0 0 auto">
                ${e.amount != null ? `<div class="strong">${esc(usdt(e.amount))} <span class="tiny dim">USDT</span></div>` : ''}
                <div class="tiny dim">${esc(ago(e.at))}</div>
              </div>
            </div>`).join('')}</div>`
            : emptyState({ iconName: 'chart', title: 'No events in this window', text: 'Widen the date range or choose another event type. Only recorded rows appear here.' })}
        </div>
      </div>
      ${pagerHtml(total, limit, offset)}`;

    bindPager(body, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
  };

  root.querySelector('[data-act-refresh]').addEventListener('click', load);
  const kindSel = root.querySelector('#act-kind');
  kindSel.addEventListener('change', () => { kind = kindSel.value; offset = 0; load(); });
  root.querySelectorAll('[data-act-days]').forEach((b) => b.addEventListener('click', () => {
    days = Number(b.dataset.actDays);
    offset = 0;
    root.querySelectorAll('[data-act-days]').forEach((x) => x.classList.toggle('active', x === b));
    load();
  }));

  await load();
}

/* =========================================================== RISK HISTORY === */
function riskTone(level) {
  return level === 'critical' ? 'red' : level === 'high' ? 'orange' : level === 'medium' ? 'gold' : 'green';
}

function riskLevelOf(score) {
  const n = Number(score || 0);
  return n >= 70 ? 'critical' : n >= 45 ? 'high' : n >= 20 ? 'medium' : 'low';
}

async function showRiskProfile(userId) {
  let d = null;
  try {
    d = await rpc('admin_risk_profile', { p_user: userId });
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }
  if (!d) return;

  const profile = d.profile || {};
  const wallet = d.wallet || {};
  const suspension = d.suspension || {};
  const signals = d.signals || {};
  const reasons = d.reasons || [];
  const flags = d.flags || [];
  const notes = d.notes || [];
  const score = Number(d.score || 0);
  const level = d.level || riskLevelOf(score);

  const m = openModal({
    title: profile.name || 'Risk profile',
    subtitle: `${profile.email || ''} · score ${score} / 100`,
    wide: true,
    body: `
      <div class="row-wrap mb-10">
        <span class="badge ${riskTone(level)}">${esc(level.toUpperCase())}</span>
        ${profile.status ? statusBadge(profile.status) : ''}
        ${wallet.frozen ? '<span class="badge red">Wallet frozen</span>' : ''}
        ${suspension.kind ? `<span class="badge red">${esc(suspension.kind)}</span>` : ''}
        <span class="badge grey">Trust ${Number(profile.trust_score || 0)}</span>
      </div>
      <div class="trust-progress mb-6"><span style="width:${Math.min(100, score)}%"></span></div>
      <div class="tiny dim mb-14">A rule-based score from recorded signals. It never bans, freezes or pays anything by itself.</div>

      <div class="grid grid-2">
        ${[
          ['Duplicate proofs', signals.duplicate_proofs],
          ['Rejected 7d', signals.rejected_7d],
          ['Rejected 30d', signals.rejected_30d],
          ['Submitted 30d', signals.submitted_30d],
          ['Withdrawals 24h', signals.withdrawals_24h],
          ['Withdrawals 7d', signals.withdrawals_7d],
          ['Referrals 7d', signals.referrals_7d],
          ['Known devices 30d', signals.devices_30d]
        ].map(([label, value]) => `<div class="card card-pad">
          <div class="tiny dim">${esc(label)}</div>
          <div class="strong" style="font-size:17px">${Number(value || 0)}</div>
        </div>`).join('')}
      </div>

      <div class="card mt-14">
        <div class="card-head"><h3>Why this score</h3><span class="badge grey">${reasons.length}</span></div>
        <div class="card-body">
          ${reasons.length ? `<div class="list">${reasons.map((r) => `
            <div class="list-row">
              <span class="badge gold">+${Number(r.points || 0)}</span>
              <div class="list-main"><div class="list-sub">${esc(r.text || '')}</div></div>
            </div>`).join('')}</div>`
            : '<p class="small muted">No recorded signal raised this score.</p>'}
        </div>
      </div>

      <div class="card mt-14">
        <div class="card-head"><h3>Risk flags</h3><span class="badge grey">${flags.length}</span></div>
        <div class="card-body">
          ${flags.length ? `<div class="list">${flags.map((f) => `
            <div class="list-row">
              ${statusBadge(f.status === 'resolved' ? 'approved' : f.status === 'dismissed' ? 'cancelled' : 'pending', f.status)}
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(f.kind)} <span class="badge ${Number(f.severity) >= 4 ? 'red' : 'gold'}">sev ${Number(f.severity)}</span></div>
                <div class="list-sub truncate mono">${esc(JSON.stringify(f.details || {}).slice(0, 140))}</div>
                <div class="tiny dim">${esc(ago(f.created_at))}</div>
              </div>
            </div>`).join('')}</div>`
            : '<p class="small muted">No fraud flags recorded for this account.</p>'}
        </div>
      </div>

      <div class="card mt-14">
        <div class="card-head"><h3>Investigation notes</h3><span class="badge grey">${notes.length}</span></div>
        <div class="card-body">
          ${notes.length ? `<div class="list">${notes.map((n) => `
            <div class="list-row">
              <div class="list-main" style="min-width:0">
                <div class="list-sub">${esc(n.note)}</div>
                <div class="tiny dim">${esc(ago(n.created_at))}</div>
              </div>
            </div>`).join('')}</div>` : '<p class="small muted">No notes yet.</p>'}
          <div class="field mt-14">
            <label class="label">Add an investigation note</label>
            <textarea class="textarea" id="risk-note" maxlength="600" placeholder="What did you check, and what did you find?"></textarea>
            <span class="hint">Stored in admin_notes and written to the audit log. Visible to admins only.</span>
          </div>
        </div>
      </div>`,
    footer: `<a class="btn btn-ghost" href="#/admin/activity/${encodeURIComponent(userId)}">Activity</a>
      <button class="btn btn-ghost" type="button" data-note-add>Add note</button>
      <button class="btn btn-primary" type="button" data-close>Close</button>`
  });

  m.root.querySelector('[data-close]').onclick = () => m.close();

  const addNote = m.root.querySelector('[data-note-add]');
  if (addNote) addNote.addEventListener('click', async () => {
    const box = m.root.querySelector('#risk-note');
    const text = (box.value || '').trim();
    if (!text) return toast('Write the note first.', 'error');
    setBusy(addNote, true, 'Saving');
    try {
      await rpc('admin_add_note', { p_user_id: userId, p_note: text, p_kind: 'investigation' });
      toast('Note saved.', 'success');
      m.close();
      showRiskProfile(userId);
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(addNote, false);
    }
  });
}

export async function renderAdminRisk(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  let offset = 0;
  const limit = 25;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Security</span><h2>Risk history</h2><p>Accounts with recorded signals: open fraud flags, reused proof hashes, repeated rejections and withdrawal bursts. The score is a rule-based summary, not a verdict — a human decides every restriction.</p></div>
      <div class="row-wrap">
        <a class="btn btn-ghost btn-sm" href="#/admin/flags">Fraud flags</a>
        <button class="btn btn-ghost btn-sm" type="button" data-risk-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>
    <div class="alert info">${icon('shield', 17)}<div>Nothing here bans, freezes or pays automatically. Restrictions stay in <span class="mono">admin_suspend_user</span> and <span class="mono">admin_freeze_wallet</span>, with an audit row.</div></div>
    <div id="risk-body">${loadingBlock('Reading recorded signals')}</div>`;

  const body = root.querySelector('#risk-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading recorded signals');
    let board = null;
    let ov = null;
    try {
      [board, ov] = await Promise.all([
        rpc('admin_risk_board', { p_limit: limit, p_offset: offset }),
        rpc('admin_fraud_overview').catch(() => null)
      ]);
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/admin-activity-risk.sql</span> and <span class="mono">supabase/advanced-management.sql</span> to read the risk board.</div></div>`;
      return;
    }

    const items = board?.items || [];
    const total = Number(board?.total || 0);
    const c = ov?.counts || {};

    body.innerHTML = `<div class="kpis">
        ${kpi({ label: 'Open flags', value: Number(c.open || 0), iconName: 'flag', tone: 'gold', foot: 'Awaiting a decision' })}
        ${kpi({ label: 'High / critical', value: Number(c.high || 0) + Number(c.critical || 0), iconName: 'alert', tone: Number(c.critical || 0) > 0 ? 'red' : 'orange', foot: `${Number(c.critical || 0)} critical` })}
        ${kpi({ label: 'Suspended', value: Number(c.suspended || 0), iconName: 'lock', tone: 'violet', foot: `${Number(c.restricted || 0)} restricted` })}
        ${kpi({ label: 'Frozen wallets', value: Number(c.frozen_wallets || 0), iconName: 'wallet', tone: 'blue', foot: 'Outflows paused' })}
      </div>
      <div class="card mt-18">
        <div class="card-head"><h3>Accounts to review</h3><span class="badge grey">${total}</span></div>
        <div class="card-body">
          ${items.length ? `<div class="list">${items.map((u) => `
            <div class="list-row">
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(u.name || 'User')} ${Number(u.max_severity || 0) >= 3 ? '<span class="badge red">high</span>' : '<span class="badge gold">review</span>'} ${u.wallet_frozen ? '<span class="badge red">wallet frozen</span>' : ''}</div>
                <div class="list-sub">${Number(u.signals || 0)} signal(s) · ${Number(u.open_flags || 0)} open flag(s) · trust ${Number(u.trust_score || 0)}${u.email ? ` · ${esc(u.email)}` : ''}</div>
                <div class="tiny dim">Last signal ${esc(u.last_signal_at ? ago(u.last_signal_at) : '—')}</div>
              </div>
              <button class="btn btn-ghost btn-sm" type="button" data-risk-user="${esc(u.user_id)}">Review</button>
            </div>`).join('')}</div>`
            : emptyState({ iconName: 'shield', title: 'No recorded signals', text: 'When a duplicate proof, repeated rejection or withdrawal burst is recorded, the account appears here.' })}
        </div>
      </div>
      ${pagerHtml(total, limit, offset)}`;

    bindPager(body, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
    body.querySelectorAll('[data-risk-user]').forEach((b) => b.addEventListener('click', () => showRiskProfile(b.dataset.riskUser)));
  };

  root.querySelector('[data-risk-refresh]').addEventListener('click', load);
  await load();
}

/* ========================================================= LOGIN HISTORY === */
export async function renderAdminLogins(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  let q = '';
  let offset = 0;
  const limit = 40;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Security</span><h2>Login history</h2><p>Recorded sessions only: platform and user agent, as far as the app can observe. No IP address is collected, so none is shown.</p></div>
      <button class="btn btn-ghost btn-sm" type="button" data-login-refresh>${icon('refresh', 14)} Refresh</button>
    </div>
    <div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="login-q" placeholder="Name, email or user agent" autocomplete="off" /></div>
    </div>
    <div id="login-body">${loadingBlock('Reading recorded logins')}</div>`;

  const body = root.querySelector('#login-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading recorded logins');
    let res;
    try {
      res = await rpc('admin_login_history', { p_query: q || null, p_limit: 50, p_offset: offset });
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }
    const items = res?.items || [];
    const total = Number(res?.total || 0);
    const missing = res?.missing || [];

    body.innerHTML = `
      ${missing.length ? `<div class="alert warn mb-14">${icon('alert', 17)}<div>${esc(res.note || 'Login history is not recorded yet.')} Missing: ${esc(missing.join(', '))}.</div></div>` : ''}
      <div class="card">
        <div class="card-head"><h3>Sessions</h3><span class="badge grey">${total}</span></div>
        <div class="card-body">
          ${items.length ? tableHtml(
            ['User', 'Platform', 'User agent', 'When'],
            items.map((e) => `<tr>
              <td data-label="User"><div class="strong">${esc(e.user_name || '')}</div><div class="tiny dim">${esc(e.email || '')}</div></td>
              <td data-label="Platform">${esc(e.platform || 'unknown')}</td>
              <td data-label="User agent" class="small muted"><span class="mono truncate">${esc(e.user_agent || '—')}</span></td>
              <td data-label="When" class="small">${esc(dateTime(e.created_at))}</td>
            </tr>`)
          ) + pagerHtml(total, limit, offset)
            : emptyState({ iconName: 'clock', title: 'No logins recorded yet', text: 'Sessions appear here after users sign in with a database that has login_events.' })}
        </div>
      </div>`;

    bindPager(body, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });
  };

  root.querySelector('[data-login-refresh]').addEventListener('click', load);
  root.querySelector('#login-q').addEventListener('input', debounce((e) => {
    q = e.target.value.trim();
    offset = 0;
    load();
  }, 320));

  await load();
}

/* ==================================================== VERIFICATION === */
const VQ_STATUS = [
  ['', 'All'],
  ['queued', 'Queued'],
  ['processing', 'Processing'],
  ['manual', 'Manual'],
  ['verified', 'Verified'],
  ['rejected', 'Rejected'],
  ['dead', 'Dead letter']
];

function vqBadge(status) {
  switch (status) {
    case 'verified': return '<span class="badge green">verified</span>';
    case 'rejected': return '<span class="badge red">rejected</span>';
    case 'manual': return '<span class="badge gold">manual</span>';
    case 'dead': return '<span class="badge red">dead</span>';
    case 'processing': return '<span class="badge orange">processing</span>';
    default: return '<span class="badge grey">queued</span>';
  }
}

export async function renderAdminVerification(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  let status = '';
  const canRun = allowed(['OWNER', 'SUPER_ADMIN']);
  const canDecide = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  const canAuto = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Automation</span><h2>Task verification</h2><p>The database sweep runs the deterministic checks it can prove — duplicate screenshots, worker state, missing evidence — and sends everything else to a human. Screenshot content and Telegram membership need an external check, so they are never guessed.</p></div>
      <div class="row-wrap">
        ${canRun ? `<button class="btn btn-primary btn-sm" type="button" data-vq-tick>${icon('play', 14)} Run sweep now</button>` : ''}
        <button class="btn btn-ghost btn-sm" type="button" data-vq-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>
    <div id="vq-body">${loadingBlock('Reading the verification queue')}</div>`;

  const body = root.querySelector('#vq-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading the verification queue');
    let res = null;
    let auto = null;
    try {
      [res, auto] = await Promise.all([
        rpc('admin_verification_queue', { p_status: status || null, p_limit: 40 }),
        rpc('admin_auto_verify_state').catch(() => null)
      ]);
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/automation-engine.sql</span> and <span class="mono">supabase/verification-automation.sql</span> to install the queue and the sweep.</div></div>`;
      return;
    }

    const items = res?.items || [];
    const engine = res?.engine || {};
    const counts = engine.counts || {};
    const sched = res?.scheduler || {};
    const scope = res?.scope || {};

    const av = auto || null;
    const avc = av?.counters || {};
    const autoCard = av ? `<div class="card card-pad mt-18">
      <div class="row-between" style="gap:12px;flex-wrap:wrap">
        <div style="min-width:240px">
          <div class="strong" style="font-size:14px">Automatic verification (API) <span class="badge ${av.enabled ? 'green' : 'grey'}">${av.enabled ? 'ON' : 'OFF'}</span></div>
          <div class="tiny dim mt-6">Comment tasks on YouTube, Instagram and TikTok are checked against the real comments endpoint. Follow / Like / Subscribe cannot be proven by this API, so they always stay in manual review.</div>
        </div>
        <div class="row-wrap">
          ${canAuto ? `<button class="btn ${av.enabled ? 'btn-ghost' : 'btn-soft'} btn-sm" type="button" data-av-toggle="${av.enabled ? 'false' : 'true'}">${av.enabled ? 'Turn off' : 'Turn on'}</button>` : ''}
          ${canAuto ? `<button class="btn btn-primary btn-sm" type="button" data-av-run>${icon('play', 14)} Run now</button>` : ''}
        </div>
      </div>
      <div class="row-wrap mt-10">
        <span class="badge ${av.api_configured ? 'green' : 'red'}">API key ${av.api_configured ? 'in Vault' : 'missing'}</span>
        <span class="badge ${av.pg_net ? 'green' : 'red'}">pg_net ${av.pg_net ? 'ready' : 'missing'}</span>
        <span class="badge ${av.socify_enabled ? 'green' : 'grey'}">Socify ${av.socify_enabled ? 'on' : 'off'}</span>
        <span class="badge ${av.auto_rewards ? 'green' : 'gold'}">Auto rewards ${av.auto_rewards ? 'on' : 'off'}</span>
        ${av.last_run ? `<span class="badge grey">Last run ${esc(ago(av.last_run.at))}</span>` : '<span class="badge gold">No run recorded yet</span>'}
      </div>
      <div class="grid grid-3 mt-12">
        <div class="card card-pad"><div class="tiny dim">API polling</div><div class="strong">${Number(avc.api_polling || 0)}</div></div>
        <div class="card card-pad"><div class="tiny dim">Verified</div><div class="strong c-green">${Number(avc.verified || 0)}</div></div>
        <div class="card card-pad"><div class="tiny dim">Manual / failed</div><div class="strong">${Number(avc.manual || 0)} / ${Number(avc.failed || 0)}</div></div>
      </div>
      ${(av.recent || []).length ? `<div class="list mt-12">${av.recent.map((j) => `<div class="list-row">
        <div class="list-main" style="min-width:0">
          <div class="list-title">${esc(j.api_platform || 'platform')} · ${esc(j.api_resource || '')} <span class="badge ${j.status === 'verified' ? 'green' : j.status === 'manual' ? 'gold' : 'grey'}">${esc(j.status)}</span></div>
          <div class="list-sub">${esc(j.api_state || 'no api state')} · attempts ${Number(j.api_attempts || 0)} · ${esc(ago(j.updated_at))}</div>
          ${j.last_error ? `<div class="tiny red truncate">${esc(j.last_error)}</div>` : ''}
        </div>
        ${canAuto && ['manual', 'dead', 'queued'].includes(j.status) ? `<button class="btn btn-ghost btn-sm" type="button" data-av-retry="${esc(j.id)}">Retry</button>` : ''}
      </div>`).join('')}</div>` : '<p class="small muted mt-10">No API verification job yet. It appears when a comment task is submitted.</p>'}
    </div>` : '';

    body.innerHTML = `
      <div class="kpis">
        ${kpi({ label: 'Queued', value: Number(counts.queued || 0), iconName: 'clock', tone: 'gold', foot: Number(counts.oldest_queued_minutes || 0) > 0 ? `Oldest ${Number(counts.oldest_queued_minutes)} min` : 'Queue clear' })}
        ${kpi({ label: 'Verified today', value: Number(counts.verified_today || 0), iconName: 'checkCircle', tone: 'green', foot: `${Number(counts.rejected_today || 0)} rejected today` })}
        ${kpi({ label: 'Manual review', value: items.filter((i) => i.status === 'manual').length, iconName: 'user', tone: 'violet', foot: 'Waiting for a person' })}
        ${kpi({ label: 'Dead letter', value: (engine.dead_letters || []).length, iconName: 'alert', tone: (engine.dead_letters || []).length ? 'red' : '', foot: 'Retry from the row' })}
      </div>

      <div class="card card-pad mt-18">
        <div class="strong" style="font-size:14px">Sweep switches</div>
        <div class="row-wrap mt-10">
          <span class="badge ${sched.automation_enabled ? 'green' : 'grey'}">Automation ${sched.automation_enabled ? 'on' : 'off'}</span>
          <span class="badge ${sched.task_verification ? 'green' : 'grey'}">Task verification ${sched.task_verification ? 'on' : 'off'}</span>
          <span class="badge ${sched.auto_rewards ? 'green' : 'grey'}">Auto rewards ${sched.auto_rewards ? 'on' : 'off'}</span>
          <span class="badge ${sched.ai_verification ? 'green' : 'grey'}">AI ${sched.ai_verification ? 'on' : 'off'}</span>
          <span class="badge ${sched.cron_schedule ? 'green' : 'red'}">${sched.cron_schedule ? `cron every ${esc(sched.cron_schedule)}` : 'cron not scheduled'}</span>
          <span class="badge ${sched.telegram_bot_token ? 'green' : 'grey'}">bot token ${sched.telegram_bot_token ? 'in Vault' : 'missing'}</span>
        </div>
        ${(!sched.automation_enabled || !sched.task_verification)
          ? `<div class="alert warn mt-10">${icon('alert', 17)}<div>Nothing is queued or checked until <strong>Automation</strong> and <strong>Task verification</strong> are on (Admin → Automation → modules).</div></div>`
          : ''}
        ${!sched.cron_schedule
          ? `<div class="alert info mt-10">${icon('info', 17)}<div>Enable pg_cron and run <span class="mono">supabase/verification-automation.sql</span> to sweep every minute. Until then use <strong>Run sweep now</strong>.</div></div>`
          : ''}
      </div>

      <div class="grid grid-2 mt-18" style="align-items:start">
        <div class="card card-pad">
          <div class="strong" style="font-size:13px">Checks the sweep performs</div>
          <ul class="small muted" style="margin:8px 0 0 16px;line-height:1.8">
            ${(scope.automatic || []).map((s) => `<li>${esc(s)}</li>`).join('')}
          </ul>
        </div>
        <div class="card card-pad">
          <div class="strong" style="font-size:13px">Not automatic</div>
          <ul class="small muted" style="margin:8px 0 0 16px;line-height:1.8">
            ${(scope.not_automatic || []).map((s) => `<li>${esc(s)}</li>`).join('')}
          </ul>
        </div>
      </div>

      ${autoCard}

      <div class="card mt-18">
        <div class="card-head">
          <h3>Verification queue</h3>
          <div class="row-wrap">
            ${VQ_STATUS.map(([v, l]) => `<button class="chip ${status === v ? 'active' : ''}" type="button" data-vq-status="${v}">${l}</button>`).join('')}
          </div>
        </div>
        <div class="card-body">
          ${items.length ? `<div class="list">${items.map((q) => `
            <div class="list-row">
              <div class="list-main" style="min-width:0">
                <div class="list-title">${vqBadge(q.status)} ${esc(q.task || 'Task')}</div>
                <div class="list-sub">${esc(q.worker || 'Worker')} · ${esc(q.platform || '')} · attempts ${Number(q.attempts || 0)}/${Number(q.max_attempts || 0)} · ${esc(ago(q.created_at))}</div>
                ${q.last_error ? `<div class="tiny dim truncate">${esc(q.last_error)}</div>` : ''}
                ${q.evidence && Object.keys(q.evidence).length ? `<div class="tiny dim mono truncate">${esc(JSON.stringify(q.evidence).slice(0, 150))}</div>` : ''}
              </div>
              <div class="row-wrap" style="flex:0 0 auto">
                ${canDecide && ['queued', 'processing', 'manual'].includes(q.status)
                  ? `<button class="btn btn-ghost btn-sm" type="button" data-vq-approve="${esc(q.id)}">Approve</button>
                     <button class="btn btn-ghost btn-sm" type="button" data-vq-manual="${esc(q.id)}">Keep manual</button>
                     <button class="btn btn-danger btn-sm" type="button" data-vq-reject="${esc(q.id)}">Reject</button>`
                  : ''}
                ${canDecide && ['dead', 'manual'].includes(q.status)
                  ? `<button class="btn btn-ghost btn-sm" type="button" data-vq-retry="${esc(q.id)}">Requeue</button>`
                  : ''}
                ${canDecide ? `<a class="btn btn-ghost btn-sm" href="#/admin/proofs">Proof</a>` : ''}
              </div>
            </div>`).join('')}</div>`
            : emptyState({ iconName: 'shield', title: 'Nothing in this queue', text: 'New proofs are enqueued when Automation and Task verification are on.' })}
        </div>
      </div>`;

    const avToggle = body.querySelector('[data-av-toggle]');
    if (avToggle) avToggle.addEventListener('click', async () => {
      setBusy(avToggle, true, 'Saving');
      try {
        await rpc('admin_update_setting', { p_key: 'auto_verify_enabled', p_value: avToggle.dataset.avToggle === 'true', p_is_public: false });
        toast('Automatic verification updated.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(avToggle, false);
      }
    });

    const avRun = body.querySelector('[data-av-run]');
    if (avRun) avRun.addEventListener('click', async () => {
      setBusy(avRun, true, 'Running');
      try {
        const r = await rpc('admin_auto_verify_run');
        const a = r?.auto || {};
        toast(`Auto verifier: ${Number(a.dispatched || 0)} sent, ${Number(a.approved || 0)} verified, ${Number(a.manual || 0)} manual. Sweep claimed ${Number((r?.sweep || {}).claimed || 0)}.`, 'success', 9000);
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(avRun, false);
      }
    });

    body.querySelectorAll('[data-av-retry]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Queuing');
      try {
        await rpc('admin_verification_retry', { p_queue_id: b.dataset.avRetry });
        toast('Job queued for the next run.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));

    body.querySelectorAll('[data-vq-status]').forEach((b) => b.addEventListener('click', () => {
      status = b.dataset.vqStatus;
      load();
    }));

    const decide = async (id, decision, reason, btn) => {
      setBusy(btn, true, 'Saving');
      try {
        await rpc('admin_verification_decide', { p_queue_id: id, p_decision: decision, p_reason: reason });
        toast('Decision saved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(btn, false);
      }
    };

    body.querySelectorAll('[data-vq-approve]').forEach((b) => b.addEventListener('click', () => decide(b.dataset.vqApprove, 'approve', 'Approved from the verification queue', b)));
    body.querySelectorAll('[data-vq-manual]').forEach((b) => b.addEventListener('click', () => decide(b.dataset.vqManual, 'manual', 'Kept for manual review', b)));
    body.querySelectorAll('[data-vq-reject]').forEach((b) => b.addEventListener('click', () => decide(b.dataset.vqReject, 'reject', 'Rejected from the verification queue', b)));
    body.querySelectorAll('[data-vq-retry]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Requeuing');
      try {
        await rpc('verification_retry', { p_queue_id: b.dataset.vqRetry });
        toast('Requeued for the next sweep.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  root.querySelector('[data-vq-refresh]').addEventListener('click', load);
  const tickBtn = root.querySelector('[data-vq-tick]');
  if (tickBtn) tickBtn.addEventListener('click', async () => {
    setBusy(tickBtn, true, 'Sweeping');
    try {
      const res = await rpc('admin_verification_tick', { p_limit: 10 });
      if (res && res.reason) {
        toast(res.reason === 'AUTOMATION_DISABLED'
          ? 'Automation is off. Turn it on in Admin → Automation first.'
          : 'Task verification is off. Turn it on in Admin → Automation first.', 'error', 9000);
      } else {
        toast(`${Number(res?.claimed || 0)} checked · ${Number(res?.rejected || 0)} rejected · ${Number(res?.manual || 0)} to manual · ${Number(res?.failed || 0)} failed.`, Number(res?.failed || 0) ? 'error' : 'success', 8000);
      }
      load();
    } catch (e) {
      toast(friendlyError(e), 'error', 8000);
      setBusy(tickBtn, false);
    }
  });

  await load();
}

/* ================================================ SOCIAL VERIFICATION === */
const SOCIAL_PUBLIC_LABEL = {
  NOT_SUBMITTED: ['grey', 'Not checked'],
  CHECKING: ['orange', 'Checking'],
  VERIFIED_PUBLIC_PROFILE: ['green', 'Public profile'],
  NEEDS_MANUAL_REVIEW: ['gold', 'Needs review'],
  REJECTED: ['red', 'Rejected'],
  API_ERROR: ['red', 'API error']
};

function socialPublicBadge(status) {
  const [tone, label] = SOCIAL_PUBLIC_LABEL[status] || SOCIAL_PUBLIC_LABEL.NOT_SUBMITTED;
  return `<span class="badge ${tone}">${esc(label)}</span>`;
}

export async function renderAdminSocialVerification(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER', 'SUPPORT'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  const canDecide = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER']);
  let status = '';

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Verification</span><h2>Social verification</h2><p>Public profile evidence from Socify, alongside the existing code-based ownership verification. A public profile is never treated as ownership.</p></div>
      <div class="row-wrap">
        <a class="btn btn-ghost btn-sm" href="#/admin/socify">${icon('zap', 14)} Socify API</a>
        <button class="btn btn-ghost btn-sm" type="button" data-sv-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>
    <div id="sv-body">${loadingBlock('Reading verification data')}</div>`;

  const body = root.querySelector('#sv-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading verification data');
    let res;
    try {
      res = await rpc('admin_social_profiles', { p_status: status || null, p_limit: 100 });
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/social-verification-frontend.sql</span> to create the queue RPCs.</div></div>`;
      return;
    }
    const items = res?.items || [];
    const c = res?.counts || {};

    body.innerHTML = `<div class="kpis">
        ${kpi({ label: 'Public profiles', value: Number(c.verified || 0), iconName: 'checkCircle', tone: 'green', foot: `${Number(c.checking || 0)} checking` })}
        ${kpi({ label: 'Needs review', value: Number(c.manual || 0), iconName: 'user', tone: 'gold', foot: 'Human decision' })}
        ${kpi({ label: 'Rejected', value: Number(c.rejected || 0), iconName: 'xCircle', tone: Number(c.rejected || 0) ? 'red' : '', foot: 'Profile not found' })}
        ${kpi({ label: 'API errors', value: Number(c.errors || 0), iconName: 'alert', tone: Number(c.errors || 0) ? 'red' : '', foot: 'Retry from Socify API' })}
      </div>
      <div class="filter-bar mt-14">
        ${[['', 'All'], ['VERIFIED_PUBLIC_PROFILE', 'Public profile'], ['NEEDS_MANUAL_REVIEW', 'Needs review'], ['REJECTED', 'Rejected'], ['API_ERROR', 'API error'], ['CHECKING', 'Checking']].map(([v, l]) => `<button class="chip ${status === v ? 'active' : ''}" type="button" data-sv-status="${v}">${l}</button>`).join('')}
      </div>
      <div class="card mt-14">
        <div class="card-head"><h3>Accounts</h3><span class="badge grey">${items.length}</span></div>
        <div class="card-body">
          ${items.length ? `<div class="list">${items.map((a) => `
            <div class="list-row">
              ${a.profile_avatar ? `<img class="proof-thumb" style="width:36px;height:36px;border-radius:10px" src="${esc(a.profile_avatar)}" alt="" />` : `<span class="empty-ic" style="width:36px;height:36px;margin:0;border-radius:10px">${platformIcon(a.platform, 17)}</span>`}
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(a.profile_name || a.profile_username || '@' + a.handle)} ${socialPublicBadge(a.public_status)}</div>
                <div class="list-sub">${esc(a.user_name || '')} · ${esc(a.platform)} @${esc(a.handle)} · ${a.profile_followers != null ? `${Number(a.profile_followers).toLocaleString()} followers` : 'no follower data'}${a.profile_checked_at ? ` · ${esc(ago(a.profile_checked_at))}` : ''}</div>
                ${a.profile_error ? `<div class="tiny red truncate">${esc(a.profile_error)}</div>` : ''}
              </div>
              <div class="row-wrap" style="flex:0 0 auto">
                <button class="btn btn-ghost btn-sm" type="button" data-sv-detail="${esc(a.id)}">Open</button>
                ${canDecide && ['NEEDS_MANUAL_REVIEW', 'API_ERROR', 'REJECTED'].includes(a.public_status)
                  ? `<button class="btn btn-soft btn-sm" type="button" data-sv-verify="${esc(a.id)}">Verify</button>
                     <button class="btn btn-danger btn-sm" type="button" data-sv-reject="${esc(a.id)}">Reject</button>`
                  : ''}
              </div>
            </div>`).join('')}</div>`
            : emptyState({ iconName: 'link', title: 'No data yet', text: 'Worker public profile checks appear here once an Instagram, TikTok or YouTube account is linked and checked.' })}
        </div>
      </div>`;

    body.querySelectorAll('[data-sv-status]').forEach((b) => b.addEventListener('click', () => {
      status = b.dataset.svStatus;
      load();
    }));
    body.querySelectorAll('[data-sv-detail]').forEach((b) => b.addEventListener('click', () => openSocialDetail(b.dataset.svDetail, load)));

    const decide = async (id, decision, btn) => {
      const reason = await askNote(
        decision === 'verify' ? 'Confirm public profile' : 'Reject public profile',
        decision === 'verify'
          ? 'The public profile exists and the details match. Ownership is still handled by the code verification flow.'
          : 'Record why this public profile cannot be accepted.',
        'Reason',
        decision === 'verify' ? 'Confirm' : 'Reject',
        decision !== 'verify'
      );
      if (reason === null) return;
      if (!reason.trim()) return toast('A reason is required.', 'error');
      setBusy(btn, true, 'Saving');
      try {
        await rpc('admin_social_profile_decide', { p_account_id: id, p_decision: decision, p_reason: reason.trim() });
        toast('Saved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(btn, false);
      }
    };

    body.querySelectorAll('[data-sv-verify]').forEach((b) => b.addEventListener('click', () => decide(b.dataset.svVerify, 'verify', b)));
    body.querySelectorAll('[data-sv-reject]').forEach((b) => b.addEventListener('click', () => decide(b.dataset.svReject, 'reject', b)));
  };

  root.querySelector('[data-sv-refresh]').addEventListener('click', load);
  await load();
}

async function openSocialDetail(accountId, reload) {
  let d;
  try {
    d = await rpc('admin_social_profile_detail', { p_account_id: accountId });
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }
  const a = d?.account || {};
  const history = d?.history || [];
  const m = openModal({
    title: a.profile_name || `@${a.handle}`,
    subtitle: `${d?.user_name || ''} · ${a.platform}`,
    wide: true,
    body: `<div class="row-wrap mb-10">
        ${socialPublicBadge(a.public_status)}
        ${statusBadge(a.status, a.status === 'linked' ? 'Ownership verified' : a.status === 'pending' ? 'Ownership pending' : 'Ownership rejected')}
      </div>
      ${a.profile_avatar ? `<img class="proof-thumb" style="width:64px;height:64px;border-radius:14px" src="${esc(a.profile_avatar)}" alt="" />` : ''}
      <div class="grid grid-2 mt-14">
        ${[['Username', a.profile_username], ['Followers', a.profile_followers], ['Posts', a.profile_posts],
           ['Verified', a.profile_verified], ['Private', a.profile_private],
           ['Checked', a.profile_checked_at ? dateTime(a.profile_checked_at) : null]]
          .map(([label, value]) => `<div class="card card-pad"><div class="tiny dim">${esc(label)}</div><div class="strong">${value == null || value === '' ? '—' : esc(String(value))}</div></div>`).join('')}
      </div>
      ${a.profile_error ? `<div class="alert warn mt-14">${icon('alert', 17)}<div>${esc(a.profile_error)}</div></div>` : ''}
      <div class="card mt-14">
        <div class="card-head"><h3>Recorded API response</h3><span class="badge grey">evidence</span></div>
        <div class="card-body">${a.profile_raw ? `<pre class="mono-box" style="max-height:220px;overflow:auto">${esc(jsonPretty(a.profile_raw))}</pre>` : '<p class="small muted">No public data stored yet.</p>'}</div>
      </div>
      <div class="card mt-14">
        <div class="card-head"><h3>Lookup history</h3><span class="badge grey">${history.length}</span></div>
        <div class="card-body">${history.length ? `<div class="list">${history.map((h) => `
          <div class="list-row">
            ${statusBadge(h.status === 'done' ? 'approved' : h.status === 'failed' ? 'rejected' : 'pending', h.status)}
            <div class="list-main"><div class="list-sub mono">${esc(h.resource)} · HTTP ${esc(String(h.http_status || '—'))} · ${Number(h.credits || 0)} credit(s)</div>
            <div class="tiny dim">${esc(dateTime(h.created_at))}${h.error_message ? ` · ${esc(h.error_message)}` : ''}</div></div>
          </div>`).join('')}</div>` : '<p class="small muted">No data yet.</p>'}
        </div>
      </div>`,
    footer: '<button class="btn btn-ghost" type="button" data-close>Close</button>'
  });
  m.root.querySelector('[data-close]').onclick = () => m.close();
  if (typeof reload === 'function') { /* the list refreshes on the next action */ }
}

/* ===================================================== SOCIFY ADMIN ===== */
export async function renderAdminSocify(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Integrations</span><h2>Socify API</h2><p>Server-side social data provider. The API key lives in Supabase Vault and is only read inside database functions.</p></div>
      <button class="btn btn-ghost btn-sm" type="button" data-soc-refresh>${icon('refresh', 14)} Refresh</button>
    </div>
    <div id="soc-body">${loadingBlock('Reading integration status')}</div>`;

  const body = root.querySelector('#soc-body');

  const load = async () => {
    body.innerHTML = loadingBlock('Reading integration status');
    let ov;
    try {
      ov = await rpc('admin_socify_overview');
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/socify-integration.sql</span> first.</div></div>`;
      return;
    }
    const lim = ov?.limits || {};
    const counts = ov?.counts || {};
    const recent = ov?.recent || [];

    body.innerHTML = `<div class="kpis">
        ${kpi({ label: 'API key', value: ov?.configured ? 'Configured' : 'Missing', iconName: 'key', tone: ov?.configured ? 'green' : 'red', foot: ov?.pg_net ? 'pg_net ready' : 'pg_net missing' })}
        ${kpi({ label: 'Today', value: Number(counts.today || 0), iconName: 'chart', tone: 'blue', foot: `${Number(counts.done_today || 0)} ok · ${Number(counts.failed_today || 0)} failed` })}
        ${kpi({ label: 'Credits today', value: Number(counts.credits_today || 0), iconName: 'star', tone: 'gold', foot: `${Number(counts.credits_month || 0)} this month` })}
        ${kpi({ label: 'Last success', value: ov?.last_success ? esc(ago(ov.last_success)) : '—', iconName: 'checkCircle', tone: 'green', foot: `${Number(counts.pending || 0)} pending` })}
      </div>

      <div class="card card-pad mt-18">
        <div class="row-between" style="gap:14px;flex-wrap:wrap">
          <div><div class="strong" style="font-size:14px">Service switches</div><div class="tiny dim mt-6">Changes are saved server-side and audited.</div></div>
          <div class="row-wrap">
            <button class="btn ${ov?.enabled ? 'btn-danger' : 'btn-soft'} btn-sm" type="button" data-soc-toggle="socify_enabled" data-value="${ov?.enabled ? 'false' : 'true'}">${ov?.enabled ? 'Disable service' : 'Enable service'}</button>
            <button class="btn ${ov?.worker_access ? 'btn-ghost' : 'btn-soft'} btn-sm" type="button" data-soc-toggle="socify_worker_access" data-value="${ov?.worker_access ? 'false' : 'true'}">${ov?.worker_access ? 'Close worker access' : 'Open worker access'}</button>
          </div>
        </div>
        <div class="row-wrap mt-10">
          <span class="badge ${ov?.enabled ? 'green' : 'grey'}">Service ${ov?.enabled ? 'on' : 'off'}</span>
          <span class="badge ${ov?.worker_access ? 'green' : 'grey'}">Workers ${ov?.worker_access ? 'allowed' : 'blocked'}</span>
          <span class="badge ${ov?.configured ? 'green' : 'red'}">${ov?.configured ? 'Key in Vault' : 'No key in Vault'}</span>
          <span class="badge ${ov?.pg_net ? 'green' : 'red'}">pg_net ${ov?.pg_net ? 'ready' : 'missing'}</span>
          <span class="badge ${ov?.last_success ? 'green' : 'grey'}">${ov?.last_success ? 'Connected (real request succeeded)' : 'Configured, not yet connected'}</span>
        </div>
      </div>

      <div class="card card-pad mt-18">
        <div class="row-between" style="gap:14px;flex-wrap:wrap">
          <div style="min-width:240px">
            <div class="strong" style="font-size:14px">Real end-to-end test</div>
            <div class="tiny dim mt-6">Calls the official Instagram endpoint for <span class="mono">natgeo</span> through pg_net. Uses 1 credit. This is the only honest way to prove the key works.</div>
          </div>
          <div class="row-wrap">
            <button class="btn btn-primary btn-sm" type="button" data-soc-test>${icon('play', 14)} Run real test</button>
            <button class="btn btn-ghost btn-sm" type="button" data-soc-diag>${icon('database', 14)} Diagnostics</button>
          </div>
        </div>
        <div id="soc-test-out" class="mt-10"></div>
      </div>

      <div class="grid grid-2 mt-18" style="align-items:start">
        <div class="card card-pad">
          <div class="strong" style="font-size:14px">Limits</div>
          <div class="field mt-10"><label class="label">Lookups per worker per day</label><input class="input" id="soc-user-limit" type="number" min="0" value="${Number(lim.user_daily_requests || 20)}" /></div>
          <div class="field mt-10"><label class="label">Platform requests per day (all users)</label><input class="input" id="soc-global-cap" type="number" min="0" value="${Number(lim.daily_credit_cap || 200)}" /></div>
          <div class="field mt-10"><label class="label">Minimum seconds between lookups</label><input class="input" id="soc-gap" type="number" min="0" value="${Number(lim.min_seconds_between || 5)}" /></div>
          <div class="field mt-10"><label class="label">Cache minutes</label><input class="input" id="soc-cache" type="number" min="0" value="${Number(lim.cache_minutes || 30)}" /></div>
          <button class="btn btn-primary btn-sm mt-14" type="button" data-soc-save-limits>Save limits</button>
        </div>
        <div class="card card-pad">
          <div class="strong" style="font-size:14px">Supported endpoints</div>
          <div class="list mt-10">
            ${(ov?.platforms || []).length ? (ov.platforms || []).map((p) => `<div class="list-row"><div class="list-main"><div class="list-title">${esc(p.platform)}</div><div class="list-sub">${Number(p.endpoints)} documented endpoint(s)</div></div><span class="badge grey">${Number(p.endpoints)}</span></div>`).join('') : '<p class="small muted">No data yet.</p>'}
          </div>
          <div class="alert info mt-14">${icon('info', 17)}<div>Only the documented catalog is callable. The key is never sent to the browser.</div></div>
        </div>
      </div>

      <div class="card mt-18">
        <div class="card-head"><h3>Recent requests</h3><span class="badge grey">${recent.length}</span></div>
        <div class="card-body">
          ${recent.length ? `<div class="list">${recent.map((r) => `
            <div class="list-row">
              ${statusBadge(r.status === 'done' ? 'approved' : r.status === 'failed' ? 'rejected' : 'pending', r.status)}
              <div class="list-main" style="min-width:0">
                <div class="list-title">${esc(r.platform)} · ${esc(r.resource)}</div>
                <div class="list-sub">${esc(r.user_name || '')} · HTTP ${esc(String(r.http_status || '—'))} · ${Number(r.credits || 0)} credit(s) · ${esc(ago(r.created_at))}</div>
                ${r.error_message ? `<div class="tiny red truncate">${esc(r.error_message)}</div>` : ''}
              </div>
              ${r.status === 'failed' ? `<button class="btn btn-ghost btn-sm" type="button" data-soc-retry="${esc(r.id)}">Retry</button>` : ''}
            </div>`).join('')}</div>` : emptyState({ iconName: 'zap', title: 'No data yet', text: 'Lookups made by workers and admins appear here.' })}
        </div>
      </div>`;

    const setSetting = async (key, value, btn) => {
      setBusy(btn, true, 'Saving');
      try {
        await rpc('admin_socify_set', { p_key: key, p_value: value });
        toast('Saved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(btn, false);
      }
    };

    body.querySelectorAll('[data-soc-toggle]').forEach((b) => b.addEventListener('click', () => {
      setSetting(b.dataset.socToggle, b.dataset.value === 'true', b);
    }));

    const saveLimits = body.querySelector('[data-soc-save-limits]');
    if (saveLimits) saveLimits.addEventListener('click', async () => {
      setBusy(saveLimits, true, 'Saving');
      try {
        await rpc('admin_socify_set', { p_key: 'socify_user_daily_requests', p_value: Number(body.querySelector('#soc-user-limit').value || 0) });
        await rpc('admin_socify_set', { p_key: 'socify_daily_credit_cap', p_value: Number(body.querySelector('#soc-global-cap').value || 0) });
        await rpc('admin_socify_set', { p_key: 'socify_min_seconds_between', p_value: Number(body.querySelector('#soc-gap').value || 0) });
        await rpc('admin_socify_set', { p_key: 'socify_cache_minutes', p_value: Number(body.querySelector('#soc-cache').value || 0) });
        toast('Limits saved.', 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(saveLimits, false);
      }
    });

    body.querySelectorAll('[data-soc-retry]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Retrying');
      try {
        const res = await rpc('admin_socify_retry', { p_request_id: b.dataset.socRetry });
        toast(res?.ok === false ? (res.message || 'Retry failed.') : 'Request dispatched again.', res && res.ok === false ? 'error' : 'success');
        setTimeout(load, 2500);
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));

    const testBtn = body.querySelector('[data-soc-test]');
    if (testBtn) testBtn.addEventListener('click', async () => {
      const out = body.querySelector('#soc-test-out');
      setBusy(testBtn, true, 'Testing');
      try {
        const started = await rpc('admin_socify_test', { p_user: 'natgeo' });
        if (!started || started.ok === false) {
          out.innerHTML = `<div class="alert warn">${icon('alert', 17)}<div>${esc((started && started.message) || 'The test could not start.')}</div></div>`;
          setBusy(testBtn, false);
          return;
        }
        let res = null;
        for (let i = 0; i < 15; i += 1) {
          await new Promise((r) => setTimeout(r, 1000));
          res = await rpc('admin_socify_test_result', { p_request_id: started.request_id });
          if (res && res.status && res.status !== 'pending') break;
        }
        const ok = res && res.status === 'done';
        out.innerHTML = `<div class="alert ${ok ? 'info' : 'warn'}">${icon(ok ? 'checkCircle' : 'alert', 17)}<div>
          <strong>${ok ? 'Socify answered' : 'Test failed'}</strong> · status ${esc(res?.status || 'pending')} · HTTP ${esc(String(res?.http_status || '—'))} · ${Number(res?.credits || 0)} credit(s)
          ${!ok && res?.message ? `<div class="mono small mt-6">${esc(res.message)}</div>` : ''}
          ${ok ? `<div class="mono small mt-6">${esc(JSON.stringify(res?.data || {}).slice(0, 400))}</div>` : ''}
        </div></div>`;
        setBusy(testBtn, false);
        load();
      } catch (e) {
        out.innerHTML = `<div class="alert warn">${icon('alert', 17)}<div>${esc(friendlyError(e))}</div></div>`;
        setBusy(testBtn, false);
      }
    });

    const diagBtn = body.querySelector('[data-soc-diag]');
    if (diagBtn) diagBtn.addEventListener('click', async () => {
      const out = body.querySelector('#soc-test-out');
      setBusy(diagBtn, true, 'Reading');
      try {
        const d = await rpc('admin_socify_diag');
        out.innerHTML = `<pre class="mono-box" style="max-height:260px;overflow:auto">${esc(jsonPretty(d))}</pre>`;
        setBusy(diagBtn, false);
      } catch (e) {
        out.innerHTML = `<div class="alert warn">${icon('alert', 17)}<div>${esc(friendlyError(e))}</div></div>`;
        setBusy(diagBtn, false);
      }
    });
  };

  root.querySelector('[data-soc-refresh]').addEventListener('click', load);
  await load();
}

/* ============================================== TASK VERIFICATION MODAL == */
async function openTaskVerification(campaignId, title) {
  let cfg;
  try {
    cfg = await rpc('admin_campaign_verification', { p_campaign_id: campaignId });
  } catch (e) {
    toast(friendlyError(e), 'error');
    return;
  }
  const rules = cfg?.verification_rules || {};
  const m = openModal({
    title: 'Task verification',
    subtitle: title,
    body: `<div class="field">
        <label class="label">Verification method</label>
        <select class="select" id="tv-method">
          ${[['manual', 'Manual proof review (default)'], ['public_profile', 'Public profile check'],
             ['followers_min', 'Minimum followers check'], ['public_media_exists', 'Public media URL exists']]
            .map(([v, l]) => `<option value="${v}" ${cfg?.verification_method === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <span class="hint">Socify can confirm public facts only. It never proves a follow, like, view, subscribe or comment, and auto-approval is always off.</span>
      </div>
      <div class="field mt-12"><label class="label">Minimum followers (for the follower check)</label>
        <input class="input" id="tv-min" type="number" min="0" value="${Number(rules.min_followers || 0)}" /></div>
      <div class="field mt-12"><label class="label">Require a verified public profile</label>
        <select class="select" id="tv-require"><option value="false" ${rules.require_public_profile ? '' : 'selected'}>No</option><option value="true" ${rules.require_public_profile ? 'selected' : ''}>Yes</option></select></div>
      <div class="field mt-12"><label class="label">Public media URL (optional)</label>
        <input class="input mono" id="tv-media" value="${esc(rules.media_url || '')}" placeholder="https://…" /></div>`,
    footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
      <button class="btn btn-primary" type="button" data-save>Save</button>`
  });
  m.root.querySelector('[data-cancel]').onclick = () => m.close();
  m.root.querySelector('[data-save]').onclick = async () => {
    const btn = m.root.querySelector('[data-save]');
    const payload = {
      min_followers: Number(m.root.querySelector('#tv-min').value || 0),
      require_public_profile: m.root.querySelector('#tv-require').value === 'true',
      media_url: m.root.querySelector('#tv-media').value.trim(),
      allow_auto_approve: false
    };
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_set_campaign_verification', {
        p_campaign_id: campaignId,
        p_method: m.root.querySelector('#tv-method').value,
        p_rules: payload
      });
      toast('Task verification saved.', 'success');
      m.close();
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(btn, false);
    }
  };
}

/* ======================================================== TELEGRAM === */
const TG_ROLES = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'SUPPORT'];

const TG_KIND_LABEL = {
  checkin: 'Check-in successful',
  task_available: 'New task available',
  task_completed: 'Task completed',
  task_approved: 'Task approved (legacy)',
  task_rejected: 'Task rejected',
  deposit_approved: 'Deposit approved',
  deposit_rejected: 'Deposit rejected',
  withdrawal_approved: 'Withdrawal approved',
  withdrawal_paid: 'Withdrawal paid',
  withdrawal_rejected: 'Withdrawal rejected',
  referral_bonus: 'Referral bonus',
  announcement: 'Announcement',
  test: 'Test message'
};

const TG_TOGGLE_KEYS = [
  'telegram_bot_enabled',
  'telegram_notify_checkin',
  'telegram_notify_task_completed',
  'telegram_notify_task_available',
  'telegram_notify_task_approved',
  'telegram_notify_task_rejected',
  'telegram_notify_deposit_approved',
  'telegram_notify_deposit_rejected',
  'telegram_notify_withdrawal_approved',
  'telegram_notify_withdrawal_paid',
  'telegram_notify_withdrawal_rejected',
  'telegram_notify_referral_bonus',
  'telegram_notify_announcement'
];

function tgToggleLabel(key) {
  if (key === 'telegram_bot_enabled') return 'Bot delivery enabled';
  const kind = key.replace('telegram_notify_', '');
  return TG_KIND_LABEL[kind] || kind;
}

/* Telegram delivery is database-native: the database queues a row in
   telegram_outbox and PostgreSQL sends it with pg_net, using a bot token that
   lives in Supabase Vault. This panel only reads real status and calls the
   SECURITY DEFINER RPCs created by supabase/telegram-db-sender.sql.

   There is no Edge Function here and the token never reaches the browser. */
const TG_SENDER_SQL = 'supabase/telegram-db-sender.sql';

function tgSenderHint(code) {
  if (code === 'PG_NET_NOT_INSTALLED') {
    return `pg_net is not installed. Enable it in Supabase → Database → Extensions → pg_net, then run ${TG_SENDER_SQL}.`;
  }
  if (code === 'TELEGRAM_BOT_TOKEN_MISSING') {
    return `The bot token is not in Vault yet. Run the Vault section of ${TG_SENDER_SQL} once.`;
  }
  return '';
}

async function tgDrain(limit = 50) {
  return rpc('admin_telegram_drain', { p_limit: limit });
}

async function tgSenderStatus() {
  return rpc('admin_telegram_sender_status');
}

function tgFlag(ok, yes = 'Ready', no = 'Missing') {
  return `<span class="badge ${ok ? 'green' : 'red'}">${ok ? yes : no}</span>`;
}

/* What the panel shows instead of a health probe: every value is a real
   database read, so it cannot report a state the database is not in. */
function showTelegramSender(st) {
  const ready = !!st.pg_net && !!st.secret_set;

  const rows = [
    ['pg_net', st.pg_net, 'Sends the HTTP request from PostgreSQL itself.'],
    ['Supabase Vault secret', st.secret_set,
      'telegram_bot_token is stored in Vault and read only inside a SECURITY DEFINER function.'],
    ['Immediate dispatch trigger', st.dispatch_trigger,
      'Fires as soon as a row is queued in telegram_outbox.'],
    ['Deferred completion trigger', st.completion_trigger_deferred,
      'Fires at commit, after the reward and TM Coin are credited, and only when the ledger credit exists.'],
    ['No message on submit', st.submit_trigger_removed === true,
      'Submitting proof never sends Telegram. Only an approved and credited task does.'],
    ['pg_cron schedule', !!st.cron_schedule,
      st.cron_schedule
        ? `Retries and reconciles on schedule: ${st.cron_schedule}.`
        : 'Optional: without it, retries need Send queued now.']
  ];

  const m = openModal({
    title: 'Telegram sender',
    subtitle: 'Database delivery · pg_net + Vault',
    wide: true,
    body: `
      ${ready ? '' : `<div class="alert warn mt-14">${icon('alert', 17)}<div>${esc(
        !st.pg_net
          ? `pg_net is not installed. Enable it in Supabase → Database → Extensions → pg_net, then run ${TG_SENDER_SQL}.`
          : `The bot token is not in Vault yet. Run section 2 of ${TG_SENDER_SQL} once.`
      )}</div></div>`}
      <div class="list">
        ${rows.map(([label, ok, hint]) => `<div class="list-row">
          <div class="list-main">
            <div class="list-title">${esc(label)}</div>
            <div class="list-sub">${esc(hint)}</div>
          </div>
          ${tgFlag(ok)}
        </div>`).join('')}
      </div>

      <div class="grid grid-2 mt-18">
        <div class="card card-pad">
          <div class="tiny dim">Queued</div>
          <div class="strong" style="font-size:18px">${Number(st.queued || 0)}</div>
        </div>
        <div class="card card-pad">
          <div class="tiny dim">In flight</div>
          <div class="strong" style="font-size:18px">${Number(st.sending || 0)}</div>
        </div>
        <div class="card card-pad">
          <div class="tiny dim">Delivered (24h)</div>
          <div class="strong" style="font-size:18px">${Number(st.sent_24h || 0)}</div>
        </div>
        <div class="card card-pad">
          <div class="tiny dim">Retrying (backoff)</div>
          <div class="strong" style="font-size:18px">${Number(st.retrying || 0)}</div>
        </div>
        <div class="card card-pad">
          <div class="tiny dim">Failed</div>
          <div class="strong" style="font-size:18px">${Number(st.failed || 0)}</div>
        </div>
      </div>

      <div class="card card-pad mt-14">
        <div class="row-between small"><span class="muted">HTTP timeout</span><strong>${Number(st.timeout_ms || 30000)} ms</strong></div>
        <div class="row-between small mt-6"><span class="muted">Max attempts</span><strong>${Number(st.max_attempts || 6)}</strong></div>
        <div class="row-between small mt-6"><span class="muted">Telegram API base</span><strong class="mono tiny">${esc(st.api_base || 'https://api.telegram.org')}</strong></div>
        <div class="row-between small mt-6"><span class="muted">Task-submitted alerts</span><strong>${st.task_submitted_enabled ? 'on' : 'off'}</strong></div>
        ${st.last_error_class ? `<div class="row-between small mt-6"><span class="muted">Last error class</span><strong>${esc(st.last_error_class)}</strong></div>` : ''}
      </div>

      ${st.last_error ? `<div class="alert error mt-14">${icon('alert', 17)}<div><strong>Last error</strong><div class="mono small">${esc(st.last_error)}</div></div></div>` : ''}

      <p class="small muted mt-14">Bot delivery is ${st.bot_enabled ? 'on' : 'off'} and task-completion messages are ${st.task_completed_enabled ? 'on' : 'off'}. Nothing is queued while either is off.${st.last_sent_at ? ` Last delivery ${esc(ago(st.last_sent_at))}.` : ''}</p>`,
    footer: `<button class="btn btn-ghost" type="button" data-close>Close</button>
      <button class="btn btn-primary" type="button" data-send>Send queued now</button>`
  });

  m.root.querySelector('[data-close]').onclick = () => m.close();

  const send = m.root.querySelector('[data-send]');
  send.onclick = async () => {
    setBusy(send, true, 'Sending');
    try {
      const res = await tgDrain(50);
      const hint = tgSenderHint(res && res.error);
      if (hint) {
        toast(hint, 'error', 12000);
        setBusy(send, false);
        return;
      }
      toast(`${Number(res.dispatched || 0)} handed to pg_net, ${Number(res.pending || 0)} still pending.`, Number(res.failed || 0) > 0 ? 'error' : 'success', 7000);
      m.close();
    } catch (e) {
      toast(friendlyError(e), 'error', 8000);
      setBusy(send, false);
    }
  };
}

export async function renderAdminTelegram(root) {
  if (!allowed(TG_ROLES)) {
    root.innerHTML = forbiddenHTML(TG_ROLES);
    return;
  }

  const canEdit = allowed(['OWNER', 'SUPER_ADMIN']);
  const canSend = allowed(TG_ROLES);

  let status = '';
  let offset = 0;
  const limit = 20;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Notifications</span><h2>Telegram delivery</h2><p>Task, deposit, withdrawal and referral messages are queued in <span class="mono">telegram_outbox</span> and sent by <strong>PostgreSQL itself</strong> through <span class="mono">pg_net</span>, with the bot token stored in Supabase Vault. No Edge Function is involved and the token never reaches this app.</p></div>
      <div class="row-wrap">
        <button class="btn btn-ghost" type="button" data-tg-sender>${icon('shield', 15)} Sender status</button>
        <button class="btn btn-ghost" type="button" data-tg-refresh>${icon('refresh', 15)} Refresh</button>
      </div>
    </div>
    <div id="tg-body">${loadingBlock('Reading Telegram queue')}</div>`;

  const bodyEl = root.querySelector('#tg-body');

  const load = async () => {
    bodyEl.innerHTML = loadingBlock('Reading Telegram queue');
    let ov = null;
    let list = { items: [], total: 0 };
    try {
      [ov, list] = await Promise.all([
        rpc('admin_telegram_overview'),
        rpc('admin_telegram_list', { p_status: status || null, p_limit: limit, p_offset: offset })
      ]);
    } catch (e) {
      bodyEl.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }
    paint(ov || {}, list || {});
  };

  const paint = (ov, list) => {
    const counts = ov.counts || {};
    const toggles = ov.toggles || {};
    const templates = ov.templates || {};
    const items = list.items || [];
    const total = Number(list.total || 0);
    const botOn = ov.bot_enabled === true;
    const tplKeys = Object.keys(templates).sort();

    bodyEl.innerHTML = `<div class="kpis">
        ${kpi({ label: 'Linked Telegram users', value: Number(ov.linked_users || 0), iconName: 'telegram', tone: 'blue', foot: `${Number(ov.opted_out || 0)} opted out` })}
        ${kpi({ label: 'Waiting to send', value: Number(counts.queued || 0), iconName: 'send', tone: 'orange', foot: 'Queued or in flight' })}
        ${kpi({ label: 'Delivered', value: Number(counts.sent || 0), iconName: 'checkCircle', tone: 'green', foot: `${Number(counts.sent_24h || 0)} in the last 24h` })}
        ${kpi({ label: 'Failed', value: Number(counts.failed || 0), iconName: 'xCircle', tone: Number(counts.failed || 0) > 0 ? 'red' : '', foot: 'Retry from the log below' })}
      </div>

      <div class="card card-pad mt-18" style="border-color:${botOn ? 'rgba(74,222,128,.32)' : 'var(--line)'}">
        <div class="row-between" style="gap:14px;flex-wrap:wrap;align-items:flex-start">
          <div style="min-width:220px">
            <div class="strong" style="font-size:14px">Bot delivery ${botOn ? '<span class="badge green">On</span>' : '<span class="badge grey">Off</span>'}</div>
            <div class="tiny dim mt-6">${botOn
              ? 'Approved work, deposits, withdrawals and referral bonuses are queued for Telegram.'
              : 'Nothing is queued while this is off. In-app notifications keep working.'}</div>
          </div>
          <div class="row-wrap">
            ${canEdit ? `<button class="btn ${botOn ? 'btn-danger' : 'btn-soft'} btn-sm" type="button" data-tg-toggle="telegram_bot_enabled" data-tg-value="${botOn ? 'false' : 'true'}">
              ${botOn ? 'Turn delivery off' : 'Turn delivery on'}
            </button>` : ''}
            ${canSend ? `<button class="btn btn-ghost btn-sm" type="button" data-tg-drain>${icon('send', 14)} Send queued now</button>
            <button class="btn btn-ghost btn-sm" type="button" data-tg-test>Send test message</button>` : ''}
          </div>
        </div>
        <div class="alert info mt-14">${icon('lock', 17)}<div><strong>The bot token is never in this app.</strong> It is stored once in Supabase Vault as <span class="mono">telegram_bot_token</span> and read only inside a SECURITY DEFINER function; delivery runs from <span class="mono">${TG_SENDER_SQL}</span>. A worker only receives messages after opening TM GROW from the bot once, which links their Telegram id. <strong>Sender status</strong> shows exactly what is installed.</div></div>
      </div>

      <div class="card card-pad mt-18">
        <div class="row-between" style="gap:14px;flex-wrap:wrap">
          <div style="min-width:240px">
            <div class="strong" style="font-size:14px">Task completion alerts <span class="badge gold">New</span></div>
            <div class="tiny dim mt-6">One message per approved submission, queued only after the reward and TM Coin are credited. The progress line is computed from <span class="mono">reward_ranks</span> and the worker's real lifetime earnings — never a fixed number.</div>
          </div>
          <a class="btn btn-ghost btn-sm" href="#/admin/settings">${icon('settings', 14)} Edit rank ladder</a>
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div>
          Checked by <span class="mono">submissions_task_completed_tg</span> — a deferred trigger, so it fires at commit, after
          the reward and TM Coin are credited, with dedupe key <span class="mono">task_completed:&lt;submission id&gt;</span>.
          Pending, rejected and expired work never triggers it. The legacy <span class="mono">task_approved</span> switch is Off,
          so the worker receives exactly one message. Delivery failures stay in the log below and can be retried.
        </div></div>
      </div>

      <div class="grid grid-2 mt-18" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Event switches</h3><span class="badge grey">${canEdit ? 'Editable' : 'Read only'}</span></div>
          <div class="card-body">
            <div class="list">
              ${TG_TOGGLE_KEYS.map((key) => {
                const on = toggles[key] === true;
                return `<div class="list-row">
                  <div class="list-main">
                    <div class="list-title">${esc(tgToggleLabel(key))}</div>
                    <div class="list-sub mono">${esc(key)}</div>
                  </div>
                  ${canEdit
                    ? `<button class="btn btn-ghost btn-sm" type="button" data-tg-toggle="${esc(key)}" data-tg-value="${on ? 'false' : 'true'}">${on ? 'Turn off' : 'Turn on'}</button>`
                    : `<span class="badge ${on ? 'green' : 'grey'}">${on ? 'On' : 'Off'}</span>`}
                </div>`;
              }).join('')}
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Message templates</h3><span class="badge grey">${tplKeys.length}</span></div>
          <div class="card-body">
            <p class="small muted mb-10">Placeholders look like <span class="mono">{{task}}</span>, <span class="mono">{{reward}}</span>, <span class="mono">{{amount}}</span>. Every value is filled from the committed database row, never from the browser.</p>
            <div class="list">
              ${tplKeys.map((key) => {
                const kind = key.replace('telegram_tpl_', '');
                const text = typeof templates[key] === 'string' ? templates[key] : String(templates[key] ?? '');
                return `<div class="list-row">
                  <div class="list-main" style="min-width:0">
                    <div class="list-title">${esc(TG_KIND_LABEL[kind] || kind)}</div>
                    <div class="list-sub truncate">${esc(text.split('\n').filter(Boolean).slice(0, 2).join(' · ') || '(empty)')}</div>
                  </div>
                  ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-tg-tpl="${esc(key)}">Edit</button>` : ''}
                </div>`;
              }).join('') || '<p class="small muted">Templates are seeded by the schema.</p>'}
            </div>
          </div>
        </div>
      </div>

      <div class="card mt-18">
        <div class="card-head">
          <h3>Delivery log</h3>
          <div class="row-wrap">
            ${[['', 'All'], ['queued', 'Queued'], ['sending', 'Sending'], ['retrying', 'Retrying'], ['sent', 'Sent'], ['failed', 'Failed']].map(([v, label]) => `
              <button class="chip ${status === v ? 'active' : ''}" type="button" data-tg-status="${v}">${label}</button>`).join('')}
          </div>
        </div>
        <div class="card-body">
          ${items.length ? tableHtml(
            ['Status', 'Kind', 'User', 'Attempts', 'HTTP', 'Error', 'Created', ''],
            items.map((o) => `<tr>
              <td data-label="Status">${statusBadge(
    o.status === 'sent' ? 'approved' : o.status === 'failed' ? 'rejected' : 'pending',
    o.status === 'sent' ? 'Sent'
      : o.status === 'failed' ? 'Failed'
        : o.status === 'retrying' ? 'Retrying'
          : o.status === 'sending' ? 'Sending' : 'Queued'
  )}</td>
              <td data-label="Kind">${esc(TG_KIND_LABEL[o.kind] || o.kind)}</td>
              <td data-label="User">${esc(o.user_name || '—')}</td>
              <td data-label="Attempts" class="num">${Number(o.attempts || 0)}</td>
              <td data-label="HTTP" class="num">${o.http_status ? Number(o.http_status) : '—'}</td>
              <td data-label="Error" class="small muted">${esc(o.last_error || '—')}${o.status === 'retrying' && o.next_attempt_at ? `<div class="tiny dim mt-6">Next try ${esc(dateTime(o.next_attempt_at))}</div>` : ''}${o.error_class ? `<div class="tiny dim mt-6">${esc(o.error_class)}</div>` : ''}</td>
              <td data-label="Created">${esc(ago(o.created_at))}</td>
              <td data-label="">
                ${canSend && (o.status === 'failed' || o.status === 'retrying')
                  ? `<button class="btn btn-ghost btn-sm" type="button" data-tg-retry="${esc(o.id)}">Retry</button>`
                  : ''}
              </td>
            </tr>`)
          ) + pagerHtml(total, limit, offset) : emptyState({
            iconName: 'telegram',
            title: 'Nothing sent yet',
            text: 'The first approved task, deposit or withdrawal with a linked Telegram account lands here.'
          })}
        </div>
      </div>`;

    bodyEl.querySelectorAll('[data-tg-status]').forEach((b) => b.addEventListener('click', () => {
      status = b.dataset.tgStatus;
      offset = 0;
      load();
    }));

    bindPager(bodyEl, { limit, offset, total, setOffset: (v) => { offset = v; }, reload: load });

    bodyEl.querySelectorAll('[data-tg-toggle]').forEach((b) => b.addEventListener('click', async () => {
      const key = b.dataset.tgToggle;
      const value = b.dataset.tgValue === 'true';
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_update_setting', { p_key: key, p_value: value, p_is_public: false });
        toast(`${tgToggleLabel(key)} ${value ? 'on' : 'off'}.`, 'success');
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));

    bodyEl.querySelectorAll('[data-tg-tpl]').forEach((b) => b.addEventListener('click', () => {
      const key = b.dataset.tgTpl;
      const current = typeof templates[key] === 'string' ? templates[key] : String(templates[key] ?? '');
      const m = openModal({
        title: TG_KIND_LABEL[key.replace('telegram_tpl_', '')] || key,
        subtitle: key,
        wide: true,
        body: `<div class="field"><label class="label">Message</label>
            <textarea class="textarea mono" id="tg-tpl-text" rows="14">${esc(current)}</textarea>
            <span class="hint">Placeholders are replaced with real values. Keep them spelled exactly, e.g. {{reward}}.</span>
          </div>`,
        footer: `<button class="btn btn-ghost" type="button" data-cancel>Cancel</button>
          <button class="btn btn-primary" type="button" data-save>Save template</button>`
      });
      m.root.querySelector('[data-cancel]').onclick = () => m.close();
      m.root.querySelector('[data-save]').onclick = async (e) => {
        const btn = e.currentTarget;
        const text = m.root.querySelector('#tg-tpl-text').value;
        if (!text.trim()) return toast('The template cannot be empty.', 'error');
        setBusy(btn, true, 'Saving');
        try {
          await rpc('admin_update_setting', { p_key: key, p_value: text, p_is_public: false });
          toast('Template saved.', 'success');
          m.close();
          load();
        } catch (err) {
          toast(friendlyError(err), 'error');
          setBusy(btn, false);
        }
      };
    }));

    bodyEl.querySelectorAll('[data-tg-retry]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Sending');
      try {
        // The database re-checks the role and writes the audit row; PostgreSQL
        // then hands the message to pg_net.
        await rpc('admin_telegram_retry', { p_id: b.dataset.tgRetry });
        const res = await tgDrain(10);
        const hint = tgSenderHint(res && res.error);
        if (hint) {
          toast(hint, 'error', 12000);
        } else {
          toast(Number(res.failed || 0) > 0
            ? 'Retry failed again — the reason is in the error column.'
            : 'Message handed to pg_net. The status updates when the bot answers.',
          Number(res.failed || 0) > 0 ? 'error' : 'success', 8000);
        }
        load();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));

    const drain = bodyEl.querySelector('[data-tg-drain]');
    if (drain) drain.addEventListener('click', async () => {
      setBusy(drain, true, 'Sending');
      try {
        const res = await tgDrain(50);
        const hint = tgSenderHint(res && res.error);
        if (hint) {
          toast(hint, 'error', 12000);
          setBusy(drain, false);
          return;
        }
        toast(`${Number(res.dispatched || 0)} handed to pg_net, ${Number(res.pending || 0)} still pending.`, Number(res.failed || 0) > 0 ? 'error' : 'success', 7000);
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(drain, false);
      }
    });

    const test = bodyEl.querySelector('[data-tg-test]');
    if (test) test.addEventListener('click', async () => {
      setBusy(test, true, 'Sending');
      try {
        await rpc('admin_telegram_test');
        toast('Test message handed to pg_net. It arrives in Telegram a moment later; the log shows the result.', 'success', 8000);
        setBusy(test, false);
        load();
      } catch (e) {
        toast(friendlyError(e), 'error', 8000);
        setBusy(test, false);
      }
    });
  };

  root.querySelector('[data-tg-refresh]').addEventListener('click', load);

  /* Sender status: a real database read (pg_net, Vault secret, triggers, cron). */
  const senderBtn = root.querySelector('[data-tg-sender]');
  if (senderBtn) senderBtn.addEventListener('click', async () => {
    setBusy(senderBtn, true, 'Checking');
    try {
      const st = await tgSenderStatus();
      setBusy(senderBtn, false);
      showTelegramSender(st || {});
    } catch (e) {
      setBusy(senderBtn, false);
      toast(friendlyError(e), 'error', 8000);
    }
  });

  await load();
}



/* ============================================================ SMM ORDERS ===
   Drip release, per-unit tasks, proof review and worker rewards. Every number
   and every state here is read from the database; the scheduler itself lives
   in supabase/smm-drip.sql (pg_cron) and this page can only trigger it. */
export async function renderAdminSmmOrders(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'SUPPORT'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }
  const canDrip = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  const canReview = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER']);

  let status = 'processing';
  let orders = [];

  const dueLabel = (ts) => {
    if (!ts) return '';
    const ms = new Date(ts).getTime() - Date.now();
    if (!Number.isFinite(ms)) return '';
    if (ms <= 0) return 'due now';
    const mins = Math.ceil(ms / 60000);
    return mins < 60 ? `in ${mins}m` : `in ${Math.floor(mins / 60)}h ${mins % 60}m`;
  };

  const smmStatusChip = (s) => {
    const map = {
      pending: ['gold', 'Pending'], processing: ['orange', 'Processing'],
      completed: ['green', 'Completed'], partial: ['blue', 'Partial'],
      cancelled: ['grey', 'Cancelled'], failed: ['red', 'Failed'],
      refunded: ['violet', 'Refunded']
    };
    const [tone, label] = map[s] || ['grey', s || '—'];
    return `<span class="badge ${tone}">${esc(label)}</span>`;
  };

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">SMM panel</span><h2>SMM orders &amp; drip</h2><p>Batches are released automatically from real task rows. Every counter below is read from the database.</p></div>
      <div class="row-wrap">
        <button class="btn btn-primary btn-sm" type="button" data-smm-diag>${icon('database', 14)} Diagnostics</button>
        <button class="btn btn-ghost btn-sm" type="button" data-smm-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>
    <div class="kpis" id="smm-kpis"></div>
    <div id="smm-proofs" class="mt-18">${loadingBlock('Loading proof queue')}</div>
    <div id="smm-rewards" class="mt-18"></div>
    <div class="card mt-18">
      <div class="card-head">
        <h3>Orders</h3>
        <select class="select input-sm" id="smm-status" style="max-width:180px">
          ${[['processing', 'Processing'], ['pending', 'Pending'], ['completed', 'Completed'], ['partial', 'Partial'],
    ['cancelled', 'Cancelled'], ['failed', 'Failed'], ['refunded', 'Refunded'], ['', 'All statuses']]
    .map(([v, l]) => `<option value="${v}" ${v === status ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </div>
      <div class="card-body" id="smm-orders">${loadingBlock('Loading orders')}</div>
    </div>`;

  const kpisEl = root.querySelector('#smm-kpis');
  const ordersEl = root.querySelector('#smm-orders');
  const proofsEl = root.querySelector('#smm-proofs');
  const rewardsEl = root.querySelector('#smm-rewards');

  /* ------------------------------------------------------------- order list */
  const loadOrders = async () => {
    ordersEl.innerHTML = loadingBlock('Loading orders');
    try {
      const [res, stats] = await Promise.all([
        rpc('admin_smm_fulfilment', { p_status: status || null, p_limit: 60 }),
        rpc('admin_smm_stats').catch(() => null)
      ]);
      orders = res?.items || [];
      kpisEl.innerHTML = stats ? [
        kpi({ label: 'Orders', value: Number(stats.orders || 0), iconName: 'layers', tone: 'blue', foot: `${Number(stats.pending || 0)} pending · ${Number(stats.processing || 0)} processing` }),
        kpi({ label: 'Completed', value: Number(stats.completed || 0), iconName: 'checkCircle', tone: 'green', foot: 'All units approved' }),
        kpi({ label: 'Revenue', value: esc(usdt(stats.revenue)), suffix: 'USDT', iconName: 'coin', tone: 'gold', foot: `${esc(usdt(stats.refunded))} USDT refunded` }),
        kpi({ label: 'Active services', value: Number(stats.active_services || 0), iconName: 'sliders', tone: 'violet', foot: `${Number(stats.services || 0)} in catalogue` })
      ].join('') : '';
    } catch (e) {
      const raw = String((e && (e.raw?.message || e.message)) || '');
      const missing = /PGRST202|Could not find the function|does not exist/i.test(raw);
      ordersEl.innerHTML = missing
        ? errorPanel('SMM drip is not installed yet. Run supabase/smm-drip.sql in the Supabase SQL editor, then reload this page.')
        : errorPanel(friendlyError(e));
      kpisEl.innerHTML = '';
      return;
    }

    if (!orders.length) {
      ordersEl.innerHTML = emptyState({ iconName: 'layers', title: 'No orders in this status', text: 'Choose another status, or wait for a buyer order.' });
      return;
    }

    ordersEl.innerHTML = `<div class="col" style="gap:12px">${orders.map((o) => {
      const blocked = /blocked/i.test(String(o.admin_note || ''));
      const dripState = o.drip_paused ? '<span class="badge red">Paused</span>'
        : o.drip_enabled ? '<span class="badge green">Drip on</span>' : '<span class="badge grey">Drip off</span>';
      return `<div class="card card-pad">
        <div class="row-between" style="gap:10px;flex-wrap:wrap">
          <div class="row" style="gap:8px;min-width:0">
            <span class="smm-service-ic">${platformIcon(o.platform, 16)}</span>
            <div style="min-width:0">
              <div class="strong truncate">#${esc(o.short_id)} · ${esc(o.service_name)}</div>
              <div class="tiny dim truncate">${esc(o.user_name || 'Buyer')} · ${esc(o.target_link)}</div>
            </div>
          </div>
          <div class="row-wrap">${smmStatusChip(o.status)}${dripState}</div>
        </div>
        <div class="row-between small mt-10" style="gap:10px;flex-wrap:wrap">
          <span>${Number(o.completed_quantity).toLocaleString()} / ${Number(o.quantity).toLocaleString()} completed · ${Number(o.open || 0)} open · ${Number(o.rejected_quantity || 0)} rejected</span>
          <span class="tiny dim">Reward ${esc(usdt(o.worker_reward))} / 1K${o.next_release_at ? ` · next ${esc(dueLabel(o.next_release_at))}` : ''}</span>
        </div>
        ${o.admin_note ? `<div class="tiny ${blocked ? 'red' : 'dim'} mt-6">${esc(o.admin_note)}</div>` : ''}
        <div class="row-wrap mt-10">
          <button class="btn btn-primary btn-sm" type="button" data-order-id="${esc(o.id)}">Open order</button>
          ${canDrip ? `<button class="btn btn-ghost btn-sm" type="button" data-quick-release="${esc(o.id)}">Release batch now</button>` : ''}
        </div>
      </div>`;
    }).join('')}</div>`;

    ordersEl.querySelectorAll('[data-order-id]').forEach((b) => b.addEventListener('click', () => {
      const order = orders.find((x) => x.id === b.dataset.orderId);
      if (order) openOrder(order);
    }));
    ordersEl.querySelectorAll('[data-quick-release]').forEach((b) => b.addEventListener('click', async () => {
      setBusy(b, true, 'Releasing');
      try {
        const res = await rpc('admin_smm_release_now', { p_order_id: b.dataset.quickRelease });
        toast(`Released ${Number(res?.released || 0)} task(s). ${Number(res?.skipped || 0)} order(s) skipped.`, Number(res?.released || 0) > 0 ? 'success' : 'info', 7000);
        await loadOrders();
        await loadProofs();
      } catch (e) {
        toast(friendlyError(e), 'error', 7000);
        setBusy(b, false);
      }
    }));
  };

  /* ------------------------------------------------------------ proof queue */
  const loadProofs = async () => {
    proofsEl.innerHTML = loadingBlock('Loading proof queue');
    let rows = [];
    try {
      const res = await rpc('admin_smm_proof_queue', { p_limit: 30 });
      rows = res?.items || [];
    } catch (e) {
      proofsEl.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }

    if (!rows.length) {
      proofsEl.innerHTML = `<div class="card"><div class="card-head"><h3>Proof queue</h3><span class="badge grey">0</span></div>
        <div class="card-body"><p class="small muted">No SMM proof is waiting for review.</p></div></div>`;
      return;
    }

    const urls = {};
    await Promise.all(rows.map(async (t) => {
      const list = Array.isArray(t.proof_paths) && t.proof_paths.length
        ? t.proof_paths
        : (t.proof_path ? [t.proof_path] : []);
      urls[t.task_id] = (await Promise.all(list.map((p) => signedProofUrl(p, 1800).catch(() => '')))).filter(Boolean);
    }));

    proofsEl.innerHTML = `<div class="card">
      <div class="card-head"><h3>Proof queue</h3><span class="badge orange">${rows.length} waiting</span></div>
      <div class="card-body"><div class="col" style="gap:12px">
        ${rows.map((t) => `<div class="card card-pad">
          <div class="row" style="gap:12px;align-items:flex-start;flex-wrap:wrap">
            <div class="proof-strip">
              ${(urls[t.task_id] || []).length
        ? urls[t.task_id].map((u, i) => `<img src="${esc(u)}" alt="Proof ${i + 1}" class="proof-thumb sm" data-smm-proof="${esc(t.task_id)}" data-idx="${i}" />`).join('')
        : `<span class="proof-thumb" style="display:grid;place-items:center;color:var(--dim)">${icon('image', 18)}</span>`}
            </div>
            <div style="flex:1;min-width:200px">
              <div class="row" style="gap:8px;flex-wrap:wrap">
                <span class="badge gold">${esc(usdt(t.reward))} USDT</span>
                <span class="badge grey">Order #${esc(t.order_short)} · unit ${Number(t.seq || 0)}</span>
                <span class="badge grey">${esc(t.platform || '')}</span>
              </div>
              <div class="strong mt-10">${esc(t.service_name || '')}</div>
              <div class="small muted mt-6">${esc(t.worker_name || 'Worker')} · submitted ${esc(ago(t.submitted_at))}</div>
              ${t.note ? `<div class="panel panel-pad mt-10 small">${esc(t.note)}</div>` : ''}
              ${safeHttpUrl(t.proof_link) ? `<a class="btn btn-ghost btn-sm mt-10" href="${esc(safeHttpUrl(t.proof_link))}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Proof link</a>` : ''}
              ${safeHttpUrl(t.target_link) ? `<a class="btn btn-ghost btn-sm mt-10" href="${esc(safeHttpUrl(t.target_link))}" target="_blank" rel="noopener noreferrer">${icon('external', 14)} Target</a>` : ''}
              <div class="tiny dim mt-6">${(urls[t.task_id] || []).length || 1} screenshot(s)${t.time_spent_seconds ? ` · ${Number(t.time_spent_seconds)}s on task` : ''}</div>
            </div>
            ${canReview ? `<div class="col" style="gap:6px">
              <button class="btn btn-success btn-sm" type="button" data-smm-approve="${esc(t.task_id)}">Approve</button>
              <button class="btn btn-danger btn-sm" type="button" data-smm-reject="${esc(t.task_id)}">Reject</button>
            </div>` : ''}
          </div>
        </div>`).join('')}
      </div></div>
    </div>`;

    proofsEl.querySelectorAll('[data-smm-proof]').forEach((img) => img.addEventListener('click', () => {
      const list = urls[img.dataset.smmProof] || [];
      const viewer = openModal({
        title: 'Proof',
        subtitle: `${list.length} screenshot${list.length === 1 ? '' : 's'}`,
        wide: true,
        body: `<div class="col" style="gap:12px">${list.map((u, i) => `<img src="${esc(u)}" alt="Proof ${i + 1}" class="proof-full" />`).join('')}</div>`,
        footer: '<button class="btn btn-ghost" type="button" data-close-img>Close</button>'
      });
      viewer.root.querySelector('[data-close-img]').onclick = () => viewer.close();
    }));

    if (canReview) {
      proofsEl.querySelectorAll('[data-smm-approve]').forEach((b) => b.addEventListener('click', () => {
        const task = rows.find((x) => x.task_id === b.dataset.smmApprove);
        if (task) reviewSmmTask({ id: task.task_id, reward: task.reward, worker_name: task.worker_name }, true, refreshAll);
      }));
      proofsEl.querySelectorAll('[data-smm-reject]').forEach((b) => b.addEventListener('click', () => {
        const task = rows.find((x) => x.task_id === b.dataset.smmReject);
        if (task) reviewSmmTask({ id: task.task_id, reward: task.reward, worker_name: task.worker_name }, false, refreshAll);
      }));
    }
  };

  /* --------------------------------------------------------- worker rewards */
  const loadRewards = async () => {
    let services = [];
    try {
      const res = await rpc('admin_smm_services', { p_limit: 200, p_offset: 0 });
      services = res?.items || [];
    } catch (e) {
      rewardsEl.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>`;
      return;
    }

    const missing = services.filter((s) => !s.worker_reward_per_1000 || Number(s.worker_reward_per_1000) <= 0);

    rewardsEl.innerHTML = `<div class="card">
      <div class="card-head">
        <h3>Worker reward per 1K</h3>
        <span class="badge ${missing.length ? 'red' : 'green'}">${missing.length} service(s) without a reward</span>
      </div>
      <div class="card-body">
        <div class="alert ${missing.length ? 'error' : 'info'} mb-14">${icon('info', 17)}<div>Each released task is one unit and pays <strong>1/1000 of this rate</strong>. Drip release refuses to issue tasks for a service with no worker reward — the order is paused with a note instead, so nothing is paid at an invented price.</div></div>
        ${services.length ? `<div class="list">${services.map((s) => `<div class="list-row">
          <div class="list-main" style="min-width:0">
            <div class="list-title truncate">${esc(s.name)} ${s.archived_at ? '<span class="badge grey">archived</span>' : ''}</div>
            <div class="list-sub">${esc(s.platform)} · buyer ${esc(usdt(s.rate_per_1000))} / 1K · #${esc(s.short_id)}</div>
          </div>
          <div class="row" style="gap:6px">
            <input class="input input-sm" style="width:110px" type="number" min="0" step="0.000001"
              value="${s.worker_reward_per_1000 ? esc(String(s.worker_reward_per_1000)) : ''}"
              placeholder="not set" data-reward-input="${esc(s.id)}" ${canDrip ? '' : 'disabled'} />
            ${canDrip ? `<button class="btn btn-soft btn-sm" type="button" data-reward-save="${esc(s.id)}">Save</button>` : ''}
          </div>
        </div>`).join('')}</div>` : '<p class="small muted">No SMM service exists yet. Create one in Services &amp; pricing.</p>'}
      </div>
    </div>`;

    rewardsEl.querySelectorAll('[data-reward-save]').forEach((b) => b.addEventListener('click', async () => {
      const input = rewardsEl.querySelector(`[data-reward-input="${b.dataset.rewardSave}"]`);
      const value = Number(input?.value || 0);
      if (!Number.isFinite(value) || value <= 0) return toast('Enter a worker reward per 1K above 0.', 'error');
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_smm_set_worker_reward', { p_service_id: b.dataset.rewardSave, p_reward: value });
        toast('Worker reward saved. Paused orders must be resumed before they release again.', 'success', 7000);
        await loadRewards();
        await loadOrders();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(b, false);
      }
    }));
  };

  /* ------------------------------------------------------------ order modal */
  const openOrder = async (order) => {
    let tasks = [];
    try {
      const res = await rpc('admin_smm_tasks', { p_order_id: order.id });
      tasks = res?.items || [];
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
      return;
    }

    const m = openModal({
      title: `Order #${order.short_id}`,
      subtitle: `${order.service_name || ''} · ${order.user_name || 'Buyer'}`,
      wide: true,
      body: `<div class="card card-pad">
          <div class="row-between" style="gap:10px;flex-wrap:wrap">
            <div><div class="strong" style="font-size:14px">Drip release</div><div class="tiny dim mt-6">One task per unit. The database scheduler releases batches on its own.</div></div>
            <span class="badge ${order.drip_paused ? 'red' : order.drip_enabled ? 'green' : 'grey'}">${order.drip_paused ? 'Paused' : order.drip_enabled ? 'On' : 'Off'}</span>
          </div>
          <div class="grid grid-2 mt-12">
            <div class="field"><label class="label">Batch size</label><input class="input" id="smm-d-batch" type="number" min="1" max="500" value="${Number(order.drip_batch_size || 10)}" ${canDrip ? '' : 'disabled'} /></div>
            <div class="field"><label class="label">Interval (minutes)</label><input class="input" id="smm-d-interval" type="number" min="1" max="1440" value="${Number(order.drip_interval_minutes || 5)}" ${canDrip ? '' : 'disabled'} /></div>
            <div class="field"><label class="label">Max active tasks</label><input class="input" id="smm-d-max" type="number" min="1" max="2000" value="${Number(order.drip_max_active || 50)}" ${canDrip ? '' : 'disabled'} /></div>
            <div class="field"><label class="label">Daily limit (tasks)</label><input class="input" id="smm-d-daily" type="number" min="1" max="100000" value="${Number(order.drip_daily_limit || 100)}" ${canDrip ? '' : 'disabled'} /></div>
          </div>
          <div class="row-wrap mt-10">
            ${canDrip ? `<button class="btn btn-primary btn-sm" type="button" data-drip-save>Save settings</button>
            <button class="btn btn-soft btn-sm" type="button" data-drip-pause>${order.drip_paused ? 'Resume drip' : 'Pause drip'}</button>
            <button class="btn btn-ghost btn-sm" type="button" data-drip-release>Release batch now</button>` : '<span class="tiny dim">Your role can review proofs but not change release settings.</span>'}
          </div>
        </div>

        <div class="grid grid-3 mt-12">
          <div class="card card-pad"><div class="tiny dim">Issued</div><div class="strong">${Number(order.issued_quantity || 0).toLocaleString()}</div></div>
          <div class="card card-pad"><div class="tiny dim">Completed</div><div class="strong c-green">${Number(order.completed_quantity || 0).toLocaleString()}</div></div>
          <div class="card card-pad"><div class="tiny dim">Open now</div><div class="strong">${Number(order.open || 0).toLocaleString()}</div></div>
        </div>
        ${order.admin_note ? `<div class="alert ${/blocked/i.test(order.admin_note) ? 'error' : 'info'} mt-12">${icon('alert', 17)}<div>${esc(order.admin_note)}</div></div>` : ''}

        <div class="card mt-12">
          <div class="card-head"><h3>Tasks</h3><span class="badge grey">${tasks.length}</span></div>
          <div class="card-body" data-tasks-box>${loadingBlock('Loading tasks')}</div>
        </div>`,
      footer: '<button class="btn btn-ghost" type="button" data-close>Close</button>'
    });
    m.root.querySelector('[data-close]').onclick = () => m.close();

    const tasksBox = m.root.querySelector('[data-tasks-box]');

    const paintTasks = async (list) => {
      if (!list.length) {
        tasksBox.innerHTML = '<p class="small muted">No task has been released for this order yet.</p>';
        return;
      }
      const urls = {};
      await Promise.all(list.map(async (t) => {
        const paths = Array.isArray(t.proof_paths) && t.proof_paths.length
          ? t.proof_paths
          : (t.proof_path ? [t.proof_path] : []);
        urls[t.id] = (await Promise.all(paths.map((p) => signedProofUrl(p, 1800).catch(() => '')))).filter(Boolean);
      }));

      tasksBox.innerHTML = `<div class="list">${list.map((t) => `<div class="list-row" style="align-items:flex-start">
        <div class="list-main" style="min-width:0">
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <span class="list-title">Unit ${Number(t.seq || 0)}</span>
            ${statusBadge(t.status)}
            <span class="badge gold">${esc(usdt(t.reward))} USDT</span>
          </div>
          <div class="list-sub">${esc(t.worker_name || 'Not claimed')}${t.claimed_at ? ` · claimed ${esc(ago(t.claimed_at))}` : ''}${t.required_seconds ? ` · ${Number(t.required_seconds)}s timer` : ''}</div>
          ${(urls[t.id] || []).length ? `<div class="proof-strip mt-6">${urls[t.id].map((u, i) => `<img src="${esc(u)}" alt="Proof ${i + 1}" class="proof-thumb sm" />`).join('')}</div>` : ''}
          ${safeHttpUrl(t.proof_link) ? `<a class="tiny brand-text mt-6" style="display:inline-block" href="${esc(safeHttpUrl(t.proof_link))}" target="_blank" rel="noopener noreferrer">Proof link</a>` : ''}
          ${t.review_note ? `<div class="tiny dim mt-6">${esc(t.review_note)}</div>` : ''}
        </div>
        ${canReview && t.status === 'submitted' ? `<div class="col" style="gap:6px">
          <button class="btn btn-success btn-sm" type="button" data-t-approve="${esc(t.id)}">Approve</button>
          <button class="btn btn-danger btn-sm" type="button" data-t-reject="${esc(t.id)}">Reject</button>
        </div>` : ''}
      </div>`).join('')}</div>`;

      if (canReview) {
        tasksBox.querySelectorAll('[data-t-approve]').forEach((b) => b.addEventListener('click', () => {
          const task = list.find((x) => x.id === b.dataset.tApprove);
          if (task) reviewSmmTask({ id: task.id, reward: task.reward, worker_name: task.worker_name }, true, async () => {
            await reloadTasks();
          });
        }));
        tasksBox.querySelectorAll('[data-t-reject]').forEach((b) => b.addEventListener('click', () => {
          const task = list.find((x) => x.id === b.dataset.tReject);
          if (task) reviewSmmTask({ id: task.id, reward: task.reward, worker_name: task.worker_name }, false, async () => {
            await reloadTasks();
          });
        }));
      }
    };

    const reloadTasks = async () => {
      try {
        const res = await rpc('admin_smm_tasks', { p_order_id: order.id });
        tasks = res?.items || [];
        await paintTasks(tasks);
      } catch (e) {
        tasksBox.innerHTML = errorPanel(friendlyError(e));
      }
      await loadOrders();
      await loadProofs();
    };

    const saveDrip = async (patch) => {
      await rpc('admin_smm_set_drip', {
        p_order_id: order.id,
        p_enabled: patch.enabled ?? null,
        p_paused: patch.paused ?? null,
        p_batch: patch.batch ?? null,
        p_interval: patch.interval ?? null,
        p_max_active: patch.maxActive ?? null,
        p_daily: patch.daily ?? null
      });
    };

    const saveBtn = m.root.querySelector('[data-drip-save]');
    if (saveBtn) saveBtn.addEventListener('click', async () => {
      setBusy(saveBtn, true, 'Saving');
      try {
        await saveDrip({
          enabled: true,
          batch: Number(m.root.querySelector('#smm-d-batch').value),
          interval: Number(m.root.querySelector('#smm-d-interval').value),
          maxActive: Number(m.root.querySelector('#smm-d-max').value),
          daily: Number(m.root.querySelector('#smm-d-daily').value)
        });
        toast('Release settings saved.', 'success');
        m.close();
        await loadOrders();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(saveBtn, false);
      }
    });

    const pauseBtn = m.root.querySelector('[data-drip-pause]');
    if (pauseBtn) pauseBtn.addEventListener('click', async () => {
      setBusy(pauseBtn, true, 'Saving');
      try {
        await saveDrip({ paused: !order.drip_paused });
        toast(order.drip_paused ? 'Drip resumed.' : 'Drip paused. No new units are released.', 'success');
        m.close();
        await loadOrders();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(pauseBtn, false);
      }
    });

    const releaseBtn = m.root.querySelector('[data-drip-release]');
    if (releaseBtn) releaseBtn.addEventListener('click', async () => {
      setBusy(releaseBtn, true, 'Releasing');
      try {
        const res = await rpc('admin_smm_release_now', { p_order_id: order.id });
        const released = Number(res?.released || 0);
        toast(released > 0
          ? `Released ${released} task(s) into the worker marketplace.`
          : 'Nothing was released: the batch size, the active cap, the daily limit or the remaining quantity is zero. Check the settings and the admin note.', released > 0 ? 'success' : 'info', 9000);
        await reloadTasks();
        setBusy(releaseBtn, false);
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(releaseBtn, false);
      }
    });

    await paintTasks(tasks);
  };

  /* ---------------------------------------------------------------- reviews */
  const reviewSmmTask = async (task, approve, reload) => {
    let note = null;
    if (approve) {
      const ok = await confirmDialog({
        title: 'Approve this SMM proof?',
        message: `${usdt(task.reward)} USDT is credited to ${task.worker_name || 'the worker'} and one unit of the order is counted as completed. This cannot be undone.`,
        confirmLabel: 'Approve & pay'
      });
      if (!ok) return;
    } else {
      note = await askNote('Reject this SMM proof', 'The worker sees this note. The unit returns to the order and is released again to another worker.', 'Rejection reason', 'Reject proof');
      if (note === null) return;
      if (!note) { toast('A rejection reason is required.', 'error'); return; }
    }
    try {
      await rpc('admin_smm_review_task', { p_task_id: task.id, p_approve: approve, p_note: note });
      toast(approve ? 'Proof approved. Reward credited and the unit counted.' : 'Proof rejected. The unit is released again.', 'success');
      await reload();
    } catch (e) {
      toast(friendlyError(e), 'error', 6500);
    }
  };

  const refreshAll = async () => {
    await Promise.all([loadOrders(), loadProofs(), loadRewards()]);
  };

  /* Live diagnostic: every number comes from the database, nothing is assumed. */
  const showDiag = async (btn) => {
    setBusy(btn, true, 'Checking');
    try {
      const d = await rpc('admin_smm_diag');
      const rows = [
        ['pg_cron installed', d.cron_installed ? 'yes' : 'no', d.cron_installed ? 'green' : 'red'],
        ['Drip cron job', d.cron_job ? (d.cron_job.active ? 'active' : 'paused') : 'missing', d.cron_job ? (d.cron_job.active ? 'green' : 'gold') : 'red'],
        ['Last scheduler run', d.last_run ? dateTime(d.last_run.at) : 'never', d.last_run ? 'green' : 'gold'],
        ['Last scheduler error', d.last_error ? String(d.last_error.error).slice(0, 70) : 'none', d.last_error ? 'red' : 'green'],
        ['Orders eligible now', Number(d.orders_eligible_now || 0), Number(d.orders_eligible_now) > 0 ? 'green' : 'gold'],
    ['Orders paused', Number(d.orders_paused || 0)],
    ['Orders blocked (no worker reward)', Number(d.orders_blocked_no_reward || 0), Number(d.orders_blocked_no_reward) > 0 ? 'red' : 'green'],
    ['Available SMM units', Number(d.units_available || 0), Number(d.units_available) > 0 ? 'green' : 'gold'],
    ['Claimed units', Number(d.units_claimed || 0)],
    ['Submitted units', Number(d.units_submitted || 0)],
    ['Approved units', Number(d.units_approved || 0)],
    ['Rejected / expired units', Number(d.units_rejected || 0)],
    ['Release events today', Number(d.release_events_today || 0)],
    ['In-app SMM alerts today', Number(d.notifications_today || 0)],
    ['Telegram batch rows today', Number(d.telegram_rows_today || 0)],
    ['Telegram bot enabled', d.telegram_bot_enabled ? 'yes' : 'no', d.telegram_bot_enabled ? 'green' : 'gold'],
    ['Release alerts enabled', d.release_notifications_enabled ? 'yes' : 'no', d.release_notifications_enabled ? 'green' : 'gold'],
    ['Active workers', Number(d.active_workers || 0)]
      ].map(([label, value, tone]) => `<div class="list-row"><div class="list-main"><div class="list-title">${esc(label)}</div></div><span class="badge ${tone || 'grey'}">${esc(String(value))}</span></div>`).join('');

      const pool = Array.isArray(d.sample_pool) ? d.sample_pool : [];
      const poolHtml = pool.length
        ? `<div class="card card-pad mt-14"><div class="strong small">Available pool sample</div><div class="list mt-10">${pool.map((t) => `<div class="list-row"><div class="list-main"><div class="list-title">Unit ${Number(t.seq)} · ${esc(t.service)}</div><div class="list-sub">#${esc(t.order_short)} · ${esc(t.platform)} · ${esc(usdt(t.reward))} USDT · ${esc(t.order_status)}${t.drip_paused ? ' · paused' : ''}</div></div></div>`).join('')}</div></div>`
        : '<div class="alert warn mt-14">' + icon('alert', 17) + '<div>The available pool is empty. Either no batch has been released yet, or every released unit is already claimed.</div></div>';

      const m = openModal({
        title: 'SMM drip diagnostics',
        subtitle: 'Live values read from the database',
        wide: true,
        body: `<div class="list">${rows}</div>
          ${poolHtml}
          <details class="mt-14"><summary class="tiny dim" style="cursor:pointer">Raw JSON</summary><pre class="mono-box mt-10" style="white-space:pre-wrap;word-break:break-word">${esc(jsonPretty(d))}</pre></details>`,
        footer: '<button class="btn btn-ghost" type="button" data-close>Close</button>'
      });
      m.root.querySelector('[data-close]').onclick = () => m.close();
    } catch (e) {
      toast(friendlyError(e), 'error', 8000);
    } finally {
      setBusy(btn, false);
    }
  };

  const diagBtn = root.querySelector('[data-smm-diag]');
  if (diagBtn) diagBtn.addEventListener('click', () => showDiag(diagBtn));

  root.querySelector('[data-smm-refresh]').addEventListener('click', refreshAll);
  root.querySelector('#smm-status').addEventListener('change', (e) => {
    status = e.target.value;
    loadOrders();
  });

  await loadOrders();
  await loadProofs();
  await loadRewards();
}



/* ========================================================= PREFLIGHT STATUS ===
   Read-only view of supabase/preflight-status.sql. It reports which migrations
   are applied and the live state of the Telegram and verification pipelines.
   Nothing on this page writes to the database. */
export async function renderAdminPreflight(root) {
  const roles = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'SUPPORT'];
  if (!allowed(roles)) {
    root.innerHTML = forbiddenHTML(roles);
    return;
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Configuration</span><h2>Migration status</h2><p>Read-only pre-flight check: which migrations are applied, the Telegram trigger layout, event switches, Vault secrets, cron jobs, outbox and verification queues.</p></div>
      <button class="btn btn-ghost btn-sm" type="button" data-pre-refresh>${icon('refresh', 14)} Refresh</button>
    </div>
    <div id="pre-body">${loadingBlock('Reading migration status')}</div>`;

  const body = root.querySelector('#pre-body');
  const badge = (ok, good = 'yes', bad = 'no') => `<span class="badge ${ok ? 'green' : 'red'}">${ok ? good : bad}</span>`;

  const load = async () => {
    body.innerHTML = loadingBlock('Reading migration status');
    let d = null;
    try {
      d = await rpc('admin_preflight_status');
    } catch (e) {
      body.innerHTML = `<div class="card card-pad">${errorPanel(friendlyError(e))}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Run <span class="mono">supabase/preflight-status.sql</span> once in the Supabase SQL editor to install this read-only status RPC.</div></div>`;
      return;
    }

    const migrations = d.migrations || [];
    const missing = migrations.filter((m) => !m.applied);
    const settings = d.settings || {};
    const triggers = d.triggers || {};
    const outbox = d.outbox_counts || [];
    const recent = d.outbox_recent || [];
    const cron = d.cron || [];
    const verify = d.verification || [];
    const secrets = d.secrets || {};
    const ai = d.ai_screenshot;
    const ann = d.announcements;

    const settingRow = (key) => {
      const v = settings[key];
      const on = v === true || v === 'true';
      return `<div class="list-row"><div class="list-main"><div class="list-title mono tiny">${esc(key)}</div></div>${badge(on, 'on', 'off')}</div>`;
    };

    body.innerHTML = `
      ${missing.length
        ? `<div class="alert warn">${icon('alert', 17)}<div><strong>${missing.length} migration(s) not applied.</strong> Run them in this order: ${esc(missing.map((m) => m.name).join(' → '))}. Do not re-run one that already shows Applied.</div></div>`
        : `<div class="alert success">${icon('checkCircle', 17)}<div>All known migrations are applied.</div></div>`}

      <div class="card mt-14">
        <div class="card-head"><h3>Migrations</h3><span class="badge grey">${migrations.length}</span></div>
        <div class="card-body"><div class="list">${migrations.map((m) => `<div class="list-row">
          <div class="list-main"><div class="list-title">${esc(m.label || m.name)}</div><div class="list-sub mono tiny">${esc(m.name)}</div></div>
          ${badge(m.applied, 'Applied', 'Missing')}
        </div>`).join('')}</div></div>
      </div>

      <div class="grid grid-2 mt-14" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Telegram triggers</h3></div>
          <div class="card-body"><div class="list">
            <div class="list-row"><div class="list-main"><div class="list-title">Submit trigger removed</div><div class="list-sub">No message on proof upload</div></div>${badge(!triggers.submit_trigger_present, 'removed', 'present')}</div>
            <div class="list-row"><div class="list-main"><div class="list-title">Completion trigger</div><div class="list-sub">Approval only, after the ledger credit</div></div>${badge(triggers.completion_trigger_present)}</div>
            <div class="list-row"><div class="list-main"><div class="list-title">Completion deferred</div><div class="list-sub">Fires at commit, after wallet_move</div></div>${badge(triggers.completion_deferred)}</div>
          </div></div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Event switches</h3></div>
          <div class="card-body"><div class="list">
            ${['telegram_notify_checkin', 'telegram_notify_task_completed', 'telegram_notify_task_available', 'telegram_notify_announcement', 'telegram_notify_task_submitted'].map(settingRow).join('')}
          </div></div>
        </div>
      </div>

      <div class="card mt-14">
        <div class="card-head"><h3>Vault secrets</h3><span class="badge grey">presence only</span></div>
        <div class="card-body"><div class="list">
          ${['telegram_bot_token', 'socify_api_key', 'ai_verify_key', 'storage_service_key'].map((k) => `<div class="list-row"><div class="list-main"><div class="list-title mono tiny">${esc(k)}</div></div>${badge(secrets[k] === true, 'in Vault', 'missing')}</div>`).join('')}
        </div></div>
      </div>

      <div class="card mt-14">
        <div class="card-head"><h3>Cron jobs</h3></div>
        <div class="card-body">${cron.length ? tableHtml(['Job', 'Schedule', 'Active'], cron.map((c) => `<tr><td data-label="Job" class="mono tiny">${esc(c.jobname)}</td><td data-label="Schedule">${esc(c.schedule)}</td><td data-label="Active">${badge(c.active === true, 'active', 'paused')}</td></tr>`)) : '<p class="small muted">No tmgrow cron job found. Enable pg_cron and run the migrations.</p>'}</div>
      </div>

      <div class="grid grid-2 mt-14" style="align-items:start">
        <div class="card">
          <div class="card-head"><h3>Telegram outbox</h3></div>
          <div class="card-body">${outbox.length ? tableHtml(['Status', 'Rows'], outbox.map((o) => `<tr><td data-label="Status">${statusBadge(o.status === 'sent' ? 'approved' : o.status === 'failed' ? 'rejected' : 'pending', o.status)}</td><td data-label="Rows" class="num">${Number(o.rows)}</td></tr>`)) : '<p class="small muted">No delivery rows yet.</p>'}</div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Verification queue</h3></div>
          <div class="card-body">${verify.length ? tableHtml(['Status', 'Rows'], verify.map((o) => `<tr><td data-label="Status">${statusBadge(o.status)}</td><td data-label="Rows" class="num">${Number(o.rows)}</td></tr>`)) : '<p class="small muted">No verification jobs yet.</p>'}</div>
        </div>
      </div>

      ${recent.length ? `<div class="card mt-14"><div class="card-head"><h3>Recent deliveries</h3><a class="small brand-text" href="#/admin/telegram">Open Telegram page</a></div><div class="card-body">${tableHtml(['Kind', 'Status', 'Attempts', 'HTTP', 'Error', 'Created'], recent.map((o) => `<tr><td data-label="Kind">${esc(o.kind)}</td><td data-label="Status">${esc(o.status)}</td><td data-label="Attempts" class="num">${Number(o.attempts || 0)}</td><td data-label="HTTP" class="num">${o.http_status ? Number(o.http_status) : '—'}</td><td data-label="Error" class="small muted">${esc(o.last_error || '—')}</td><td data-label="Created">${esc(ago(o.created_at))}</td></tr>`))}</div></div>` : ''}

      ${ai ? `<div class="card mt-14"><div class="card-head"><h3>AI screenshot engine</h3></div><div class="card-body"><div class="list">${Object.entries(ai.counters || {}).map(([k, v]) => `<div class="list-row"><div class="list-main"><div class="list-title">${esc(k)}</div></div><span class="badge grey">${Number(v)}</span></div>`).join('') || '<p class="small muted">No AI job yet.</p>'}${ai.last ? `<div class="list-row"><div class="list-main"><div class="list-title">Last: ${esc(ai.last.state)}</div><div class="list-sub">${esc(ai.last.verdict || '')} · ${esc(String(ai.last.confidence ?? ''))} · ${esc(ai.last.reason || ai.last.last_error || '')}</div></div></div>` : ''}</div></div></div>` : ''}

      ${ann ? `<div class="card mt-14"><div class="card-head"><h3>Announcements</h3><a class="small brand-text" href="#/admin/notifications">Open announcements</a></div><div class="card-body"><div class="list">${Object.entries(ann.counters || {}).map(([k, v]) => `<div class="list-row"><div class="list-main"><div class="list-title">${esc(k)}</div></div><span class="badge grey">${Number(v)}</span></div>`).join('') || '<p class="small muted">No announcement yet.</p>'}<div class="list-row"><div class="list-main"><div class="list-title">Retrying deliveries</div></div><span class="badge ${Number(ann.retrying || 0) > 0 ? 'gold' : 'green'}">${Number(ann.retrying || 0)}</span></div></div></div></div>` : ''}

      <p class="tiny dim mt-14">Generated ${esc(dateTime(d.server_time))}. Read-only: nothing here changes a balance, a role or a message.</p>`;
  };

  const refreshBtn = root.querySelector('[data-pre-refresh]');
  if (refreshBtn) refreshBtn.addEventListener('click', load);

  await load();
}


/* ================================================== TASK CATEGORIES === */
/* Gated on supabase/admin-panel-upgrade.sql: until admin_category_list()
   exists, this page explains the migration instead of pretending. */
export async function renderAdminCategories(root) {
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Catalogue</span><h2>Task categories</h2><p>Group tasks by campaign type. A disabled category stops receiving new tasks; historical tasks keep their records.</p></div>
      ${canEdit ? `<button class="btn btn-primary" type="button" data-new-cat>${icon('plus', 16)} New category</button>` : '<span class="badge grey">Read only</span>'}
    </div>
    <div id="cat-list">${loadingBlock('Loading categories')}</div>`;

  const listEl = root.querySelector('#cat-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading categories');
    let rows = [];
    try {
      rows = (await rpc('admin_category_list')) || [];
    } catch (e) {
      const raw = String((e && (e.raw?.message || e.message)) || '');
      listEl.innerHTML = /PGRST202|Could not find the function|does not exist/i.test(raw)
        ? `<div class="card card-pad">${errorPanel('Task categories are not installed yet. Run supabase/admin-panel-upgrade.sql in the Supabase SQL editor, then reload.')}</div>`
        : errorPanel(friendlyError(e));
      return;
    }

    listEl.innerHTML = rows.length ? tableHtml(
      ['Category', 'Icon', 'Sort', 'Tasks', 'Status', ''],
      rows.map((c) => `<tr>
        <td data-label="Category"><span class="strong">${esc(c.name)}</span></td>
        <td data-label="Icon"><span class="mono tiny">${esc(c.icon)}</span></td>
        <td data-label="Sort" class="num">${Number(c.sort_order || 0)}</td>
        <td data-label="Tasks" class="num">${Number(c.task_count || 0)}</td>
        <td data-label="Status">${c.active ? '<span class="badge green">Active</span>' : '<span class="badge grey">Disabled</span>'}</td>
        <td data-label="Actions" class="cell-actions">
          ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-cat-edit="${esc(c.id)}">Edit</button>
          ${Number(c.task_count || 0) === 0 ? `<button class="btn btn-danger btn-sm" type="button" data-cat-del="${esc(c.id)}">Delete</button>` : ''}` : ''}
        </td>
      </tr>`)
    ) : emptyState({ iconName: 'layers', title: 'No categories yet', text: 'Create categories to group tasks; assignment happens per task slot batch.' });

    if (!canEdit) return;
    listEl.querySelectorAll('[data-cat-edit]').forEach((b) => b.addEventListener('click', () => {
      const c = rows.find((x) => x.id === b.dataset.catEdit);
      if (c) categoryModal(c, load);
    }));
    listEl.querySelectorAll('[data-cat-del]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Delete this category?',
        message: 'Only unused categories can be deleted. Categories with tasks are refused by the server — disable them instead.',
        confirmLabel: 'Delete',
        danger: true
      });
      if (!ok) return;
      setBusy(b, true, 'Deleting');
      try {
        await rpc('admin_category_delete', { p_id: b.dataset.catDel });
        toast('Category deleted.', 'success');
        load();
      } catch (e) {
        const raw = String((e && (e.raw?.message || e.message)) || '');
        const m = raw.match(/CATEGORY_IN_USE:(\d+)/);
        toast(m ? `This category still has ${m[1]} task(s). Disable it instead — historical records stay accessible.` : friendlyError(e), 'error', 8000);
        setBusy(b, false);
      }
    }));
  };

  const newBtn = root.querySelector('[data-new-cat]');
  if (newBtn) newBtn.addEventListener('click', () => categoryModal(null, load));
  await load();
}

function categoryModal(c, reload) {
  const isNew = !c;
  const m = openModal({
    title: isNew ? 'New task category' : `Edit ${c.name}`,
    body: `<form id="cat-form" class="col" style="gap:12px">
      <div class="field"><label class="label">Name</label><input class="input" name="name" required minlength="2" maxlength="60" value="${esc(c?.name || '')}" /></div>
      <div class="field-row">
        <div class="field"><label class="label">Icon key</label>
          <select class="select" name="icon">
            ${['layers', 'youtube', 'instagram', 'tiktok', 'facebook', 'x', 'telegram', 'reddit', 'spotify', 'discord', 'globe', 'star'].map((i) => `<option value="${i}" ${c?.icon === i ? 'selected' : ''}>${i}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label class="label">Sort order</label><input class="input" name="sort_order" type="number" step="1" value="${c ? Number(c.sort_order || 100) : 100}" /></div>
      </div>
      <label class="check"><input type="checkbox" name="active" ${!c || c.active ? 'checked' : ''} /> <span>Active — can receive new tasks</span></label>
      <button class="btn btn-primary" type="submit">${isNew ? 'Create category' : 'Save changes'}</button>
    </form>`
  });

  m.root.querySelector('#cat-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const btn = e.currentTarget.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_category_save', {
        p_payload: {
          id: c?.id || null,
          name: String(fd.get('name')).trim(),
          icon: String(fd.get('icon')),
          sort_order: Number(fd.get('sort_order') || 100),
          active: fd.get('active') === 'on'
        }
      });
      toast('Category saved.', 'success');
      m.close();
      reload();
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });
}

/* ==================================================== MAINTENANCE MODE === */
/* Toggle + copy + schedule. The schedule is enforced server-side by
   public.maintenance_tick() on pg_cron (supabase/admin-panel-upgrade.sql). */
export async function renderAdminMaintenance(root) {
  const canManage = allowed(['OWNER', 'SUPER_ADMIN']);
  if (!canManage) {
    root.innerHTML = forbiddenHTML(['OWNER', 'SUPER_ADMIN']);
    return;
  }

  let settings = [];
  try { settings = (await rpc('admin_get_settings')) || []; } catch (_) { settings = []; }
  const get = (k, d = '') => {
    const r = settings.find((s) => s.key === k);
    if (!r) return d;
    const v = r.value;
    return typeof v === 'string' ? v : (v === null || v === undefined ? d : String(v));
  };
  const on = get('maintenance') === 'true';
  const startAt = get('maintenance_start_at');
  const endAt = get('maintenance_end_at');
  const dtLocal = (iso) => (iso ? new Date(iso).toISOString().slice(0, 16) : '');

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Operations</span><h2>Maintenance mode</h2><p>Manual control plus a scheduled window enforced by the server, not a browser timer.</p></div>
    </div>

    <div class="grid grid-2" style="align-items:start">
      <div class="card card-pad">
        <div class="row-between" style="gap:12px;flex-wrap:wrap">
          <div style="min-width:200px">
            <div class="strong" style="font-size:14px">Maintenance is ${on ? '<span class="badge red">On</span>' : '<span class="badge grey">Off</span>'}</div>
            <div class="tiny dim mt-6">Admins keep access. Users see the maintenance screen immediately.</div>
          </div>
          <button class="btn ${on ? 'btn-danger' : 'btn-soft'} btn-sm" type="button" data-mt-toggle="${on ? '0' : '1'}">${on ? 'Turn off now' : 'Turn on now'}</button>
        </div>

        <hr class="divider" />
        <form id="mt-copy" class="col" style="gap:12px">
          <h3 style="font-size:13px">What users see</h3>
          <div class="field"><label class="label">Scope</label>
            <select class="select" name="scope">
              ${['all', 'worker', 'buyer'].map((s) => `<option value="${s}" ${get('maintenance_scope', 'all') === s ? 'selected' : ''}>${s === 'all' ? 'Whole platform' : s === 'worker' ? 'Worker app only' : 'SMM / buyer panel only'}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label class="label">Short message</label><input class="input" name="short" maxlength="400" value="${esc(get('maintenance_short'))}" placeholder="We are upgrading and will be back shortly." /></div>
          <div class="field"><label class="label">Detail (optional)</label><textarea class="textarea" name="detail" maxlength="800" rows="3">${esc(get('maintenance_detail'))}</textarea></div>
          <div class="field-row">
            <div class="field"><label class="label">Timezone label</label><input class="input" name="tz" value="${esc(get('maintenance_tz', 'Asia/Dhaka'))}" /></div>
          </div>
          <button class="btn btn-primary" type="submit">Save copy</button>
        </form>
      </div>

      <div class="card card-pad">
        <h3 style="font-size:13px" class="mb-10">Scheduled window</h3>
        <p class="small muted" style="line-height:1.6">Maintenance switches on at the start and off at the end automatically, using server time. In-progress payouts are never interrupted. Changes are audited.</p>
        <form id="mt-schedule" class="col" style="gap:12px">
          <div class="field-row">
            <div class="field"><label class="label">Starts</label><input class="input" type="datetime-local" name="start" value="${dtLocal(startAt)}" required /></div>
            <div class="field"><label class="label">Ends</label><input class="input" type="datetime-local" name="end" value="${dtLocal(endAt)}" required /></div>
          </div>
          <div class="row-wrap">
            <button class="btn btn-primary" type="submit">Schedule window</button>
            <button class="btn btn-ghost btn-sm" type="button" data-schedule-clear>Clear schedule</button>
          </div>
          <div class="tiny dim">Current window: ${startAt ? `${esc(dateTime(startAt))} → ${esc(dateTime(endAt))}` : 'none'}</div>
        </form>
        <div class="alert info mt-14">${icon('info', 17)}<div>The countdown on the maintenance screen uses the scheduled end time when one exists.</div></div>
      </div>
    </div>`;

  root.querySelector('[data-mt-toggle]').addEventListener('click', async (e) => {
    const turnOn = e.currentTarget.dataset.mtToggle === '1';
    const ok = await confirmDialog({
      title: turnOn ? 'Turn maintenance on?' : 'Turn maintenance off?',
      message: turnOn ? 'Users are blocked immediately; admins keep access.' : 'The platform reopens immediately.',
      confirmLabel: turnOn ? 'Turn on' : 'Turn off'
    });
    if (!ok) return;
    setBusy(e.currentTarget, true, 'Saving');
    try {
      await rpc('admin_update_setting', { p_key: 'maintenance', p_value: turnOn, p_is_public: true });
      await loadPublicData();
      toast(turnOn ? 'Maintenance mode is on.' : 'Maintenance mode is off.', 'success');
      renderAdminMaintenance(root);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(e.currentTarget, false);
    }
  });

  root.querySelector('#mt-copy').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const btn = e.currentTarget.querySelector('button[type=submit]');
    setBusy(btn, true, 'Saving');
    try {
      await rpc('admin_update_setting', { p_key: 'maintenance_scope', p_value: String(fd.get('scope')), p_is_public: true });
      await rpc('admin_update_setting', { p_key: 'maintenance_short', p_value: String(fd.get('short') || ''), p_is_public: true });
      await rpc('admin_update_setting', { p_key: 'maintenance_detail', p_value: String(fd.get('detail') || ''), p_is_public: true });
      await rpc('admin_update_setting', { p_key: 'maintenance_tz', p_value: String(fd.get('tz') || 'Asia/Dhaka'), p_is_public: true });
      await loadPublicData();
      toast('Maintenance copy saved.', 'success');
      renderAdminMaintenance(root);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });

  root.querySelector('#mt-schedule').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const start = String(fd.get('start') || '');
    const end = String(fd.get('end') || '');
    if (!start || !end) return toast('Both start and end are required.', 'error');
    const startIso = new Date(start).toISOString();
    const endIso = new Date(end).toISOString();
    if (new Date(endIso) <= new Date(startIso)) return toast('The end must be after the start.', 'error');
    const btn = e.currentTarget.querySelector('button[type=submit]');
    setBusy(btn, true, 'Scheduling');
    try {
      await rpc('admin_maintenance_schedule', {
        p_start_at: startIso,
        p_end_at: endIso,
        p_scope: String(fd.get('scope') || 'all') || 'all',
        p_short: String(fd.get('short') || '') || null,
        p_detail: String(fd.get('detail') || '') || null,
        p_tz: String(fd.get('tz') || 'Asia/Dhaka') || 'Asia/Dhaka'
      });
      toast('Maintenance window scheduled.', 'success');
      renderAdminMaintenance(root);
    } catch (err) {
      const raw = String((err && (err.raw?.message || err.message)) || '');
      toast(/PGRST202|Could not find the function|does not exist/i.test(raw)
        ? 'Scheduling needs supabase/admin-panel-upgrade.sql — run it in the SQL editor, then reload. The manual toggle keeps working meanwhile.'
        : friendlyError(err), 'error', 9000);
      setBusy(btn, false);
    }
  });

  root.querySelector('[data-schedule-clear]').addEventListener('click', async (e) => {
    const ok = await confirmDialog({ title: 'Clear the scheduled window?', message: 'Automatic start/end stops. The current on/off state stays as it is.', confirmLabel: 'Clear' });
    if (!ok) return;
    setBusy(e.currentTarget, true, 'Saving');
    try {
      await rpc('admin_update_setting', { p_key: 'maintenance_start_at', p_value: '', p_is_public: true });
      await rpc('admin_update_setting', { p_key: 'maintenance_end_at', p_value: '', p_is_public: true });
      await loadPublicData();
      toast('Schedule cleared.', 'success');
      renderAdminMaintenance(root);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(e.currentTarget, false);
    }
  });
}

/* ======================================================== AI MANAGER === */
/* Real analytics over live rows (admin_ai_insights), a computed daily report
   and the status of the server-side AI screenshot verification system. */
export async function renderAdminAIInsights(root) {
  if (!allowed(ROLES)) {
    root.innerHTML = forbiddenHTML(ROLES);
    return;
  }

  root.innerHTML = loadingBlock('Reading platform intelligence');
  let insights = null;
  let snapshot = null;
  let aiConfigured = false;
  const [insRes, snapRes] = await Promise.all([
    rpc('admin_ai_insights').then((r) => ({ r })).catch((e) => ({ e })),
    rpc('admin_ai_snapshot', { p_days: 7 }).then((r) => ({ r })).catch((e) => ({ e }))
  ]);
  try {
    const rows = (await rpc('admin_get_settings')) || [];
    aiConfigured = rows.find((s) => s.key === 'ai_screenshot_enabled')?.value === true;
  } catch (_) { /* settings unavailable */ }

  if (insRes.e) {
    const raw = String((insRes.e && (insRes.e.raw?.message || insRes.e.message)) || '');
    if (!/PGRST202|Could not find the function|does not exist/i.test(raw)) {
      root.innerHTML = errorPanel(friendlyError(insRes.e));
      return;
    }
  } else {
    insights = insRes.r;
  }
  if (snapRes.r) snapshot = snapRes.r;

  const t = snapshot?.totals || {};
  const f = snapshot?.finance || {};
  const missing = !insights;

  const reasons = (insights?.risky_workers || []).map((w) => w.worker);
  const report = [
    `TM GROW daily report — ${dateTime(new Date().toISOString())}`,
    '',
    `Accounts: ${Number(t.users || 0)} total (${Number(t.new_users || 0)} new in 7d). Workers ${Number(t.workers || 0)} · Buyers ${Number(t.buyers || 0)}.`,
    `Proof queue: ${Number(t.proofs_pending || 0)} waiting${Number(t.proofs_oldest_hours || 0) ? `, oldest ${Number(t.proofs_oldest_hours)}h` : ''}. Approved 7d: ${Number(t.approved_in_range || 0)} · Rejected 7d: ${Number(t.rejected_in_range || 0)}.`,
    `Money: ${usdt(f.available)} USDT available · ${usdt(f.pending)} pending · ${usdt(f.reserved)} reserved · revenue ${usdt(f.revenue)} USDT.`,
    `Withdrawals: ${Number(t.withdrawals_pending || 0)} open worth ${usdt(t.withdrawals_pending_amount)} USDT. Deposits waiting: ${Number(t.deposits_pending || 0)} worth ${usdt(t.deposits_pending_amount)} USDT.`,
    `Risk: ${Number(t.open_flags || 0)} open flags. Support: ${Number(t.open_tickets || 0)} open tickets.`,
    insights ? `Rejections (30d): ${Number(insights.rejections_30d?.approved || 0)} approved vs ${Number(insights.rejections_30d?.rejected || 0)} rejected (rate ${Number(insights.rejections_30d?.rate || 0)}).` : '',
    insights?.signup_spike?.spike ? `ALERT: signup spike detected — ${Number(insights.signup_spike.today)} accounts today vs 7-day average ${Number(insights.signup_spike.avg7)}.` : '',
    '',
    'Sources: live database rows only. No LLM is involved in this report.'
  ].filter(Boolean).join('\n');

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Intelligence</span><h2>AI Manager</h2><p>Every figure is computed from live database rows. Recommendations are advisory only — financial actions always stay in your hands.</p></div>
      <div class="row-wrap">
        <a class="btn btn-ghost btn-sm" href="#/admin/ai">${icon('send', 14)} Command assistant</a>
        <button class="btn btn-soft btn-sm" type="button" data-copy-report>${icon('copy', 14)} Copy daily report</button>
        <button class="btn btn-ghost btn-sm" type="button" data-refresh>${icon('refresh', 14)} Refresh</button>
      </div>
    </div>

    ${missing ? `<div class="alert info mt-14">${icon('info', 17)}<div>The insights layer is not installed yet. Run <span class="mono">supabase/admin-panel-upgrade.sql</span>, then reload. The rest of this page uses live data already.</div></div>` : ''}

    <div class="kpis mt-18">
      ${kpi({ label: 'Proofs waiting', value: Number(t.proofs_pending || 0), iconName: 'shield', tone: 'gold', foot: Number(t.proofs_oldest_hours || 0) > 0 ? `Oldest ${Number(t.proofs_oldest_hours)}h` : 'Queue clear' })}
      ${kpi({ label: 'Rejection rate 30d', value: insights ? `${Math.round(Number(insights.rejections_30d?.rate || 0) * 100)}%` : '—', iconName: 'chart', tone: Number(insights?.rejections_30d?.rate || 0) > 0.5 ? 'red' : 'blue', foot: `${Number(insights?.rejections_30d?.approved || 0)} approved / ${Number(insights?.rejections_30d?.rejected || 0)} rejected` })}
      ${kpi({ label: 'Withdrawals open', value: insights ? Number(insights.withdrawals?.pending || 0) : Number(t.withdrawals_pending || 0), iconName: 'wallet', tone: 'violet', foot: insights ? `${esc(usdt(insights.withdrawals?.amount))} USDT · oldest ${Number(insights.withdrawals?.oldest_hours || 0)}h` : `${esc(usdt(t.withdrawals_pending_amount))} USDT` })}
      ${kpi({ label: 'Open flags', value: Number(t.open_flags || 0), iconName: 'flag', tone: 'red', foot: `${Number(t.open_tickets || 0)} support tickets` })}
    </div>

    <div class="grid grid-2 mt-18" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>Suspicious activity</h3><span class="badge gold">Advisory</span></div>
        <div class="card-body">
          ${(insights?.risky_workers || []).length ? `
            <h4 style="font-size:12.5px" class="mb-6">High rejection-rate workers (≥60% over ≥5 reviews, 30d)</h4>
            <div class="list mb-10">${(insights.risky_workers || []).map((w) => `
              <div class="list-row"><div class="list-main"><div class="list-title">${esc(w.worker)}</div><div class="list-sub">${Number(w.approved)} approved · ${Number(w.rejected)} rejected · ${Math.round(Number(w.rate) * 100)}% rejected</div></div></div>`).join('')}</div>` : ''}
          ${(insights?.duplicate_proofs || []).length ? `
            <h4 style="font-size:12.5px" class="mb-6">Duplicate proof hashes (same screenshot, several submissions)</h4>
            <div class="list mb-10">${(insights.duplicate_proofs || []).map((d) => `
              <div class="list-row"><div class="list-main"><div class="list-title mono tiny">${esc(d.hash)}…</div><div class="list-sub">used ${Number(d.times)}× · last ${esc(ago(d.last))}</div></div></div>`).join('')}</div>` : ''}
          ${(insights?.fast_proofs || []).length ? `
            <h4 style="font-size:12.5px" class="mb-6">Approved proofs completed in under 15 seconds (30d)</h4>
            <div class="list mb-10">${(insights.fast_proofs || []).map((p) => `
              <div class="list-row"><div class="list-main"><div class="list-title">${esc(p.worker)}</div><div class="list-sub">${Number(p.seconds)}s on task · ${esc(usdt(p.reward))} USDT</div></div></div>`).join('')}</div>` : ''}
          ${insights?.signup_spike?.spike ? `<div class="alert warn mt-10">${icon('alert', 17)}<div><strong>Signup spike:</strong> ${Number(insights.signup_spike.today)} new accounts today vs 7-day average ${Number(insights.signup_spike.avg7)}. Review the newest accounts before payouts.</div></div>` : ''}
          ${missing ? '<p class="small muted">Install the insights migration to see this section with live data.</p>' : ''}
          ${!(insights?.risky_workers || []).length && !(insights?.duplicate_proofs || []).length && !(insights?.fast_proofs || []).length && !missing ? '<p class="small muted">No suspicious patterns right now. The scan reruns every time you open this page.</p>' : ''}
        </div>
      </div>

      <div class="col" style="gap:14px">
        <div class="card">
          <div class="card-head"><h3>Pending review summary</h3><a class="small brand-text" href="#/admin/proofs">Open queue</a></div>
          <div class="card-body">
            ${(snapshot?.pending_proofs || []).length ? `<div class="list">${(snapshot.pending_proofs || []).slice(0, 6).map((p) => `
              <div class="list-row">
                <span class="empty-ic" style="width:30px;height:30px;margin:0;border-radius:9px">${platformIcon(p.platform, 14)}</span>
                <div class="list-main"><div class="list-title truncate">${esc(p.campaign)}</div><div class="list-sub">${esc(p.worker)} · ${esc(usdt(p.reward))} USDT · ${esc(ago(p.created_at))}</div></div>
                ${p.duplicate_hash ? '<span class="badge red">Dup</span>' : ''}
              </div>`).join('')}</div>` : '<p class="small muted">Proof queue is clear.</p>'}
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>AI proof verification</h3><span class="badge ${aiConfigured ? 'green' : 'grey'}">${aiConfigured ? 'Enabled' : 'Not enabled'}</span></div>
          <div class="card-body">
            <p class="small muted" style="line-height:1.7">The server-side AI screenshot checker runs through Supabase Vault keys (<span class="mono">ai_verify_key</span>) and never auto-approves: approval needs verdict + confidence ≥ threshold + a concrete reason; everything else routes to a human. Configure it with <span class="mono">supabase/ai-screenshot-verification.sql</span> and the settings listed on the AI assistant page. AI verdicts appear on each proof card once submissions flow through the queue.</p>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Daily report</h3><span class="badge grey">Computed</span></div>
          <div class="card-body">
            <pre class="mono-box" style="white-space:pre-wrap;max-height:300px;overflow:auto">${esc(report)}</pre>
            <p class="tiny dim mt-10">Generated from the snapshot and insights above — real rows, no model output.</p>
          </div>
        </div>
      </div>
    </div>`;

  root.querySelector('[data-copy-report]').addEventListener('click', async (e) => {
    const ok = await copyText(report);
    toast(ok ? 'Daily report copied.' : 'Copy failed.', ok ? 'success' : 'error');
  });
  root.querySelector('[data-refresh]').addEventListener('click', () => renderAdminAIInsights(root));
}

/* ================================================ SMM SERVICES (catalogue) === */
/* The buyer SMM panel lists every services row with is_smm + smm_active and
   archived_at is null (smm_list_services). This page is the only place those
   rows can be created or changed: admin_upsert_smm_service / admin_upsert_smm_category
   / admin_smm_services / admin_smm_categories_list / admin_smm_stats, all
   SECURITY DEFINER RPCs from supabase/smm-orders.sql. Campaign services
   (is_smm = false) are managed on "Services & pricing" and never appear here. */

const SMM_PLATFORMS_ADMIN = ['telegram', 'x', 'tiktok', 'instagram', 'facebook', 'youtube', 'threads'];

/* platformMeta() has no entry for 'threads' and would fall back to "Website";
   the RPC accepts 'threads', so label it properly here. */
function smmPlatformLabel(p) {
  if (String(p) === 'threads') return 'Threads';
  return platformMeta(p).label;
}

export async function renderAdminSmmServices(root) {
  const canEdit = allowed(['OWNER', 'SUPER_ADMIN', 'ADMIN']);
  let search = '';
  let platform = '';
  let offset = 0;
  const limit = 50;
  let items = [];
  let total = 0;
  let categories = [];
  let stats = null;

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">SMM panel</span><h2>SMM services</h2><p>The catalogue buyers see at SMM → Services. Every row here is charged in USDT and delivered to your specification — nothing is fetched from a reseller API.</p></div>
      <div class="row-wrap">
        <button class="btn btn-ghost btn-sm" type="button" data-refresh>${icon('refresh', 14)} Refresh</button>
        ${canEdit ? `<button class="btn btn-soft btn-sm" type="button" data-new-category>${icon('layers', 14)} New category</button>
        <button class="btn btn-primary btn-sm" type="button" data-new>${icon('plus', 14)} New service</button>` : '<span class="badge grey">Read only</span>'}
      </div>
    </div>
    <div id="smms-stats" class="kpis mt-14">${loadingBlock('Loading catalogue stats')}</div>
    <div class="card mt-14"><div class="card-body">
      <div class="row-wrap" style="gap:10px">
        <div class="input-group" style="flex:1;min-width:200px">${icon('search', 16)}<input class="input input-icon" id="smms-q" placeholder="Search by service name" autocomplete="off" /></div>
        <select class="select input-sm" id="smms-platform" style="max-width:180px">
          <option value="">All platforms</option>
          ${SMM_PLATFORMS_ADMIN.map((p) => `<option value="${p}">${esc(smmPlatformLabel(p))}</option>`).join('')}
        </select>
        <button class="btn btn-soft btn-sm" type="button" id="smms-go">Search</button>
      </div>
      <div id="smms-list" class="mt-14">${loadingBlock('Loading SMM services')}</div>
      <div class="center mt-10"><button class="btn btn-ghost hide" id="smms-more" type="button">Load more</button></div>
    </div></div>
    <div class="card mt-14"><div class="card-head"><h3>Categories</h3>${canEdit ? '<button class="btn btn-ghost btn-sm" type="button" data-new-category-2>Add category</button>' : ''}</div>
      <div class="card-body" id="smms-cats">${loadingBlock('Loading categories')}</div>
    </div>
    <div class="card mt-14"><div class="card-head"><h3>Buyer diagnostics</h3><span class="badge grey">Read-only</span></div>
      <div class="card-body">
        <p class="small muted" style="line-height:1.7">If the buyer Services list is empty or placing an order shows a database error, fix it from here in two steps. <strong>1.</strong> Run <span class="mono">supabase/smm-orders-repair.sql</span> in the Supabase SQL editor — it re-deploys the buyer SMM RPCs additively and idempotently (no data touched) and reloads the PostgREST schema cache itself. <strong>2.</strong> If the list is still empty, the catalogue itself has no active services — create real ones above. <span class="mono">supabase/smm-buyer-diagnostics.sql</span> is a read-only companion that prints a VERDICT naming the exact cause.</p>
        <div class="row-wrap mt-10">
          <button class="btn btn-primary btn-sm" type="button" data-copy-repair>${icon('copy', 14)} Copy repair SQL</button>
          <button class="btn btn-soft btn-sm" type="button" data-copy-diagnostics>${icon('copy', 14)} Copy diagnostics SQL</button>
        </div>
        <p class="tiny dim mt-10">If the copy buttons cannot fetch the files from the site, open them in the project (<span class="mono">supabase/</span>) and paste manually.</p>
      </div>
    </div>`;

  const statsEl = root.querySelector('#smms-stats');
  const listEl = root.querySelector('#smms-list');
  const moreBtn = root.querySelector('#smms-more');
  const catsEl = root.querySelector('#smms-cats');

  const paintStats = () => {
    if (!stats) {
      statsEl.innerHTML = '<div class="alert warn mt-0" style="margin-bottom:0">' + icon('alert', 16) + '<div>Stats are unavailable (admin_smm_stats failed). The list below still works.</div></div>';
      return;
    }
    statsEl.innerHTML = `
      ${kpi({ label: 'Services', value: Number(stats.services || 0), iconName: 'layers', tone: 'blue', foot: `${Number(stats.active_services || 0)} live for buyers` })}
      ${kpi({ label: 'Categories', value: Number(stats.categories || 0), iconName: 'grid', tone: 'violet', foot: 'Shown as filters on the buyer page' })}
      ${kpi({ label: 'Orders', value: Number(stats.orders || 0), iconName: 'book', tone: 'gold', foot: `${Number(stats.pending || 0)} pending` })}
      ${kpi({ label: 'Cost price set', value: Number(stats.cost_configured || 0), iconName: 'trending', tone: 'green', foot: `Revenue ${esc(usdt(stats.revenue))} USDT` })}`;
  };

  const paintCats = () => {
    if (!categories.length) {
      catsEl.innerHTML = '<p class="small muted">No categories yet. Categories are optional — a service without one still appears in the catalogue — but they give buyers handy filters.</p>';
      return;
    }
    catsEl.innerHTML = `<div class="list">${categories.map((c) => `
      <div class="list-row">
        <span class="empty-ic" style="width:30px;height:30px;margin:0;border-radius:9px">${platformIcon(c.platform, 14)}</span>
        <div class="list-main">
          <div class="list-title">${esc(c.name)} <span class="badge grey">${esc(smmPlatformLabel(c.platform))}</span></div>
          <div class="list-sub">${Number(c.services || 0)} service(s)${c.icon ? ` · icon ${esc(c.icon)}` : ''}</div>
        </div>
        ${c.is_active ? '<span class="badge green">Active</span>' : '<span class="badge grey">Hidden</span>'}
        ${canEdit ? `<button class="btn btn-soft btn-sm" type="button" data-edit-cat="${esc(c.id)}">Edit</button>` : ''}
      </div>`).join('')}</div>`;

    catsEl.querySelectorAll('[data-edit-cat]').forEach((b) => b.addEventListener('click', () => {
      const c = categories.find((x) => x.id === b.dataset.editCat);
      if (c) categoryModal(c);
    }));
  };

  const paint = () => {
    const rows = items.map((s) => {
      const cat = categories.find((c) => c.id === s.category_id);
      const status = s.archived_at
        ? '<span class="badge grey">Archived</span>'
        : s.smm_active ? '<span class="badge green">Live</span>' : '<span class="badge gold">Paused</span>';
      return `<tr>
        <td data-label="Service"><div class="row" style="gap:8px">${platformIcon(s.platform, 15)}<div><div>${esc(s.name)} <span class="mono tiny dim">#${esc(s.short_id || '')}</span></div><div class="tiny dim truncate">${esc(s.description || '')}</div></div></div></td>
        <td data-label="Platform"><span class="badge grey">${esc(smmPlatformLabel(s.platform))}</span>${cat ? ` <span class="badge grey">${esc(cat.name)}</span>` : ''}</td>
        <td data-label="Rate">${esc(usdt(s.rate_per_1000))}<span class="tiny dim">/1K</span>${s.cost_price_per_1000 != null ? `<div class="tiny dim">cost ${esc(usdt(s.cost_price_per_1000))}</div>` : ''}</td>
        <td data-label="Quantity">${Number(s.min_quantity).toLocaleString()}–${Number(s.max_quantity).toLocaleString()}</td>
        <td data-label="Extras">${[s.language, s.estimated_time].filter(Boolean).map((x) => `<span class="badge grey">${esc(x)}</span>`).join(' ') || '<span class="tiny dim">—</span>'}</td>
        <td data-label="Orders">${Number(s.orders_count || 0)}</td>
        <td data-label="Status">${status}</td>
        <td data-label="Actions" class="cell-actions">
          ${canEdit ? `<button class="btn btn-ghost btn-sm" type="button" data-toggle="${esc(s.id)}" ${s.archived_at ? 'disabled title="Restore before pausing"' : ''}>${s.smm_active ? 'Pause' : 'Publish'}</button>
          <button class="btn btn-soft btn-sm" type="button" data-edit="${esc(s.id)}">Edit</button>` : ''}
        </td>
      </tr>`;
    }).join('');

    if (!items.length) {
      listEl.innerHTML = emptyState({
        iconName: 'sliders',
        title: search || platform ? 'Nothing matches' : 'No SMM services yet',
        text: search || platform
          ? 'No service matches this search or platform filter.'
          : 'This is why the buyer SMM panel shows 0: no SMM catalogue rows exist yet. Create the first service (and optionally categories) with the buttons above — the buyer panel lists them immediately.'
      });
      moreBtn.classList.add('hide');
      return;
    }

    listEl.innerHTML = tableHtml(
      ['Service', 'Platform', 'Rate', 'Quantity', 'Extras', 'Orders', 'Status', ''],
      rows
    );

    moreBtn.classList.toggle('hide', items.length >= total);
    moreBtn.textContent = `Load more (${items.length} of ${total})`;
    if (!canEdit) return;

    listEl.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => {
      const s = items.find((x) => x.id === b.dataset.edit);
      if (s) serviceModal(s);
    }));
    listEl.querySelectorAll('[data-toggle]').forEach((b) => b.addEventListener('click', async () => {
      const s = items.find((x) => x.id === b.dataset.toggle);
      if (!s) return;
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_upsert_smm_service', {
          p_payload: {
            id: s.id,
            platform: s.platform,
            name: s.name,
            description: s.description || '',
            category_id: s.category_id || '',
            rate_per_1000: Number(s.rate_per_1000),
            cost_price_per_1000: s.cost_price_per_1000 == null ? '' : String(s.cost_price_per_1000),
            min_quantity: Number(s.min_quantity),
            max_quantity: Number(s.max_quantity),
            language: s.language || '',
            estimated_time: s.estimated_time || '',
            features: Array.isArray(s.features) ? s.features : [],
            smm_active: !s.smm_active
          }
        });
        toast(s.smm_active ? 'Service paused — buyers no longer see it.' : 'Service published — buyers see it now.', 'success');
        await loadAll();
      } catch (e) {
        toast(friendlyError(e), 'error');
        setBusy(b, false);
      }
    }));
  };

  const loadServices = async (reset = true) => {
    if (reset) { offset = 0; listEl.innerHTML = loadingBlock('Loading SMM services'); }
    let res;
    try {
      res = await rpc('admin_smm_services', {
        p_search: search || null,
        p_platform: platform || null,
        p_limit: limit,
        p_offset: offset
      });
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }
    const fresh = res?.items || [];
    total = Number(res?.total || 0);
    items = reset ? fresh : items.concat(fresh);
    offset += fresh.length;
    paint();
  };

  const loadMeta = async () => {
    const [catsRes, statsRes] = await Promise.all([
      rpc('admin_smm_categories_list').then((r) => ({ r })).catch((e) => ({ e })),
      rpc('admin_smm_stats').then((r) => ({ r })).catch((e) => ({ e }))
    ]);
    if (catsRes.r) categories = catsRes.r || [];
    else catsEl.innerHTML = `<div class="alert warn" style="margin-bottom:0">${icon('alert', 16)}<div>Categories could not be loaded: ${esc(friendlyError(catsRes.e))}</div></div>`;
    if (statsRes.r) stats = statsRes.r;
    paintCats();
    paintStats();
  };

  const loadAll = async (reset = true) => {
    await Promise.all([loadServices(reset), loadMeta()]);
  };

  /* --- service modal ----------------------------------------------------- */
  const serviceModal = (s) => {
    const isNew = !s;
    const m = openModal({
      title: isNew ? 'New SMM service' : 'Edit SMM service',
      subtitle: isNew ? 'Buyers see it at SMM → Services as soon as it is live.' : `#${String(s.short_id || '')} ${s.name}`,
      body: `<form id="smms-form" class="col" style="gap:12px">
        <div class="field-row">
          <div class="field"><label class="label">Platform</label>
            <select class="select" name="platform">
              ${SMM_PLATFORMS_ADMIN.map((p) => `<option value="${p}" ${s?.platform === p ? 'selected' : ''}>${esc(smmPlatformLabel(p))}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label class="label">Name</label><input class="input" name="name" required value="${esc(s?.name || '')}" maxlength="120" placeholder="Telegram post views — 30 days" /></div>
        </div>
        <div class="field"><label class="label">Description</label><input class="input" name="description" value="${esc(s?.description || '')}" maxlength="300" placeholder="What the buyer gets" /></div>
        <div class="field-row">
          <div class="field"><label class="label">Category</label>
            <select class="select" name="category_id">
              <option value="">No category</option>
              ${categories.map((c) => `<option value="${esc(c.id)}" ${s?.category_id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label class="label">Sort order</label><input class="input" name="sort_order" type="number" step="1" min="0" value="${s ? Number(s.sort_order || 100) : 100}" /></div>
        </div>
        <div class="field-row">
          <div class="field"><label class="label">Price per 1000 (USDT)</label><input class="input" name="rate_per_1000" type="number" step="0.000001" min="0.000001" required value="${s ? Number(s.rate_per_1000) : ''}" /></div>
          <div class="field"><label class="label">Cost per 1000 (USDT, internal)</label><input class="input" name="cost_price_per_1000" type="number" step="0.000001" min="0" value="${s?.cost_price_per_1000 != null ? Number(s.cost_price_per_1000) : ''}" /></div>
        </div>
        <div class="field-row">
          <div class="field"><label class="label">Minimum quantity</label><input class="input" name="min_quantity" type="number" step="1" min="1" required value="${s ? Number(s.min_quantity) : 100}" /></div>
          <div class="field"><label class="label">Maximum quantity</label><input class="input" name="max_quantity" type="number" step="1" min="1" required value="${s ? Number(s.max_quantity) : 100000}" /></div>
        </div>
        <div class="field-row">
          <div class="field"><label class="label">Language (optional)</label><input class="input" name="language" value="${esc(s?.language || '')}" maxlength="40" placeholder="English" /></div>
          <div class="field"><label class="label">Estimated time (optional)</label><input class="input" name="estimated_time" value="${esc(s?.estimated_time || '')}" maxlength="60" placeholder="0–1 hours" /></div>
        </div>
        <div class="field"><label class="label">Features (one per line, optional)</label><textarea class="input" name="features" rows="3" placeholder="Start 0–10 min${'\n'}No drop">${esc((s?.features || []).map((x) => (typeof x === 'string' ? x : x?.label || '')).join('\n'))}</textarea></div>
        ${isNew ? `
        <div class="field"><label class="label">Visibility</label>
          <select class="select" name="smm_active">
            <option value="true" selected>Live — buyers can order</option>
            <option value="false">Paused — hidden from buyers</option>
          </select>
        </div>` : `
        <div class="field-row">
          <div class="field"><label class="label">Visibility</label>
            <select class="select" name="smm_active">
              <option value="true" ${s?.smm_active ? 'selected' : ''}>Live — buyers can order</option>
              <option value="false" ${!s?.smm_active ? 'selected' : ''}>Paused — hidden from buyers</option>
            </select>
          </div>
          <div class="field"><label class="label">Archive</label>
            <select class="select" name="archived">
              <option value="false" ${!s?.archived_at ? 'selected' : ''}>No — keep in catalogue</option>
              <option value="true" ${s?.archived_at ? 'selected' : ''}>Yes — retire this service</option>
            </select>
          </div>
        </div>`}
        <button class="btn btn-primary" type="submit">${isNew ? 'Create service' : 'Save changes'}</button>
      </form>`
    });

    m.root.querySelector('#smms-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      const featureList = String(fd.get('features') || '').split('\n').map((x) => x.trim()).filter(Boolean);
      const payload = {
        platform: String(fd.get('platform')),
        name: String(fd.get('name')).trim(),
        description: String(fd.get('description') || '').trim(),
        category_id: String(fd.get('category_id') || ''),
        sort_order: Number(fd.get('sort_order') || 100),
        rate_per_1000: Number(fd.get('rate_per_1000')),
        cost_price_per_1000: String(fd.get('cost_price_per_1000') || '').trim(),
        min_quantity: Number(fd.get('min_quantity')),
        max_quantity: Number(fd.get('max_quantity')),
        language: String(fd.get('language') || '').trim(),
        estimated_time: String(fd.get('estimated_time') || '').trim(),
        features: featureList,
        smm_active: String(fd.get('smm_active') || 'true') === 'true'
      };
      if (!isNew) {
        payload.id = s.id;
        payload.archived = String(fd.get('archived') || 'false') === 'true';
      }
      if (!(payload.rate_per_1000 > 0)) return toast('Price per 1000 must be greater than 0.', 'error');
      if (payload.max_quantity < payload.min_quantity) return toast('Max quantity must be greater than min quantity.', 'error');

      const btn = e.currentTarget.querySelector('button[type=submit]');
      setBusy(btn, true, 'Saving');
      try {
        await rpc('admin_upsert_smm_service', { p_payload: payload });
        toast(isNew ? 'SMM service created — buyers see it immediately.' : 'SMM service updated.', 'success');
        m.close();
        await loadAll();
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(btn, false);
      }
    });
  };

  /* --- category modal ---------------------------------------------------- */
  const categoryModal = (c) => {
    const isNew = !c;
    const m = openModal({
      title: isNew ? 'New SMM category' : 'Edit SMM category',
      subtitle: 'Categories are the filter list buyers see above the catalogue.',
      body: `<form id="smms-cat-form" class="col" style="gap:12px">
        <div class="field-row">
          <div class="field"><label class="label">Platform</label>
            <select class="select" name="platform">
              ${SMM_PLATFORMS_ADMIN.map((p) => `<option value="${p}" ${c?.platform === p ? 'selected' : ''}>${esc(smmPlatformLabel(p))}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label class="label">Name</label><input class="input" name="name" required value="${esc(c?.name || '')}" maxlength="80" placeholder="Telegram — Views" /></div>
        </div>
        <div class="field-row">
          <div class="field"><label class="label">Icon (optional)</label><input class="input" name="icon" value="${esc(c?.icon || '')}" maxlength="24" /></div>
          <div class="field"><label class="label">Sort order</label><input class="input" name="sort_order" type="number" step="1" min="0" value="${c ? Number(c.sort_order || 100) : 100}" /></div>
        </div>
        <div class="field"><label class="label">Visibility</label>
          <select class="select" name="is_active">
            <option value="true" ${!c || c.is_active ? 'selected' : ''}>Active — shown to buyers</option>
            <option value="false" ${c && !c.is_active ? 'selected' : ''}>Hidden</option>
          </select>
        </div>
        <button class="btn btn-primary" type="submit">${isNew ? 'Create category' : 'Save changes'}</button>
      </form>`
    });

    m.root.querySelector('#smms-cat-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      const payload = {
        platform: String(fd.get('platform')),
        name: String(fd.get('name')).trim(),
        icon: String(fd.get('icon') || '').trim(),
        sort_order: Number(fd.get('sort_order') || 100),
        is_active: String(fd.get('is_active')) === 'true'
      };
      if (!isNew) payload.id = c.id;
      const btn = e.currentTarget.querySelector('button[type=submit]');
      setBusy(btn, true, 'Saving');
      try {
        await rpc('admin_upsert_smm_category', { p_payload: payload });
        toast(isNew ? 'Category created.' : 'Category updated.', 'success');
        m.close();
        await loadAll();
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(btn, false);
      }
    });
  };

  /* --- wiring ------------------------------------------------------------ */
  const qInput = root.querySelector('#smms-q');
  const platformSel = root.querySelector('#smms-platform');
  const runSearch = () => { search = qInput.value.trim(); platform = platformSel.value; loadServices(true); };
  root.querySelector('#smms-go').addEventListener('click', runSearch);
  qInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); runSearch(); } });
  platformSel.addEventListener('change', runSearch);
  moreBtn.addEventListener('click', () => loadServices(false));
  const refreshBtn = root.querySelector('[data-refresh]');
  if (refreshBtn) refreshBtn.addEventListener('click', () => renderAdminSmmServices(root));
  root.querySelectorAll('[data-new]').forEach((b) => b.addEventListener('click', () => serviceModal(null)));
  root.querySelectorAll('[data-new-category], [data-new-category-2]').forEach((b) => b.addEventListener('click', () => categoryModal(null)));

  /* One-tap copy of the repair and diagnostics SQL for the Supabase SQL editor.
     Both files ship with the site (plain hosting serves every folder), so a
     plain fetch is enough; the card also names the paths as a manual fallback. */
  const copyFileSQL = async (btn, path, doneMsg) => {
    setBusy(btn, true, 'Copying');
    try {
      const res = await fetch(path + '?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) throw new Error(`The file ${path} is not reachable from the site — copy it from the project instead.`);
      const ok = await copyText(await res.text());
      toast(ok ? doneMsg : 'Copy failed — copy the file manually from the project.', ok ? 'success' : 'error');
    } catch (err) {
      toast(err.message || 'Copy failed.', 'error', 8000);
    } finally {
      setBusy(btn, false);
    }
  };
  const copyRepair = root.querySelector('[data-copy-repair]');
  if (copyRepair) copyRepair.addEventListener('click', () =>
    copyFileSQL(copyRepair, '/supabase/smm-orders-repair.sql', 'Repair SQL copied — paste it into the Supabase SQL editor and run it once. It is additive and idempotent.'));
  const copyDiag = root.querySelector('[data-copy-diagnostics]');
  if (copyDiag) copyDiag.addEventListener('click', () =>
    copyFileSQL(copyDiag, '/supabase/smm-buyer-diagnostics.sql', 'Diagnostics SQL copied — paste it into the Supabase SQL editor and read the VERDICT in Messages.'));

  await loadAll();
}