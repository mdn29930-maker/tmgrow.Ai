/* Wallet screens: deposit with live on-chain verification, withdraw,
   transaction history and linked-account management. */

import { sb, rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import { state, loadContext, withdrawalMin, settingText, settingNumber } from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, usdt, ago, shortDate, dateTime, statusBadge, toast, openModal,
  confirmDialog, loadingBlock, emptyState, errorPanel, setBusy, copyText, avatarHTML,
  platformMeta, platformIcon
} from '../lib/ui.js?v=2025-10-12-39';
import { CONFIG } from '../config.js?v=2025-10-12-39';
import { verifyUsdtDeposit } from '../lib/bsc.js?v=2025-10-12-39';

const KIND_LABEL = {
  task_pending: 'Reward pending review',
  task_reward: 'Task reward released',
  task_refund: 'Pending reward reversed',
  escrow_release: 'Campaign escrow released',
  escrow_return: 'Campaign escrow returned',
  campaign_funding: 'Campaign funded',
  campaign_refund: 'Campaign escrow refunded',
  deposit: 'Deposit credited',
  withdrawal_hold: 'Withdrawal requested',
  withdrawal_paid: 'Withdrawal paid',
  withdrawal_refund: 'Withdrawal refunded',
  referral_bonus: 'Referral commission',
  admin_adjustment: 'Balance adjustment'
};

function kpi({ label, value, suffix = '', foot = '', iconName = 'chart', tone = '' }) {
  return `<div class="kpi ${tone}">
    <div class="kpi-top">
      <div class="kpi-label">${esc(label)}</div>
      <span class="kpi-ic">${icon(iconName, 16)}</span>
    </div>
    <div class="kpi-num">${value}${suffix ? `<small>${esc(suffix)}</small>` : ''}</div>
    ${foot ? `<div class="kpi-foot">${foot}</div>` : ''}
  </div>`;
}

function txAmount(entry) {
  const a = Number(entry.available_delta || 0);
  const p = Number(entry.pending_delta || 0);
  const r = Number(entry.reserved_delta || 0);
  const pick = a !== 0 ? a : p !== 0 ? p : r;
  const positive = pick >= 0;
  return `<span class="list-amount ${positive ? 'green' : 'red'}">${positive ? '+' : ''}${esc(usdt(pick))}</span>`;
}

/* ================================================================= DEPOSIT === */
export async function renderDeposit(root) {
  await loadContext().catch(() => {});
  root.innerHTML = loadingBlock('Loading deposit details');

  /* One authoritative limit: the same value the server enforces. Reading it
     from public settings can diverge if the setting was saved as private. */
  let limits = null;
  try { limits = await rpc('deposit_limits'); } catch (_) { limits = null; }

  const address = String(limits?.deposit_address || settingText('deposit_address', '') || CONFIG.depositAddress).trim();
  const min = Number(limits?.min_amount ?? settingNumber('min_deposit', 5));
  const w = state.wallet || {};

  const depRes = await sb.from('deposits')
    .select('id,amount,method,tx_hash,status,admin_note,created_at,verified_at,confirmations,from_address')
    .order('created_at', { ascending: false })
    .limit(10);
  const deposits = depRes.error ? [] : (depRes.data || []);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Wallet</span><h2>Deposit USDT</h2><p>Send on BNB Smart Chain (BEP-20), then confirm the transaction and the app checks it on-chain.</p></div>
      <a class="btn btn-ghost" href="#/withdraw">${icon('arrowUpRight', 15)} Withdraw</a>
    </div>

    <div class="kpis">
      ${kpi({ label: 'Available', value: esc(usdt(w.available)), suffix: 'USDT', iconName: 'wallet', tone: 'green', foot: 'Spendable now' })}
      ${kpi({ label: 'Pending', value: esc(usdt(w.pending)), suffix: 'USDT', iconName: 'clock', tone: 'gold', foot: 'Awaiting review' })}
      ${kpi({ label: 'Deposited', value: esc(usdt(w.lifetime_deposited)), suffix: 'USDT', iconName: 'download', tone: 'blue', foot: 'Verified deposits' })}
      ${kpi({ label: 'Minimum', value: esc(usdt(min)), suffix: 'USDT', iconName: 'info', tone: 'violet', foot: 'Per deposit' })}
    </div>

    <div class="grid grid-2 mt-24" style="align-items:start">
      <div class="col" style="gap:14px">
        <div class="card card-pad">
          <div class="row-between mb-10"><h3 style="font-size:14px">Your deposit address</h3><span class="badge gold">BEP-20</span></div>
          <div class="row" style="gap:8px">
            <span class="mono-box" style="flex:1;font-size:12px" data-deposit-address>${esc(address)}</span>
            <button class="btn btn-soft btn-sm" type="button" data-copy-address>${icon('copy', 14)} Copy</button>
          </div>
          <div class="alert warn mt-14">${icon('alert', 17)}<div>Send <strong>USDT on BNB Smart Chain (BEP-20)</strong> only. Another network or another token is lost forever and cannot be refunded.</div></div>
          <div class="step-list mt-14">
            <div class="step"><span class="sn">1</span><span>Copy the address and send at least ${esc(usdt(min))} USDT from your wallet or exchange.</span></div>
            <div class="step"><span class="sn">2</span><span>Copy the transaction hash (0x…) from your wallet or BscScan.</span></div>
            <div class="step"><span class="sn">3</span><span>Enter the amount and hash below, then press Confirm payment.</span></div>
            <div class="step"><span class="sn">4</span><span>The app reads the transaction from BNB Smart Chain. Once it is confirmed, the balance is credited automatically.</span></div>
          </div>
        </div>

        <div class="card card-pad">
          <h3 style="font-size:14px" class="mb-10">Recent deposits</h3>
          ${deposits.length ? `<div class="list">${deposits.map((d) => `
            <div class="list-row" style="align-items:flex-start">
              <div class="list-main">
                <div class="row" style="gap:8px"><span class="list-title">${esc(usdt(d.amount))} USDT</span>${statusBadge(d.status)}</div>
                <div class="list-sub">${esc(ago(d.created_at))}${d.verified_at ? ' · verified on-chain' : ''}</div>
                ${d.tx_hash ? `<a class="tiny blue mono truncate mt-6" style="display:block" href="https://bscscan.com/tx/${esc(d.tx_hash)}" target="_blank" rel="noopener noreferrer">${esc(d.tx_hash)}</a>` : ''}
                ${d.admin_note ? `<div class="tiny dim mt-6">${esc(d.admin_note)}</div>` : ''}
              </div>
            </div>`).join('')}</div>` : '<p class="small muted">No deposits yet.</p>'}
        </div>
      </div>

      <div class="card card-pad">
        <h3 style="font-size:14px" class="mb-10">Confirm your payment</h3>
        <form id="dep-form" class="col" style="gap:13px">
          <div class="field">
            <label class="label">Amount sent (USDT)</label>
            <input class="input" id="dep-amount" type="number" min="${esc(min)}" step="0.000001" required placeholder="${esc(usdt(min))}" />
            <span class="hint">The verified on-chain amount is what gets credited, not this entry.</span>
          </div>
          <div class="field">
            <label class="label">Transaction hash</label>
            <input class="input mono" id="dep-hash" placeholder="0x…" autocomplete="off" required />
            <span class="hint">0x followed by 64 characters. Copy it from your wallet or BscScan.</span>
          </div>
          <button class="btn btn-primary btn-lg" type="submit" id="dep-submit">${icon('shield', 17)} Confirm payment</button>
        </form>
        <div id="dep-state" class="mt-14"></div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Verification reads the real BNB Smart Chain receipt: token contract, recipient address, amount, success status and ${Number(CONFIG.depositConfirmations)} confirmations. Unverified transactions are never credited.</div></div>
      </div>
    </div>`;

  const copyBtn = root.querySelector('[data-copy-address]');
  if (copyBtn) copyBtn.addEventListener('click', async () => {
    const ok = await copyText(address);
    toast(ok ? 'Deposit address copied.' : 'Copy failed.', ok ? 'success' : 'error');
  });

  const form = root.querySelector('#dep-form');
  const stateEl = root.querySelector('#dep-state');
  const submitBtn = root.querySelector('#dep-submit');

  const paintSteps = (steps, tone) => (steps || []).map((s) => `
    <div class="row" style="gap:9px;align-items:flex-start;margin-top:7px">
      <span style="color:${s.ok ? 'var(--green)' : 'var(--dim)'};flex:none">${icon(s.ok ? 'checkCircle' : 'clock', 15)}</span>
      <div style="min-width:0">
        <div class="small ${tone === 'error' && !s.ok ? 'red' : ''}">${esc(s.label)}</div>
        ${s.detail ? `<div class="tiny dim">${esc(s.detail)}</div>` : ''}
      </div>
    </div>`).join('');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const amount = Number(root.querySelector('#dep-amount').value);
    const hash = root.querySelector('#dep-hash').value.trim();
    if (!Number.isFinite(amount) || amount < min) return toast(`Minimum deposit is ${usdt(min)} USDT.`, 'error');
    if (!/^0x[a-fA-F0-9]{64}$/.test(hash)) return toast('Transaction hash must be 0x + 64 hex characters.', 'error');

    setBusy(submitBtn, true, 'Checking chain');
    stateEl.innerHTML = `<div class="card card-pad" style="background:var(--surface-2)">
      <div class="row" style="gap:10px"><span class="spinner"></span><div>
        <div class="strong">Checking BNB Smart Chain…</div>
        <div class="small muted">Reading the transaction receipt from a public BSC node.</div>
      </div></div>
      <div class="tiny dim mt-10">This usually takes a few seconds.</div>
    </div>`;

    try {
      const v = await verifyUsdtDeposit(hash, { address });

      /* Exact stage values, visible in the console for support. No secrets. */
      console.info('[tmgrow:deposit]', {
        txHash: v.txHash, chainAmount: v.amount, matchedTransfers: v.matchedTransfers,
        confirmations: v.confirmations, uiMinimum: min, depositAddress: address
      });

      if (!Number.isFinite(v.amount) || v.amount <= 0) {
        stateEl.innerHTML = `<div class="card card-pad" style="border-color:rgba(255,84,104,.3)">
          ${errorPanel('The USDT amount in this transaction could not be read correctly. Nothing was credited. Contact support with the transaction hash.')}
          ${paintSteps(v.steps, 'error')}
        </div>`;
        setBusy(submitBtn, false);
        return;
      }

      if (!v.enoughConfirmations) {
        stateEl.innerHTML = `<div class="card card-pad" style="background:var(--surface-2)">
          <div class="strong">Waiting for confirmations</div>
          <p class="small muted mt-6">The transfer is on-chain with ${v.confirmations} of ${Number(CONFIG.depositConfirmations)} confirmations and ${esc(usdt(v.amount))} USDT verified. Wait a moment, then press Confirm payment again.</p>
          ${paintSteps(v.steps, 'info')}
        </div>`;
        setBusy(submitBtn, false);
        return;
      }

      const res = await rpc('submit_verified_deposit', {
        p_tx_hash: v.txHash,
        p_amount: v.amount,
        p_from_address: v.from,
        p_block: v.block,
        p_confirmations: v.confirmations
      });

      await loadContext().catch(() => {});
      toast(`${usdt(v.amount)} USDT verified and credited.`, 'success', 6000);
      stateEl.innerHTML = `<div class="card card-pad" style="border-color:rgba(34,197,138,.35)">
        <div class="row" style="gap:8px;color:var(--green)">${icon('checkCircle', 17)}<span class="strong">Payment verified and credited</span></div>
        <p class="small muted mt-6">${esc(usdt(v.amount))} USDT from ${esc(v.from.slice(0, 8))}… is now in your available balance.</p>
        ${paintSteps(v.steps, 'success')}
        <a class="btn btn-soft btn-sm mt-14" href="#/withdraw">Go to withdraw</a>
      </div>`;
      setBusy(submitBtn, false);
      setTimeout(() => { renderDeposit(root); }, 2500);
    } catch (err) {
      stateEl.innerHTML = `<div class="card card-pad" style="border-color:rgba(255,84,104,.3)">
        ${errorPanel(friendlyError(err))}
        ${paintSteps(err.steps, 'error')}
      </div>`;
      setBusy(submitBtn, false);
    }
  });
}

/* ================================================================ WITHDRAW === */
export async function renderWithdraw(root) {
  await loadContext().catch(() => {});
  const w = state.wallet || {};
  const min = withdrawalMin();
  const feePct = settingNumber('withdrawal_fee_pct', 5);
  const feeFreeMin = settingNumber('withdrawal_fee_free_min', 5);
  const feeFor = (amount) => (amount >= feeFreeMin ? 0 : Math.round(amount * feePct) / 100);
  const networkName = settingText('network_name', CONFIG.networkName);

  const wdRes = await sb.from('withdrawals')
    .select('id,amount,fee,net_amount,network,address,status,tx_hash,admin_note,created_at,processed_at')
    .order('created_at', { ascending: false })
    .limit(15);
  const withdrawals = wdRes.error ? [] : (wdRes.data || []);

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Payouts</span><h2>Wallet</h2><p>USDT payouts on BNB Smart Chain (BEP-20). Reviewed by finance, then sent to your address.</p></div>
      <a class="btn btn-ghost" href="#/deposit">${icon('download', 15)} Deposit</a>
    </div>

    <div class="row-between mb-16" style="gap:10px">
      <div class="mode-switch">
        <button class="mode-btn active" type="button">Worker</button>
        <a class="mode-btn" href="${state.profile?.is_buyer ? '#/buyer/wallet' : '#/buyer'}">Buyer</a>
      </div>
      <span class="tiny dim">Worker wallet · earnings and withdrawals</span>
    </div>

    <div class="card card-pad" style="background:radial-gradient(circle at 12% 0%, rgba(255,122,24,.22), transparent 55%), var(--surface);border-color:rgba(255,122,24,.25)">
      <div class="row-between" style="align-items:flex-end;flex-wrap:wrap;gap:14px">
        <div>
          <div class="kpi-label">Available to withdraw</div>
          <div style="font-size:34px;font-weight:800;letter-spacing:-1.4px;margin-top:4px">${esc(usdt(w.available))} <span class="small muted">USDT</span></div>
          <div class="small muted mt-6">Held in payouts: ${esc(usdt(w.reserved))} USDT · Lifetime withdrawn: ${esc(usdt(w.lifetime_withdrawn))} USDT</div>
        </div>
        <div class="row" style="gap:8px">
          <a class="btn btn-ghost btn-sm" href="#/history">${icon('book', 15)} History</a>
          <a class="btn btn-soft btn-sm" href="#/tasks">${icon('tasks', 15)} Earn more</a>
        </div>
      </div>
    </div>

    <div class="tabs" id="wd-tabs" style="margin-bottom:14px;max-width:420px">
      <button class="tab active" type="button" data-wd-tab="withdraw">Withdraw</button>
      <button class="tab" type="button" data-wd-tab="history">History <span class="count">${withdrawals.length}</span></button>
    </div>

    <div class="col" style="gap:14px">
      <div class="card card-pad" data-wd-panel="withdraw">
        <h3 style="font-size:14px" class="mb-10">New withdrawal</h3>
        <form id="wd-form" class="col" style="gap:14px">
          <div class="field">
            <label class="label">Amount (USDT)</label>
            <div class="row" style="gap:8px">
              <input class="input" id="wd-amount" type="number" min="${esc(min)}" step="0.000001" max="${esc(Number(w.available || 0))}" placeholder="${esc(usdt(min))}" required />
              <button class="btn btn-ghost btn-sm" type="button" data-max>MAX</button>
            </div>
            <span class="hint">Minimum ${esc(usdt(min))} USDT · Available ${esc(usdt(w.available))} USDT</span>
          </div>

          <div class="field">
            <label class="label">Network</label>
            <div class="panel panel-pad row" style="gap:10px;align-items:center">
              <span class="task-ic" style="width:34px;height:34px;background:linear-gradient(140deg,#f3ba2f,#b8860b);color:#fff">${icon('coin', 16)}</span>
              <div style="flex:1"><div class="strong small">USDT · BEP-20</div><div class="tiny dim">${esc(networkName)}</div></div>
              <span class="badge green">Selected</span>
            </div>
          </div>

          <div class="field">
            <label class="label">USDT receiving address</label>
            <input class="input mono" id="wd-address" placeholder="0x…" pattern="^0x[a-fA-F0-9]{40}$" required />
            <span class="hint">Enter your USDT receiving address on the BSC (BEP20) network. Blockchain transfers cannot be reversed.</span>
            ${withdrawals[0]?.address ? `<div class="row-between tiny mt-6"><span class="muted">Last used: <span class="mono">${esc(withdrawals[0].address.slice(0, 10))}…${esc(withdrawals[0].address.slice(-6))}</span></span><button class="btn btn-ghost btn-sm" type="button" data-use-address>Use</button></div>` : ''}
          </div>

          <div class="panel panel-pad">
            <div class="row-between small"><span class="muted">Fee (${esc(String(feePct))}% under ${esc(usdt(feeFreeMin))} USDT)</span><span id="wd-fee">0.00 USDT</span></div>
            <div class="row-between small mt-6"><span class="muted">You receive</span><span class="strong green" id="wd-net">0.00 USDT</span></div>
            <div class="row-between small mt-6"><span class="muted">Requested amount</span><span id="wd-gross">0.00 USDT</span></div>
            <button class="btn btn-ghost btn-sm btn-block mt-10" type="button" data-fee-rules>${icon('info', 14)} Fee rules</button>
          </div>

          <div class="alert info">${icon('info', 17)}<div>Minimum ${esc(usdt(min))} USDT. ${Number(w.available || 0) >= feeFreeMin ? 'This withdrawal is fee-free.' : `${esc(usdt(Math.max(0, feeFreeMin - Number(w.available || 0))))} USDT more in your balance to reach the fee-free level.`}</div></div>

          <button class="btn btn-primary btn-lg" type="submit" id="wd-submit">${icon('arrowUpRight', 16)} Request withdrawal</button>
          <p class="hint">The amount is held as soon as you request it. Finance approves and pays it from the platform wallet, then the real transaction hash appears in your history.</p>
        </form>
      </div>

      <div class="card" data-wd-panel="history" hidden>
        <div class="card-head"><h3>Withdrawal history</h3><span class="badge grey">${withdrawals.length}</span></div>
        <div class="card-body">
          ${withdrawals.length ? `<div class="list">${withdrawals.map((x) => {
            const order = ['pending', 'approved', 'processing', 'paid'];
            const idx = order.indexOf(x.status);
            const steps = order.map((s, i) => `<span class="badge ${x.status === 'rejected' ? (i === 0 ? 'red' : 'grey') : (i <= idx ? 'green' : 'grey')}" style="font-size:10px">${s}</span>`).join('');
            return `<div class="list-row" style="align-items:flex-start">
              <div class="list-main">
                <div class="row" style="gap:8px"><span class="list-title">${esc(usdt(x.amount))} USDT</span><span class="badge ${x.status === 'paid' ? 'green' : x.status === 'rejected' ? 'red' : 'gold'}">${x.status === 'paid' ? 'Completed' : x.status === 'rejected' ? 'Rejected' : 'Waiting'}</span></div>
                <div class="list-sub mono truncate">${esc(x.address)}</div>
                <div class="tiny dim mt-6">${esc(ago(x.created_at))}${Number(x.fee) > 0 ? ` · fee ${esc(usdt(x.fee))} USDT · net ${esc(usdt(x.net_amount))} USDT` : ''}</div>
                <div class="row mt-6" style="gap:4px;flex-wrap:wrap">${steps}</div>
                ${x.admin_note ? `<div class="tiny ${x.status === 'rejected' ? 'red' : 'dim'} mt-6">${esc(x.admin_note)}</div>` : ''}
                ${x.tx_hash ? `<a class="tiny blue mono truncate mt-6" style="display:block" href="https://bscscan.com/tx/${esc(x.tx_hash)}" target="_blank" rel="noopener noreferrer">${esc(x.tx_hash)}</a>` : ''}
              </div>
            </div>`;
          }).join('')}</div>` : emptyState({ iconName: 'wallet', title: 'No withdrawals yet', text: 'Payout requests and their progress appear here.' })}
        </div>
      </div>
    </div>`;

  const amountEl = root.querySelector('#wd-amount');
  const feeEl = root.querySelector('#wd-fee');
  const netEl = root.querySelector('#wd-net');
  const grossEl = root.querySelector('#wd-gross');

  const recalc = () => {
    const amount = Number(amountEl.value || 0);
    const fee = feeFor(amount);
    feeEl.textContent = `${usdt(fee)} USDT`;
    netEl.textContent = `${usdt(Math.max(0, amount - fee))} USDT`;
    grossEl.textContent = `${usdt(amount)} USDT`;
  };
  amountEl.addEventListener('input', recalc);
  recalc();

  root.querySelector('[data-max]').addEventListener('click', () => {
    amountEl.value = Number(w.available || 0).toFixed(6);
    recalc();
  });

  const wdTabs = root.querySelectorAll('[data-wd-tab]');
  const wdPanels = root.querySelectorAll('[data-wd-panel]');
  wdTabs.forEach((t) => t.addEventListener('click', () => {
    const key = t.dataset.wdTab;
    wdTabs.forEach((x) => x.classList.toggle('active', x === t));
    wdPanels.forEach((p) => { p.hidden = p.dataset.wdPanel !== key; });
  }));

  const useAddress = root.querySelector('[data-use-address]');
  if (useAddress) useAddress.addEventListener('click', () => {
    root.querySelector('#wd-address').value = withdrawals[0].address;
    toast('Last payout address filled in.', 'success');
  });

  const feeRules = root.querySelector('[data-fee-rules]');
  if (feeRules) feeRules.addEventListener('click', () => {
    const fm = openModal({
      title: 'Withdrawal fee',
      subtitle: 'The fee is deducted from the amount you withdraw.',
      body: `<div class="grid grid-2" style="gap:10px">
          <div class="panel panel-pad center" style="border-color:${Number(w.available || 0) < feeFreeMin ? 'rgba(255,122,24,.45)' : ''}">
            <div class="small muted">Under ${esc(usdt(feeFreeMin))} USDT</div>
            <div class="strong orange-text" style="color:var(--brand);margin:5px 0">${esc(String(feePct))}% fee</div>
            <div class="tiny dim">Withdraw 2 → receive ${esc(usdt(2 - feeFor(2)))}</div>
          </div>
          <div class="panel panel-pad center" style="border-color:${Number(w.available || 0) >= feeFreeMin ? 'rgba(34,197,138,.45)' : ''}">
            <div class="small muted">${esc(usdt(feeFreeMin))} USDT and above</div>
            <div class="strong" style="margin:5px 0">No fee</div>
            <div class="tiny dim">Withdraw ${esc(usdt(feeFreeMin))} → receive ${esc(usdt(feeFreeMin))}</div>
          </div>
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div>${Number(w.available || 0) >= feeFreeMin
          ? 'Your whole balance is already in the fee-free level.'
          : `${esc(usdt(Math.max(0, feeFreeMin - Number(w.available || 0))))} USDT more to reach the ${esc(usdt(feeFreeMin))} USDT fee-free level.`}</div></div>`,
      footer: '<button class="btn btn-primary" type="button" data-fee-ok>Got it, continue</button>'
    });
    fm.root.querySelector('[data-fee-ok]').onclick = () => fm.close();
  });

  root.querySelector('#wd-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = root.querySelector('#wd-submit');
    const amount = Number(amountEl.value);
    const address = root.querySelector('#wd-address').value.trim();
    const fee = feeFor(amount);

    if (!Number.isFinite(amount) || amount < min) return toast(`Minimum withdrawal is ${usdt(min)} USDT.`, 'error');
    if (amount > Number(w.available || 0)) return toast('Amount exceeds your available balance.', 'error');
    if (!/^0x[a-fA-F0-9]{40}$/.test(address)) return toast('Enter a valid BEP-20 address (0x + 40 hex characters).', 'error');

    const ok = await confirmDialog({
      title: 'Request this withdrawal?',
      message: `${usdt(amount)} USDT leaves your available balance. Fee ${usdt(fee)} USDT, you receive ${usdt(amount - fee)} USDT to ${address.slice(0, 10)}… on BEP-20.${fee === 0 ? ' This amount is fee-free.' : ''}`,
      confirmLabel: 'Request withdrawal'
    });
    if (!ok) return;

    setBusy(btn, true, 'Requesting');
    try {
      await rpc('request_withdrawal', { p_amount: amount, p_address: address, p_network: 'BEP20' });
      toast('Withdrawal requested. The amount is held until finance pays it.', 'success');
      btn.disabled = true;
      btn.textContent = 'Waiting';
      await renderWithdraw(root);
      const fresh = root.querySelector('[data-wd-tab="history"]');
      if (fresh) fresh.click();
    } catch (err) {
      toast(friendlyError(err), 'error', 7000);
      setBusy(btn, false);
    }
  });
}

/* ================================================================= HISTORY === */
export async function renderHistory(root) {
  await loadContext().catch(() => {});
  root.innerHTML = loadingBlock('Loading transactions');

  const [ledgerRes, depRes, wdRes] = await Promise.all([
    sb.from('ledger_entries')
      .select('id,kind,available_delta,pending_delta,reserved_delta,note,created_at')
      .order('created_at', { ascending: false }).limit(80),
    sb.from('deposits')
      .select('id,amount,status,created_at,tx_hash')
      .order('created_at', { ascending: false }).limit(40),
    sb.from('withdrawals')
      .select('id,amount,status,created_at,tx_hash')
      .order('created_at', { ascending: false }).limit(40)
  ]);

  const entries = ledgerRes.error ? [] : (ledgerRes.data || []);
  const deposits = depRes.error ? [] : (depRes.data || []);
  const withdrawals = wdRes.error ? [] : (wdRes.data || []);

  const items = [
    ...entries.map((e) => ({ type: 'ledger', at: e.created_at, title: KIND_LABEL[e.kind] || e.kind, sub: e.note || '', entry: e })),
    ...deposits.map((d) => ({ type: 'deposit', at: d.created_at, title: 'Deposit', sub: d.tx_hash ? `${d.tx_hash.slice(0, 18)}…` : '', amount: Number(d.amount), status: d.status })),
    ...withdrawals.map((x) => ({ type: 'withdrawal', at: x.created_at, title: 'Withdrawal', sub: x.tx_hash ? `${x.tx_hash.slice(0, 18)}…` : '', amount: -Number(x.amount), status: x.status }))
  ].sort((a, b) => new Date(b.at) - new Date(a.at));

  let filter = 'all';

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Wallet</span><h2>Transaction history</h2><p>Every wallet movement, deposit and payout in one place.</p></div>
      <a class="btn btn-ghost" href="#/deposit">${icon('download', 15)} Deposit</a>
    </div>
    <div class="tabs" style="margin-bottom:14px" id="h-tabs">
      ${[['all', 'All'], ['ledger', 'Earnings'], ['deposit', 'Deposits'], ['withdrawal', 'Withdrawals']]
        .map(([v, l]) => `<button class="tab ${v === 'all' ? 'active' : ''}" type="button" data-tab="${v}">${l}</button>`).join('')}
    </div>
    <div class="card"><div class="card-body" id="h-list"></div></div>`;

  const listEl = root.querySelector('#h-list');
  const paint = () => {
    const shown = filter === 'all' ? items : items.filter((i) => i.type === filter);
    listEl.innerHTML = shown.length ? `<div class="list">${shown.map((i) => `
      <div class="list-row">
        <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px${i.type === 'deposit' ? ';color:var(--green)' : i.type === 'withdrawal' ? ';color:var(--blue)' : ''}">${icon(i.type === 'deposit' ? 'download' : i.type === 'withdrawal' ? 'arrowUpRight' : 'coin', 15)}</span>
        <div class="list-main">
          <div class="row" style="gap:8px"><span class="list-title">${esc(i.title)}</span>${i.status ? statusBadge(i.status) : ''}</div>
          <div class="list-sub truncate">${esc(i.sub || '')}${i.sub ? ' · ' : ''}${esc(dateTime(i.at))}</div>
        </div>
        ${i.entry ? txAmount(i.entry) : `<span class="list-amount ${Number(i.amount) >= 0 ? 'green' : 'red'}">${Number(i.amount) >= 0 ? '+' : ''}${esc(usdt(i.amount))}</span>`}
      </div>`).join('')}</div>`
      : emptyState({ iconName: 'book', title: 'Nothing here yet', text: 'Wallet movements appear as soon as money moves.' });
  };

  root.querySelector('#h-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    filter = b.dataset.tab;
    root.querySelectorAll('#h-tabs .tab').forEach((t) => t.classList.toggle('active', t === b));
    paint();
  });

  paint();
}

/* ================================================================ ACCOUNTS === */
function providerRow(provider) {
  const p = String(provider || '').toLowerCase();
  const label = p === 'google' ? 'Google' : p === 'telegram' ? 'Telegram' : p === 'email' ? 'Email & password' : p;
  const file = p === 'google' ? 'google' : p === 'telegram' ? 'telegram' : '';
  const logo = file
    ? `<img class="platform-glyph" src="/assets/logos/${file}.svg" alt="" width="18" height="18" />`
    : icon('mail', 17);
  return { label, logo };
}

export async function renderAccounts(root) {
  await loadContext().catch(() => {});
  const p = state.profile || {};

  let identities = [];
  let identitiesError = '';
  try {
    identities = (await rpc('my_identities')) || [];
  } catch (e) { identitiesError = friendlyError(e); }

  let social = [];
  let socialError = '';
  try {
    social = (await rpc('my_social_accounts')) || [];
  } catch (e) { socialError = friendlyError(e); }

  const linkedPlatforms = new Set(social.map((a) => a.platform));
  const taskPlatforms = ['x', 'youtube', 'instagram', 'tiktok', 'facebook', 'telegram', 'reddit', 'spotify', 'discord'];
  const publicAccounts = social.filter((a) => ['instagram', 'tiktok', 'youtube'].includes(a.platform));

  const PUBLIC_LABEL = {
    NOT_SUBMITTED: ['grey', 'Not checked'],
    CHECKING: ['orange', 'Checking'],
    VERIFIED_PUBLIC_PROFILE: ['green', 'Public profile'],
    NEEDS_MANUAL_REVIEW: ['gold', 'Needs review'],
    REJECTED: ['red', 'Rejected'],
    API_ERROR: ['red', 'API error']
  };

  const publicBadge = (status) => {
    const [tone, label] = PUBLIC_LABEL[status] || PUBLIC_LABEL.NOT_SUBMITTED;
    return `<span class="badge ${tone}">${esc(label)}</span>`;
  };

  const checkProfile = async (accountId, btn) => {
    setBusy(btn, true, 'Checking');
    try {
      const started = await rpc('social_profile_check', { p_account_id: accountId });
      if (!started || started.ok === false) {
        const msg = (started && started.message) || 'The lookup could not start.';
        toast(msg, 'error', 10000);
        await renderAccounts(root);
        return;
      }
      for (let i = 0; i < 30; i += 1) {
        await new Promise((r) => setTimeout(r, 1500));
        const res = await rpc('social_profile_finish', { p_account_id: accountId });
        if (res && res.status && res.status !== 'CHECKING') {
          if (res.status === 'VERIFIED_PUBLIC_PROFILE') toast('Public profile confirmed.', 'success');
          else if (res.status === 'REJECTED') toast(res.message || 'That profile was not found.', 'error', 9000);
          else if (res.status === 'API_ERROR') toast(res.message || 'The lookup service is unavailable.', 'error', 10000);
          else toast(res.message || 'Saved for manual review.', 'info', 8000);
          await renderAccounts(root);
          return;
        }
      }
      toast('Still checking. Open this page again in a moment.', 'info', 7000);
      await renderAccounts(root);
    } catch (err) {
      const raw = String((err && err.message) || '');
      const msg = /Could not find the function|PGRST202|does not exist/i.test(raw)
        ? 'The Socify lookup functions are missing on this database. Run supabase/social-verification-frontend.sql and supabase/socify-fix.sql in the SQL editor, then reload.'
        : friendlyError(err);
      toast(msg, 'error', 12000);
      await renderAccounts(root);
    }
  };

  const providers = new Set(identities.map((i) => String(i.provider).toLowerCase()));

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Account</span><h2>Linked accounts</h2><p>Your name, email and photo come from the account you sign in with.</p></div>
      <a class="btn btn-ghost" href="#/profile">${icon('user', 15)} Profile</a>
    </div>

    <div class="card card-pad">
      <div class="row" style="gap:14px">
        ${avatarHTML(p, 'avatar lg')}
        <div style="min-width:0;flex:1">
          <div class="strong truncate">${esc(p.full_name || 'Worker')}</div>
          <div class="small muted truncate">${esc(p.email || '')}</div>
          <div class="row mt-6" style="gap:6px;flex-wrap:wrap">
            <span class="badge ${p.admin_role ? 'gold' : p.is_buyer ? 'blue' : 'orange'}">${esc(p.admin_role || (p.is_buyer ? 'Buyer' : 'Worker'))}</span>
            <span class="badge grey">Photo syncs automatically</span>
          </div>
        </div>
        <button class="btn btn-soft btn-sm" type="button" data-refresh>${icon('refresh', 14)} Refresh from provider</button>
      </div>
      <p class="hint mt-14">There is no avatar URL field any more. Google and Telegram return your current profile photo on every sign-in and it is copied into your TM GROW profile.</p>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Sign-in methods</h3><span class="badge grey">${identities.length}</span></div>
      <div class="card-body">
        ${identitiesError ? errorPanel(identitiesError) : ''}
        ${identities.length ? `<div class="list">${identities.map((i) => {
          const meta = providerRow(i.provider);
          return `<div class="list-row">
            <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${meta.logo}</span>
            <div class="list-main">
              <div class="list-title">${esc(meta.label)}</div>
              <div class="list-sub">${esc(i.email || i.name || '')}${i.last_sign_in_at ? ` · last used ${esc(ago(i.last_sign_in_at))}` : ''}</div>
            </div>
            <span class="badge green">Linked</span>
          </div>`;
        }).join('')}</div>` : '<p class="small muted">No linked identities were returned.</p>'}

        <div class="divider"></div>
        <h3 style="font-size:13px" class="mb-10">Add another sign-in method</h3>
        <div class="row-wrap">
          ${providers.has('google') ? '<span class="badge grey">Google linked</span>' : `<button class="btn btn-ghost btn-sm" type="button" data-link="google"><img class="platform-glyph" src="/assets/logos/google.svg" alt="" width="15" height="15" /> Link Google</button>`}
          ${providers.has('telegram') ? '<span class="badge grey">Telegram linked</span>' : '<span class="badge grey">Telegram not connected</span>'}
        </div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Linking needs "Allow manual linking" enabled in Supabase Authentication settings. Telegram is not a built-in Supabase provider: it needs a custom OIDC/Edge Function before it can appear here, and the app says so instead of pretending.</div></div>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head">
        <div><h3>Task accounts</h3><p class="tiny dim mt-6">The social profiles you complete tasks with. A verifier matches your proof to these.</p></div>
        <button class="btn btn-soft btn-sm" type="button" data-add-social>${icon('plus', 14)} Link account</button>
      </div>
      <div class="card-body">
        ${socialError ? errorPanel(socialError) : ''}
        ${social.length ? `<div class="list">${social.map((a) => {
          const m = platformMeta(a.platform);
          return `<button class="list-row" type="button" style="width:100%;background:none;border-left:0;border-right:0;border-top:0;text-align:left" data-social="${esc(a.id)}">
            <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px;background:${m.bg};color:${m.color}">${platformIcon(a.platform, 18)}</span>
            <div class="list-main">
              <div class="list-title">@${esc(a.handle)}</div>
              <div class="list-sub">${esc(m.label)} · ${a.last_synced_at ? `synced ${esc(ago(a.last_synced_at))}` : 'linked ' + esc(ago(a.created_at))}</div>
            </div>
            <span class="badge ${a.status === 'linked' ? 'green' : a.status === 'rejected' ? 'red' : 'orange'}">${a.status === 'linked' ? esc(a.trust_label || 'Linked') : a.status === 'rejected' ? 'Rejected' : 'Awaiting review'}</span>
            ${icon('chevronRight', 16)}
          </button>`;
        }).join('')}</div>` : '<p class="small muted">No task accounts linked yet. Link the social profiles you use so verifiers can match your proofs.</p>'}

        <div class="row-wrap mt-14">
          ${taskPlatforms.filter((pl) => !linkedPlatforms.has(pl)).slice(0, 6).map((pl) => `
            <button class="btn btn-ghost btn-sm" type="button" data-quick-link="${pl}">
              ${platformIcon(pl, 14)} ${esc(platformMeta(pl).label)}
            </button>`).join('')}
        </div>
        <div class="alert info mt-14">${icon('shield', 17)}<div>Never share a social password. TM GROW only stores the public handle and profile link, and marks the account with your current trust level.</div></div>
      </div>
    </div>

    ${(publicAccounts.length ? `<div class="card mt-18">
      <div class="card-head">
        <div><h3>Public profile check</h3><p class="tiny dim mt-6">Reads public data through Socify. It confirms the profile exists and is public. It does not prove that you own it.</p></div>
        <span class="badge grey">${publicAccounts.length}</span>
      </div>
      <div class="card-body">
        <div class="list">${publicAccounts.map((a) => {
          const m = platformMeta(a.platform);
          return `<div class="list-row">
            ${a.profile_avatar ? `<img class="proof-thumb" style="width:34px;height:34px;border-radius:10px" src="${esc(a.profile_avatar)}" alt="" />` : `<span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px;background:${m.bg};color:${m.color}">${platformIcon(a.platform, 16)}</span>`}
            <div class="list-main" style="min-width:0">
              <div class="list-title">${esc(a.profile_name || a.profile_username || '@' + a.handle)} ${publicBadge(a.public_status)}</div>
              <div class="list-sub">${esc(m.label)} · ${a.profile_followers != null ? `${Number(a.profile_followers).toLocaleString()} followers · ` : ''}${a.profile_checked_at ? `checked ${esc(ago(a.profile_checked_at))}` : 'not checked yet'}</div>
              ${a.profile_error ? `<div class="tiny red truncate">${esc(a.profile_error)}</div>` : ''}
            </div>
            <button class="btn ${a.public_status === 'CHECKING' ? 'btn-ghost' : 'btn-soft'} btn-sm" type="button" data-check-profile="${esc(a.id)}" ${a.public_status === 'CHECKING' ? 'disabled' : ''}>
              ${a.public_status === 'CHECKING' ? 'Checking…' : (['API_ERROR', 'REJECTED', 'NEEDS_MANUAL_REVIEW'].includes(a.public_status) ? 'Retry check' : 'Check public profile')}
            </button>
          </div>`;
        }).join('')}</div>
        <div class="alert info mt-14">${icon('info', 17)}<div>A public profile result is <strong>not ownership</strong>. Ownership is still confirmed with your verification code by a human. Lookups are limited per day; repeated checks reuse the cached result.</div></div>
      </div>
    </div>` : '')}`;

  root.querySelectorAll('[data-check-profile]').forEach((b) => b.addEventListener('click', (e) => {
    e.stopPropagation();
    checkProfile(b.dataset.checkProfile, b);
  }));

  root.querySelector('[data-refresh]').addEventListener('click', async (e) => {
    setBusy(e.currentTarget, true, 'Syncing');
    try {
      await rpc('refresh_my_identity');
      await loadContext();
      toast('Profile synced from your sign-in provider.', 'success');
      await renderAccounts(root);
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(e.currentTarget, false);
    }
  });

  root.querySelectorAll('[data-link]').forEach((b) => b.addEventListener('click', async () => {
    const provider = b.dataset.link;
    if (typeof sb.auth.linkIdentity !== 'function') {
      toast('This browser build of supabase-js does not support linking. Sign out and sign in with the other provider instead.', 'error', 8000);
      return;
    }
    setBusy(b, true, 'Opening');
    try {
      const { error } = await sb.auth.linkIdentity({ provider, options: { redirectTo: window.location.origin } });
      if (error) throw error;
    } catch (err) {
      toast(friendlyError(err), 'error', 8000);
      setBusy(b, false);
    }
  }));

  const openLink = (platform = 'x') => {
    const options = ['x', 'youtube', 'instagram', 'tiktok', 'facebook', 'telegram', 'reddit', 'spotify', 'discord'];
    const m = openModal({
      title: 'Link a task account',
      subtitle: 'Step 1 — tell us which account you use',
      body: `<form id="social-form" class="col" style="gap:13px">
        <div class="field">
          <label class="label">Platform</label>
          <select class="select" name="platform">
            ${options.map((p) => `<option value="${p}" ${p === platform ? 'selected' : ''}>${esc(platformMeta(p).label)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label class="label">Handle or username</label>
          <input class="input" name="handle" required minlength="2" maxlength="80" placeholder="e.g. TaskMasterbd" />
          <span class="hint">Only the public handle — never a password, email or phone number.</span>
        </div>
        <div class="field">
          <label class="label">Profile link <span class="hint">(optional)</span></label>
          <input class="input mono" name="profile_url" placeholder="https://…" />
        </div>
        <button class="btn btn-primary" type="submit">Get verification code</button>
      </form>`
    });
    const form = m.root.querySelector('#social-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const btn = form.querySelector('button[type=submit]');
      setBusy(btn, true, 'Preparing');
      try {
        const res = await rpc('start_social_verification', {
          p_platform: String(fd.get('platform')),
          p_handle: String(fd.get('handle')),
          p_profile_url: String(fd.get('profile_url') || '').trim() || null
        });
        m.close();
        openVerify(res.account, res.code || res.account?.verification_code);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(btn, false);
      }
    });
  };

  const openVerify = (account, code) => {
    const label = platformMeta(account.platform).label;
    const vm = openModal({
      title: `Verify your ${label} account`,
      subtitle: `@${account.handle}`,
      body: `<div class="panel panel-pad center" style="background:rgba(249,115,22,.07);border-color:rgba(249,115,22,.3)">
          <div class="tiny dim">Your verification code</div>
          <div class="mono" style="font-size:22px;font-weight:800;letter-spacing:2px;color:var(--brand);margin:8px 0 12px">${esc(code || '')}</div>
          <button class="btn btn-soft btn-sm" type="button" data-copy-code>${icon('copy', 14)} Copy code</button>
        </div>
        <div class="step-list mt-18">
          <div class="step"><span class="sn">1</span><span>Copy the code above.</span></div>
          <div class="step"><span class="sn">2</span><span>Paste it into your ${esc(label)} profile bio / channel description and publish.</span></div>
          <div class="step"><span class="sn">3</span><span>Come back and press Verify. A verifier checks the code on your profile before the account is approved.</span></div>
        </div>
        <div class="alert warn mt-14">${icon('info', 17)}<div>You can remove the code after verification. Verification is done by a human — the app does not claim to read your profile automatically.</div></div>`,
      footer: `<button class="btn btn-ghost" type="button" data-cancel>Back</button>
        <button class="btn btn-primary" type="button" data-verify disabled>Verify <span data-wait>(10s)</span></button>`
    });

    vm.root.querySelector('[data-cancel]').onclick = () => vm.close();
    vm.root.querySelector('[data-copy-code]').onclick = async (e) => {
      const ok = await copyText(code || '');
      toast(ok ? 'Verification code copied.' : 'Copy failed.', ok ? 'success' : 'error');
    };

    const verifyBtn = vm.root.querySelector('[data-verify]');
    const waitEl = vm.root.querySelector('[data-wait]');
    let left = 10;
    const timer = setInterval(() => {
      left -= 1;
      if (!verifyBtn.isConnected) { clearInterval(timer); return; }
      if (left > 0) { waitEl.textContent = `(${left}s)`; return; }
      clearInterval(timer);
      verifyBtn.disabled = false;
      waitEl.textContent = '';
    }, 1000);

    verifyBtn.onclick = async () => {
      setBusy(verifyBtn, true, 'Submitting');
      try {
        await rpc('submit_social_verification', { p_id: account.id });
        vm.close();
        toast('Submitted. A verifier will confirm your account shortly.', 'success', 6000);
        await renderAccounts(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(verifyBtn, false);
      }
    };
  };

  root.querySelector('[data-add-social]')?.addEventListener('click', () => openLink('x'));
  root.querySelectorAll('[data-quick-link]').forEach((b) => b.addEventListener('click', () => openLink(b.dataset.quickLink)));

  root.querySelectorAll('[data-social]').forEach((row) => row.addEventListener('click', () => {
    const acc = social.find((a) => a.id === row.dataset.social);
    if (!acc) return;
    const m = openModal({
      title: `@${acc.handle}`,
      subtitle: `${platformMeta(acc.platform).label} · ${acc.trust_label || 'Newbie'}`,
      body: `<div class="row" style="gap:12px">
          <span class="empty-ic" style="width:46px;height:46px;margin:0;border-radius:12px;background:${platformMeta(acc.platform).bg};color:${platformMeta(acc.platform).color}">${platformIcon(acc.platform, 22)}</span>
          <div><div class="strong">@${esc(acc.handle)}</div><div class="tiny dim">${acc.profile_url ? esc(acc.profile_url) : 'No profile link'}</div></div>
        </div>
        <div class="divider"></div>
        <div class="row-between small"><span class="muted">Status</span><span>${esc(acc.status)}</span></div>
        <div class="row-between small mt-6"><span class="muted">Last synced</span><span>${acc.last_synced_at ? esc(dateTime(acc.last_synced_at)) : '—'}</span></div>
        <div class="alert info mt-14">${icon('info', 17)}<div>Refreshing updates the trust label from your current trust score. It does not read your social account — verification is still done from your proof.</div></div>`,
      footer: `<button class="btn btn-danger btn-sm" type="button" data-unlink>Unlink</button>
        <button class="btn btn-ghost btn-sm" type="button" data-close>Close</button>
        <button class="btn btn-primary btn-sm" type="button" data-resync>Refresh</button>`
    });
    m.root.querySelector('[data-close]').onclick = () => m.close();
    m.root.querySelector('[data-resync]').onclick = async (e) => {
      setBusy(e.currentTarget, true, 'Refreshing');
      try {
        await rpc('refresh_social_account', { p_id: acc.id });
        toast('Task account refreshed.', 'success');
        m.close();
        await renderAccounts(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
        setBusy(e.currentTarget, false);
      }
    };
    m.root.querySelector('[data-unlink]').onclick = async () => {
      const ok = await confirmDialog({
        title: 'Unlink this account?',
        message: `@${acc.handle} is removed from your profile. You can link it again later.`,
        confirmLabel: 'Unlink',
        danger: true
      });
      if (!ok) return;
      try {
        await rpc('unlink_social_account', { p_id: acc.id });
        toast('Task account unlinked.', 'success');
        m.close();
        await renderAccounts(root);
      } catch (err) {
        toast(friendlyError(err), 'error');
      }
    };
  }));
}
