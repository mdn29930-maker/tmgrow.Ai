/* Buyer platform: services, campaigns, deposits and delivery reporting.
   Every mutation goes through a SECURITY DEFINER RPC, so the server
   re-checks the caller, the balance and the campaign state. */

import { sb, rpc, friendlyError } from '../lib/sb.js?v=2025-10-12-39';
import {
  state, loadContext, campaignFeePct, settingText, settingNumber, switchMode
} from '../lib/store.js?v=2025-10-12-39';
import {
  icon, esc, usdt, ago, shortDate, dateTime, statusBadge, platformMeta, platformIcon,
  toast, openModal, confirmDialog, loadingBlock, emptyState, errorPanel, uploadProofFile,
  safeHttpUrl, setBusy, pct, copyText
} from '../lib/ui.js?v=2025-10-12-39';
import { navigate } from '../lib/router.js?v=2025-10-12-39';

const NETWORK = 'BEP-20';

const KIND_LABEL = {
  campaign_funding: 'Campaign funded',
  campaign_refund: 'Campaign escrow refunded',
  escrow_release: 'Escrow released to a worker',
  escrow_return: 'Escrow returned',
  deposit: 'Deposit credited',
  withdrawal_hold: 'Withdrawal requested',
  withdrawal_paid: 'Withdrawal paid',
  withdrawal_refund: 'Withdrawal refunded',
  admin_adjustment: 'Balance adjustment'
};

let preselectedService = null;
let activeDraft = null; /* resumed from #/buyer/drafts */

function kpi({ label, value, suffix = '', foot = '', iconName = 'chart', tone = '' }) {
  return `<div class="kpi ${tone}">
    <div class="kpi-top">
      <div class="kpi-label">${esc(label)}</div>
      <span class="kpi-ic">${icon(iconName, 16)}</span>
    </div>
    <div class="kpi-num">${value}${suffix ? `<small>${esc(suffix)}</small>` : ''}</div>
    ${foot ? `<div class="kpi-foot">${foot}</div>` : ''}
  </div>`;
}

function money(n) { return `<span class="nowrap">${esc(usdt(n))} <span class="small muted">USDT</span></span>`; }

async function gate(root) {
  if (state.profile?.is_buyer) return true;
  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Buyer</span><h2>Open a buyer account</h2><p>Order real engagement. You pay only for approved delivery.</p></div>
    </div>
    <div class="card card-pad" style="max-width:560px">
      <div class="empty-ic" style="margin:0 0 14px">${icon('megaphone', 22)}</div>
      <h3 style="font-size:16px;margin-bottom:8px">Buyer mode is off</h3>
      <p class="small muted" style="line-height:1.7">Buyer mode adds campaigns, deposits and buyer reporting to your account. Your worker earnings are not touched.</p>
      <button class="btn btn-primary mt-14" type="button" data-enable-buyer>${icon('check', 16)} Enable buyer account</button>
      <p class="hint mt-10">Campaign budgets are paid from your available USDT balance and held in escrow until delivery is approved.</p>
    </div>`;
  root.querySelector('[data-enable-buyer]').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    setBusy(btn, true, 'Enabling');
    try {
      await rpc('enable_buyer_mode');
      await loadContext();
      toast('Buyer account enabled.', 'success');
      navigate('/buyer');
    } catch (err) {
      toast(friendlyError(err), 'error');
      setBusy(btn, false);
    }
  });
  return false;
}

function campaignCard(c) {
  const m = platformMeta(c.platform);
  const done = Number(c.approved_count || 0);
  return `<a class="list-row" href="#/buyer/campaigns/${encodeURIComponent(c.id)}">
    <span class="task-ic" style="background:${m.bg};color:${m.color};width:38px;height:38px">${platformIcon(c.platform, 18)}</span>
    <div class="list-main">
      <div class="row" style="gap:8px;flex-wrap:wrap"><span class="list-title">${esc(c.title)}</span>${statusBadge(c.status)}</div>
      <div class="list-sub">${esc(c.service_name || m.label)} · ${done}/${Number(c.quantity || 0)} delivered · ${esc(usdt(c.reward_per_task))} USDT per task</div>
      <div class="progress mt-6"><i style="width:${pct(done, c.quantity)}%"></i></div>
    </div>
    ${icon('chevronRight', 16)}
  </a>`;
}

/* ============================================================== BUYER HUB === */
export async function renderBuyerHub(root) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Loading buyer workspace');
  await loadContext().catch(() => {});

  let campaigns = [];
  let loadErr = '';
  try {
    campaigns = (await rpc('list_my_campaigns')) || [];
  } catch (e) { loadErr = friendlyError(e); }

  const depRes = await sb.from('deposits')
    .select('id,amount,status,created_at')
    .order('created_at', { ascending: false })
    .limit(5);
  const deposits = depRes.error ? [] : (depRes.data || []);

  let catalog = [];
  try {
    const { data } = await sb.from('services')
      .select('id,platform,name,description,default_reward,min_reward,min_quantity,max_quantity,sort_order')
      .eq('active', true)
      .order('sort_order')
      .limit(60);
    catalog = data || [];
  } catch (_) { catalog = []; }

  const hot = catalog.slice(0, 6);

  const w = state.wallet || {};
  const active = campaigns.filter((c) => c.status === 'active');
  const escrow = campaigns.reduce((sum, c) => sum + Number(c.reserved_remaining || 0), 0);
  const committed = campaigns.reduce((sum, c) => sum + Number(c.total_budget || 0), 0);
  const delivered = campaigns.reduce((sum, c) => sum + Number(c.approved_count || 0), 0);
  const feePct = campaignFeePct();

  root.innerHTML = `<div class="buyer-dashboard">
    <div class="workspace-page-intro">
      <div><span class="eyebrow">BUYER / OVERVIEW</span><h2>Campaign workspace</h2><p>Plan social campaigns, fund delivery and follow real progress.</p></div>
      <a class="btn btn-primary" href="#/buyer/new">${icon('plus', 16)} Create campaign</a>
    </div>

    ${loadErr ? errorPanel(loadErr) : ''}

    <section class="buyer-hero-panel">
      <div class="buyer-hero-copy">
        <span class="buyer-hero-kicker">TM GROW FOR BRANDS</span>
        <h2>Build social momentum.<br /><em>Track every delivery.</em></h2>
        <p>Launch worker-powered campaigns or place a direct SMM order. See funding, progress and account activity in one workspace.</p>
        <div class="buyer-hero-actions">
          <a class="btn btn-primary" href="#/buyer/new">${icon('plus', 15)} New campaign</a>
          <a class="btn btn-ghost" href="#/smm/services">Browse SMM services ${icon('arrowRight', 14)}</a>
        </div>
      </div>
      <div class="buyer-balance-card">
        <span>AVAILABLE BALANCE</span>
        <strong>${esc(usdt(w.available))}<small>USDT</small></strong>
        <p>Available for campaigns and orders</p>
        <button class="btn btn-soft btn-block" type="button" data-add-funds>${icon('download', 15)} Add funds</button>
        <a href="#/buyer/wallet">Open buyer wallet ${icon('arrowRight', 13)}</a>
      </div>
      <div class="buyer-hero-gridmark" aria-hidden="true"></div>
    </section>

    <section class="buyer-overview-metrics" aria-label="Campaign summary">
      <div><span>In escrow</span><strong>${esc(usdt(escrow))}<small>USDT</small></strong><i>${icon('lock', 16)}</i></div>
      <div><span>Active campaigns</span><strong>${Number(active.length)}<small> / ${Number(campaigns.length)} total</small></strong><i>${icon('megaphone', 16)}</i></div>
      <div><span>Approved deliveries</span><strong>${delivered}<small>tasks</small></strong><i>${icon('checkCircle', 16)}</i></div>
      <div><span>Campaign budgets</span><strong>${esc(usdt(committed))}<small>USDT</small></strong><i>${icon('wallet', 16)}</i></div>
    </section>

    <section class="buyer-workspace-actions">
      <a href="#/buyer/campaigns"><span class="buyer-action-icon">${icon('layers', 18)}</span><span><strong>Campaigns</strong><small>Delivery, status and escrow</small></span>${icon('arrowRight', 15)}</a>
      <a href="#/smm/services"><span class="buyer-action-icon">${icon('sliders', 18)}</span><span><strong>SMM catalogue</strong><small>Browse available social services</small></span>${icon('arrowRight', 15)}</a>
      <a href="#/smm/orders"><span class="buyer-action-icon">${icon('book', 18)}</span><span><strong>Direct orders</strong><small>Review order status and progress</small></span>${icon('arrowRight', 15)}</a>
    </section>

    <div class="buyer-dashboard-grid">
      <section class="buyer-content-panel">
        <div class="buyer-panel-heading"><div><span class="eyebrow">WORKER CAMPAIGNS</span><h3>Recent campaigns</h3></div><a href="#/buyer/campaigns">All campaigns ${icon('arrowRight', 13)}</a></div>
        ${campaigns.length
          ? `<div class="buyer-campaign-list">${campaigns.slice(0, 6).map(campaignCard).join('')}</div>`
          : emptyState({
            iconName: 'megaphone',
            title: 'No campaigns yet',
            text: 'Choose a service, set a target and budget, then track each approved delivery here.',
            action: '<a class="btn btn-primary" href="#/buyer/services">Browse campaign services</a>'
          })}
      </section>

      <aside class="buyer-dashboard-aside">
        <section class="buyer-content-panel buyer-funding-panel">
          <div class="buyer-panel-heading"><div><span class="eyebrow">FUNDING MODEL</span><h3>Campaign escrow</h3></div><span class="badge gold">${esc(String(feePct))}% fee</span></div>
          <p>Campaign budgets and the platform fee are shown before funding. Unspent escrow is returned when a campaign is cancelled.</p>
          <div class="buyer-funding-line"><span>Budget</span><strong>Quantity × reward</strong></div>
          <div class="buyer-funding-line"><span>Worker payout</span><strong>On approved proof</strong></div>
          <a class="btn btn-ghost btn-block mt-14" href="#/buyer/new">Review campaign builder ${icon('arrowRight', 14)}</a>
        </section>

        <section class="buyer-content-panel">
          <div class="buyer-panel-heading"><div><span class="eyebrow">WALLET</span><h3>Recent deposits</h3></div><a href="#/buyer/wallet">Wallet ${icon('arrowRight', 13)}</a></div>
          ${deposits.length ? `<div class="list">${deposits.map((d) => `
            <div class="list-row">
              <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${icon('download', 15)}</span>
              <div class="list-main"><div class="list-title">${esc(usdt(d.amount))} USDT</div><div class="list-sub">${esc(ago(d.created_at))}</div></div>
              ${statusBadge(d.status)}
            </div>`).join('')}</div>` : '<p class="small muted">No deposits yet. Add funds to place an order.</p>'}
        </section>
      </aside>
    </div>

    ${hot.length ? `<section class="buyer-services-preview">
      <div class="buyer-panel-heading"><div><span class="eyebrow">CAMPAIGN CATALOGUE</span><h3>Start with a service</h3></div><a href="#/buyer/services">Browse all ${catalog.length} ${icon('arrowRight', 13)}</a></div>
      <div class="buyer-service-grid">${hot.map((s) => {
        const m = platformMeta(s.platform);
        return `<article class="buyer-service-card">
          <div class="buyer-service-top"><span class="srv-icon" style="background:${m.bg};color:${m.color}">${platformIcon(s.platform, 18)}</span><span>${esc(m.label)}</span></div>
          <h4>${esc(s.name)}</h4>
          <p>${Number(s.min_quantity)}–${Number(s.max_quantity)} tasks · from ${esc(usdt(s.min_reward))} USDT each</p>
          <button class="btn btn-soft btn-sm" type="button" data-order="${esc(s.id)}">Build campaign ${icon('arrowRight', 13)}</button>
        </article>`;
      }).join('')}</div>
    </section>` : ''}
  </div>`;

  root.querySelectorAll('[data-order]').forEach((b) => b.addEventListener('click', () => {
    preselectedService = b.dataset.order;
    navigate('/buyer/new');
  }));
  const addFunds = root.querySelector('[data-add-funds]');
  if (addFunds) addFunds.addEventListener('click', () => navigate('/buyer/wallet'));
}

/* ================================================================ SERVICES === */
export async function renderBuyerServices(root) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Loading services');

  let services = [];
  let loadErr = '';
  try {
    const { data, error } = await sb.from('services')
      .select('id,platform,name,description,default_reward,min_reward,min_quantity,max_quantity,sort_order')
      .eq('active', true)
      .order('sort_order');
    if (error) throw error;
    services = data || [];
  } catch (e) { loadErr = friendlyError(e); }

  const groups = {};
  services.forEach((s) => { (groups[s.platform] = groups[s.platform] || []).push(s); });
  const feePct = campaignFeePct();

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Catalogue</span><h2>Services</h2><p>Choose the action you need. Pricing is set per task, with a ${esc(String(feePct))}% platform fee at checkout.</p></div>
      <a class="btn btn-ghost" href="#/buyer/new">${icon('plus', 16)} Build a campaign</a>
    </div>
    ${loadErr ? errorPanel(loadErr) : ''}
    <div class="filter-bar">
      <div class="input-group">${icon('search', 17)}<input class="input input-icon" id="svc-search" placeholder="Search services or platforms" autocomplete="off" /></div>
      <span class="badge grey">${services.length} services</span>
    </div>
    ${services.length === 0 && !loadErr ? emptyState({ iconName: 'layers', title: 'No services configured', text: 'An administrator has to enable services in the admin panel before campaigns can be created.' }) : ''}
    <div class="grid grid-2" style="align-items:start" id="svc-grid">
      ${Object.keys(groups).map((platform) => {
        const m = platformMeta(platform);
        return `<div class="card" data-svc-card>
          <div class="card-head">
            <div class="row" style="gap:10px">
              <span class="task-ic" style="background:${m.bg};color:${m.color};width:36px;height:36px">${platformIcon(platform, 18)}</span>
              <h3>${esc(m.label)}</h3>
            </div>
            <span class="badge grey">${groups[platform].length}</span>
          </div>
          <div class="card-body">
            <div class="list">
              ${groups[platform].map((s) => `
                <div class="list-row" data-svc-row style="align-items:flex-start">
                  <div class="list-main">
                    <div class="list-title">${esc(s.name)}</div>
                    <div class="list-sub">${esc(s.description || '')}</div>
                    <div class="tiny dim mt-6">From ${esc(usdt(s.min_reward))} USDT per task · ${Number(s.min_quantity)}–${Number(s.max_quantity)} tasks</div>
                  </div>
                  <button class="btn btn-soft btn-sm" type="button" data-order="${esc(s.id)}">Order</button>
                </div>`).join('')}
            </div>
          </div>
        </div>`;
      }).join('')}
    </div>`;

  root.querySelectorAll('[data-order]').forEach((b) => b.addEventListener('click', () => {
    preselectedService = b.dataset.order;
    navigate('/buyer/new');
  }));

  const searchEl = root.querySelector('#svc-search');
  if (searchEl) searchEl.addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    root.querySelectorAll('[data-svc-row]').forEach((row) => {
      row.style.display = !q || row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
    root.querySelectorAll('[data-svc-card]').forEach((card) => {
      const visible = Array.from(card.querySelectorAll('[data-svc-row]')).some((r) => r.style.display !== 'none');
      card.style.display = visible ? '' : 'none';
    });
  });
}

/* ============================================================ NEW CAMPAIGN === */
export async function renderNewCampaign(root) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Preparing campaign builder');
  await loadContext().catch(() => {});

  let services = [];
  let countries = [];
  let loadErr = '';
  try {
    const svc = await sb.from('services')
      .select('id,platform,name,description,default_reward,min_reward,min_quantity,max_quantity,sort_order')
      .eq('active', true)
      .order('sort_order');
    if (svc.error) throw svc.error;
    services = svc.data || [];

    const ctr = await sb.from('countries')
      .select('code,name')
      .eq('active', true)
      .eq('allow_buyers', true)
      .order('name');
    countries = ctr.error ? [] : (ctr.data || []);
  } catch (e) { loadErr = friendlyError(e); }

  if (!services.length) {
    root.innerHTML = `<div class="page-head"><div><span class="eyebrow">Campaign</span><h2>New campaign</h2><p>Nothing to order yet.</p></div></div>
      ${loadErr ? errorPanel(loadErr) : emptyState({
        iconName: 'layers',
        title: 'No services are active',
        text: 'Ask an administrator to enable at least one service before creating campaigns.',
        action: '<a class="btn btn-ghost" href="#/buyer/services">Back to services</a>'
      })}`;
    return;
  }

  const initial = services.find((s) => s.id === preselectedService) || services[0];
  preselectedService = null;
  const available = Number(state.wallet?.available || 0);
  const feePct = campaignFeePct();

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Campaign</span><h2>New campaign</h2><p>Set the action, the target and the quantity. Budget and fee are held in escrow.</p></div>
      <a class="btn btn-ghost" href="#/buyer/services">${icon('arrowLeft', 15)} Services</a>
    </div>
    ${loadErr ? errorPanel(loadErr) : ''}
    <div class="detail-grid">
      <div class="card card-pad">
        <form id="nc-form" class="col" style="gap:14px">
          <div class="field">
            <label class="label" for="nc-service">Service</label>
            <select class="select" id="nc-service">
              ${services.map((s) => `<option value="${esc(s.id)}" ${s.id === initial.id ? 'selected' : ''}>${esc(platformMeta(s.platform).label)} — ${esc(s.name)}</option>`).join('')}
            </select>
            <span class="hint" id="nc-service-hint"></span>
          </div>

          <div class="field">
            <label class="check"><input type="checkbox" id="nc-require-account" /> <span>Only workers with a <strong>verified linked account</strong> on this platform can claim this campaign</span></label>
            <span class="hint">They verify ownership through a code in their profile. This reduces fake accounts.</span>
          </div>

          <div class="field">
            <label class="label" for="nc-title">Campaign title</label>
            <input class="input" id="nc-title" maxlength="120" minlength="3" required placeholder="e.g. Subscribe to our new product channel" />
            <span class="hint">Workers only see this title and your instructions, never your account details.</span>
          </div>

          <div class="field">
            <label class="label" for="nc-target">Target link</label>
            <input class="input mono" id="nc-target" type="url" required placeholder="https://…" />
            <span class="hint">The public link workers open to complete the action.</span>
          </div>

          <div class="field">
            <label class="label" for="nc-instructions">Instructions</label>
            <textarea class="textarea" id="nc-instructions" maxlength="4000" minlength="10" required placeholder="Explain exactly what to do, what to keep (e.g. stay subscribed 30 days) and what the screenshot must show."></textarea>
          </div>

          <div class="field-row">
            <div class="field">
              <label class="label" for="nc-quantity">Quantity</label>
              <input class="input" id="nc-quantity" type="number" step="1" required />
            </div>
            <div class="field">
              <label class="label" for="nc-reward">Reward per task (USDT)</label>
              <input class="input" id="nc-reward" type="number" step="0.000001" required />
            </div>
          </div>

          <div class="field">
            <label class="label">Allowed countries <span class="hint">(leave empty for worldwide)</span></label>
            <div class="panel panel-pad" style="max-height:190px;overflow:auto;display:grid;grid-template-columns:1fr 1fr;gap:8px">
              ${countries.map((c) => `<label class="check"><input type="checkbox" data-country value="${esc(c.code)}" /> <span>${esc(c.name)}</span></label>`).join('') || '<span class="small muted">Country list is empty.</span>'}
            </div>
            <span class="hint">Workers whose profile country is not selected will not see the tasks.</span>
          </div>

          <div class="field">
            <label class="label" for="nc-trust">Minimum worker trust score</label>
            <select class="select" id="nc-trust">
              <option value="0">No minimum</option>
              <option value="50">50+</option>
              <option value="70">70+</option>
              <option value="90">90+</option>
            </select>
          </div>

          <button class="btn btn-ghost btn-block" type="button" data-save-draft>${icon('edit', 15)} Save draft</button>
          <button class="btn btn-primary btn-lg" type="submit" id="nc-submit">${icon('zap', 17)} Create and fund campaign</button>
          <p class="hint">By creating a campaign you confirm the target link and instructions follow the platform rules. Escrow is refunded for anything not delivered.</p>
        </form>
      </div>

      <aside class="col" style="gap:14px;position:sticky;top:80px">
        <div class="card card-pad">
          <div class="kpi-label">Cost summary</div>
          <div class="mt-10" id="nc-summary"></div>
        </div>
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Your balance</h3>
          <div class="row-between small"><span class="muted">Available</span><span class="strong">${esc(usdt(available))} USDT</span></div>
          <div class="row-between small mt-6"><span class="muted">Platform fee</span><span>${esc(String(feePct))}%</span></div>
          <a class="btn btn-ghost btn-block mt-14" href="#/buyer/wallet">${icon('download', 15)} Add funds</a>
        </div>
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Delivery rules</h3>
          <div class="step-list">
            <div class="step"><span class="sn">1</span><span>Each task is claimed by one worker for 30 minutes.</span></div>
            <div class="step"><span class="sn">2</span><span>Proof is reviewed manually by a verifier.</span></div>
            <div class="step"><span class="sn">3</span><span>Approved proofs release the reward from escrow.</span></div>
          </div>
        </div>
      </aside>
    </div>`;

  const selEl = root.querySelector('#nc-service');
  const qtyEl = root.querySelector('#nc-quantity');
  const rewEl = root.querySelector('#nc-reward');
  const summaryEl = root.querySelector('#nc-summary');
  const hintEl = root.querySelector('#nc-service-hint');

  const current = () => services.find((s) => s.id === selEl.value) || services[0];

  const recalc = () => {
    const s = current();
    const qty = Number(qtyEl.value || 0);
    const rew = Number(rewEl.value || 0);
    const budget = qty * rew;
    const fee = budget * feePct / 100;
    const total = budget + fee;
    const short = total > available;

    hintEl.textContent = s ? `${s.name}: ${Number(s.min_quantity)}–${Number(s.max_quantity)} tasks, minimum reward ${usdt(s.min_reward)} USDT.` : '';

    summaryEl.innerHTML = `
      <div class="row-between small"><span class="muted">Tasks</span><span>${qty > 0 ? qty : '—'}</span></div>
      <div class="row-between small mt-6"><span class="muted">Reward each</span><span>${esc(usdt(rew))} USDT</span></div>
      <div class="row-between small mt-6"><span class="muted">Budget</span><span>${esc(usdt(budget))} USDT</span></div>
      <div class="row-between small mt-6"><span class="muted">Fee (${esc(String(feePct))}%)</span><span>${esc(usdt(fee))} USDT</span></div>
      <div class="divider"></div>
      <div class="row-between"><span class="strong">Total now</span><span class="strong gold-text">${esc(usdt(total))} USDT</span></div>
      ${short ? `<div class="alert warn mt-14">${icon('alert', 17)}<div>Your available balance covers ${esc(usdt(available))} USDT. Deposit the difference before creating this campaign.</div></div>` : ''}`;
  };

  const applyDefaults = () => {
    const s = current();
    if (!s) return;
    qtyEl.value = String(s.min_quantity);
    rewEl.value = Number(s.default_reward).toFixed(6);
    qtyEl.min = String(s.min_quantity);
    qtyEl.max = String(s.max_quantity);
    rewEl.min = Number(s.min_reward).toFixed(6);
    rewEl.max = (Number(s.min_reward) * 50).toFixed(6);
    recalc();
  };

  selEl.addEventListener('change', applyDefaults);
  qtyEl.addEventListener('input', recalc);
  rewEl.addEventListener('input', recalc);
  applyDefaults();

  /* Resume a saved draft (from #/buyer/drafts). Nothing is funded here. */
  try {
    activeDraft = null;
    const raw = sessionStorage.getItem('tmgrow-draft');
    if (raw) {
      sessionStorage.removeItem('tmgrow-draft');
      const d = JSON.parse(raw);
      if (d && d.payload) {
        activeDraft = { id: d.id || null, payload: d.payload };
        const p = d.payload;
        if (p.service_id && services.some((s) => s.id === p.service_id)) {
          selEl.value = p.service_id;
          applyDefaults();
        }
        if (p.title) root.querySelector('#nc-title').value = String(p.title);
        if (p.target_url) root.querySelector('#nc-target').value = String(p.target_url);
        if (p.instructions) root.querySelector('#nc-instructions').value = String(p.instructions);
        if (Number.isFinite(Number(p.quantity))) qtyEl.value = String(p.quantity);
        if (Number.isFinite(Number(p.reward_per_task))) rewEl.value = String(p.reward_per_task);
        if (p.require_linked_account != null) root.querySelector('#nc-require-account').checked = !!p.require_linked_account;
        if (p.min_trust_score != null) root.querySelector('#nc-trust').value = String(p.min_trust_score);
        const cs = Array.isArray(p.countries) ? p.countries : [];
        root.querySelectorAll('[data-country]').forEach((cb) => { cb.checked = cs.includes(cb.value); });
        recalc();
        toast('Draft loaded. Review everything before funding.', 'info', 3200);
      }
    }
  } catch (_) { activeDraft = null; }

  const collectDraft = () => ({
    service_id: current()?.id || null,
    title: root.querySelector('#nc-title').value.trim(),
    target_url: root.querySelector('#nc-target').value.trim(),
    instructions: root.querySelector('#nc-instructions').value.trim(),
    quantity: Number(qtyEl.value || 0),
    reward_per_task: Number(rewEl.value || 0),
    require_linked_account: root.querySelector('#nc-require-account').checked,
    min_trust_score: Number(root.querySelector('#nc-trust').value || 0),
    countries: Array.from(root.querySelectorAll('[data-country]:checked')).map((i) => i.value)
  });

  root.querySelector('[data-save-draft]').addEventListener('click', async () => {
    const btn = root.querySelector('[data-save-draft]');
    const payload = collectDraft();
    if (!payload.title || payload.title.length < 3) {
      toast('Give the draft a title of at least 3 characters before saving.', 'error');
      return;
    }
    setBusy(btn, true, 'Saving');
    try {
      await rpc('save_campaign_draft', {
        p_id: activeDraft?.id || null,
        p_title: payload.title,
        p_payload: payload
      });
      toast('Draft saved. Resume it any time from Drafts.', 'success');
      navigate('/buyer/drafts');
    } catch (err) {
      const raw = String((err && (err.raw?.message || err.message)) || '');
      toast(/PGRST202|Could not find the function|does not exist/i.test(raw)
        ? 'Drafts need the premium platform migration — run supabase/premium-platform.sql in the SQL editor, then reload.'
        : friendlyError(err), 'error', 6500);
      setBusy(btn, false);
    }
  });

  root.querySelector('#nc-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const s = current();
    const qty = Number(qtyEl.value);
    const rew = Number(rewEl.value);
    const title = root.querySelector('#nc-title').value.trim();
    const target = root.querySelector('#nc-target').value.trim();
    const instructions = root.querySelector('#nc-instructions').value.trim();
    const minTrust = Number(root.querySelector('#nc-trust').value || 0);
    const selected = Array.from(root.querySelectorAll('[data-country]:checked')).map((i) => i.value);

    if (!s) return toast('Choose a service first.', 'error');
    if (title.length < 3) return toast('Title must be at least 3 characters.', 'error');
    if (!/^https?:\/\//i.test(target)) return toast('Target link must start with http:// or https://', 'error');
    if (instructions.length < 10) return toast('Write instructions of at least 10 characters.', 'error');
    if (!Number.isFinite(qty) || qty < Number(s.min_quantity) || qty > Number(s.max_quantity)) {
      return toast(`Quantity must be between ${s.min_quantity} and ${s.max_quantity}.`, 'error');
    }
    if (!Number.isFinite(rew) || rew < Number(s.min_reward) || rew > Number(s.min_reward) * 50) {
      return toast(`Reward must be between ${usdt(s.min_reward)} and ${usdt(Number(s.min_reward) * 50)} USDT.`, 'error');
    }

    const budget = qty * rew;
    const fee = budget * feePct / 100;
    const total = budget + fee;

    const ok = await confirmDialog({
      title: 'Create this campaign?',
      message: `${qty} tasks at ${usdt(rew)} USDT = ${usdt(budget)} USDT budget plus ${usdt(fee)} USDT fee. ${usdt(total)} USDT leaves your available balance into escrow.`,
      confirmLabel: 'Create & fund'
    });
    if (!ok) return;

    const btn = root.querySelector('#nc-submit');
    setBusy(btn, true, 'Creating');
    try {
      const res = await rpc('create_campaign', {
        p_service_id: s.id,
        p_title: title,
        p_instructions: instructions,
        p_target_url: target,
        p_quantity: qty,
        p_reward: rew,
        p_require_linked_account: root.querySelector('#nc-require-account').checked,
        p_countries: selected,
        p_min_trust: minTrust
      });
      if (activeDraft?.id) {
        /* The draft became a real funded campaign; remove it so it cannot be
           submitted twice. The campaign itself is untouched. */
        try { await rpc('delete_campaign_draft', { p_id: activeDraft.id }); } catch (_) { /* best effort */ }
        activeDraft = null;
      }
      await loadContext().catch(() => {});
      toast(`Campaign created${res?.campaign?.status === 'pending' ? ' and queued for review' : ' and now live'}.`, 'success');
      if (res?.campaign?.id) navigate(`/buyer/campaigns/${res.campaign.id}`);
      else await renderNewCampaign(root);
    } catch (err) {
      toast(friendlyError(err), 'error', 7000);
      setBusy(btn, false);
    }
  });
}

/* =============================================================== CAMPAIGNS === */
export async function renderBuyerCampaigns(root) {
  if (!(await gate(root))) return;
  let filter = 'all';

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Delivery</span><h2>Campaigns</h2><p>Progress, escrow and delivery for every order.</p></div>
      <a class="btn btn-primary" href="#/buyer/new">${icon('plus', 16)} New campaign</a>
    </div>
    <div class="tabs" style="margin-bottom:14px" id="cp-tabs">
      ${[['all', 'All'], ['active', 'Active'], ['paused', 'Paused'], ['pending', 'Pending review'], ['completed', 'Completed'], ['cancelled', 'Cancelled'], ['rejected', 'Rejected']]
        .map(([v, l]) => `<button class="tab ${v === 'all' ? 'active' : ''}" type="button" data-tab="${v}">${l}</button>`).join('')}
    </div>
    <div id="cp-list">${loadingBlock('Loading campaigns')}</div>`;

  const listEl = root.querySelector('#cp-list');

  const load = async () => {
    listEl.innerHTML = loadingBlock('Loading campaigns');
    let rows = [];
    try {
      rows = (await rpc('list_my_campaigns')) || [];
    } catch (e) {
      listEl.innerHTML = errorPanel(friendlyError(e));
      return;
    }
    const shown = filter === 'all' ? rows : rows.filter((c) => c.status === filter);
    listEl.innerHTML = rows.length === 0
      ? emptyState({
        iconName: 'megaphone',
        title: 'No campaigns yet',
        text: 'Choose a service and fund your first campaign. Workers start within minutes of it going live.',
        action: '<a class="btn btn-primary" href="#/buyer/services">Browse services</a>'
      })
      : shown.length === 0
        ? emptyState({ iconName: 'filter', title: 'Nothing in this status', text: 'Try another tab.' })
        : `<div class="card"><div class="card-body"><div class="list">${shown.map(campaignCard).join('')}</div></div></div>`;
  };

  root.querySelector('#cp-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    filter = b.dataset.tab;
    root.querySelectorAll('#cp-tabs .tab').forEach((t) => t.classList.toggle('active', t === b));
    load();
  });

  await load();
}

/* ======================================================== CAMPAIGN DETAIL === */
export async function renderBuyerCampaign(root, { params }) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Loading campaign');

  let data;
  try {
    data = await rpc('get_my_campaign', { p_campaign_id: params.id });
  } catch (e) {
    root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/buyer/campaigns">${icon('arrowLeft', 15)} Campaigns</a>
      <div class="mt-14">${errorPanel(friendlyError(e))}</div>`;
    return;
  }

  const c = data.campaign || {};
  const counts = data.counts || {};
  const subs = data.submissions || [];
  const m = platformMeta(data.service?.platform);
  const done = Number(counts.approved || 0);
  const target = safeHttpUrl(c.target_url);
  const canControl = ['active', 'paused', 'pending'].includes(c.status);

  const action = (name, label, iconName, danger) =>
    `<button class="btn ${danger ? 'btn-danger' : 'btn-ghost'} btn-sm" type="button" data-action="${name}">${icon(iconName, 14)} ${esc(label)}</button>`;

  root.innerHTML = `<a class="btn btn-ghost btn-sm" href="#/buyer/campaigns">${icon('arrowLeft', 15)} Campaigns</a>

    <div class="card card-pad mt-14">
      <div class="row" style="gap:12px;align-items:flex-start">
        <span class="task-ic" style="background:${m.bg};color:${m.color};width:46px;height:46px">${platformIcon(data.service?.platform, 22)}</span>
        <div style="flex:1;min-width:0">
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <span class="badge" style="color:${m.color};background:${m.bg}">${esc(m.label)}</span>
            ${statusBadge(c.status)}
            ${c.review_note ? `<span class="badge red">Review note</span>` : ''}
          </div>
          <h2 style="font-size:21px;margin-top:9px">${esc(c.title)}</h2>
          <p class="small muted mt-6">${esc(data.service?.name || '')} · created ${esc(shortDate(c.created_at))}${c.completed_at ? ` · completed ${esc(shortDate(c.completed_at))}` : ''}</p>
        </div>
        ${canControl ? `<div class="row-wrap">
          ${c.status === 'active' ? action('pause', 'Pause', 'pause') : ''}
          ${c.status === 'paused' ? action('resume', 'Resume', 'play') : ''}
          ${c.status !== 'completed' ? action('cancel', 'Cancel & refund', 'stop', true) : ''}
        </div>` : ''}
      </div>
      ${c.review_note ? `<div class="alert warn mt-14">${icon('info', 17)}<div>${esc(c.review_note)}</div></div>` : ''}
    </div>

    <div class="kpis mt-18">
      ${kpi({ label: 'Delivered', value: `${done}/${Number(c.quantity || 0)}`, iconName: 'checkCircle', tone: 'green', foot: `${pct(done, c.quantity)}% of target` })}
      ${kpi({ label: 'In progress', value: Number(counts.claimed || 0) + Number(counts.submitted || 0), iconName: 'clock', tone: 'gold', foot: `${Number(counts.submitted || 0)} awaiting review` })}
      ${kpi({ label: 'Escrow left', value: esc(usdt(c.reserved_remaining)), suffix: 'USDT', iconName: 'lock', tone: 'blue', foot: `${esc(usdt(c.total_budget))} USDT funded` })}
      ${kpi({ label: 'Rejected', value: Number(counts.rejected || 0), iconName: 'xCircle', tone: 'red', foot: 'Rewards returned to escrow' })}
    </div>

    <div class="grid grid-2 mt-18" style="align-items:start">
      <div class="col" style="gap:14px">
        <div class="card card-pad">
          <div class="row-between mb-10"><h3 style="font-size:13px">Delivery progress</h3><span class="small muted">${pct(done, c.quantity)}%</span></div>
          <div class="progress"><i style="width:${pct(done, c.quantity)}%"></i></div>
          <div class="grid grid-3 mt-14" style="gap:10px">
            <div><div class="tiny dim">Waiting</div><div class="strong">${Number(counts.available || 0)}</div></div>
            <div><div class="tiny dim">Claimed</div><div class="strong">${Number(counts.claimed || 0)}</div></div>
            <div><div class="tiny dim">In review</div><div class="strong">${Number(counts.submitted || 0)}</div></div>
            <div><div class="tiny dim">Approved</div><div class="strong green">${Number(counts.approved || 0)}</div></div>
            <div><div class="tiny dim">Rejected</div><div class="strong red">${Number(counts.rejected || 0)}</div></div>
            <div><div class="tiny dim">Expired</div><div class="strong dim">${Number(counts.expired || 0)}</div></div>
          </div>
        </div>

        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Instructions workers see</h3>
          <div class="panel panel-pad" style="white-space:pre-wrap;font-size:13px;line-height:1.7;color:var(--muted)">${esc(c.instructions || '')}</div>
          <h3 style="font-size:13px" class="mb-10 mt-18">Target</h3>
          ${target
            ? `<a class="btn btn-soft" href="${esc(target)}" target="_blank" rel="noopener noreferrer">${icon('external', 16)} Open target</a>
               <div class="mono-box mt-10">${esc(target)}</div>`
            : '<div class="alert error">' + icon('alert', 17) + '<div>Target link is invalid.</div></div>'}
          <div class="row-between small mt-18"><span class="muted">Countries</span><span>${(c.countries || []).length ? (c.countries || []).map(esc).join(', ') : 'Worldwide'}</span></div>
          <div class="row-between small mt-6"><span class="muted">Minimum trust</span><span>${Number(c.min_trust_score || 0)}</span></div>
        </div>
      </div>

      <div class="col" style="gap:14px">
        <div class="card card-pad">
          <h3 style="font-size:13px" class="mb-10">Money</h3>
          <div class="row-between small"><span class="muted">Budget</span><span>${esc(usdt(c.total_budget))} USDT</span></div>
          <div class="row-between small mt-6"><span class="muted">Platform fee</span><span>${esc(usdt(c.fee_amount))} USDT</span></div>
          <div class="row-between small mt-6"><span class="muted">Reward per task</span><span>${esc(usdt(c.reward_per_task))} USDT</span></div>
          <div class="row-between small mt-6"><span class="muted">Escrow remaining</span><span class="strong">${esc(usdt(c.reserved_remaining))} USDT</span></div>
          <div class="divider"></div>
          <div class="row-between small"><span class="muted">Spent on approved delivery</span><span>${esc(usdt(Number(c.approved_count || 0) * Number(c.reward_per_task || 0)))} USDT</span></div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Deliveries</h3><span class="badge grey">${subs.length}</span></div>
          <div class="card-body">
            ${subs.length ? `<div class="list">${subs.map((s) => `
              <div class="list-row">
                <span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('image', 15)}</span>
                <div class="list-main">
                  <div class="row" style="gap:8px"><span class="list-title">${esc(s.worker || 'Worker')}</span>${statusBadge(s.status)}</div>
                  <div class="list-sub">Submitted ${esc(ago(s.created_at))}${s.reviewed_at ? ` · reviewed ${esc(ago(s.reviewed_at))}` : ''}</div>
                </div>
              </div>`).join('')}</div>`
              : `<p class="small muted">No proofs submitted yet. Workers appear here as soon as they claim and submit.</p>`}
          </div>
        </div>
      </div>
    </div>`;

  root.querySelectorAll('[data-action]').forEach((b) => b.addEventListener('click', async () => {
    const act = b.dataset.action;
    const copy = act === 'pause'
      ? { title: 'Pause campaign?', message: 'Workers stop seeing new tasks. Tasks already claimed can still be submitted and reviewed.', label: 'Pause' }
      : act === 'resume'
        ? { title: 'Resume campaign?', message: 'Available tasks become visible to workers again.', label: 'Resume' }
        : { title: 'Cancel campaign?', message: `Unspent escrow (${usdt(c.reserved_remaining)} USDT) is refunded to your available balance. Pending proofs are rejected and their rewards reversed. This cannot be undone.`, label: 'Cancel & refund' };

    const ok = await confirmDialog({ title: copy.title, message: copy.message, confirmLabel: copy.label, danger: act === 'cancel' });
    if (!ok) return;

    setBusy(b, true, 'Working');
    try {
      await rpc('set_campaign_status', { p_campaign_id: params.id, p_action: act });
      await loadContext().catch(() => {});
      toast(`Campaign ${act === 'cancel' ? 'cancelled and escrow refunded' : act + 'd'}.`, 'success');
      await renderBuyerCampaign(root, { params });
    } catch (e) {
      toast(friendlyError(e), 'error', 7000);
      setBusy(b, false);
    }
  }));
}

/* ============================================================ BUYER WALLET === */
export async function renderBuyerWallet(root) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Loading buyer wallet');
  await loadContext().catch(() => {});

  const [depRes, ledgerRes] = await Promise.all([
    sb.from('deposits')
      .select('id,amount,method,tx_hash,status,admin_note,created_at,reviewed_at')
      .order('created_at', { ascending: false })
      .limit(40),
    sb.from('ledger_entries')
      .select('id,kind,available_delta,pending_delta,reserved_delta,note,created_at')
      .order('created_at', { ascending: false })
      .limit(40)
  ]);

  const deposits = depRes.error ? [] : (depRes.data || []);
  const entries = ledgerRes.error ? [] : (ledgerRes.data || []);
  const w = state.wallet || {};
  const address = settingText('deposit_address', '');
  const minDeposit = settingNumber('min_deposit', 5);
  const feePct = campaignFeePct();

  const amountCell = (e) => {
    const pick = Number(e.available_delta || 0) !== 0 ? Number(e.available_delta)
      : Number(e.pending_delta || 0) !== 0 ? Number(e.pending_delta) : Number(e.reserved_delta || 0);
    const positive = pick >= 0;
    return `<span class="list-amount ${positive ? 'green' : 'red'}">${positive ? '+' : ''}${esc(usdt(pick))}</span>`;
  };

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Funding</span><h2>Buyer wallet</h2><p>Deposits, escrow and the ledger behind every campaign.</p></div>
      <button class="btn btn-primary" type="button" data-new-deposit>${icon('download', 16)} New deposit</button>
    </div>

    <div class="row-between mb-16" style="gap:10px">
      <div class="mode-switch">
        ${state.profile?.is_worker ? '<button class="mode-btn" type="button" data-mode-go="worker">Worker</button>' : ''}
        <button class="mode-btn active" type="button">Buyer</button>
      </div>
      <span class="tiny dim">Buyer wallet · deposits and campaign spending</span>
    </div>

    <div class="kpis">
      ${kpi({ label: 'Available', value: esc(usdt(w.available)), suffix: 'USDT', iconName: 'wallet', tone: 'green', foot: 'Spendable now' })}
      ${kpi({ label: 'In escrow', value: esc(usdt(w.reserved)), suffix: 'USDT', iconName: 'lock', tone: 'blue', foot: 'Campaign budgets and withdrawals' })}
      ${kpi({ label: 'Deposited', value: esc(usdt(w.lifetime_deposited)), suffix: 'USDT', iconName: 'download', tone: 'gold', foot: 'Approved deposits' })}
      ${kpi({ label: 'Platform fee', value: `${feePct}%`, iconName: 'trending', tone: 'violet', foot: 'Charged once per campaign' })}
    </div>

    <div class="grid grid-2 mt-24" style="align-items:start">
      <div class="card">
        <div class="card-head"><h3>Deposit USDT</h3><span class="badge gold">${esc(NETWORK)}</span></div>
        <div class="card-body">
          <p class="small muted">Send USDT on <strong>BNB Smart Chain (BEP-20)</strong> to the platform address, then submit the amount, transaction hash and a screenshot of the transfer. Finance credits it after verification.</p>
          <div class="field mt-14">
            <label class="label">Deposit address</label>
            ${address
              ? `<div class="row"><span class="mono-box" style="flex:1">${esc(address)}</span><button class="btn btn-ghost btn-sm" type="button" data-copy-address>${icon('copy', 14)}</button></div>`
              : `<div class="alert warn">${icon('alert', 17)}<div>No deposit address is published yet. Open a support ticket and finance will send the current address.</div></div>`}
          </div>
          <div class="row-between small mt-14"><span class="muted">Minimum deposit</span><span>${esc(usdt(minDeposit))} USDT</span></div>
          <div class="row-between small mt-6"><span class="muted">Network</span><span>BEP-20 only</span></div>
          <button class="btn btn-soft btn-block mt-14" type="button" data-new-deposit>Submit a deposit</button>
          <div class="alert info mt-14">${icon('shield', 17)}<div>Never send another network's asset. BEP-20 transfers are irreversible and cannot be recovered by support.</div></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>Deposit requests</h3><span class="badge grey">${deposits.length}</span></div>
        <div class="card-body">
          ${deposits.length ? `<div class="list">${deposits.map((d) => `
            <div class="list-row" style="align-items:flex-start">
              <div class="list-main">
                <div class="row" style="gap:8px"><span class="list-title">${esc(usdt(d.amount))} USDT</span>${statusBadge(d.status)}</div>
                <div class="list-sub">${esc(String(d.method || '').replace('_', ' '))} · ${esc(ago(d.created_at))}</div>
                ${d.tx_hash ? `<div class="tiny mono truncate mt-6">${esc(d.tx_hash)}</div>` : ''}
                ${d.admin_note ? `<div class="tiny ${d.status === 'rejected' ? 'red' : 'dim'} mt-6">${esc(d.admin_note)}</div>` : ''}
              </div>
            </div>`).join('')}</div>`
            : `<p class="small muted">No deposit requests yet.</p>`}
        </div>
      </div>
    </div>

    <div class="card mt-18">
      <div class="card-head"><h3>Wallet ledger</h3><span class="badge grey">${entries.length}</span></div>
      <div class="card-body">
        ${entries.length ? `<div class="list">${entries.map((e) => `
          <div class="list-row">
            <span class="empty-ic" style="width:32px;height:32px;margin:0;border-radius:9px">${icon('coin', 15)}</span>
            <div class="list-main">
              <div class="list-title">${esc(KIND_LABEL[e.kind] || e.kind)}</div>
              <div class="list-sub">${e.note ? esc(e.note) + ' · ' : ''}${esc(ago(e.created_at))}</div>
            </div>
            ${amountCell(e)}
          </div>`).join('')}</div>`
          : emptyState({ iconName: 'coin', title: 'No wallet activity', text: 'Deposits and campaign spending will be listed here.' })}
      </div>
    </div>`;

  const copyBtn = root.querySelector('[data-copy-address]');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      const ok = await copyText(address);
      toast(ok ? 'Address copied.' : 'Copy failed.', ok ? 'success' : 'error');
    });
  }

  const openDeposit = () => {
    const m = openModal({
      title: 'Submit a deposit',
      subtitle: `Send USDT on BNB Smart Chain (BEP-20) first, then record it here.`,
      body: `<form id="dep-form" class="col" style="gap:13px">
        <div class="field">
          <label class="label">Amount (USDT)</label>
          <input class="input" name="amount" type="number" min="${esc(minDeposit)}" step="0.000001" required placeholder="${esc(usdt(minDeposit))}" />
          <span class="hint">Minimum ${esc(usdt(minDeposit))} USDT. Enter exactly what you sent.</span>
        </div>
        <div class="field">
          <label class="label">Method</label>
          <select class="select" name="method">
            <option value="USDT_BEP20">USDT on BEP-20</option>
            <option value="BINANCE_PAY">Binance Pay</option>
          </select>
        </div>
        <div class="field">
          <label class="label">Transaction hash</label>
          <input class="input mono" name="tx_hash" placeholder="0x…" pattern="^0x[a-fA-F0-9]{64}$" />
          <span class="hint">64 hex characters after 0x. Required for BEP-20 deposits so finance can verify on-chain.</span>
        </div>
        <div class="field">
          <label class="label">Proof screenshot</label>
          <input class="input" name="proof" type="file" accept="image/png,image/jpeg,image/webp,application/pdf" required />
          <span class="hint">JPG, PNG, WebP or PDF · max 5 MB. A clear transfer confirmation speeds up approval.</span>
        </div>
        <button class="btn btn-primary" type="submit">Submit for review</button>
      </form>`,
      wide: false
    });

    const form = m.root.querySelector('#dep-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]');
      const fd = new FormData(form);
      const amount = Number(fd.get('amount'));
      const hash = String(fd.get('tx_hash') || '').trim();
      const file = fd.get('proof');

      if (!Number.isFinite(amount) || amount < minDeposit) return toast(`Minimum deposit is ${usdt(minDeposit)} USDT.`, 'error');
      if (hash && !/^0x[a-fA-F0-9]{64}$/.test(hash)) return toast('Transaction hash must be 0x followed by 64 hex characters.', 'error');
      if (!file || !file.size) return toast('Attach the transfer screenshot.', 'error');

      setBusy(btn, true, 'Uploading');
      try {
        const { path } = await uploadProofFile(file, state.profile.id);
        await rpc('request_deposit', {
          p_amount: amount,
          p_method: String(fd.get('method') || 'USDT_BEP20'),
          p_tx_hash: hash || null,
          p_proof_path: path
        });
        m.close();
        toast('Deposit submitted. Finance will verify it.', 'success');
        await renderBuyerWallet(root);
      } catch (err) {
        toast(friendlyError(err), 'error', 7000);
        setBusy(btn, false);
      }
    });
  };

  root.querySelectorAll('[data-new-deposit]').forEach((b) => b.addEventListener('click', openDeposit));
  root.querySelectorAll('[data-mode-go="worker"]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try {
      await switchMode('worker');
      await loadContext();
      toast('Worker mode on.', 'success');
      navigate('/dashboard');
    } catch (err) {
      toast(friendlyError(err), 'error');
      b.disabled = false;
    }
  }));
}


/* ================================================== BUYER CAMPAIGN DRAFTS ===
   Saved builder states. A draft never touches the wallet: funding only
   happens when the buyer submits it through the normal campaign builder. */
export async function renderBuyerDrafts(root) {
  if (!(await gate(root))) return;
  root.innerHTML = loadingBlock('Loading drafts');

  let drafts = [];
  let loadErr = '';
  try {
    drafts = (await rpc('list_my_campaign_drafts')) || [];
  } catch (e) {
    const raw = String((e && (e.raw?.message || e.message)) || '');
    loadErr = /PGRST202|Could not find the function|schema cache|does not exist/i.test(raw)
      ? 'Drafts need the premium platform migration — run supabase/premium-platform.sql in the SQL editor, then reload.'
      : friendlyError(e);
  }

  root.innerHTML = `<div class="page-head">
      <div><span class="eyebrow">Campaign</span><h2>Drafts</h2><p>Saved campaign builders. Nothing is funded until a draft is submitted.</p></div>
      <a class="btn btn-primary" href="#/buyer/new">${icon('plus', 16)} New campaign</a>
    </div>
    ${loadErr ? errorPanel(loadErr) : ''}
    ${drafts.length ? `<div class="card"><div class="card-body"><div class="list">
      ${drafts.map((d) => `
        <div class="list-row">
          <span class="empty-ic" style="width:34px;height:34px;margin:0;border-radius:10px">${icon('edit', 15)}</span>
          <div class="list-main">
            <div class="list-title">${esc(d.title)}</div>
            <div class="list-sub">${esc(Number(d.payload?.quantity) || 0)} tasks · ${esc(usdt(Number(d.payload?.reward_per_task) || 0))} USDT each · last edited ${esc(ago(d.updated_at))}</div>
          </div>
          <div class="row" style="gap:6px">
            <button class="btn btn-soft btn-sm" type="button" data-resume="${esc(d.id)}">${icon('play', 13)} Resume</button>
            <button class="btn btn-danger btn-sm" type="button" data-del="${esc(d.id)}" aria-label="Delete draft">${icon('trash', 13)}</button>
          </div>
        </div>`).join('')}
    </div></div></div>`
      : !loadErr
        ? emptyState({
          iconName: 'edit',
          title: 'No drafts yet',
          text: 'Build a campaign, then press Save draft to come back to it later. Drafts never touch your balance.',
          action: '<a class="btn btn-primary" href="#/buyer/new">Start a campaign</a>'
        })
        : ''}`;

  root.querySelectorAll('[data-resume]').forEach((b) => b.addEventListener('click', () => {
    const d = drafts.find((x) => x.id === b.dataset.resume);
    if (!d) return;
    try { sessionStorage.setItem('tmgrow-draft', JSON.stringify(d)); } catch (_) { /* ignore */ }
    navigate('/buyer/new');
  }));

  root.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Delete draft?',
      message: 'The saved builder values are removed. No live campaign or funds are touched.',
      confirmLabel: 'Delete',
      danger: true
    });
    if (!ok) return;
    setBusy(b, true, 'Deleting');
    try {
      await rpc('delete_campaign_draft', { p_id: b.dataset.del });
      toast('Draft deleted.', 'success');
      await renderBuyerDrafts(root);
    } catch (e) {
      toast(friendlyError(e), 'error');
      setBusy(b, false);
    }
  }));
}