import { CONFIG } from './config.js?v=2025-10-12-39';
import { sb, rpc, friendlyError } from './lib/sb.js?v=2025-10-12-39';
import {
  state, loadSession, loadContext, loadPublicData, loadFeatureStatus, captureRefFromUrl,
  applyPendingReferral, applyPendingUsername, resetState, displayName, isAdmin, currentMode, switchMode,
  rememberHash, takeRememberedHash, pendingRef, withdrawalMin, hasPerm
} from './lib/store.js?v=2025-10-12-39';
import { addRoute, startRouter, navigate, currentPath, refreshRoute } from './lib/router.js?v=2025-10-12-39';
import { prepareTelegram, isTelegramMiniApp, isTelegramEnvironment, telegramInitData, signInWithTelegram, telegramFriendlyError, telegramApp } from './lib/telegram.js?v=2025-10-12-39';
import {
  icon, esc, toast, openModal, confirmDialog, errorPanel, usdt, safeHttpUrl,
  initials, avatarInner, avatarHTML, copyText, dateTime, setBusy, openTelegramUrl
} from './lib/ui.js?v=2025-10-12-39';
import { renderLanding } from './views/landing.js?v=2025-10-12-39';
import { renderAuth } from './views/auth.js?v=2025-10-12-39';
import {
  renderDashboard, renderTasks, renderTaskDetail, renderMyTasks, renderMore,
  renderLeaderboard, renderReferrals, renderProfile, renderNotifications,
  renderSupport, renderSupportTicket, renderTerms, renderSmmTasks, renderWorkerAnalytics,
  renderAnnouncements, renderTrustCenter
} from './views/worker.js?v=2025-10-12-39';
import { renderDeposit, renderWithdraw, renderHistory, renderAccounts } from './views/wallet.js?v=2025-10-12-39';
import { renderSmmDashboard, renderSmmServices, renderSmmMass, renderSmmOrders } from './views/smm.js?v=2025-10-12-39';
import {
  renderBuyerHub, renderBuyerServices, renderNewCampaign, renderBuyerCampaigns,
  renderBuyerCampaign, renderBuyerWallet, renderBuyerDrafts
} from './views/buyer.js?v=2025-10-12-39';
import { renderAchievements } from './views/achievements.js?v=2025-10-12-39';
import {
  renderAdminOverview, renderAdminUsers, renderAdminTasks, renderAdminCampaigns,
  renderAdminProofs, renderAdminDeposits, renderAdminWithdrawals, renderAdminLedger,
  renderAdminServices, renderAdminCountries, renderAdminSupport, renderAdminFlags,
  renderAdminSettings, renderAdminAdmins, renderAdminAudit, renderAdminAI,
  renderAdminBroadcast, renderAdminReferrals, renderAdminTelegram, renderAdminSocial,
  renderAdminWorkers, renderAdminBuyers, renderAdminWallets, renderAdminLeaderboard,
  renderAdminRewards, renderAdminSystem, renderAdminSuspended, renderAdminAutomation,
  renderAdminActivity, renderAdminRisk, renderAdminLogins, renderAdminVerification,
  renderAdminSocialVerification, renderAdminSocify, renderAdminSmmOrders, renderAdminPreflight,
  renderAdminCategories, renderAdminMaintenance, renderAdminAIInsights, renderAdminSmmServices
} from './views/admin.js?v=2025-10-12-39';

const appEl = document.getElementById('app');

/* Boot watchdog stand-down: set the moment this module graph has resolved
   and started executing, so a slow network never triggers the boot-failure
   screen while loading is still in progress. */
window.__TMGROW_BOOTED = true;

/* RBAC map: the permission a page requires. The database is the authority;
   this only decides what the panel draws and which route it refuses. */
const ADMIN_PERM_BY_PATH = [
  ['/admin/wallets', 'wallets.view'],
  ['/admin/ledger', 'ledger.view'],
  ['/admin/deposits', 'deposits.view'],
  ['/admin/withdrawals', 'withdrawals.view'],
  ['/admin/settings', 'settings.manage'],
  ['/admin/admins', 'admins.manage'],
  ['/admin/audit', 'audit.view'],
  ['/admin/preflight', 'audit.view'],
  ['/admin/referrals', 'referrals.view'],
  ['/admin/support', 'support.view'],
  ['/admin/notifications', 'notifications.send'],
  ['/admin/countries', 'countries.manage'],
  ['/admin/flags', 'fraud.view'],
  ['/admin/risk', 'fraud.view'],
  ['/admin/verification', 'verification.view'],
  ['/admin/social-verification', 'verification.view'],
  ['/admin/socify', 'verification.view'],
  ['/admin/smm-orders', 'smm.view'],
  ['/admin/smm-services', 'smm.view'],
  ['/admin/services', 'smm.view'],
  ['/admin/campaigns', 'campaigns.view'],
  ['/admin/tasks', 'tasks.view'],
  ['/admin/automation', 'settings.manage'],
  ['/admin/rewards', 'wallets.view'],
  ['/admin/users', 'users.view'],
  ['/admin/workers', 'workers.view'],
  ['/admin/buyers', 'buyers.view'],
  ['/admin/suspended', 'users.edit'],
  ['/admin/activity', 'users.view'],
  ['/admin/logins', 'users.view'],
  ['/admin/leaderboard', 'analytics.view'],
  ['/admin/system', 'dashboard.view'],
  ['/admin', 'dashboard.view']
];

function adminPermForPath(path) {
  const hit = ADMIN_PERM_BY_PATH.find(([p]) => path === p || path.startsWith(p + '/'));
  return hit ? hit[1] : null;
}

/* ------------------------------------------------------------------ routes */
function registerRoutes() {
  addRoute('/', renderLanding, { public: true });
  addRoute('/login', renderAuthPage, { public: true });
  addRoute('/forgot', (root) => renderAuth(root, { mode: 'forgot' }), { public: true });
  addRoute('/reset', (root) => renderAuth(root, { mode: 'reset' }), { public: true });

  addRoute('/dashboard', renderDashboard, { title: 'Dashboard', sub: 'Your earning overview' });
  addRoute('/tasks', renderTasks, { title: 'Tasks', sub: 'Available social micro tasks' });
  addRoute('/tasks/:id', renderTaskDetail, { title: 'Task', sub: 'Instructions and proof' });
  addRoute('/my-tasks', renderMyTasks, { title: 'My tasks', sub: 'Claims, reviews and results' });
  addRoute('/more', renderMore, { title: 'More', sub: 'Settings, tools and support' });
  addRoute('/wallet', renderWithdraw, { title: 'Withdraw', sub: 'USDT payouts on BEP-20' });
  addRoute('/withdraw', renderWithdraw, { title: 'Withdraw', sub: 'USDT payouts on BEP-20' });
  addRoute('/deposit', renderDeposit, { title: 'Deposit', sub: 'Fund your wallet with USDT' });
  addRoute('/history', renderHistory, { title: 'Transactions', sub: 'Every wallet movement' });
  addRoute('/accounts', renderAccounts, { title: 'Linked accounts', sub: 'Sign-in methods and security' });
  addRoute('/leaderboard', renderLeaderboard, { title: 'Leaderboard', sub: 'Weekly top earners' });
  addRoute('/achievements', renderAchievements, { title: 'Achievements', sub: 'Badges, milestones and TM Coin rewards' });
  addRoute('/analytics', renderWorkerAnalytics, { title: 'Analytics', sub: 'Your earning performance' });
  addRoute('/referrals', renderReferrals, { title: 'Referrals', sub: 'Invite and earn commission' });
  addRoute('/notifications', renderNotifications, { title: 'Notifications', sub: 'Account activity' });
  addRoute('/announcements', renderAnnouncements, { title: 'Announcements', sub: 'Messages from the team' });
  addRoute('/trust', renderTrustCenter, { title: 'Trust center', sub: 'Reputation and verification' });
  addRoute('/profile', renderProfile, { title: 'Profile', sub: 'Account and preferences' });
  addRoute('/support', renderSupport, { title: 'Support', sub: 'Talk to the TM GROW team' });
  addRoute('/support/:id', renderSupportTicket, { title: 'Ticket', sub: 'Support conversation' });
  addRoute('/terms', renderTerms, { public: true });
  addRoute('/privacy', () => { window.location.replace('/privacy.html'); return Promise.resolve(); }, { public: true });

  addRoute('/buyer', renderBuyerHub, { title: 'Buyer hub', sub: 'Order real social engagement' });
  addRoute('/buyer/services', renderBuyerServices, { title: 'Services', sub: 'Choose a task type' });
  addRoute('/buyer/new', renderNewCampaign, { title: 'New campaign', sub: 'Fund and launch in minutes' });
  addRoute('/buyer/campaigns', renderBuyerCampaigns, { title: 'Campaigns', sub: 'Progress and delivery' });
  addRoute('/buyer/campaigns/:id', renderBuyerCampaign, { title: 'Campaign', sub: 'Live delivery report' });
  addRoute('/buyer/wallet', renderBuyerWallet, { title: 'Buyer wallet', sub: 'Deposit and spend' });
  addRoute('/buyer/drafts', renderBuyerDrafts, { title: 'Drafts', sub: 'Saved campaign builders' });

  addRoute('/smm', renderSmmDashboard, { title: 'SMM dashboard', sub: 'Orders, balance and popular services' });
  addRoute('/smm/services', renderSmmServices, { title: 'Services', sub: 'Buy social services with USDT' });
  addRoute('/smm/services/:platform', renderSmmServices, { title: 'Services', sub: 'Platform catalogue' });
  addRoute('/smm/mass', renderSmmMass, { title: 'Mass order', sub: 'Many orders, one atomic charge' });
  addRoute('/smm/orders', renderSmmOrders, { title: 'My orders', sub: 'Status, history and details' });

  addRoute('/smm-tasks', renderSmmTasks, { title: 'SMM tasks', sub: 'Batches released from paid orders' });

  addRoute('/admin', renderAdminOverview, { title: 'Admin overview', sub: 'Platform health and queues', admin: true });
  addRoute('/admin/users', renderAdminUsers, { title: 'Users', sub: 'Workers, buyers and admins', admin: true });
  addRoute('/admin/workers', renderAdminWorkers, { title: 'Workers', sub: 'Earnings, approved work and account state', admin: true });
  addRoute('/admin/buyers', renderAdminBuyers, { title: 'Buyers', sub: 'Wallets, campaigns and account state', admin: true });
  addRoute('/admin/wallets', renderAdminWallets, { title: 'Wallets', sub: 'Balances across every account', admin: true });
  addRoute('/admin/leaderboard', renderAdminLeaderboard, { title: 'Leaderboard', sub: 'Weekly earners', admin: true });
  addRoute('/admin/rewards', renderAdminRewards, { title: 'Rewards & bonuses', sub: 'Coin, commissions and fees', admin: true });
  addRoute('/admin/system', renderAdminSystem, { title: 'System status', sub: 'Database, role and schema health', admin: true });
  addRoute('/admin/preflight', renderAdminPreflight, { title: 'Migration status', sub: 'Read-only pre-flight check', admin: true });
  addRoute('/admin/categories', renderAdminCategories, { title: 'Task categories', sub: 'Group and gate task types', admin: true });
  addRoute('/admin/maintenance', renderAdminMaintenance, { title: 'Maintenance mode', sub: 'Manual toggle and scheduled windows', admin: true });
  addRoute('/admin/ai-manager', renderAdminAIInsights, { title: 'AI Manager', sub: 'Insights, alerts and daily reports', admin: true });
  addRoute('/admin/suspended', renderAdminSuspended, { title: 'Suspended accounts', sub: 'Suspensions, restrictions and restores', admin: true });
  addRoute('/admin/automation', renderAdminAutomation, { title: 'TM GROW AUTO MANAGER', sub: 'Jobs, schedule and run history', admin: true });
  addRoute('/admin/tasks', renderAdminTasks, { title: 'Tasks', sub: 'Every task and its state', admin: true });
  addRoute('/admin/campaigns', renderAdminCampaigns, { title: 'Campaigns', sub: 'Buyer campaigns and escrow', admin: true });
  addRoute('/admin/proofs', renderAdminProofs, { title: 'Proof verification', sub: 'Review submitted evidence', admin: true });
  addRoute('/admin/social', renderAdminSocial, { title: 'Task accounts', sub: 'Social account verification', admin: true });
  addRoute('/admin/deposits', renderAdminDeposits, { title: 'Deposits', sub: 'Verify buyer deposits', admin: true });
  addRoute('/admin/withdrawals', renderAdminWithdrawals, { title: 'Withdrawals', sub: 'Payout approval and settlement', admin: true });
  addRoute('/admin/ledger', renderAdminLedger, { title: 'Ledger', sub: 'Immutable financial entries', admin: true });
  addRoute('/admin/referrals', renderAdminReferrals, { title: 'Referrals', sub: 'Invite links and commission', admin: true });
  addRoute('/admin/services', renderAdminServices, { title: 'Services & pricing', sub: 'Worker reward and limits', admin: true });
  addRoute('/admin/countries', renderAdminCountries, { title: 'Countries', sub: 'Market availability', admin: true });
  addRoute('/admin/support', renderAdminSupport, { title: 'Support inbox', sub: 'Ticket conversations', admin: true });
  addRoute('/admin/flags', renderAdminFlags, { title: 'Fraud & abuse', sub: 'Automated risk flags', admin: true });
  addRoute('/admin/settings', renderAdminSettings, { title: 'Platform settings', sub: 'Fees, limits and public config', admin: true });
  addRoute('/admin/admins', renderAdminAdmins, { title: 'Admin accounts', sub: 'Roles and access', admin: true });
  addRoute('/admin/audit', renderAdminAudit, { title: 'Audit log', sub: 'Who changed what', admin: true });
  addRoute('/admin/notifications', renderAdminBroadcast, { title: 'Announcements', sub: 'Message users', admin: true });
  addRoute('/admin/telegram', renderAdminTelegram, { title: 'Telegram', sub: 'Bot delivery, templates and errors', admin: true });
  addRoute('/admin/ai', renderAdminAI, { title: 'AI assistant', sub: 'Ask about live platform data', admin: true });
  addRoute('/admin/activity', renderAdminActivity, { title: 'User activity', sub: 'Recorded events across the platform', admin: true });
  addRoute('/admin/activity/:id', renderAdminActivity, { title: 'User activity', sub: 'Recorded events for one account', admin: true });
  addRoute('/admin/risk', renderAdminRisk, { title: 'Risk history', sub: 'Recorded signals and manual review', admin: true });
  addRoute('/admin/logins', renderAdminLogins, { title: 'Login history', sub: 'Recorded sessions', admin: true });
  addRoute('/admin/verification', renderAdminVerification, { title: 'Task verification', sub: 'Database sweep and manual decisions', admin: true });
  addRoute('/admin/social-verification', renderAdminSocialVerification, { title: 'Social verification', sub: 'Public profile checks and ownership review', admin: true });
  addRoute('/admin/socify', renderAdminSocify, { title: 'Socify API', sub: 'Server-side social data provider', admin: true });
  addRoute('/admin/smm-orders', renderAdminSmmOrders, { title: 'SMM orders & drip', sub: 'Release batches, review proofs and set worker rewards', admin: true });
  addRoute('/admin/smm-services', renderAdminSmmServices, { title: 'SMM services', sub: 'The catalogue buyers order from', admin: true });
}

/* --------------------------------------------------------------- auth view */
async function renderAuthPage(root) {
  if (state.session) { navigate(homeFor(), { replace: true }); return; }
  await renderAuth(root);
}

/* -------------------------------------------------------------- app shell */
const ADMIN_TABS = [
  { href: '/admin', label: 'Overview', icon: 'grid' },
  { href: '/admin/proofs', label: 'Proofs', icon: 'shield' },
  { href: '/admin/withdrawals', label: 'Payouts', icon: 'wallet' },
  { href: '/admin/users', label: 'Users', icon: 'users' },
  { label: 'Menu', icon: 'menu', action: 'menu' }
];

/* ------------------------------------------------------------------ shell */

/* An admin lands in the panel. Worker tools stay reachable, but only through
   this explicit switch, never as the default screen. */
const ADMIN_WORKER_VIEW = 'tmgrow-admin-worker-view';

function adminWorkerView() {
  try { return sessionStorage.getItem(ADMIN_WORKER_VIEW) === '1'; } catch (_) { return false; }
}

function setAdminWorkerView(on) {
  try {
    if (on) sessionStorage.setItem(ADMIN_WORKER_VIEW, '1');
    else sessionStorage.removeItem(ADMIN_WORKER_VIEW);
  } catch (_) { /* ignore */ }
}

/* Master Admin Control Room — navigation groups A–H.
   Every entry carries the key of its module in admin_feature_status(), so the
   badge under each label is the real database state. Items still marked `soon`
   have no page yet and stay disabled. */
function adminModuleStatus(key) {
  const list = state.featureStatus?.modules;
  if (!key || !Array.isArray(list)) return null;
  return list.find((m) => m.key === key) || null;
}

function adminNavGroups() {
  const groups = [
    {
      label: 'Overview',
      items: [
        { key: 'overview', href: '/admin', label: 'Master dashboard', icon: 'grid' },
        { key: 'system', href: '/admin/system', label: 'Platform health', icon: 'database' },
        { key: 'ai', href: '/admin/ai', label: 'AI assistant', icon: 'sparkles' }
      ]
    },
    {
      label: 'Users',
      items: [
        { key: 'users', href: '/admin/users', label: 'All users', icon: 'users' },
        { key: 'workers', href: '/admin/workers', label: 'Workers', icon: 'target' },
        { key: 'buyers', href: '/admin/buyers', label: 'Buyers', icon: 'megaphone' },
        { key: 'suspended', href: '/admin/suspended', label: 'Suspended & banned', icon: 'lock' },
        { key: 'user_activity', href: '/admin/activity', label: 'User activity', icon: 'chart' },
        { key: 'risk_history', href: '/admin/risk', label: 'Risk history', icon: 'flag' }
      ]
    },
    {
      label: 'Earning',
      items: [
        { key: 'tasks', href: '/admin/tasks', label: 'Task management', icon: 'tasks' },
        { key: 'proofs', href: '/admin/proofs', label: 'Verification center', icon: 'shield', badge: state.counts.proofs_pending },
        { key: 'social', href: '/admin/social', label: 'Task accounts', icon: 'link' },
        { key: 'rewards', href: '/admin/rewards', label: 'Rewards & bonuses', icon: 'star' },
        { key: 'create_task', label: 'Add task slots', icon: 'plus', href: '/admin/tasks' },
        { key: 'task_categories', label: 'Task categories', icon: 'layers', href: '/admin/categories' }
      ]
    },
    {
      label: 'Financial',
      items: [
        { key: 'wallets', href: '/admin/wallets', label: 'Wallet management', icon: 'card' },
        { key: 'ledger', href: '/admin/ledger', label: 'Transaction ledger', icon: 'book' },
        { key: 'deposits', href: '/admin/deposits', label: 'Deposits', icon: 'download' },
        { key: 'withdrawals', href: '/admin/withdrawals', label: 'Withdrawals', icon: 'wallet' },
        { key: 'flags', href: '/admin/flags', label: 'Fraudulent transactions', icon: 'flag' },
        { key: 'financial_reports', label: 'Financial reports', icon: 'chart', soon: true }
      ]
    },
    {
      label: 'SMM panel',
      items: [
        { key: 'smm_services', href: '/admin/smm-services', label: 'SMM services', icon: 'sliders' },
        { key: 'services', href: '/admin/services', label: 'Campaign services & pricing', icon: 'sliders' },
        { key: 'campaigns', href: '/admin/campaigns', label: 'Orders & campaigns', icon: 'layers' },
        { key: 'smm_orders', href: '/admin/smm-orders', label: 'SMM orders & drip', icon: 'refresh' },
        { key: 'profit_management', label: 'Profit management', icon: 'trending', soon: true }
      ]
    },
    {
      label: 'Automation',
      items: [
        { key: 'automation', href: '/admin/automation', label: 'Automation control', icon: 'zap' },
        { key: 'telegram', href: '/admin/telegram', label: 'Telegram & task alerts', icon: 'telegram' },
        { key: 'announcements', href: '/admin/notifications', label: 'Announcements', icon: 'megaphone' },
        { key: 'verification_queue', href: '/admin/verification', label: 'Verification queue', icon: 'shield' },
        { key: 'social_verification', href: '/admin/social-verification', label: 'Social verification', icon: 'link' },
        { key: 'socify_api', href: '/admin/socify', label: 'Socify API', icon: 'zap' },
        { key: 'failed_jobs', label: 'Failed jobs & logs', icon: 'alert', soon: true }
      ]
    },
    {
      label: 'Security',
      items: [
        { key: 'admins', href: '/admin/admins', label: 'Admin roles', icon: 'key' },
        { key: 'audit', href: '/admin/audit', label: 'Audit log', icon: 'file' },
        { key: 'support', href: '/admin/support', label: 'Support inbox', icon: 'ticket', badge: state.counts.open_tickets },
        { key: 'login_history', href: '/admin/logins', label: 'Login history', icon: 'clock' }
      ]
    },
    {
      label: 'Configuration',
      items: [
        { key: 'settings', href: '/admin/settings', label: 'Website settings', icon: 'settings' },
        { key: 'maintenance', href: '/admin/maintenance', label: 'Maintenance mode', icon: 'lock' },
        { key: 'ai_manager', href: '/admin/ai-manager', label: 'AI Manager', icon: 'sparkles' },
        { key: 'preflight', href: '/admin/preflight', label: 'Migration status', icon: 'database' },
        { key: 'countries', href: '/admin/countries', label: 'Countries', icon: 'globe' },
        { key: 'referrals', href: '/admin/referrals', label: 'Referrals', icon: 'gift' },
        { key: 'leaderboard', href: '/admin/leaderboard', label: 'Rankings', icon: 'trophy' }
      ]
    },
    {
      label: 'Switch',
      items: [
        { href: '/dashboard', label: 'Worker tools', icon: 'home', switchView: true }
      ]
    }
  ];

  return groups.map((group) => ({
    ...group,
    items: group.items.map((item) => {
      const mod = adminModuleStatus(item.key);
      return mod ? { ...item, status: mod.status, detail: mod.detail } : item;
    })
  }));
}

function navGroups() {
  const mode = currentMode();
  const groups = [];

  if (mode === 'buyer') {
    const sc = state.smmCounts || {};
    groups.push({
      label: 'SMM panel',
      items: [
        { href: '/smm', label: 'Dashboard', icon: 'grid' },
        { href: '/buyer/wallet', label: 'Add funds', icon: 'download' },
        { href: '/smm/services', label: 'Create order', icon: 'plus' },
        { href: '/smm/mass', label: 'Mass order', icon: 'layers' },
        { href: '/smm/orders', label: 'Orders', icon: 'book', badge: state.counts.pending_smm_orders },
        { href: '/buyer/new', label: 'Custom task', icon: 'target' },
        { href: '/support', label: 'Support tickets', icon: 'ticket', badge: state.counts.open_tickets }
      ]
    });
    groups.push({
      label: 'Services',
      items: [
        { href: '/smm/services/telegram', label: 'Telegram', icon: 'telegram', badge: sc.telegram },
        { href: '/smm/services/x', label: 'X / Twitter', icon: 'x', badge: sc.x },
        { href: '/smm/services/tiktok', label: 'TikTok', icon: 'tiktok', badge: sc.tiktok },
        { href: '/smm/services/instagram', label: 'Instagram', icon: 'instagram', badge: sc.instagram },
        { href: '/smm/services/facebook', label: 'Facebook', icon: 'facebook', badge: sc.facebook },
        { href: '/smm/services/youtube', label: 'YouTube', icon: 'youtube', badge: sc.youtube },
        { href: '/smm/services/threads', label: 'Threads', icon: 'globe', badge: sc.threads }
      ]
    });
    groups.push({
      label: 'Worker campaigns',
      items: [
        { href: '/buyer', label: 'Buyer hub', icon: 'megaphone' },
        { href: '/buyer/campaigns', label: 'Campaigns', icon: 'layers' },
        { href: '/buyer/drafts', label: 'Drafts', icon: 'edit' },
        { href: '/buyer/wallet', label: 'Campaign wallet', icon: 'card' }
      ]
    });
    groups.push({
      label: 'Account',
      items: [
        { href: '/profile', label: 'Profile', icon: 'user' },
        { href: '/notifications', label: 'Notifications', icon: 'bell', badge: state.counts.unread_notifications }
      ]
    });
    if (state.profile?.is_worker) {
      groups.push({ label: 'Switch', items: [{ label: 'Switch to worker', icon: 'target', mode: 'worker' }] });
    }
  } else {
    groups.push({
      label: 'Earn',
      items: [
        { href: '/dashboard', label: 'Earn home', icon: 'home' },
        { href: '/tasks', label: 'Tasks', icon: 'tasks', badge: state.counts.available_tasks },
        { href: '/smm-tasks', label: 'SMM tasks', icon: 'zap' },
        { href: '/my-tasks', label: 'My tasks', icon: 'checkCircle' },
        { href: '/leaderboard', label: 'Leaderboard', icon: 'trophy' },
        { href: '/achievements', label: 'Achievements', icon: 'star' },
        { href: '/analytics', label: 'Analytics', icon: 'chart' },
        { href: '/referrals', label: 'Referrals', icon: 'users' }
      ]
    });
    groups.push({
      label: 'Wallet',
      items: [
        { href: '/deposit', label: 'Deposit', icon: 'download' },
        { href: '/withdraw', label: 'Withdraw', icon: 'arrowUpRight' },
        { href: '/history', label: 'Transactions', icon: 'book' }
      ]
    });
    groups.push({
      label: 'Account',
      items: [
        { href: '/profile', label: 'Profile', icon: 'user' },
        { href: '/trust', label: 'Trust center', icon: 'shield' },
        { href: '/accounts', label: 'Linked accounts', icon: 'link' },
        { href: '/notifications', label: 'Notifications', icon: 'bell', badge: state.counts.unread_notifications },
        { href: '/announcements', label: 'Announcements', icon: 'megaphone' },
        { href: '/support', label: 'Support', icon: 'ticket' }
      ]
    });
    if (state.profile?.is_buyer) {
      groups.push({ label: 'Switch', items: [{ label: 'Switch to buyer', icon: 'megaphone', mode: 'buyer' }] });
    }
  }

  if (isAdmin()) {
    groups.push({
      label: 'Admin',
      items: [
        { href: '/admin', label: 'Overview', icon: 'grid' },
        { href: '/admin/proofs', label: 'Proofs', icon: 'shield', badge: state.counts.proofs_pending },
        { href: '/admin/social', label: 'Task accounts', icon: 'link' },
        { href: '/admin/campaigns', label: 'Campaigns', icon: 'layers' },
        { href: '/admin/tasks', label: 'Tasks', icon: 'tasks' },
        { href: '/admin/users', label: 'Users', icon: 'users' },
        { href: '/admin/support', label: 'Support', icon: 'ticket' },
        { href: '/admin/flags', label: 'Fraud', icon: 'flag' }
      ]
    });
    groups.push({
      label: 'Finance',
      items: [
        { href: '/admin/deposits', label: 'Deposits', icon: 'download' },
        { href: '/admin/withdrawals', label: 'Withdrawals', icon: 'wallet' },
        { href: '/admin/ledger', label: 'Ledger', icon: 'book' },
        { href: '/admin/referrals', label: 'Referrals', icon: 'gift' }
      ]
    });
    groups.push({
      label: 'Configuration',
      items: [
        { href: '/admin/services', label: 'Services', icon: 'sliders' },
        { href: '/admin/countries', label: 'Countries', icon: 'globe' },
        { href: '/admin/settings', label: 'Settings', icon: 'settings' },
        { href: '/admin/admins', label: 'Admins', icon: 'key' },
        { href: '/admin/audit', label: 'Audit log', icon: 'file' },
        { href: '/admin/notifications', label: 'Announcements', icon: 'megaphone' },
        { href: '/admin/telegram', label: 'Telegram', icon: 'telegram' },
        { href: '/admin/ai', label: 'AI assistant', icon: 'sparkles' }
      ]
    });
  }
  return groups;
}

function navItem(item, path) {
  /* Admin shell: a module the role has no permission for is shown as locked,
     never as a working link. */
  if (isAdmin() && currentPath().startsWith('/admin') && item.href) {
    const perm = adminPermForPath(item.href);
    if (perm && !hasPerm(perm)) {
      return `<span class="nav-item soon" aria-disabled="true" title="Your role does not include ${esc(perm)}">
        ${icon(item.icon, 18)}
        <span>${esc(item.label)}</span>
        <span class="nav-badge off-badge">no access</span>
      </span>`;
    }
  }

  if (item.mode) {
    return `<button class="nav-item" type="button" style="width:100%" data-mode-switch="${esc(item.mode)}">
      ${icon(item.icon, 18)}
      <span>${esc(item.label)}</span>
    </button>`;
  }

  const status = item.status || '';
  /* Module without a working backend page: visible, clearly disabled. */
  if (item.soon || status === 'coming_soon') {
    return `<span class="nav-item soon" aria-disabled="true" title="${esc(item.statusDetail || item.detail || 'Not available yet')}">
      ${icon(item.icon, 18)}
      <span>${esc(item.label)}</span>
      <span class="nav-badge soon-badge">soon</span>
    </span>`;
  }

  const flag = status === 'needs_config' ? '<span class="nav-badge setup-badge">setup</span>'
    : status === 'error' ? '<span class="nav-badge error-badge">error</span>'
      : status === 'disabled' ? '<span class="nav-badge off-badge">off</span>'
        : '';

  const active = path === item.href
    || (item.href !== '/dashboard' && item.href !== '/admin' && path.startsWith(item.href + '/'));
  return `<a class="nav-item ${active ? 'active' : ''}" href="#${item.href}"${item.switchView ? ' data-worker-tools="1"' : ''}${flag ? ` title="${esc(item.detail || '')}"` : ''}>
    ${icon(item.icon, 18)}
    <span>${esc(item.label)}</span>
    ${item.badge ? `<span class="nav-badge">${Number(item.badge) > 99 ? '99+' : Number(item.badge)}</span>` : ''}
    ${flag}
  </a>`;
}

function activeTab(path, tab) {
  if (tab.href === '/admin') return path === '/admin';
  return path === tab.href || path.startsWith(tab.href + '/');
}

/* Original TM GROW shell: fixed top navigation (logo pill, centre icons,
   bell / theme / avatar) and fixed bottom navigation (Home, Tasks, Wallet,
   Rank, Profile). Buyer mode keeps its own routes under the same chrome. */
function appShellHTML(meta) {
  const buyer = currentMode() === 'buyer';
  const path = currentPath();
  const unread = Number(state.counts.unread_notifications || 0);
  const home = buyer ? '/buyer' : '/dashboard';

  const centerLinks = buyer
    ? [
      { href: '/buyer', label: 'Dashboard', icon: 'grid' },
      { href: '/smm/services', label: 'Services', icon: 'layers' },
      { href: '/smm/orders', label: 'My orders', icon: 'book', badge: state.counts.pending_smm_orders },
      { href: '/support', label: 'Support', icon: 'ticket' },
      { href: '/buyer/wallet', label: 'Wallet', icon: 'wallet' }
    ]
    : [
      { href: '/dashboard', label: 'Home', icon: 'home' },
      { href: '/tasks', label: 'Tasks', icon: 'target', badge: state.counts.available_tasks },
      { href: '/referrals', label: 'Users', icon: 'users' },
      { href: '/leaderboard', label: 'Rank', icon: 'trophy' },
      { href: '/withdraw', label: 'Wallet', icon: 'wallet' }
    ];

  const tabs = buyer
    ? [
      { href: '/buyer', label: 'Home', icon: 'home' },
      { href: '/smm/services', label: 'Services', icon: 'layers' },
      { href: '/buyer/wallet', label: 'Wallet', icon: 'wallet' },
      { href: '/smm/orders', label: 'Orders', icon: 'book' },
      { href: '/profile', label: 'Profile', icon: 'user' }
    ]
    : [
      { href: '/dashboard', label: 'Home', icon: 'home' },
      { href: '/tasks', label: 'Tasks', icon: 'target' },
      { href: '/withdraw', label: 'Wallet', icon: 'wallet' },
      { href: '/leaderboard', label: 'Rank', icon: 'trophy' },
      { href: '/profile', label: 'Profile', icon: 'user' }
    ];

  const isActive = (href) => path === href
    || (href !== '/dashboard' && href !== '/buyer' && path.startsWith(href + '/'));
  const centerHTML = centerLinks.map((item) => `
      <a href="#${item.href}" class="${isActive(item.href) ? 'active' : ''}" title="${esc(item.label)}" aria-label="${esc(item.label)}">
        ${icon(item.icon, 21)}
        ${item.badge ? `<i class="topbar-badge">${Number(item.badge) > 99 ? '99+' : Number(item.badge)}</i>` : ''}
      </a>`).join('');
  const tabsHTML = tabs.map((t) => `
      <a href="#${t.href}" class="${isActive(t.href) ? 'active' : ''}"${isActive(t.href) ? ' aria-current="page"' : ''}>
        ${icon(t.icon, 22)}<span>${esc(t.label)}</span>
      </a>`).join('');
  const sidebarHTML = `<aside class="app-sidebar" aria-label="Sections">
      ${navGroups().map((g) => `
        <div class="app-sidebar-group">
          <div class="app-sidebar-label">${esc(g.label)}</div>
          ${g.items.map((i) => navItem(i, path)).join('')}
        </div>`).join('')}
    </aside>`;

  return `<div class="app-shell ${buyer ? 'is-buyer' : 'is-worker'}">
    ${sidebarHTML}
    <header class="app-topbar">
      <a class="tm-brand" href="#${home}" aria-label="TM GROW home">
        <span class="tm-pill">TM</span><span class="tm-word">GROW</span>
      </a>
      <nav class="topbar-center" aria-label="Primary">${centerHTML}</nav>
      <div class="topbar-actions">
        ${isAdmin() ? `<button class="topbar-icon" type="button" data-admin-panel aria-label="Admin panel" title="Admin panel">${icon('grid', 19)}</button>` : ''}
        <a class="topbar-icon has-dot" href="#/notifications" aria-label="Notifications${unread ? `, ${unread} unread` : ''}" title="Notifications">
          ${icon('bell', 19)}${unread ? '<i></i>' : ''}
        </a>
        <button class="topbar-icon" type="button" data-theme-toggle aria-label="Toggle theme" title="Toggle theme">
          ${icon(document.documentElement.dataset.theme === 'light' ? 'moon' : 'sun', 19)}
        </button>
        <button class="topbar-icon" type="button" data-open-menu aria-label="All sections" title="All sections">
          ${icon('menu', 19)}
        </button>
        <button class="topbar-avatar" type="button" data-account-menu aria-label="Account menu">
          <span class="avatar" data-avatar>${avatarInner(state.profile)}</span>
        </button>
      </div>
    </header>
    <main id="view" class="view app-view" tabindex="-1"></main>
    <nav class="app-tabbar" aria-label="Bottom navigation">${tabsHTML}</nav>
  </div>`;
}

function shellHTML(meta) {
  const path = currentPath();
  const adminShell = isAdmin() && path.startsWith('/admin');
  /* Body flag: lets modals (which mount outside the .shell container) pick up
     the admin glassmorphism layer without touching worker/buyer surfaces. */
  document.body.classList.toggle('admin-ui', adminShell);
  if (!adminShell) return appShellHTML(meta);
  const groups = adminNavGroups();
  const tabs = ADMIN_TABS;
  const unread = Number(state.counts.unread_notifications || 0);
  const name = displayName();
  const role = state.profile?.admin_role;
  const roleLabel = role
    ? role.replace('_', ' ')
    : currentMode() === 'buyer' ? 'Buyer account' : 'Worker account';
  const home = adminShell ? '/admin' : '/dashboard';

  const adminFoot = `<div class="wallet-mini">
      <div class="wm-label">Signed in as</div>
      <div class="wm-value" style="font-size:15px;letter-spacing:.8px">${esc(role || 'ADMIN')}</div>
      <div class="tiny dim truncate" style="margin-top:3px">${esc(state.profile?.email || '')}</div>
      <div class="wm-actions">
        <button class="btn btn-soft btn-sm" type="button" data-admin-signout>${icon('logout', 13)} Sign out</button>
        <a class="btn btn-ghost btn-sm" href="#/admin/system">System</a>
      </div>
    </div>
    <div class="user-chip" style="cursor:default">
      <span class="avatar" data-avatar>${avatarInner(state.profile)}</span>
      <span style="min-width:0">
        <span class="uc-name truncate" style="display:block">${esc(name)}</span>
        <span class="uc-role" style="display:block">${esc(roleLabel)}</span>
      </span>
    </div>`;

  const workerFoot = `<div class="wallet-mini">
      <div class="wm-label">Available balance</div>
      <div class="wm-value" data-wallet-available>${usdt(state.wallet?.available)} <span>USDT</span></div>
      <div class="wm-actions">
        <a class="btn btn-soft btn-sm" href="#/withdraw">${icon('arrowUpRight', 14)} Withdraw</a>
        <a class="btn btn-ghost btn-sm" href="#/deposit">Deposit</a>
      </div>
    </div>
    <a class="user-chip" href="#/profile">
      <span class="avatar" data-avatar>${avatarInner(state.profile)}</span>
      <span style="min-width:0">
        <span class="uc-name truncate" style="display:block">${esc(name)}</span>
        <span class="uc-role" style="display:block">${esc(roleLabel)}</span>
      </span>
    </a>`;

  return `<div class="shell">
    <aside class="sidebar">
      <a class="brand" href="#${home}">
        <span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span>
        <span>
          <span class="brand-name">TM GROW</span>
          <span class="brand-sub">${adminShell ? 'MASTER CONTROL' : 'Social task network'}</span>
        </span>
      </a>
      ${adminShell ? `<div class="admin-id">
        <span class="avatar" data-avatar>${avatarInner(state.profile)}</span>
        <span class="admin-id-text">
          <span class="admin-id-name truncate">${esc(name)}</span>
          <span class="admin-id-role"><span class="role-dot"></span>${esc(role || 'ADMIN')} · online</span>
        </span>
      </div>` : ''}
      <nav class="nav" aria-label="Main">
        ${groups.map((g) => `
          <div class="nav-label">${esc(g.label)}</div>
          ${g.items.map((i) => navItem(i, path)).join('')}
        `).join('')}
      </nav>
      <div class="sidebar-foot">
        ${adminShell ? adminFoot : workerFoot}
      </div>
    </aside>

    <div class="main">
      <header class="topbar">
        <div style="min-width:0">
          <div class="crumb"><span>Admin</span><span class="crumb-sep">/</span><span class="crumb-now">${esc(meta.title || 'Command Center')}</span></div>
          <span class="role-badge admin">${esc(roleLabel)} · MASTER ADMIN</span>
          ${maintenanceOn() ? `<span class="badge red" style="margin-left:6px">Maintenance ON</span>` : ''}
          <h1 class="truncate">${esc(meta.title || 'Master Command Center')}</h1>
          ${meta.sub ? `<div class="tb-sub truncate">${esc(meta.sub)}</div>` : ''}
        </div>
        <div class="topbar-actions">
          <div class="quick-actions">
            <a class="qa-btn" href="#/admin/proofs" title="Verification queue">${icon('shield', 15)}<span>${Number(state.counts.proofs_pending || 0)}</span></a>
            <a class="qa-btn" href="#/admin/deposits" title="Deposits">${icon('download', 15)}</a>
            <a class="qa-btn" href="#/admin/withdrawals" title="Withdrawals">${icon('wallet', 15)}</a>
            <a class="qa-btn" href="#/admin/support" title="Support">${icon('ticket', 15)}<span>${Number(state.counts.open_tickets || 0)}</span></a>
          </div>
          <button class="tb-icon admin-collapse-btn" type="button" data-admin-collapse aria-label="Collapse sidebar">${icon('menu', 18)}</button>
          <button class="tb-icon" type="button" data-theme-toggle aria-label="Toggle theme">${icon(document.documentElement.dataset.theme === 'light' ? 'moon' : 'sun', 18)}</button>
          <a class="tb-icon" href="#/admin/support" aria-label="Support inbox">${icon('ticket', 18)}</a>
          ${state.settings?.maintenance === true && canToggleMaintenance()
            ? `<button class="btn btn-danger btn-sm" type="button" data-maintenance-off>${icon('lock', 14)} Turn maintenance off</button>`
            : ''}
          <button class="btn btn-ghost btn-sm" type="button" data-admin-signout>${icon('logout', 15)} Sign out</button>
        </div>
      </header>
      ${!adminShell && state.profile?.withdrawals_blocked ? `<div class="alert info" style="margin:14px 20px 0">
        ${icon('lock', 17)}<div><strong>Withdrawals are temporarily restricted on this account.</strong> You can keep browsing and completing work, but new withdrawal requests and payouts are on hold. Contact support if this looks wrong.</div>
      </div>` : ''}
      <main id="view" class="view" tabindex="-1"></main>
    </div>

    <nav class="tabbar" aria-label="Mobile">
      ${tabs.map((t) => (t.action === 'menu'
        ? `<button type="button" data-open-menu aria-label="Open menu">
            ${icon(t.icon, 22)}
            <span>${esc(t.label)}</span>
          </button>`
        : `<a href="#${t.href}" class="${activeTab(path, t) ? 'active' : ''}">
            ${icon(t.icon, 22)}
            <span>${esc(t.label)}</span>
          </a>`)).join('')}
    </nav>
  </div>`;
}

function bindShell() {
  document.querySelectorAll('[data-open-menu]').forEach((button) => {
    button.addEventListener('click', () => {
      /* Desktop: the ≡ button collapses the sidebar (brief: collapsible
         sidebar). Mobile: it opens the drawer with every section. */
      if (window.matchMedia('(min-width: 1025px)').matches) {
        const on = document.body.classList.toggle('app-collapsed');
        try { localStorage.setItem('tmgrow-sidebar', on ? '1' : '0'); } catch (_) { /* ignore */ }
      } else {
        showMobileMenu();
      }
    });
  });
  /* Restore the saved collapse state before first paint of the shell. */
  try {
    if (window.matchMedia('(min-width: 1025px)').matches && localStorage.getItem('tmgrow-sidebar') === '1') {
      document.body.classList.add('app-collapsed');
    }
  } catch (_) { /* ignore */ }
  document.querySelectorAll('[data-account-menu]').forEach((button) => {
    button.addEventListener('click', () => showAccountMenu());
  });
  const themeBtn = document.querySelector('[data-theme-toggle]');
  if (themeBtn) themeBtn.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('tmgrow-theme', next); } catch (_) { /* ignore */ }
    themeBtn.innerHTML = icon(next === 'light' ? 'moon' : 'sun', 18);
    toast(next === 'light' ? 'Light theme on.' : 'Dark theme on.', 'success');
  });

  /* Admin sidebar collapse (desktop). Preference survives reloads. */
  const collapseKey = 'tmgrow-admin-collapsed';
  try {
    if (localStorage.getItem(collapseKey) === '1') document.body.classList.add('admin-collapsed');
  } catch (_) { /* ignore */ }
  const collapseBtn = document.querySelector('[data-admin-collapse]');
  if (collapseBtn) collapseBtn.addEventListener('click', () => {
    const on = document.body.classList.toggle('admin-collapsed');
    try { localStorage.setItem(collapseKey, on ? '1' : '0'); } catch (_) { /* ignore */ }
  });

  /* Admin identity: sign out from the panel shell itself. */
  document.querySelectorAll('[data-admin-signout]').forEach((b) => {
    b.addEventListener('click', () => signOut());
  });

  /* One-tap exit from maintenance for OWNER / SUPER_ADMIN, from any admin page. */
  document.querySelectorAll('[data-maintenance-off]').forEach((b) => {
    b.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Turn maintenance mode off?',
        message: 'The worker and buyer apps become available again immediately.',
        confirmLabel: 'Turn off'
      });
      if (!ok) return;
      setBusy(b, true, 'Saving');
      try {
        await rpc('admin_update_setting', { p_key: 'maintenance', p_value: false, p_is_public: true });
        await loadPublicData();
        hideMaintenance();
        toast('Maintenance mode is off.', 'success');
        refreshRoute();
      } catch (e) {
        toast(friendlyError(e), 'error', 6500);
        setBusy(b, false);
      }
    });
  });

  /* Explicit role switch: admin panel <-> worker tools. */
  document.querySelectorAll('[data-worker-tools]').forEach((a) => a.addEventListener('click', (e) => {
    e.preventDefault();
    setAdminWorkerView(true);
    navigate('/dashboard');
  }));

  const panelBtn = document.querySelector('[data-admin-panel]');
  if (panelBtn) panelBtn.addEventListener('click', () => {
    setAdminWorkerView(false);
    navigate('/admin');
  });

  /* Role switch: worker <-> buyer. The preference is stored on the profile, and
     each side is still authorized by is_worker / is_buyer in the database. */
  document.querySelectorAll('[data-mode-switch]').forEach((b) => {
    b.addEventListener('click', async () => {
      const mode = b.dataset.modeSwitch;
      b.disabled = true;
      try {
        await switchMode(mode);
        await loadContext();
        toast(mode === 'buyer' ? 'Buyer mode on.' : 'Worker mode on.', 'success');
        navigate(mode === 'buyer' ? '/buyer' : '/dashboard');
      } catch (e) {
        toast(friendlyError(e), 'error', 6000);
        b.disabled = false;
      }
    });
  });
}

function showMobileMenu() {
  const adminShell = isAdmin() && currentPath().startsWith('/admin');
  const groups = adminShell ? adminNavGroups() : navGroups();
  const links = groups.map((g) => `
    <div class="nav-label" style="padding:10px 4px 4px">${esc(g.label)}</div>
    ${g.items.map((i) => (i.mode
      ? `<button class="nav-item" type="button" style="width:100%" data-close-menu data-mode-switch="${esc(i.mode)}">
          ${icon(i.icon, 18)}<span>${esc(i.label)}</span>
        </button>`
      : (i.soon || i.status === 'coming_soon')
        ? `<span class="nav-item soon" aria-disabled="true" title="${esc(i.detail || 'Not available yet')}">
            ${icon(i.icon, 18)}<span>${esc(i.label)}</span>
            <span class="nav-badge soon-badge">soon</span>
          </span>`
        : `<a class="nav-item" href="#${i.href}" data-close-menu${i.switchView ? ' data-worker-tools="1"' : ''}>
          ${icon(i.icon, 18)}<span>${esc(i.label)}</span>
          ${i.badge ? `<span class="nav-badge">${Number(i.badge) > 99 ? '99+' : Number(i.badge)}</span>` : ''}
          ${i.status === 'needs_config' ? '<span class="nav-badge setup-badge">setup</span>'
            : i.status === 'error' ? '<span class="nav-badge error-badge">error</span>'
              : i.status === 'disabled' ? '<span class="nav-badge off-badge">off</span>' : ''}
        </a>`)).join('')}
  `).join('');
  const m = openModal({
    title: 'Menu',
    subtitle: 'TM GROW',
    body: `${links}
      <div class="divider"></div>
      <button class="nav-item" style="width:100%;color:var(--red)" type="button" data-sign-out>
        ${icon('logout', 18)}<span>Sign out</span>
      </button>`,
    wide: false
  });
  m.root.querySelectorAll('[data-close-menu]').forEach((a) => a.addEventListener('click', m.close));
  m.root.querySelectorAll('[data-worker-tools]').forEach((a) => a.addEventListener('click', () => setAdminWorkerView(true)));
  m.root.querySelectorAll('[data-mode-switch]').forEach((b) => b.addEventListener('click', async () => {
    const mode = b.dataset.modeSwitch;
    b.disabled = true;
    try {
      await switchMode(mode);
      await loadContext();
      m.close();
      toast(mode === 'buyer' ? 'Buyer mode on.' : 'Worker mode on.', 'success');
      navigate(mode === 'buyer' ? '/buyer' : '/dashboard');
    } catch (e) {
      toast(friendlyError(e), 'error', 6000);
      b.disabled = false;
    }
  }));
  m.root.querySelector('[data-sign-out]').addEventListener('click', () => { m.close(); signOut(); });
}

function showAccountMenu() {
  const walletLinks = currentMode() === 'buyer'
    ? `<a class="nav-item" href="#/buyer/wallet" data-close>${icon('wallet', 18)}<span>Buyer wallet</span></a>`
    : `<a class="nav-item" href="#/deposit" data-close>${icon('download', 18)}<span>Deposit</span></a>
       <a class="nav-item" href="#/withdraw" data-close>${icon('arrowUpRight', 18)}<span>Withdraw</span></a>`;
  const m = openModal({
    title: displayName(),
    subtitle: state.profile?.email || '',
    body: `
      <div class="row" style="gap:12px;margin-bottom:14px">
        ${avatarHTML(state.profile, 'avatar lg')}
        <div>
          <div class="strong">${esc(displayName())}</div>
          <div class="small muted">${esc(state.profile?.admin_role || (state.profile?.is_buyer ? 'Buyer' : 'Worker'))}</div>
        </div>
      </div>
      <a class="nav-item" href="#/profile" data-close>${icon('user', 18)}<span>Profile</span></a>
      <a class="nav-item" href="#/accounts" data-close>${icon('link', 18)}<span>Linked accounts</span></a>
      ${walletLinks}
      <a class="nav-item" href="#/support" data-close>${icon('ticket', 18)}<span>Support</span></a>
      ${state.profile?.is_buyer ? `<a class="nav-item" href="#/buyer" data-close>${icon('megaphone', 18)}<span>Buyer hub</span></a>` : `<button class="nav-item" style="width:100%" type="button" data-enable-buyer>${icon('megaphone', 18)}<span>Open buyer account</span></button>`}
      ${isAdmin() ? `<a class="nav-item" href="#/admin" data-close data-admin-panel>${icon('grid', 18)}<span>Admin panel</span></a>` : ''}
      <div class="divider"></div>
      <button class="nav-item" style="width:100%;color:var(--red)" type="button" data-sign-out>${icon('logout', 18)}<span>Sign out</span></button>`
  });
  m.root.querySelectorAll('[data-close]').forEach((a) => a.addEventListener('click', m.close));
  m.root.querySelector('[data-sign-out]').addEventListener('click', () => { m.close(); signOut(); });
  const enable = m.root.querySelector('[data-enable-buyer]');
  if (enable) {
    enable.addEventListener('click', async () => {
      enable.disabled = true;
      try {
        const { rpc } = await import('./lib/sb.js');
        await rpc('enable_buyer_mode');
        await loadContext();
        m.close();
        toast('Buyer account enabled.', 'success');
        navigate('/buyer');
      } catch (e) {
        toast(friendlyError(e), 'error');
        enable.disabled = false;
      }
    });
  }
}

export function syncShell() {
  document.querySelectorAll('[data-wallet-available]').forEach((el) => {
    el.innerHTML = `${usdt(state.wallet?.available)} <span>USDT</span>`;
  });
  document.querySelectorAll('[data-avatar]').forEach((el) => {
    el.innerHTML = avatarInner(state.profile);
  });
}

async function signOut() {
  try { await sb.auth.signOut(); } catch (_) { /* ignore */ }
  resetState();
  setAdminWorkerView(false);
  toast('Signed out.', 'info');
  navigate('/');
}

/* Login history: the only session detail a browser can honestly report is its
   user agent. Stored per user, capped server-side, admin-only to read. */
let loginRecorded = false;
async function recordLoginOnce() {
  if (loginRecorded || !state.session) return;
  loginRecorded = true;
  try {
    await rpc('record_login_event', {
      p_user_agent: (typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown').slice(0, 300),
      p_platform: isTelegramMiniApp() ? 'telegram-mini-app' : 'web'
    });
  } catch (_) { /* older database without the RPC */ }
}

let ownerClaimDone = false;

/* Server-side identity: role, status and whether this verified JWT belongs to
   the configured owner. Used for diagnostics and for a safe repair button. */
async function loadIdentity() {
  try {
    state.identity = (await rpc('my_identity')) || null;
  } catch (_) {
    state.identity = null;
  }
  return state.identity;
}

function ownerAccountMatches() {
  const id = state.identity;
  return !!(id && (id.matches_owner_email === true || id.matches_owner_uid === true));
}

async function ensureOwnerAccess() {
  if (!state.session || state.isAdmin || ownerClaimDone) return false;
  ownerClaimDone = true;
  try {
    const res = await rpc('claim_owner');
    if (res?.ok) {
      await loadContext();
      await loadIdentity();
      return true;
    }
  } catch (_) { /* older database without the RPC: the access page explains the SQL */ }
  await loadIdentity();
  return false;
}

/* Landing screen by role. The database decides who is admin; this only maps
   the result to a module. */
function homeFor() {
  if (isAdmin()) return '/admin';
  if (currentMode() === 'buyer') return '/buyer';
  return '/dashboard';
}

/* Browser Telegram OIDC logins are identified by the stable "sub" claim. Copy
   it onto the profile once, so repeat logins map to the same account and the
   bot can message them. No email is required. */
let telegramLinkDone = false;
async function linkTelegramIdentity() {
  if (telegramLinkDone || !state.session) return;
  const provider = String(state.session.user?.app_metadata?.provider || '');
  if (!provider.includes('telegram')) return;
  telegramLinkDone = true;
  try {
    await rpc('link_telegram_identity');
    await loadContext();
  } catch (_) { /* RPC not installed yet, or identity already owned */ }
}

/* --------------------------------------------------------------- rendering */
function setupScreen(message) {
  appEl.innerHTML = `<div class="auth-wrap" style="grid-template-columns:1fr">
    <div class="auth-form-side">
      <div class="auth-card">
        <div class="brand" style="padding:0 0 18px"><span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span><span><span class="brand-name">TM GROW</span><span class="brand-sub">Setup required</span></span></div>
        <h1>Database setup needed</h1>
        <p class="auth-sub">The app loaded, but the TM GROW schema is not installed on this Supabase project yet.</p>
        ${errorPanel(message)}
        <div class="alert info mt-14">${icon('info', 17)}<div>Open the Supabase dashboard, go to <strong>SQL Editor</strong>, paste <strong>supabase/schema.sql</strong> from this project and run it once. Then reload this page.</div></div>
        <div class="row mt-18">
          <button class="btn btn-primary" type="button" data-reload>Reload</button>
          <button class="btn btn-ghost" type="button" data-setup-signout>Sign out</button>
        </div>
      </div>
    </div>
  </div>`;
  appEl.querySelector('[data-reload]').addEventListener('click', () => window.location.reload());
  appEl.querySelector('[data-setup-signout]').addEventListener('click', signOut);
}

function notFoundHTML() {  return `<div class="card card-pad center" style="padding:54px 24px;max-width:520px;margin:40px auto">
    <div class="empty-ic">${icon('search', 22)}</div>
    <h2 style="font-size:20px;margin-bottom:8px">Page not found</h2>
    <p class="muted small" style="margin-bottom:18px">The link may be old, or the page moved.</p>
    <a class="btn btn-primary" href="#/dashboard">Back to dashboard</a>
  </div>`;
}

/* --------------------------------------------------- maintenance screen --- */
function maintenanceOn() {
  return state.settings?.maintenance === true;
}

/* Roles that may always reach the Admin Panel during maintenance. This is only
   the display half of the rule: every admin RPC re-checks the role in the
   database, so a forged browser flag gains nothing. */
const MAINTENANCE_BYPASS_ROLES = ['OWNER', 'SUPER_ADMIN', 'ADMIN', 'MODERATOR', 'VERIFIER', 'SUPPORT', 'FINANCE'];

function maintenanceBypass() {
  if (!state.session) return false;
  const role = state.profile?.admin_role;
  if (!role || !MAINTENANCE_BYPASS_ROLES.includes(String(role))) return false;
  const status = state.profile?.status || 'active';
  return status === 'active';
}

/* OWNER/SUPER_ADMIN can also switch maintenance from inside the panel. */
function canToggleMaintenance() {
  return ['OWNER', 'SUPER_ADMIN'].includes(String(state.profile?.admin_role || ''));
}

function showMaintenance() {
  if (document.getElementById('mt-overlay')) return;

  const shortMsg = String(state.settings?.maintenance_short || 'TM GROW is currently undergoing scheduled maintenance to improve your experience. We expect services to be restored soon. Thank you for your patience!');
  const detail = String(state.settings?.maintenance_detail || '');
  const tz = String(state.settings?.maintenance_tz || 'Asia/Dhaka');
  const endRaw = String(state.settings?.maintenance_end_at || '');
  const endMs = endRaw ? new Date(endRaw).getTime() : 0;
  const fmt = (t) => (Number.isFinite(t) && t ? new Date(t).toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  }) + ' (' + tz + ')' : 'to be announced');

  const el = document.createElement('div');
  el.id = 'mt-overlay';
  el.className = 'mt-overlay mt2-overlay';
  el.innerHTML = `    ${!isTelegramMiniApp() ? `
    <div class="mt2-topbar">
      <button class="mt2-topbar-close" type="button" data-mt-close aria-label="Close">${icon('x', 15)}</button>
      <div class="mt2-topbar-brand"><strong>TM GROW</strong><small>${isTelegramMiniApp() ? 'mini app' : 'web'}</small></div>
      <span class="mt2-topbar-dots" aria-hidden="true"><i></i><i></i><i></i></span>
    </div>` : ''}
    <div class="mt2-card" role="status" aria-live="polite">
      <div class="mt2-logo-wrap">
        <div class="mt2-logo"><img src="/assets/logo.svg" alt="TM GROW" /></div>
        <div class="mt2-dots" aria-hidden="true"><i></i><i></i><i></i></div>
      </div>

      <h1 class="mt2-title">Scheduled Maintenance</h1>
      <p class="mt2-sub">${esc(String(state.settings?.maintenance_scope || 'all') === 'worker' ? 'TM GROW worker services are temporarily unavailable.' : state.settings?.maintenance_scope === 'buyer' ? 'The TM Grow SMM panel is temporarily unavailable.' : 'TM Grow is temporarily unavailable.')}</p>
      <div class="mt2-message">
        <p class="mt2-message-text">${esc(shortMsg)}</p>
        ${detail ? `<p class="mt2-message-detail">${esc(detail)}</p>` : ''}
      </div>

      <div class="mt2-count">
        <div class="mt2-count-label">Expected back</div>
        <div class="mt2-count-value">${esc(fmt(endMs))}</div>
        <div class="mt2-timer" data-mt-countdown>—</div>
        <div class="mt2-divider" aria-hidden="true"></div>
      </div>

      <div class="mt2-status">
        <span class="mt2-status-pill"><span class="mt2-status-dot" aria-hidden="true"></span>System maintenance in progress</span>
        <div class="mt2-status-pulse" aria-hidden="true"></div>
      </div>

      <button class="btn btn-block mt2-cta" type="button" data-mt-retry>
        <span class="mt2-spin" data-mt-spin hidden></span>
        <span data-mt-label>Try again</span>
      </button>
      ${state.session ? '<button class="btn btn-block mt-10 mt2-secondary" type="button" data-mt-out>Sign out</button>'
        : '<a class="btn btn-block mt-10 mt2-secondary" href="#/login">Admin sign in</a>'}

      <div class="mt2-actions">
        <button class="mt2-soft-action" type="button" data-tg-url="https://t.me/BTCsignal777">${icon('telegram', 15)} Contact support</button>
        <button class="mt2-soft-action" type="button" data-tg-url="https://t.me/Tmgrowglobal">${icon('users', 15)} Community</button>
      </div>
      <p class="mt2-foot">Your account, balances and tasks are untouched.</p>
    </div>`;

  document.body.appendChild(el);

  el.querySelectorAll('[data-tg-url]').forEach((b) => b.addEventListener('click', () => openTelegramUrl(b.dataset.tgUrl)));

  /* Real countdown from the database end time. When it reaches zero we re-read
     the public settings; if the server has not switched maintenance off yet we
     say "final checks" and poll again — never show a fake available state. */
  const cd = el.querySelector('[data-mt-countdown]');
  let timer = null;
  const tick = () => {
    if (!cd || !cd.isConnected) { if (timer) clearInterval(timer); return; }
    if (!endMs) { cd.textContent = '—'; return; }
    const left = Math.max(0, Math.floor((endMs - Date.now()) / 1000));
    if (left === 0) {
      cd.textContent = 'Final checks…';
      if (timer) clearInterval(timer);
      loadPublicData().then(() => {
        if (!maintenanceOn()) { hideMaintenance(); refreshRoute(); }
        else setTimeout(() => { if (document.getElementById('mt-overlay')) showMaintenanceRefresh(); }, 30000);
      }).catch(() => {});
      return;
    }
    const d = Math.floor(left / 86400);
    const h = Math.floor((left % 86400) / 3600);
    const m = Math.floor((left % 3600) / 60);
    const s = left % 60;
    cd.textContent = `${d > 0 ? d + 'd ' : ''}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };
  tick();
  timer = setInterval(tick, 1000);

  el.querySelector('[data-mt-retry]').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const label = btn.querySelector('[data-mt-label]');
    const spin = btn.querySelector('[data-mt-spin]');
    btn.disabled = true;
    btn.classList.add('busy');
    if (spin) spin.hidden = false;
    if (label) label.textContent = 'Checking';
    try {
      await loadPublicData();
      if (maintenanceOn() && !isAdmin()) {
        if (label) label.textContent = 'Still upgrading';
        toast('Still upgrading. We will reopen shortly.', 'info');
        return;
      }
      hideMaintenance();
      refreshRoute();
    } catch (_) {
      toast('Still offline. Try again in a moment.', 'error');
    } finally {
      if (btn.isConnected) {
        btn.disabled = false;
        btn.classList.remove('busy');
        if (spin) spin.hidden = true;
        if (label) label.textContent = 'Try again';
      }
    }
  });

  const out = el.querySelector('[data-mt-out]');
  if (out) out.addEventListener('click', signOut);

  /* Web top bar: dismiss the notice for two minutes with a silent re-check.
     If maintenance is still on afterwards, the screen returns on its own. */
  const closeBtn = el.querySelector('[data-mt-close]');
  if (closeBtn) closeBtn.addEventListener('click', () => {
    hideMaintenance();
    setTimeout(() => {
      loadPublicData().then(() => {
        if (maintenanceOn()) showMaintenance();
        else refreshRoute();
      }).catch(() => {});
    }, 2 * 60 * 1000);
  });
}

/* Re-enter the screen after a poll, keeping the countdown live. */
function showMaintenanceRefresh() {
  hideMaintenance();
  showMaintenance();
}

function hideMaintenance() {
  const el = document.getElementById('mt-overlay');
  if (el) el.remove();
}

/* ------------------------------------------------------------------ suspended */
function isSuspendedAccount() {
  const st = state.profile?.status;
  return st === 'suspended' || st === 'banned';
}

/* Full-screen status page. The database blocks the same operations, so hiding
   the app here is the presentation of an enforced rule, not the rule itself. */
function showSuspended() {
  hideMaintenance();
  document.getElementById('mt-overlay')?.remove();

  const p = state.profile || {};
  const banned = p.status === 'banned';
  const kind = p.suspension_kind || (banned ? 'permanent' : 'permanent');
  const temporary = kind === 'temporary';
  const kindLabel = banned
    ? 'Permanently suspended'
    : temporary ? 'Temporary suspension'
      : kind === 'under_review' ? 'Under investigation'
        : kind === 'restricted' ? 'Restricted account'
          : 'Permanent suspension';
  const fmt = (v) => (v ? new Date(v).toLocaleString() : null);

  appEl.innerHTML = `<div class="suspend-screen">
    <div class="suspend-card">
      <a class="brand" href="#/" style="padding:0 0 18px">
        <span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span>
        <span><span class="brand-name">TM GROW</span><span class="brand-sub">Account status</span></span>
      </a>

      <div class="suspend-icon" style="color:#f43f5e;background:rgba(244,63,94,.1);border-color:rgba(244,63,94,.35)">${icon('lock', 30)}</div>
      <h1>${banned ? 'ACCOUNT BANNED' : 'ACCOUNT SUSPENDED'}</h1>
      <p class="suspend-lede">${banned
        ? 'This TM GROW account has been permanently closed for a policy violation.'
        : 'Your TM GROW account has been temporarily suspended.'}</p>

      <div class="suspend-grid">
        <div><span>Status</span><strong>${esc(banned ? 'Permanently suspended' : 'Temporary suspension')}</strong></div>
        <div><span>Account</span><strong class="truncate">${esc(p.email || '')}</strong></div>
        <div><span>Reason</span><strong>${esc(p.suspension_reason || 'Spam or fraudulent activity')}</strong></div>
      </div>

      <div class="suspend-actions">
        <button class="btn btn-primary btn-block" type="button" data-tg-url="https://t.me/BTCsignal777">
          Contact Admin on Telegram
        </button>
        <button class="btn btn-ghost btn-block mt-10" type="button" data-tg-url="https://t.me/Tmgrowglobal">
          Join Global Community
        </button>
      </div>

      <button class="btn btn-ghost btn-block mt-14" type="button" data-susp-logout>${icon('logout', 15)} Logout</button>

      <p class="tiny dim mt-14">Your wallet balance and transaction history are preserved. TM GROW never takes funds because of a suspension; withdrawals stay frozen until the account is restored.</p>
    </div>
  </div>`;

  const logout = appEl.querySelector('[data-susp-logout]');
  if (logout) logout.addEventListener('click', () => signOut());

  appEl.querySelectorAll('[data-tg-url]').forEach((b) => b.addEventListener('click', () => {
    openTelegramUrl(b.dataset.tgUrl);
  }));
}

/* ---------------------------------------------------- admin access pages --- */
async function renderAdminDenied() {
  const ident = state.identity || await loadIdentity();
  const uid = ident?.uid || state.session?.user?.id || '';
  const email = ident?.profile_email || state.profile?.email || ident?.jwt_email || '';
  const role = ident?.admin_role ?? state.profile?.admin_role ?? null;
  const status = ident?.status || state.profile?.status || 'unknown';
  const ownerEmail = ident?.owner_email_configured || '';
  const ownerUid = ident?.owner_user_id_configured || '';
  const matches = !!(ident?.matches_owner_email || ident?.matches_owner_uid);

  const sql = uid
    ? `update public.profiles set admin_role = 'OWNER', status = 'active', is_suspended = false where id = '${uid}';`
    : '';

  appEl.innerHTML = shellHTML({ title: 'Access denied', sub: 'Administrator only' });
  bindShell();
  const view = document.getElementById('view');
  view.innerHTML = `<div class="card card-pad" style="max-width:640px;margin:26px auto;padding:30px 22px">
      <div class="empty-ic">${icon('shield', 22)}</div>
      <h2 style="font-size:19px;margin-bottom:6px;text-align:center">Admin access required</h2>
      <p class="muted small" style="margin-bottom:16px;text-align:center">This account has no active admin role in the database, so the panel is not loaded. Nothing is judged from the browser.</p>

      <div class="susp-grid" style="margin-bottom:16px">
        <div class="susp-row"><span>Signed in as</span><strong class="truncate">${esc(email || 'unknown')}</strong></div>
        <div class="susp-row"><span>Auth user id</span><strong class="mono tiny truncate">${esc(uid || '—')}</strong></div>
        <div class="susp-row"><span>Admin role</span><strong>${esc(role || 'none')}</strong></div>
        <div class="susp-row"><span>Profile status</span><strong>${esc(String(status))}</strong></div>
        <div class="susp-row"><span>Configured owner email</span><strong class="truncate">${esc(ownerEmail || 'not set')}</strong></div>
        <div class="susp-row"><span>Configured owner user id</span><strong class="truncate">${esc(ownerUid || 'not set')}</strong></div>
        <div class="susp-row"><span>Matches configured owner</span><strong>${matches ? 'yes' : 'no'}</strong></div>
      </div>

      ${matches
        ? `<button class="btn btn-primary btn-block" type="button" data-owner-repair>${icon('shield', 15)} Grant my OWNER access server-side</button>
           <p class="tiny dim mt-10">This calls <span class="mono">claim_owner()</span>, which the database accepts only for the configured owner. It cannot be used by another account.</p>`
        : `<p class="small muted">This signed-in account is not the configured owner. Sign in with the owner account, or make this account the owner on purpose:</p>
           <div class="mono-box mt-10" style="white-space:pre-wrap;word-break:break-word;line-height:1.6;font-size:12px">${esc(sql || 'Sign in first to get the auth user id.')}</div>
           <button class="btn btn-soft btn-sm mt-10" type="button" data-copy-owner-sql>${icon('copy', 14)} Copy SQL</button>`}

      <div class="row-wrap mt-18">
        <button class="btn btn-ghost" type="button" data-copy-identity>${icon('copy', 14)} Copy identity</button>
        <button class="btn btn-ghost" type="button" data-reload-app>${icon('refresh', 14)} Reload app</button>
        <a class="btn btn-ghost" href="#/dashboard">Back to dashboard</a>
      </div>
      <p class="tiny dim mt-12">If the row above already says OWNER but this page still appears, the auth helper functions are an older definition. Run <span class="mono">supabase/access-repair.sql</span> (re-creates <span class="mono">is_admin()</span>, <span class="mono">has_admin_role()</span>, <span class="mono">admin_role()</span> and <span class="mono">my_context()</span>), then reload.</p>
    </div>`;

  const repair = view.querySelector('[data-owner-repair]');
  if (repair) repair.addEventListener('click', () => repairOwnerAccess(repair));
  const copySql = view.querySelector('[data-copy-owner-sql]');
  if (copySql) copySql.addEventListener('click', async () => {
    const ok = await copyText(sql);
    toast(ok ? 'SQL copied. Paste it in Supabase → SQL Editor and run it.' : 'Copy failed — select the SQL manually.',
      ok ? 'success' : 'error', 7000);
  });
  view.querySelector('[data-copy-identity]').addEventListener('click', async () => {
    const ok = await copyText(JSON.stringify({
      uid, email, role, status, owner_email: ownerEmail, owner_user_id: ownerUid, matches
    }, null, 2));
    toast(ok ? 'Identity copied.' : 'Copy failed.', ok ? 'success' : 'error');
  });
  view.querySelector('[data-reload-app]').addEventListener('click', () => window.location.reload());
}

/* The configured owner, but the profile is not an active OWNER. Never show the
   worker dashboard in this state: offer the server-side repair. */
function showOwnerAccountIssue() {
  const ident = state.identity || {};
  const uid = ident.uid || state.session?.user?.id || '';
  const email = ident.profile_email || state.profile?.email || ident.jwt_email || '';
  const role = ident.admin_role ?? state.profile?.admin_role ?? null;
  const status = ident.status || state.profile?.status || 'unknown';
  const sql = uid
    ? `update public.profiles set admin_role = 'OWNER', status = 'active', is_suspended = false where id = '${uid}';`
    : '';

  appEl.innerHTML = `<div class="suspend-screen">
    <div class="suspend-card">
      <div class="suspend-icon">${icon('shield', 28)}</div>
      <h1>OWNER ACCESS NOT ACTIVE</h1>
      <p class="suspend-lede">This is the configured TM GROW owner account, but its profile is not an active OWNER right now, so the Master Admin Panel cannot be opened.</p>

      <div class="suspend-grid">
        <div class="susp-row"><span>Account</span><strong class="truncate">${esc(email || 'unknown')}</strong></div>
        <div class="susp-row"><span>Auth user id</span><strong class="mono tiny truncate">${esc(uid || '—')}</strong></div>
        <div class="susp-row"><span>Admin role</span><strong>${esc(role || 'none')}</strong></div>
        <div class="susp-row"><span>Status</span><strong>${esc(String(status))}</strong></div>
      </div>

      <button class="btn btn-primary btn-block" type="button" data-owner-repair>${icon('shield', 15)} Repair OWNER access</button>
      <div class="row-wrap mt-10" style="justify-content:center">
        <button class="btn btn-ghost btn-sm" type="button" data-copy-owner-sql>${icon('copy', 14)} Copy SQL</button>
        <button class="btn btn-ghost btn-sm" type="button" data-owner-logout>${icon('logout', 14)} Logout</button>
      </div>
      <p class="tiny dim mt-14">Repair calls <span class="mono">claim_owner()</span>. The server grants OWNER only to the configured owner email or user id and records an audit row.</p>
    </div>
  </div>`;

  appEl.querySelector('[data-owner-repair]').addEventListener('click', (e) => repairOwnerAccess(e.currentTarget));
  appEl.querySelector('[data-copy-owner-sql]').addEventListener('click', async () => {
    const ok = await copyText(sql || 'Sign in first.');
    toast(ok ? 'SQL copied.' : 'Copy failed.', ok ? 'success' : 'error');
  });
  appEl.querySelector('[data-owner-logout]').addEventListener('click', signOut);
}

async function repairOwnerAccess(btn) {
  setBusy(btn, true, 'Checking');
  try {
    const res = await rpc('claim_owner');
    if (res?.ok) {
      ownerClaimDone = true;

      /* A fresh token plus a fresh context: the role lives in the database, and
         all admin RPCs re-check it, so the session must be re-read here. */
      try { await sb.auth.refreshSession(); } catch (_) { /* ignore */ }
      await loadContext();
      await loadIdentity();

      if (!state.isAdmin) {
        toast('The role is saved in the database, but my_context() still reports a non-admin profile. Run supabase/access-repair.sql (it re-creates is_admin, my_context and the debug RPC), then reload.', 'error', 12000);
        setBusy(btn, false);
        return;
      }

      setAdminWorkerView(false);
      toast('OWNER access confirmed. Opening the panel…', 'success');
      navigate('/admin', { replace: true });
      refreshRoute();
      return;
    }
    toast(`The database refused the claim: ${res?.reason || 'unknown reason'}.`, 'error', 9000);
    setBusy(btn, false);
  } catch (e) {
    toast(friendlyError(e), 'error', 9000);
    setBusy(btn, false);
  }
}

async function handleRoute({ path, route, params, meta }) {
  console.log('[tmgrow:route]', path, route ? 'matched' : 'NO ROUTE');

  if (!route) {
    /* Defensive fallback: if /tasks/:id ever fails to match (stale cache, older
       route table), render the task page anyway instead of silently bouncing
       back to the dashboard. */
    const taskMatch = path.match(/^\/tasks\/([^/]+)$/);
    if (taskMatch && state.session && !isAdmin() && currentMode() === 'buyer') {
      navigate('/buyer', { replace: true });
      return;
    }
    if (taskMatch && state.session) {
      appEl.innerHTML = shellHTML({ title: 'Task', sub: 'Task details' });
      bindShell();
      await renderTaskDetail(document.getElementById('view'), {
        params: { id: decodeURIComponent(taskMatch[1]) }
      });
      return;
    }
    navigate('/dashboard', { replace: true });
    return;
  }

  /* Suspended or banned accounts get the status screen on every route. The
     triggers in the database block the same operations, so this is display. */
  if (state.session && isSuspendedAccount()) {
    showSuspended();
    return;
  }

  /* Maintenance mode: visitors see the notice, but /login, /terms and the
     /admin routes stay reachable so an authorized admin can sign in and turn
     it off. Non-admin signed-in users are blocked further below. */
  if (maintenanceOn() && !state.session
      && !['/login', '/terms'].includes(path)
      && !path.startsWith('/admin')) {
    showMaintenance();
    return;
  }

  if (route.meta.public) {
    document.body.classList.remove('admin-ui');
    if (maintenanceOn() && state.session && !maintenanceBypass()
        && !['/login', '/terms'].includes(path)) {
      showMaintenance();
      return;
    }
    if (state.session && !isAdmin() && !['/login', '/terms'].includes(path)
        && ['suspended', 'banned'].includes(state.profile?.status)) {
      showSuspended();
      return;
    }
    hideMaintenance();
    try {
      await route.loader(appEl, { params });
    } catch (e) {
      appEl.innerHTML = `<div style="padding:30px">${errorPanel(friendlyError(e))}</div>`;
    }
    return;
  }

  if (!state.session) {
    rememberHash(path);
    navigate('/login', { replace: true });
    return;
  }

  if (!state.loaded) {
    if (state.loadError) { setupScreen(state.loadError); return; }
    try { await loadContext(); } catch (e) { setupScreen(friendlyError(e)); return; }
  }

  /* A configured owner whose profile has no role yet gets it from the server
     (verified JWT email), never from anything the browser sends. */
  if (!isAdmin()) await ensureOwnerAccess();

  /* Re-check after a fresh context load: the guard above runs before the
     profile is known on a cold start. */
  if (state.session && isSuspendedAccount()) {
    showSuspended();
    return;
  }

  /* Maintenance gate. A cold start can leave the cached role stale, so refresh
     the profile once before deciding; a real admin must never be locked out. */
  if (maintenanceOn() && state.session && !maintenanceBypass()) {
    try { await loadContext(); } catch (_) { /* keep the last known profile */ }
  }

  if (maintenanceOn() && !maintenanceBypass()) {
    showMaintenance();
    return;
  }
  hideMaintenance();

  /* Admins start in the panel, but an admin who explicitly opens worker tools
     may follow any worker route (tasks, task detail, my tasks). Only the
     dashboard itself is redirected when the switch was never used. */
  if (isAdmin() && path === '/dashboard' && !adminWorkerView()
      && !['/', '/login', '/terms'].includes(path)) {
    navigate('/admin', { replace: true });
    return;
  }

  /* The configured owner whose profile has no active role must never be shown
     the worker dashboard: show the repair screen instead. */
  if (!isAdmin() && ownerAccountMatches()) {
    showOwnerAccountIssue();
    return;
  }

  /* A buyer in buyer mode stays inside the buyer module (plus account/support).
     Worker earning pages are not the buyer's workspace. */
  if (!isAdmin() && currentMode() === 'buyer') {
    const allowedBuyer = path.startsWith('/buyer')
      || path.startsWith('/smm')
      || ['/profile', '/accounts', '/notifications', '/support', '/terms'].includes(path)
      || path.startsWith('/support/');
    if (!allowedBuyer) {
      navigate('/buyer', { replace: true });
      return;
    }
  }

  if (meta.admin && !isAdmin()) {
    await renderAdminDenied();
    return;
  }

  /* Deny-by-default on protected admin modules, whatever the URL. */
  if (meta.admin) {
    const perm = adminPermForPath(path);
    if (perm && !hasPerm(perm)) {
      appEl.innerHTML = shellHTML(meta);
      bindShell();
      document.getElementById('view').innerHTML = `<div class="card card-pad center" style="max-width:560px;margin:30px auto;padding:44px 22px">
        <div class="empty-ic">${icon('lock', 22)}</div>
        <h2 style="font-size:18px;margin-bottom:8px">Your role cannot open this page</h2>
        <p class="small muted">${esc(state.profile?.admin_role || 'This account')} does not have the <span class="mono">${esc(perm)}</span> permission. The server enforces the same rule, so calling the RPC directly is refused too.</p>
        <a class="btn btn-ghost mt-14" href="#/admin">Back to overview</a>
      </div>`;
      return;
    }
  }

  appEl.innerHTML = shellHTML(meta);
  bindShell();
  const view = document.getElementById('view');
  try {
    await route.loader(view, { params, meta, path });
  } catch (e) {
    view.innerHTML = `<div class="mt-10">${errorPanel(friendlyError(e))}</div>
      <div class="row mt-14"><button class="btn btn-ghost" type="button" onclick="location.reload()">Reload</button></div>`;
  }
  window.scrollTo({ top: 0, behavior: 'auto' });
}

/* ------------------------------------------------------- release update --
   Telegram keeps a Mini App's JS in its WebView cache. This compares the
   deployed version.json with the version bundled in this build and offers a
   hard reload, so a new release never stays invisible inside the bot. */
function showUpdateBar(next) {
  if (document.getElementById('update-bar')) return;
  const el = document.createElement('div');
  el.id = 'update-bar';
  el.className = 'update-bar';
  el.innerHTML = `<span>New version available${next ? ` · ${esc(next)}` : ''}</span>
    <button type="button" class="btn btn-sm btn-primary" data-update-reload>Reload</button>
    <button type="button" class="update-bar-x" data-update-close aria-label="Dismiss">×</button>`;
  document.body.appendChild(el);
  el.querySelector('[data-update-reload]').addEventListener('click', () => {
    location.replace(`${location.pathname}?fresh=${Date.now()}${location.hash}`);
  });
  el.querySelector('[data-update-close]').addEventListener('click', () => el.remove());
}

async function checkForUpdate() {
  try {
    const res = await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    if (data?.version && CONFIG.appVersion && data.version !== CONFIG.appVersion) {
      showUpdateBar(data.version);
    }
  } catch (_) { /* offline: keep the current build */ }
}

/* -------------------------------------------------------------------- boot */
let booted = false;

async function boot() {
  if (booted) return;
  booted = true;

  try {
    const stored = localStorage.getItem('tmgrow-theme');
    document.documentElement.dataset.theme = stored === 'light' ? 'light' : 'dark';
  } catch (_) {
    document.documentElement.dataset.theme = 'dark';
  }

  captureRefFromUrl();

  /* Inside a Telegram Mini App there is a verified identity from the start:
     exchange initData for a session before anything else runs. Outside
     Telegram (or when the function is not deployed yet) this is skipped and
     the normal Google / email sign-in screen is shown. */
  prepareTelegram();
  if (isTelegramMiniApp() && !state.session) {
    try {
      /* Never let a slow/undeployed Edge Function hold the whole app on the
         splash: 12 seconds, then fall through to the normal sign-in screen
         with the real reason. */
      await Promise.race([
        signInWithTelegram(sb),
        new Promise((_, reject) => setTimeout(
          () => reject(new Error('Telegram sign-in timed out: the telegram-auth function did not respond in time.')),
          12000
        ))
      ]);
      state.telegramError = null;
    } catch (e) {
      state.telegramError = telegramFriendlyError(e);
    }
  } else if (isTelegramEnvironment() && !telegramInitData() && !state.session) {
    /* Inside Telegram but the client gave us no signed initData: say so instead
       of quietly pretending the user is not in the Mini App. */
    state.telegramError = 'Telegram opened TM GROW without initData. Close the mini app and reopen it from the bot’s menu button.';
  }

  try {
    await loadSession();
    if (state.session) {
      try {
        await loadContext();
        await applyPendingUsername();
        await applyPendingReferral();
        await ensureOwnerAccess();
        await recordLoginOnce();
        await linkTelegramIdentity();
      } catch (e) {
        state.loadError = friendlyError(e);
      }
    }
  } catch (e) {
    state.loadError = friendlyError(e);
  }

  try { await loadPublicData(); } catch (_) { /* landing still renders */ }
  try { await loadFeatureStatus(); } catch (_) { /* migration not run yet */ }

  registerRoutes();

  sb.auth.onAuthStateChange(async (event, session) => {
    const had = !!state.session;
    state.session = session || null;
    if (event === 'SIGNED_IN' && session && !had) {
      try {
        await loadContext();
        await applyPendingUsername();
        await applyPendingReferral();
        await ensureOwnerAccess();
        await recordLoginOnce();
        await linkTelegramIdentity();
        await loadFeatureStatus();
      } catch (e) {
        state.loadError = friendlyError(e);
      }
      const remembered = takeRememberedHash();
      const home = homeFor();
      const target = remembered && !['/', '/login', '/dashboard'].includes(remembered)
        ? remembered
        : home;
      if (currentPath() === '/login') navigate(target, { replace: true });
      else if (isAdmin() && !currentPath().startsWith('/admin') && !adminWorkerView()) {
        navigate('/admin', { replace: true });
      } else refreshRoute();
    } else if (event === 'SIGNED_OUT') {
      resetState();
      setAdminWorkerView(false);
      if (!['/', '/login'].includes(currentPath())) navigate('/');
    }
  });

  startRouter((ctx) => {
    handleRoute(ctx).catch((e) => {
      console.error('[tmgrow:route-failed]', e);
      appEl.innerHTML = `<div style="padding:24px">${errorPanel(friendlyError(e))}</div>`;
    });
  });

  window.addEventListener('hashchange', () => {
    console.log('[tmgrow:hash]', window.location.hash);
  });

  const remembered = state.session ? takeRememberedHash() : '';
  if (remembered && remembered !== '/dashboard') {
    navigate(remembered, { replace: true });
  } else if (state.session) {
    /* The database role decides the landing module: OWNER/ADMIN → panel,
       buyer-only → buyer hub, everyone else → worker dashboard. */
    navigate(homeFor(), { replace: true });
  } else if (remembered) {
    navigate(remembered, { replace: true });
  } else if ((isTelegramMiniApp() || isTelegramEnvironment()) && currentPath() === '/') {
    navigate(state.session ? homeFor() : '/login', { replace: true });
  }

  checkForUpdate();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') checkForUpdate();
  });
  window.setInterval(checkForUpdate, 5 * 60 * 1000);
}

window.addEventListener('error', (e) => {
  console.error('[tmgrow]', e.error || e.message);
});

window.addEventListener('unhandledrejection', (e) => {
  console.error('[tmgrow] unhandled', e.reason);
});

boot().catch((e) => {
  console.error('[tmgrow] boot failed', e);
  appEl.innerHTML = `<div class="auth-wrap" style="grid-template-columns:1fr">
    <div class="auth-form-side">
      <div class="auth-card">
        <div class="brand" style="padding:0 0 18px"><span class="brand-mark"><img src="/assets/logo.svg" alt="TM GROW" /></span><span><span class="brand-name">TM GROW</span><span class="brand-sub">Startup failed</span></span></div>
        <h1>Could not start the app</h1>
        <p class="auth-sub">A script failed while the app was starting. The details are below.</p>
        ${errorPanel(e && e.message ? e.message : String(e))}
        <div class="row mt-18">
          <button class="btn btn-primary" type="button" onclick="window.location.reload()">Reload</button>
        </div>
      </div>
    </div>
  </div>`;
});
