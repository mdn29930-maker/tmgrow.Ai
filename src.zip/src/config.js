/* Global configuration. The publishable key is safe for the browser:
   all privileged work runs through SECURITY DEFINER RPCs + RLS. */
export const CONFIG = {
  supabaseUrl: 'https://uqynletitbcksggunubs.supabase.co',
  supabaseKey: 'sb_publishable_oR94QFQAvBWBSl_DgIn4_Q_QG5UNsyQ',
  brand: 'TM GROW',
  brandShort: 'TM',
  /* Bump with version.json whenever a release must reach Telegram WebViews. */
  appVersion: '2025-10-12-39',
  coin: 'TG Coin',
  coinSymbol: 'TG',
  network: 'BEP20',
  networkName: 'BNB Smart Chain (BEP-20)',
  fallbackWithdrawalMin: 2,
  proofBucket: 'proofs',
  claimMinutes: 30,
  pageSize: 25,
  supportEmailFallback: '',

  /* Sign-in: Telegram uses a Supabase custom OIDC provider with this
     identifier. The button calls it directly, so it starts working the moment
     the provider exists in Authentication → Providers. */
  telegramProvider: 'custom:telegram',

  /* Telegram Mini App sign-in: an Edge Function verifies initData with the bot
     token and returns a one-time token hash (see supabase/functions).
     The deployed route is case-sensitive and keeps its trailing hyphen. */
  telegramAuthFunction: 'Telegram-auth-',
  telegramAuthUrl: 'https://uqynletitbcksggunubs.supabase.co/functions/v1/Telegram-auth-',

  /* Deposits: shown on the deposit page and verified against the live chain. */
  depositAddress: '0xaa23b4c36b00a1edefb4b12449a472de56cb843f',
  usdtContract: '0x55d398326f99059fF775485246999027B3197955',
  depositConfirmations: 12,
  bscRpcs: [
    'https://bsc-dataseed.binance.org',
    'https://bsc-rpc.publicnode.com',
    'https://bsc-dataseed1.defibit.io',
    'https://1rpc.io/bnb'
  ]
};
